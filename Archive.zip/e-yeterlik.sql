--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."DanismanPersonelEksiklik" DROP CONSTRAINT IF EXISTS "DanismanPersonelEksiklik_BasvuruPersonelKimlik_fkey";
ALTER TABLE IF EXISTS ONLY public."CevreYonetimPersonelEksiklik" DROP CONSTRAINT IF EXISTS "CevreYonetimPersonelEksiklik_BasvuruPersonelKimlik_fkey";
ALTER TABLE IF EXISTS ONLY public."CevreYonetimBirimiPersonelTesis" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiPersonelTesis_TesisKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."CevreYonetimBirimiPersonelTesis" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiPersonelTesis_PersonelKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruEgitimEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruEgitimEksiklik_BasvuruEgitimKimlik_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruDeneyimEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruDeneyimEksiklik_BasvuruDeneyimKimlik_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruBelgeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruBelgeEksiklik_BasvuruBelgeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."DanismanPersonelEksiklik" DROP CONSTRAINT IF EXISTS "DanismanPersonelEksiklik_BasvuruPersonelKimlik_fkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."CevreYonetimPersonelEksiklik" DROP CONSTRAINT IF EXISTS "CevreYonetimPersonelEksiklik_BasvuruPersonelKimlik_fkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."CevreYonetimBirimiPersonelTesis" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiPersonelTesis_TesisKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."CevreYonetimBirimiPersonelTesis" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiPersonelTesis_PersonelKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."BasvuruEgitimEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruEgitimEksiklik_BasvuruEgitimKimlik_fkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."BasvuruDeneyimEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruDeneyimEksiklik_BasvuruDeneyimKimlik_fkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."BasvuruBelgeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruBelgeEksiklik_BasvuruBelgeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeOdeme" DROP CONSTRAINT IF EXISTS "Vize_VizeOdeme";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeBelge" DROP CONSTRAINT IF EXISTS "Vize_VizeBelge";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeAtama" DROP CONSTRAINT IF EXISTS "Vize_VizeAtama";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Vize" DROP CONSTRAINT IF EXISTS "Vize_Basvuru";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeOdemeEksiklik" DROP CONSTRAINT IF EXISTS "VizeOdeme_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeBelgeEksiklik" DROP CONSTRAINT IF EXISTS "VizeBelge_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelTalepIslemAtama" DROP CONSTRAINT IF EXISTS "TalepIslem_TalepIslemAtama";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelTalepIslem" DROP CONSTRAINT IF EXISTS "Personel_PersonelTalep";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelEksiklik" DROP CONSTRAINT IF EXISTS "Personel_PersonelEksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelEgitim" DROP CONSTRAINT IF EXISTS "Personel_PersonelEgitim";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelDeneyim" DROP CONSTRAINT IF EXISTS "Personel_PersonelDeneyim";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelBelge" DROP CONSTRAINT IF EXISTS "Personel_PersonelBege";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Personel" DROP CONSTRAINT IF EXISTS "Personel_BasvuruKimlik_fkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelEgitimEksiklik" DROP CONSTRAINT IF EXISTS "PersonelEgitim_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelDeneyimEksiklik" DROP CONSTRAINT IF EXISTS "PersonelDeneyim_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelBelgeEksiklik" DROP CONSTRAINT IF EXISTS "PersonelBelge_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Iptal" DROP CONSTRAINT IF EXISTS "Iptal_IptalTalep";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."IptalTalep" DROP CONSTRAINT IF EXISTS "Iptal_Basvuru";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanOdeme" DROP CONSTRAINT IF EXISTS "FirmaUnvan_FirmaUnvanOdeme";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanBelge" DROP CONSTRAINT IF EXISTS "FirmaUnvan_Belge";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanAtama" DROP CONSTRAINT IF EXISTS "FirmaUnvan_Atama";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanOdemeEksiklik" DROP CONSTRAINT IF EXISTS "FirmaUnvanOdeme_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik" DROP CONSTRAINT IF EXISTS "FirmaUnvanBelgeEksiklik_FirmaUnvanBelge";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresOdeme" DROP CONSTRAINT IF EXISTS "FirmaAdres_Odeme";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresBelge" DROP CONSTRAINT IF EXISTS "FirmaAdres_Belge";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresAtama" DROP CONSTRAINT IF EXISTS "FirmaAdres_Atama";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresOdemeEksiklik" DROP CONSTRAINT IF EXISTS "FirmaAdresOdeme_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresBelgeEksiklik" DROP CONSTRAINT IF EXISTS "FirmaAdresBelge_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Ceza" DROP CONSTRAINT IF EXISTS "Ceza_CezaTalep";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."AskiTalep" DROP CONSTRAINT IF EXISTS "Basvuru_askiTalep";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruReferansNo" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruReferans";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruOdeme" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruOdeme";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruEksiklik" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruEksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruBelge" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruBelge";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruAtama" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruAtama";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruOdemeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruOdeme_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruBelgeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruBelge_Eksiklik";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Aski" DROP CONSTRAINT IF EXISTS "AskiTalep_Aski";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Ğ";
DROP INDEX IF EXISTS "e-ced-yeterlik".fki_f;
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Vize_VizeOdeme";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Vize_VizeBelge";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Vize_VizeAtama";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Vize_Basvuru";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_VizeOdeme_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_VizeBelge_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_TalepIslem_TalepIslemAtama";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Personel_PersonelTalep";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Personel_PersonelEksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Personel_PersonelEgitim";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Personel_PersonelBege";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Personel_Basvuru";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_PersonelEgitim_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_PersonelDeneyim_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_PersonelBelge_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Iptal_IptalTalep";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Iptal_Basvuru";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaUnvan_FirmaUnvanOdeme";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaUnvan_Belge";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaUnvan_Atama";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaUnvanBelge_FirmaUnvanBelgeEksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaUnvanBelgeEksiklik_FirmaUnvanBelge";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaAdres_Odeme";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaAdres_Belge";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaAdres_Atama";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaAdresOdeme_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_FirmaAdresBelge_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Ceza_CezaTalep";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Basvuru_askiTalep";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Basvuru_BasvuruReferans";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Basvuru_BasvuruOdeme";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Basvuru_BasvuruEksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Basvuru_BasvuruBelge";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_Basvuru_BasvuruAtama";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_BasvuruOdeme_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_BasvuruBelge_Eksiklik";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_BasvuruAtama_Basvuru";
DROP INDEX IF EXISTS "e-ced-yeterlik"."fki_AskiTalep_Aski";
ALTER TABLE IF EXISTS ONLY public."TamZamanliPersonel" DROP CONSTRAINT IF EXISTS "TamZamanliPersonel_pkey";
ALTER TABLE IF EXISTS ONLY public."ReferansNumarasi" DROP CONSTRAINT IF EXISTS "ReferansNo_pkey";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY public."KisiBasvuru" DROP CONSTRAINT IF EXISTS "PK_Basvuru";
ALTER TABLE IF EXISTS ONLY public."Not" DROP CONSTRAINT IF EXISTS "Not_pkey";
ALTER TABLE IF EXISTS ONLY public."Belge" DROP CONSTRAINT IF EXISTS "KisiBelge_pkey";
ALTER TABLE IF EXISTS ONLY public."Egitim" DROP CONSTRAINT IF EXISTS "Egitim_pkey";
ALTER TABLE IF EXISTS ONLY public."Deneyim" DROP CONSTRAINT IF EXISTS "Deneyim_pkey";
ALTER TABLE IF EXISTS ONLY public."DanismanPersonelEksiklik" DROP CONSTRAINT IF EXISTS "DanismanPersonelEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."DanismanFirmaPersonel" DROP CONSTRAINT IF EXISTS "DanismanFirmaPersonel_pkey";
ALTER TABLE IF EXISTS ONLY public."DanismanFirmaBasvuru" DROP CONSTRAINT IF EXISTS "DanismanFirmaBasvuru_pkey";
ALTER TABLE IF EXISTS ONLY public."CevreYonetimPersonel" DROP CONSTRAINT IF EXISTS "CevreYonetimiPersonel_pkey";
ALTER TABLE IF EXISTS ONLY public."CevreYonetimPersonelEksiklik" DROP CONSTRAINT IF EXISTS "CevreYonetimPersonelEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."CevreYonetimBirimiTesis" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiTesis_pkey";
ALTER TABLE IF EXISTS ONLY public."CevreYonetimBirimiPersonelTesis" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiPersonelTesis_pkey";
ALTER TABLE IF EXISTS ONLY public."CevreYonetimBirimiBasvuru" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiBasvuru_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruEgitimEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruEgitimEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruDeneyimEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruDeneyimEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruBelgeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruBelgeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."BakanlikPersonelOdeme" DROP CONSTRAINT IF EXISTS "BakanlikPersonelOdeme_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."TamZamanliPersonel" DROP CONSTRAINT IF EXISTS "TamZamanliPersonel_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."ReferansNumarasi" DROP CONSTRAINT IF EXISTS "ReferansNo_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."KisiBasvuru" DROP CONSTRAINT IF EXISTS "PK_Basvuru";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."Not" DROP CONSTRAINT IF EXISTS "Not_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."Belge" DROP CONSTRAINT IF EXISTS "KisiBelge_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."Egitim" DROP CONSTRAINT IF EXISTS "Egitim_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."Deneyim" DROP CONSTRAINT IF EXISTS "Deneyim_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."DanismanPersonelEksiklik" DROP CONSTRAINT IF EXISTS "DanismanPersonelEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."DanismanFirmaPersonel" DROP CONSTRAINT IF EXISTS "DanismanFirmaPersonel_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."DanismanFirmaBasvuru" DROP CONSTRAINT IF EXISTS "DanismanFirmaBasvuru_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."CevreYonetimPersonel" DROP CONSTRAINT IF EXISTS "CevreYonetimiPersonel_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."CevreYonetimPersonelEksiklik" DROP CONSTRAINT IF EXISTS "CevreYonetimPersonelEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."CevreYonetimBirimiTesis" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiTesis_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."CevreYonetimBirimiPersonelTesis" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiPersonelTesis_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."CevreYonetimBirimiBasvuru" DROP CONSTRAINT IF EXISTS "CevreYonetimBirimiBasvuru_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."BasvuruEgitimEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruEgitimEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."BasvuruDeneyimEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruDeneyimEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."BasvuruBelgeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruBelgeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-yeterlik"."BakanlikPersonelOdeme" DROP CONSTRAINT IF EXISTS "BakanlikPersonelOdeme_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Vize" DROP CONSTRAINT IF EXISTS "Vize_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeOdeme" DROP CONSTRAINT IF EXISTS "VizeOdeme_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeOdemeEksiklik" DROP CONSTRAINT IF EXISTS "VizeOdemeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeBelge" DROP CONSTRAINT IF EXISTS "VizeBelge_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeBelgeEksiklik" DROP CONSTRAINT IF EXISTS "VizeBelgeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."VizeAtama" DROP CONSTRAINT IF EXISTS "VizeAtama_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."SektorCED" DROP CONSTRAINT IF EXISTS "SektorCED_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelTalepIslem" DROP CONSTRAINT IF EXISTS "PersonelTalepIslem_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelTalepIslemAtama" DROP CONSTRAINT IF EXISTS "PersonelTalepIslemAtama_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelGecmis" DROP CONSTRAINT IF EXISTS "PersonelLog_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelEksiklik" DROP CONSTRAINT IF EXISTS "PersonelEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelEgitim" DROP CONSTRAINT IF EXISTS "PersonelEgitim_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelEgitimGecmis" DROP CONSTRAINT IF EXISTS "PersonelEgitimLog_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelEgitimEksiklik" DROP CONSTRAINT IF EXISTS "PersonelEgitimEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelDeneyim" DROP CONSTRAINT IF EXISTS "PersonelDeneyim_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelDeneyimGecmis" DROP CONSTRAINT IF EXISTS "PersonelDeneyimLog_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelDeneyimEksiklik" DROP CONSTRAINT IF EXISTS "PersonelDeneyimEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelBelge" DROP CONSTRAINT IF EXISTS "PersonelBelge_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelBelgeGecmis" DROP CONSTRAINT IF EXISTS "PersonelBelgeLog_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."PersonelBelgeEksiklik" DROP CONSTRAINT IF EXISTS "PersonelBelgeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Personel" DROP CONSTRAINT IF EXISTS "PK_YeterlikBasvuru";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."TestData" DROP CONSTRAINT IF EXISTS "PK_TestData";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Iptal" DROP CONSTRAINT IF EXISTS "Iptal_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."IptalTalep" DROP CONSTRAINT IF EXISTS "IptalTalep_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvan" DROP CONSTRAINT IF EXISTS "FirmaUnvan_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanOdeme" DROP CONSTRAINT IF EXISTS "FirmaUnvanOdeme_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanOdemeEksiklik" DROP CONSTRAINT IF EXISTS "FirmaUnvanOdemeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanBelge" DROP CONSTRAINT IF EXISTS "FirmaUnvanBelge_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik" DROP CONSTRAINT IF EXISTS "FirmaUnvanBelgeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaUnvanAtama" DROP CONSTRAINT IF EXISTS "FirmaUnvanAtama_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdres" DROP CONSTRAINT IF EXISTS "FirmaAdres_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresOdeme" DROP CONSTRAINT IF EXISTS "FirmaAdresOdeme_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresOdemeEksiklik" DROP CONSTRAINT IF EXISTS "FirmaAdresOdemeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresBelge" DROP CONSTRAINT IF EXISTS "FirmaAdresBelge_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresBelgeEksiklik" DROP CONSTRAINT IF EXISTS "FirmaAdresBelgeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."FirmaAdresAtama" DROP CONSTRAINT IF EXISTS "FirmaAdresAtama_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Ceza" DROP CONSTRAINT IF EXISTS "Ceza_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."CezaTur" DROP CONSTRAINT IF EXISTS "CezaTur_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."CezaTalep" DROP CONSTRAINT IF EXISTS "CezaTalep_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Basvuru" DROP CONSTRAINT IF EXISTS "Basvuru_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruReferansNo" DROP CONSTRAINT IF EXISTS "BasvuruReferansNo_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruOdeme" DROP CONSTRAINT IF EXISTS "BasvuruOdeme_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruOdemeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruOdemeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruLog" DROP CONSTRAINT IF EXISTS "BasvuruLog_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruBelge" DROP CONSTRAINT IF EXISTS "BasvuruBelge_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruBelgeGecmis" DROP CONSTRAINT IF EXISTS "BasvuruBelgeLog_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruBelgeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruBelgeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."BasvuruAtama" DROP CONSTRAINT IF EXISTS "BasvuruAtama_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."Aski" DROP CONSTRAINT IF EXISTS "Aski_pkey";
ALTER TABLE IF EXISTS ONLY "e-ced-yeterlik"."AskiTalep" DROP CONSTRAINT IF EXISTS "AskiTalep_pkey";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS public."TamZamanliPersonel";
DROP TABLE IF EXISTS public."ReferansNumarasi";
DROP TABLE IF EXISTS public."Not";
DROP TABLE IF EXISTS public."KisiBasvuru";
DROP TABLE IF EXISTS public."Egitim";
DROP TABLE IF EXISTS public."Deneyim";
DROP TABLE IF EXISTS public."DanismanPersonelEksiklik";
DROP TABLE IF EXISTS public."DanismanFirmaPersonel";
DROP TABLE IF EXISTS public."DanismanFirmaBasvuru";
DROP TABLE IF EXISTS public."CevreYonetimPersonelEksiklik";
DROP TABLE IF EXISTS public."CevreYonetimPersonel";
DROP TABLE IF EXISTS public."CevreYonetimBirimiTesis";
DROP TABLE IF EXISTS public."CevreYonetimBirimiPersonelTesis";
DROP TABLE IF EXISTS public."CevreYonetimBirimiBasvuru";
DROP TABLE IF EXISTS public."Belge";
DROP TABLE IF EXISTS public."BasvuruEgitimEksiklik";
DROP TABLE IF EXISTS public."BasvuruDeneyimEksiklik";
DROP TABLE IF EXISTS public."BasvuruBelgeEksiklik";
DROP TABLE IF EXISTS public."BakanlikPersonelOdeme";
DROP TABLE IF EXISTS "e-yeterlik"."__EFMigrationsHistory";
DROP TABLE IF EXISTS "e-yeterlik"."TamZamanliPersonel";
DROP TABLE IF EXISTS "e-yeterlik"."ReferansNumarasi";
DROP TABLE IF EXISTS "e-yeterlik"."Not";
DROP TABLE IF EXISTS "e-yeterlik"."KisiBasvuru";
DROP TABLE IF EXISTS "e-yeterlik"."Egitim";
DROP TABLE IF EXISTS "e-yeterlik"."Deneyim";
DROP TABLE IF EXISTS "e-yeterlik"."DanismanPersonelEksiklik";
DROP TABLE IF EXISTS "e-yeterlik"."DanismanFirmaPersonel";
DROP TABLE IF EXISTS "e-yeterlik"."DanismanFirmaBasvuru";
DROP TABLE IF EXISTS "e-yeterlik"."CevreYonetimPersonelEksiklik";
DROP TABLE IF EXISTS "e-yeterlik"."CevreYonetimPersonel";
DROP TABLE IF EXISTS "e-yeterlik"."CevreYonetimBirimiTesis";
DROP TABLE IF EXISTS "e-yeterlik"."CevreYonetimBirimiPersonelTesis";
DROP TABLE IF EXISTS "e-yeterlik"."CevreYonetimBirimiBasvuru";
DROP TABLE IF EXISTS "e-yeterlik"."Belge";
DROP TABLE IF EXISTS "e-yeterlik"."BasvuruEgitimEksiklik";
DROP TABLE IF EXISTS "e-yeterlik"."BasvuruDeneyimEksiklik";
DROP TABLE IF EXISTS "e-yeterlik"."BasvuruBelgeEksiklik";
DROP TABLE IF EXISTS "e-yeterlik"."BakanlikPersonelOdeme";
DROP TABLE IF EXISTS "e-ced-yeterlik"."__EFMigrationsHistory";
DROP TABLE IF EXISTS "e-ced-yeterlik"."VizeOdemeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."VizeOdeme";
DROP TABLE IF EXISTS "e-ced-yeterlik"."VizeBelgeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."VizeBelge";
DROP TABLE IF EXISTS "e-ced-yeterlik"."VizeAtama";
DROP TABLE IF EXISTS "e-ced-yeterlik"."Vize";
DROP TABLE IF EXISTS "e-ced-yeterlik"."TestData";
DROP TABLE IF EXISTS "e-ced-yeterlik"."SektorCED";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelTalepIslemAtama";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelTalepIslem";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelGecmis";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelEgitimGecmis";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelEgitimEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelEgitim";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelDeneyimGecmis";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelDeneyimEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelDeneyim";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelBelgeGecmis";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelBelgeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."PersonelBelge";
DROP TABLE IF EXISTS "e-ced-yeterlik"."Personel";
DROP TABLE IF EXISTS "e-ced-yeterlik"."IptalTalep";
DROP TABLE IF EXISTS "e-ced-yeterlik"."Iptal";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaUnvanOdemeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaUnvanOdeme";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaUnvanBelge";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaUnvanAtama";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaUnvan";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaAdresOdemeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaAdresOdeme";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaAdresBelgeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaAdresBelge";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaAdresAtama";
DROP TABLE IF EXISTS "e-ced-yeterlik"."FirmaAdres";
DROP TABLE IF EXISTS "e-ced-yeterlik"."CezaTur";
DROP TABLE IF EXISTS "e-ced-yeterlik"."CezaTalep";
DROP TABLE IF EXISTS "e-ced-yeterlik"."Ceza";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruReferansNo";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruOdemeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruOdeme";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruLog";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruBelgeGecmis";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruBelgeEksiklik";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruBelge";
DROP TABLE IF EXISTS "e-ced-yeterlik"."BasvuruAtama";
DROP TABLE IF EXISTS "e-ced-yeterlik"."Basvuru";
DROP TABLE IF EXISTS "e-ced-yeterlik"."AskiTalep";
DROP TABLE IF EXISTS "e-ced-yeterlik"."Aski";
DROP SCHEMA IF EXISTS "e-yeterlik";
DROP SCHEMA IF EXISTS "e-ced-yeterlik";
--
-- Name: e-ced-yeterlik; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "e-ced-yeterlik";


--
-- Name: e-yeterlik; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "e-yeterlik";


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Aski; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."Aski" (
    "Kimlik" uuid NOT NULL,
    "AskiTalepKimlik" uuid,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "AskiBaslangic" timestamp without time zone,
    "AskiBitis" timestamp without time zone,
    "AskiKarar" text,
    "Uygunluk" integer,
    "SubeMudurKimlik" uuid,
    "EvrakKimlik" character varying
);


--
-- Name: AskiTalep; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."AskiTalep" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Aciklama" text,
    "UzmanKarar" text,
    "BasvuruKimlik" uuid,
    "IslemTur" text,
    "Onay" integer,
    "TalepEdenTur" integer,
    "AskiAlKaldirmaTalep" integer,
    "UzmanOnay" integer,
    "UzmanKimlik" uuid,
    "AskiTur" integer,
    "AskiTalepKimlik" uuid
);


--
-- Name: Basvuru; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."Basvuru" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "OnayGonder" integer,
    "OnayDurumu" integer,
    "EksiklikNotu" text,
    "FirmaKimlik" uuid,
    "SubeDurum" text,
    "BasvuruEksiklik" integer,
    "SubeMerkezDurum" integer,
    "BelgeSonGecerlilikTarih" timestamp without time zone,
    "BasvuruYon" integer,
    "SubeKimlik" uuid,
    "BasvuruNumara" text,
    "EvrakKimlik" character varying,
    "KurumAciklama" character varying,
    "UzmanAciklama" character varying,
    "SubeMudurAciklama" character varying,
    "OnayliBasvuruyaPersonelEkle" boolean
);


--
-- Name: BasvuruAtama; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruAtama" (
    "Kimlik" uuid NOT NULL,
    "BasvuruKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "AtamaDurum" text,
    "UzmanKimlik" uuid,
    "SubeMudurKimlik" uuid
);


--
-- Name: BasvuruBelge; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruBelge" (
    "Kimlik" uuid NOT NULL,
    "BelgeTur" integer,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UygunlukDurum" integer,
    "EksiklikNotu" text,
    "BasvuruKimlik" uuid NOT NULL
);


--
-- Name: BasvuruBelgeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruBelgeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruBelgeKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: BasvuruBelgeGecmis; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruBelgeGecmis" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "BasvuruKimlik" uuid NOT NULL,
    "Eski" text,
    "Yeni" text
);


--
-- Name: BasvuruEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruKimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "EskiVeri" character varying[],
    "YeniVeri" character varying[],
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text
);


--
-- Name: BasvuruLog; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruLog" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "OnayGonder" integer,
    "OnayDurumu" integer,
    "EksiklikNotu" text,
    "FirmaKimlik" uuid,
    "SubeDurum" text
);


--
-- Name: BasvuruOdeme; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruOdeme" (
    "Kimlik" uuid NOT NULL,
    "BasvuruKimlik" uuid NOT NULL,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "ReferansNo" text,
    "OdemeMiktar" double precision,
    "OdenmeDurum" boolean
);


--
-- Name: BasvuruOdemeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruOdemeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruOdemeKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: BasvuruReferansNo; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."BasvuruReferansNo" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "ReferansNumara" text,
    "BasvuruKimlik" uuid,
    "OdenmeDurum" boolean,
    "OdemeMıktar" double precision,
    "Tur" integer
);


--
-- Name: Ceza; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."Ceza" (
    "Kimlik" uuid NOT NULL,
    "CezaTalepKimlik" uuid,
    "Durum" integer,
    "Olusturulma" timestamp without time zone,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "SubeMudurKarar" text,
    "OnayDurum" integer
);


--
-- Name: CezaTalep; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."CezaTalep" (
    "Kimlik" uuid NOT NULL,
    "CezaTalepKimlik" uuid,
    "Durum" integer,
    "Olusturulma" timestamp without time zone,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "FirmaKimlik" uuid,
    "UzmanKimlik" uuid,
    "CezaTur" text,
    "CezaPuan" text,
    "Aciklama" text,
    "CezaTip" integer,
    "SubeMudurKimlik" uuid
);


--
-- Name: CezaTur; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."CezaTur" (
    "Kimlik" uuid NOT NULL,
    "Tur" text,
    "Puan" text,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone
);


--
-- Name: FirmaAdres; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaAdres" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturulma" timestamp without time zone,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "FirmaKimlik" uuid NOT NULL,
    "SubeKimlik" uuid,
    "OnayaGonder" integer,
    "OnayDurum" integer,
    "EksiklikDurum" integer,
    "BasvuruYon" integer,
    "BasvuruNo" text,
    "EksiklikNotu" text,
    "EvrakKimlik" character varying,
    "KurumAciklama" character varying,
    "UzmanAciklama" character varying,
    "SubeMudurAciklama" character varying
);


--
-- Name: FirmaAdresAtama; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaAdresAtama" (
    "Kimlik" uuid NOT NULL,
    "FirmaAdresKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UzmanKimlik" uuid,
    "SubeMudurKimlik" uuid
);


--
-- Name: FirmaAdresBelge; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaAdresBelge" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "BelgeTur" integer,
    "UygunlukDurum" integer,
    "EksiklikNotu" text,
    "FirmaAdresKimlik" uuid NOT NULL
);


--
-- Name: FirmaAdresBelgeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaAdresBelgeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "FirmaAdresBelgeKimlik" uuid,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: FirmaAdresOdeme; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaAdresOdeme" (
    "Kimlik" uuid NOT NULL,
    "FirmaAdresKimlik" uuid NOT NULL,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "ReferansNo" text,
    "OdemeMiktar" double precision,
    "OdenmeDurum" boolean
);


--
-- Name: FirmaAdresOdemeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaAdresOdemeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "FirmaAdresOdemeKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: FirmaUnvan; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaUnvan" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturulma" timestamp without time zone,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "FirmaKimlik" uuid NOT NULL,
    "SubeKimlik" uuid,
    "OnayaGonder" integer,
    "OnayDurum" integer,
    "EksiklikDurum" integer,
    "BasvuruYon" integer,
    "BasvuruNo" text,
    "EksiklikNotu" text,
    "EvrakKimlik" character varying,
    "KurumAciklama" character varying,
    "UzmanAciklama" character varying,
    "SubeMudurAciklama" character varying
);


--
-- Name: FirmaUnvanAtama; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaUnvanAtama" (
    "Kimlik" uuid NOT NULL,
    "FirmaUnvanKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UzmanKimlik" uuid,
    "SubeMudurKimlik" uuid
);


--
-- Name: FirmaUnvanBelge; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaUnvanBelge" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "BelgeTur" integer,
    "UygunlukDurum" integer,
    "EksiklikNotu" text,
    "FirmaUnvanKimlik" uuid NOT NULL
);


--
-- Name: FirmaUnvanBelgeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "FirmaUnvanBelgeKimlik" uuid,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: FirmaUnvanOdeme; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaUnvanOdeme" (
    "Kimlik" uuid NOT NULL,
    "FirmaUnvanKimlik" uuid NOT NULL,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "ReferansNo" text,
    "OdemeMiktar" double precision,
    "OdenmeDurum" boolean
);


--
-- Name: FirmaUnvanOdemeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."FirmaUnvanOdemeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "FirmaUnvanOdemeKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: Iptal; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."Iptal" (
    "Kimlik" uuid NOT NULL,
    "IptalTalepKimlik" uuid,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "IptalTarih" timestamp without time zone,
    "IptalKarar" text,
    "Uygunluk" integer,
    "SubeMudurKimlik" uuid,
    "EvrakKimlik" character varying
);


--
-- Name: IptalTalep; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."IptalTalep" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "BasvuruKimlik" uuid,
    "UzmanKarar" text,
    "UzmanOnay" integer,
    "Onay" integer,
    "SistemTarafindanTespit" integer,
    "IptalTur" integer,
    "UzmanKimlik" uuid
);


--
-- Name: Personel; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."Personel" (
    "Kimlik" uuid NOT NULL,
    "IsTecrube" integer NOT NULL,
    "FirmaUnvani" text NOT NULL,
    "Gorevi" text NOT NULL,
    "GirisTarihi" timestamp without time zone NOT NULL,
    "AyrilisTarihi" timestamp without time zone NOT NULL,
    "NihaiCEDRaporSayisi" integer NOT NULL,
    "PTDHazirlamaSayisi" integer NOT NULL,
    "Grubu" integer NOT NULL,
    "Durum" integer DEFAULT 0 NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    "Olusturulma" timestamp without time zone DEFAULT '-infinity'::timestamp with time zone NOT NULL,
    "Ad" text NOT NULL,
    "Soyad" text NOT NULL,
    "Meslek" text NOT NULL,
    "Universite" text,
    "TCKN" text NOT NULL,
    "BasvurudaKullanım" smallint NOT NULL,
    "UygunlukDurum" integer,
    "EksiklikNotu" text,
    "BasvuruKimlik" uuid NOT NULL,
    "MevcutGrubu" text,
    "Cinsiyet" integer,
    "DogumTarihi" timestamp without time zone,
    "DogumYeri" text,
    "Eposta" text,
    "DogumIznıBaslangic" timestamp without time zone,
    "DogumIznıBitis" timestamp without time zone,
    "CepTel" text
);


--
-- Name: PersonelBelge; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelBelge" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlik" uuid NOT NULL,
    "BelgeTur" integer,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UygunlukDurum" integer,
    "EksiklikNotu" text
);


--
-- Name: PersonelBelgeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelBelgeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "PersonelBelgeKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: PersonelBelgeGecmis; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelBelgeGecmis" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlik" uuid NOT NULL,
    "BelgeTur" integer,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UygunlukDurum" integer,
    "EksiklikNotu" text
);


--
-- Name: PersonelDeneyim; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelDeneyim" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlik" uuid NOT NULL,
    "DeneyimKimlik" uuid,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UygunlukDurum" integer,
    "EksiklikNotu" text,
    "KurumAdi" text,
    "Meslek" text,
    "IseGiris" timestamp without time zone,
    "IstenAyrilis" timestamp without time zone,
    "SicilNo" text
);


--
-- Name: PersonelDeneyimEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelDeneyimEksiklik" (
    "Kimlik" uuid NOT NULL,
    "PersonelDeneyimKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: PersonelDeneyimGecmis; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelDeneyimGecmis" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlik" uuid NOT NULL,
    "DeneyimKimlik" uuid,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UygunlukDurum" integer,
    "EksiklikNotu" text
);


--
-- Name: PersonelEgitim; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelEgitim" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlik" uuid NOT NULL,
    "EgitimKimlik" uuid,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UygunlukDurum" integer,
    "EksiklikNotu" text
);


--
-- Name: PersonelEgitimEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelEgitimEksiklik" (
    "Kimlik" uuid NOT NULL,
    "PersonelEgitimKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: PersonelEgitimGecmis; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelEgitimGecmis" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlik" uuid NOT NULL,
    "EgitimKimlik" uuid,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "UygunlukDurum" integer,
    "EksiklikNotu" text
);


--
-- Name: PersonelEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelEksiklik" (
    "Kimlik" uuid NOT NULL,
    "PersonelKimlik" uuid NOT NULL,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: PersonelGecmis; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelGecmis" (
    "Kimlik" uuid NOT NULL,
    "IsTecrube" integer NOT NULL,
    "FirmaUnvani" text NOT NULL,
    "Gorevi" text NOT NULL,
    "GirisTarihi" timestamp without time zone NOT NULL,
    "AyrilisTarihi" timestamp without time zone NOT NULL,
    "NihaiCEDRaporSayisi" integer NOT NULL,
    "PTDHazirlamaSayisi" integer NOT NULL,
    "Grubu" integer NOT NULL,
    "Durum" integer DEFAULT 0 NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Ad" text NOT NULL,
    "Soyad" text NOT NULL,
    "Meslek" text NOT NULL,
    "Universite" text,
    "TCKN" text NOT NULL,
    "BasvurudaKullanım" smallint NOT NULL,
    "UygunlukDurum" integer,
    "EksiklikNotu" text,
    "BasvuruKimlik" uuid NOT NULL
);


--
-- Name: PersonelTalepIslem; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelTalepIslem" (
    "Kimlik" uuid NOT NULL,
    "PersonelKimlik" uuid,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "TalepTuru" integer NOT NULL,
    "DogumBaslangic" timestamp without time zone,
    "DogumBitis" timestamp without time zone,
    "Ad" text,
    "Soyad" text,
    "DogumTarih" timestamp without time zone,
    "DogumYer" text,
    "Eposta" text,
    "Meslek" text,
    "IseGiris" timestamp without time zone,
    "IstenAyrilis" timestamp without time zone,
    "KurumdanAyrilma" integer,
    "YeterliktenAyrilma" integer,
    "Onay" integer,
    "OnayaGonder" integer,
    "Grup" integer,
    "UzmanOnay" integer,
    "EvrakKimlik" character varying
);


--
-- Name: PersonelTalepIslemAtama; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."PersonelTalepIslemAtama" (
    "Kimlik" uuid NOT NULL,
    "PersonelTalepIslemKimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "AtamaDurum" text,
    "UzmanKimlik" uuid,
    "SubeMudurKimlik" uuid
);


--
-- Name: SektorCED; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."SektorCED" (
    "Kimlik" uuid NOT NULL,
    "CEDRaporSayisi" integer,
    "Sektor" text,
    "KullaniciKimlik" integer,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone
);


--
-- Name: TestData; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."TestData" (
    "Id" uuid NOT NULL,
    "GeneralDataType" integer NOT NULL,
    "Key" text,
    "Description" text,
    "Value" text,
    "Unit" text
);


--
-- Name: Vize; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."Vize" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "VizeTarih" timestamp without time zone,
    "BasvuruKimlik" uuid,
    "OnayGonder" integer,
    "OnayDurum" integer,
    "EksiklikBildirim" integer,
    "EksiklikNot" text,
    "VizeBasvuruNumara" text,
    "BasvuruYon" integer,
    "EvrakKimlik" character varying,
    "KurumAciklama" character varying,
    "UzmanAciklama" character varying,
    "SubeMudurAciklama" character varying
);


--
-- Name: VizeAtama; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."VizeAtama" (
    "Kimlik" uuid NOT NULL,
    "VizeKimlik" uuid,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "AtamaDurum" text,
    "UzmanKimlik" uuid,
    "SubeMudurKimlik" uuid
);


--
-- Name: VizeBelge; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."VizeBelge" (
    "Kimlik" uuid NOT NULL,
    "VizeKimlik" uuid,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "BelgeTur" integer
);


--
-- Name: VizeBelgeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."VizeBelgeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "VizeBelgeKimlik" uuid,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: VizeOdeme; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."VizeOdeme" (
    "Kimlik" uuid NOT NULL,
    "VizeKimlik" uuid,
    "ReferansNumara" text,
    "Durum" integer,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "OdemeMiktar" double precision,
    "OdenmeDurum" boolean
);


--
-- Name: VizeOdemeEksiklik; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."VizeOdemeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "VizeOdemeKimlik" uuid,
    "Durum" integer,
    "Olusturan" uuid,
    "Olusturulma" timestamp without time zone,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EksiklikDurum" integer,
    "UygunlukDurum" integer,
    "UygunlukNot" text,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: e-ced-yeterlik; Owner: -
--

CREATE TABLE "e-ced-yeterlik"."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Name: BakanlikPersonelOdeme; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."BakanlikPersonelOdeme" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BakanlikAdi" character varying,
    "Birimi" character varying,
    "Gorevi" character varying,
    "Aciklama" character varying,
    "BakanlikTuru" integer NOT NULL,
    "KullaniciKimlikRef" uuid
);


--
-- Name: BasvuruBelgeEksiklik; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."BasvuruBelgeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruBelgeKimlikRef" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "BelgeBasvuruTuru" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: BasvuruDeneyimEksiklik; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."BasvuruDeneyimEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruDeneyimKimlik" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: BasvuruEgitimEksiklik; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."BasvuruEgitimEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruEgitimKimlik" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: Belge; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."Belge" (
    "Kimlik" uuid NOT NULL,
    "BelgeKimlikRef" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "KullaniciKimlikRef" uuid NOT NULL,
    "BelgeTipi" character varying,
    "DosyaAdi" character varying
);


--
-- Name: CevreYonetimBirimiBasvuru; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."CevreYonetimBirimiBasvuru" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "FirmaTipi" integer NOT NULL,
    "BasvuruDurum" integer NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "UzmanKimlikRef" uuid,
    "OnaylanmaTarihi" timestamp without time zone,
    "BeyanDurumu" boolean,
    "BeyanTarihi" timestamp without time zone,
    "EvrakId" character varying,
    "BelgeTarihi" character varying
);


--
-- Name: CevreYonetimBirimiPersonelTesis; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."CevreYonetimBirimiPersonelTesis" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "PersonelKimlikRef" uuid NOT NULL,
    "TesisKimlikRef" uuid NOT NULL,
    "CevreYonetimBirimiKimlikRef" uuid NOT NULL
);


--
-- Name: CevreYonetimBirimiTesis; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."CevreYonetimBirimiTesis" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "TesisCevreKimlikNo" character varying NOT NULL,
    "FirmaCevreKimlikNo" character varying NOT NULL,
    "VergiNo" character varying NOT NULL,
    "FirmaKimlikRef" uuid NOT NULL,
    "TesisKimlikRef" uuid NOT NULL,
    "FirmaUnvani" character varying NOT NULL,
    "TesisAdi" character varying NOT NULL
);


--
-- Name: CevreYonetimPersonel; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."CevreYonetimPersonel" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "CalismaDurumu" integer NOT NULL,
    "Unvan" character varying NOT NULL,
    "Bolum" character varying NOT NULL,
    "CalismaSuresi" integer NOT NULL,
    "IseGirisTarihi" timestamp without time zone NOT NULL,
    "Dosya" character varying,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "PersonelKimlikRef" uuid
);


--
-- Name: CevreYonetimPersonelEksiklik; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."CevreYonetimPersonelEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruPersonelKimlik" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: DanismanFirmaBasvuru; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."DanismanFirmaBasvuru" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "FirmaTipi" integer NOT NULL,
    "BasvuruDurum" integer NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "UzmanKimlikRef" uuid,
    "OnaylanmaTarihi" timestamp without time zone,
    "BeyanDurumu" boolean,
    "BeyanTarihi" timestamp without time zone,
    "EvrakId" character varying,
    "BelgeTarihi" character varying
);


--
-- Name: DanismanFirmaPersonel; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."DanismanFirmaPersonel" (
    "Kimlik" uuid NOT NULL,
    "DanismanFirmaKimlikRef" uuid NOT NULL,
    "CalismaDurumu" integer NOT NULL,
    "Unvan" character varying NOT NULL,
    "Bolum" character varying NOT NULL,
    "CalismaSuresi" integer NOT NULL,
    "IseGirisTarihi" timestamp without time zone NOT NULL,
    "Dosya" character varying,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "PersonelKimlikRef" uuid
);


--
-- Name: DanismanPersonelEksiklik; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."DanismanPersonelEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruPersonelKimlik" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: Deneyim; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."Deneyim" (
    "Kimlik" uuid NOT NULL,
    "Gorevi" character varying NOT NULL,
    "KurumAdi" character varying NOT NULL,
    "KurumAdresi" character varying NOT NULL,
    "IseGirisTarihi" timestamp without time zone NOT NULL,
    "IstenAyrilisTarihi" timestamp without time zone,
    "DevamDurumu" boolean NOT NULL,
    "DeneyimNotu" character varying,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "KullaniciKimlikRef" uuid NOT NULL
);


--
-- Name: Egitim; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."Egitim" (
    "Kimlik" uuid NOT NULL,
    "EgitimKimlikRef" uuid NOT NULL,
    "OnayDurumu" integer NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Derece" character varying,
    "KurumAdi" character varying,
    "BolumAdi" character varying,
    "MezuniyetTarihi" timestamp without time zone,
    "BasvuruSekli" integer,
    "FakulteAdi" character varying,
    "NotOrtalamasi" character varying
);


--
-- Name: KisiBasvuru; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."KisiBasvuru" (
    "Kimlik" uuid NOT NULL,
    "BasvuruSekli" integer NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "BasvuruDurum" integer NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "UzmanKimlikRef" uuid,
    "OnaylanmaTarihi" timestamp without time zone,
    "BeyanDurumu" boolean,
    "BeyanTarihi" timestamp without time zone,
    "EvrakId" character varying,
    "BelgeTarihi" character varying
);


--
-- Name: Not; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."Not" (
    "Kimlik" uuid NOT NULL,
    "Konu" character varying NOT NULL,
    "Aciklama" character varying NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp with time zone,
    "Guncelleyen" uuid,
    "KullaniciKimlikRef" uuid NOT NULL
);


--
-- Name: ReferansNumarasi; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."ReferansNumarasi" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "ReferansNo" character varying(250) NOT NULL,
    "BasvuruSekli" integer NOT NULL,
    "BasvuruTipi" integer NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "OdemeDurumu" boolean NOT NULL,
    "OdenecekToplamTutar" double precision NOT NULL,
    "Dekont" character varying
);


--
-- Name: TamZamanliPersonel; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."TamZamanliPersonel" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "EgitimKimlikRef" uuid,
    "DeneyimKimlikRef" uuid,
    "TesisKimlikRef" uuid,
    "TesisAdi" character varying,
    "TesisCevreKimlikNo" character varying,
    "TesisIli" character varying,
    "TesisYetkilisi" character varying,
    "PersonelAdi" character varying,
    "PersonelSoyadi" character varying,
    "Unvan" character varying,
    "Bolum" character varying,
    "CalismaSuresi" integer,
    "IseGirisTarihi" timestamp without time zone
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: e-yeterlik; Owner: -
--

CREATE TABLE "e-yeterlik"."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Name: BakanlikPersonelOdeme; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BakanlikPersonelOdeme" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BakanlikAdi" character varying,
    "Birimi" character varying,
    "Gorevi" character varying,
    "Aciklama" character varying,
    "BakanlikTuru" integer NOT NULL,
    "KullaniciKimlikRef" uuid
);


--
-- Name: BasvuruBelgeEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruBelgeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruBelgeKimlikRef" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "BelgeBasvuruTuru" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: BasvuruDeneyimEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruDeneyimEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruDeneyimKimlik" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: BasvuruEgitimEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruEgitimEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruEgitimKimlik" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: Belge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Belge" (
    "Kimlik" uuid NOT NULL,
    "BelgeKimlikRef" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "KullaniciKimlikRef" uuid NOT NULL,
    "BelgeTipi" character varying,
    "DosyaAdi" character varying,
    "TcKimlikNumarasi" character varying
);


--
-- Name: CevreYonetimBirimiBasvuru; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CevreYonetimBirimiBasvuru" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "FirmaTipi" integer NOT NULL,
    "BasvuruDurum" integer NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Aciklama" character varying
);


--
-- Name: CevreYonetimBirimiPersonelTesis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CevreYonetimBirimiPersonelTesis" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "PersonelKimlikRef" uuid NOT NULL,
    "TesisKimlikRef" uuid NOT NULL,
    "CevreYonetimBirimiKimlikRef" uuid NOT NULL
);


--
-- Name: CevreYonetimBirimiTesis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CevreYonetimBirimiTesis" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "TesisCevreKimlikNo" character varying NOT NULL,
    "FirmaCevreKimlikNo" character varying NOT NULL,
    "VergiNo" character varying NOT NULL,
    "FirmaKimlikRef" uuid NOT NULL,
    "TesisKimlikRef" uuid NOT NULL,
    "FirmaUnvani" character varying NOT NULL,
    "TesisAdi" character varying NOT NULL
);


--
-- Name: CevreYonetimPersonel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CevreYonetimPersonel" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Adi" character varying NOT NULL,
    "Soyadi" character varying NOT NULL,
    "TCKimlikNo" character varying NOT NULL,
    "CalismaDurumu" integer NOT NULL,
    "Unvan" character varying NOT NULL,
    "Bolum" character varying NOT NULL,
    "CalismaSuresi" double precision NOT NULL,
    "IseGirisTarihi" timestamp without time zone NOT NULL,
    "Dosya" character varying,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: CevreYonetimPersonelEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CevreYonetimPersonelEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruPersonelKimlik" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: DanismanFirmaBasvuru; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DanismanFirmaBasvuru" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "FirmaTipi" integer NOT NULL,
    "BasvuruDurum" integer NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Aciklama" character varying
);


--
-- Name: DanismanFirmaPersonel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DanismanFirmaPersonel" (
    "Kimlik" uuid NOT NULL,
    "DanismanFirmaKimlikRef" uuid NOT NULL,
    "Adi" character varying NOT NULL,
    "Soyadi" character varying NOT NULL,
    "TCKimlikNo" character varying NOT NULL,
    "CalismaDurumu" integer NOT NULL,
    "Unvan" character varying NOT NULL,
    "Bolum" character varying NOT NULL,
    "CalismaSuresi" double precision NOT NULL,
    "IseGirisTarihi" timestamp without time zone NOT NULL,
    "Dosya" character varying,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: DanismanPersonelEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DanismanPersonelEksiklik" (
    "Kimlik" uuid NOT NULL,
    "BasvuruPersonelKimlik" uuid NOT NULL,
    "UygunlukDurum" integer,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid
);


--
-- Name: Deneyim; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Deneyim" (
    "Kimlik" uuid NOT NULL,
    "Gorevi" character varying NOT NULL,
    "KurumAdi" character varying NOT NULL,
    "KurumAdresi" character varying NOT NULL,
    "IseGirisTarihi" timestamp without time zone NOT NULL,
    "IstenAyrilisTarihi" timestamp without time zone,
    "DevamDurumu" boolean NOT NULL,
    "DeneyimNotu" character varying,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "KullaniciKimlikRef" uuid NOT NULL,
    "TcKimlikNumarasi" character varying NOT NULL
);


--
-- Name: Egitim; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Egitim" (
    "Kimlik" uuid NOT NULL,
    "EgitimKimlikRef" uuid NOT NULL,
    "OnayDurumu" integer NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Derece" character varying,
    "KurumAdi" character varying,
    "BolumAdi" character varying,
    "MezuniyetTarihi" timestamp without time zone,
    "BasvuruSekli" integer,
    "NotOrtalamasi" character varying,
    "FakulteAdi" character varying
);


--
-- Name: KisiBasvuru; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."KisiBasvuru" (
    "Kimlik" uuid NOT NULL,
    "BasvuruSekli" integer NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "BasvuruDurum" integer NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "TCKimlikNo" character varying
);


--
-- Name: Not; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Not" (
    "Kimlik" uuid NOT NULL,
    "Konu" character varying NOT NULL,
    "Aciklama" character varying NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp with time zone,
    "Guncelleyen" uuid,
    "KullaniciKimlikRef" uuid NOT NULL,
    "TcKimlikNumarasi" character varying
);


--
-- Name: ReferansNumarasi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ReferansNumarasi" (
    "Kimlik" uuid NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "ReferansNo" character varying(250) NOT NULL,
    "BasvuruSekli" integer NOT NULL,
    "BasvuruTipi" integer NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "OdemeDurumu" boolean NOT NULL,
    "OdenecekToplamTutar" double precision NOT NULL,
    "Dekont" character varying
);


--
-- Name: TamZamanliPersonel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TamZamanliPersonel" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "EgitimKimlikRef" uuid,
    "DeneyimKimlikRef" uuid,
    "TesisKimlikRef" uuid,
    "TesisAdi" character varying,
    "TesisCevreKimlikNo" character varying,
    "TesisIli" character varying,
    "TesisYetkilisi" character varying,
    "TcKimlikNo" character varying,
    "PersonelAdi" character varying,
    "PersonelSoyadi" character varying,
    "Unvan" character varying,
    "Bolum" character varying,
    "CalismaSuresi" integer,
    "IseGirisTarihi" timestamp without time zone
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Data for Name: Aski; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."Aski" VALUES ('dafa76f1-3736-48e7-adc3-4509bc49a2c8', '0bc6d9e3-1c72-4e40-9519-7cdfacdf2649', 1, NULL, NULL, '8c3862b7-3a13-4ef0-9b9a-3bf86e30eb49', '2023-08-18 11:11:14.789687', '2023-08-18 11:11:14.790285', '2024-02-18 11:11:14.790369', 'trrytrytry', 1, '5fd5d9d9-0e13-4095-915e-c93ca1d37717', '81607');
INSERT INTO "e-ced-yeterlik"."Aski" VALUES ('4d619376-a314-4dc6-944a-9667f5aa6a6a', '873c5305-652f-482c-8ce3-a08a9fd62a5a', 1, NULL, NULL, '969dd7d4-8650-4016-9b06-2369f8e5c504', '2023-08-18 11:21:33.392084', NULL, NULL, 'dddsfdf', 1, '5fd5d9d9-0e13-4095-915e-c93ca1d37717', '81607');
INSERT INTO "e-ced-yeterlik"."Aski" VALUES ('4baab736-24d2-4562-bbf2-67cbf1f9a079', '1760a0f3-eb7d-472d-aea6-64f309198bf9', 1, NULL, NULL, '385ca513-80fe-446a-9b66-c44a87afe677', '2023-08-18 13:12:58.996168', '2023-08-18 13:12:58.996689', '2024-02-18 13:12:58.996762', 'Yapılan Değerlendirme Uygundur', 1, '5fd5d9d9-0e13-4095-915e-c93ca1d37717', '81607');


--
-- Data for Name: AskiTalep; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."AskiTalep" VALUES ('873c5305-652f-482c-8ce3-a08a9fd62a5a', 0, '2023-08-18 11:21:30.031299', '3ca8c68d-7673-495d-a2e7-ce6adc806ccd', '0b3066e5-7add-47d2-bf83-5674e7576db4', '2023-08-18 11:18:25.939597', NULL, 'rewre', '825f38ee-368d-4f8c-abe0-3787e37e0802', 'Askı Kaldır', 1, 1, NULL, 1, '040824bf-dade-4667-bcc3-dc7fc943ceb8', 1, '0bc6d9e3-1c72-4e40-9519-7cdfacdf2649');
INSERT INTO "e-ced-yeterlik"."AskiTalep" VALUES ('1760a0f3-eb7d-472d-aea6-64f309198bf9', 0, '2023-08-18 13:14:59.514118', '5a38ca18-bae0-4f56-ac24-628fa545a7f6', '19b84421-4792-4002-bfd0-227abcf242ca', '2023-08-18 13:10:52.429478', NULL, 'Test Ceza', '825f38ee-368d-4f8c-abe0-3787e37e0802', 'Askı Al', 1, NULL, 1, NULL, '040824bf-dade-4667-bcc3-dc7fc943ceb8', 1, NULL);
INSERT INTO "e-ced-yeterlik"."AskiTalep" VALUES ('1ca91261-c477-47e8-a33e-8b70636d7b0a', 1, '2023-08-18 13:17:43.956356', 'cac955f6-4fcc-4093-8b3c-ee10885b6c6b', 'fecb11bf-4a92-4035-ba0b-f320a07bfb08', '2023-08-18 13:15:00.940709', NULL, 'Askıyı Kaldır Onay', '825f38ee-368d-4f8c-abe0-3787e37e0802', 'Askı Kaldır', NULL, 1, NULL, 1, '040824bf-dade-4667-bcc3-dc7fc943ceb8', 1, '1760a0f3-eb7d-472d-aea6-64f309198bf9');
INSERT INTO "e-ced-yeterlik"."AskiTalep" VALUES ('254b9009-c186-4a0f-8fce-592ffc4c7f67', 0, '2023-08-17 08:38:47.519279', '43c0e24a-21a0-4824-bf04-bbf392caf945', 'fe65925c-22df-4275-b95a-90ea338fb38f', '2023-08-17 07:50:17.217982', NULL, 'uzman görüşümü ekliyorum', '825f38ee-368d-4f8c-abe0-3787e37e0802', 'Askı Al', 1, NULL, 1, NULL, '040824bf-dade-4667-bcc3-dc7fc943ceb8', 2, NULL);
INSERT INTO "e-ced-yeterlik"."AskiTalep" VALUES ('eca639ef-0bc2-48c9-9c02-05374801dcb4', 0, '2023-08-17 08:39:03.607993', '0fb08336-1a61-47cd-b473-4bc8e5f66e00', '3281d4eb-4aae-4da8-ab06-b8f24c29f86e', '2023-08-17 08:38:48.21308', NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'Askı Kaldır', 1, NULL, NULL, NULL, '040824bf-dade-4667-bcc3-dc7fc943ceb8', 2, '254b9009-c186-4a0f-8fce-592ffc4c7f67');
INSERT INTO "e-ced-yeterlik"."AskiTalep" VALUES ('0bc6d9e3-1c72-4e40-9519-7cdfacdf2649', 0, '2023-08-18 11:18:23.90595', '24687e1b-0cdb-4e58-83c8-dbbcc2946a0b', '70c1856c-3496-4c2c-9a7b-d5525d6b218e', '2023-08-18 11:04:01.106634', NULL, 'retrtrt', '825f38ee-368d-4f8c-abe0-3787e37e0802', 'Askı Al', 1, NULL, 1, NULL, '25afde51-1b93-4f80-b9a0-53ea30d43072', 1, NULL);


--
-- Data for Name: Basvuru; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."Basvuru" VALUES ('825f38ee-368d-4f8c-abe0-3787e37e0802', 2, '2023-08-18 13:12:57.414992', 'a6e922f6-9c77-4f4e-ab24-ac2508589ecd', '70c43d15-526b-4bbf-a950-4e4ede884738', '2023-08-17 06:46:38.268691', 1, 1, NULL, '25afde51-1b93-4f80-b9a0-53ea30d43072', NULL, 0, 1, '2023-08-18 12:51:33.530019', 5, NULL, 'LXUDJWT', '', 'Test İşlemleri', 'test', 'test', true);


--
-- Data for Name: BasvuruAtama; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."BasvuruAtama" VALUES ('9bb13423-e988-417f-a126-36a7227790ad', '825f38ee-368d-4f8c-abe0-3787e37e0802', 0, 'ee8b4302-8e8b-4058-ba1a-698eba8c36ee', '2023-08-17 09:56:00.526764', '6634e043-40a5-40f9-8396-57c85da18643', '2023-08-18 12:21:38.273554', 'Atandı', '040824bf-dade-4667-bcc3-dc7fc943ceb8', '5fd5d9d9-0e13-4095-915e-c93ca1d37717');
INSERT INTO "e-ced-yeterlik"."BasvuruAtama" VALUES ('ef1e333e-b9cf-44b3-b195-81c3b617f2e4', '825f38ee-368d-4f8c-abe0-3787e37e0802', 1, '74e5c85d-f48c-42a2-935e-a4ead6a67834', '2023-08-18 10:24:50.286832', '6c1411ea-cf57-4fd7-aa66-a59ad1db25c6', '2023-08-18 12:39:20.946814', 'Atandı', '040824bf-dade-4667-bcc3-dc7fc943ceb8', '5fd5d9d9-0e13-4095-915e-c93ca1d37717');


--
-- Data for Name: BasvuruBelge; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."BasvuruBelge" VALUES ('99d69761-1c11-4a7b-b661-41ee776072cd', 0, 1, 'd620254c-58e5-4a01-8bfc-d40d4ae230d0', '2023-08-17 06:48:19.522149', NULL, NULL, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802');
INSERT INTO "e-ced-yeterlik"."BasvuruBelge" VALUES ('44cf0d9b-9191-4a5a-9460-b584a79cf736', 1, 1, 'c2194b40-c97b-4145-95a6-5ce222962b9a', '2023-08-17 06:48:22.443684', NULL, NULL, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802');
INSERT INTO "e-ced-yeterlik"."BasvuruBelge" VALUES ('36a20e87-5039-4cb6-b6be-62eb14753441', 2, 1, '013eeb2e-b3b0-449b-860d-0efbe1f5c586', '2023-08-17 06:48:25.73935', NULL, NULL, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802');


--
-- Data for Name: BasvuruBelgeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."BasvuruBelgeEksiklik" VALUES ('e64ec575-1e76-4b1d-933f-ee0e73b01522', '99d69761-1c11-4a7b-b661-41ee776072cd', 1, 'ee48d9c4-a136-4a69-b2d1-892d6319ec8d', '2023-08-17 06:57:53.216473', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."BasvuruBelgeEksiklik" VALUES ('4b368ff6-6f52-4b8e-84d9-ed5bd719dce3', '44cf0d9b-9191-4a5a-9460-b584a79cf736', 1, '01458cc2-27b9-40ef-8860-9d620e17e562', '2023-08-17 06:57:53.679416', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."BasvuruBelgeEksiklik" VALUES ('f4deaa4b-a532-4480-96ab-93986f9e11cf', '36a20e87-5039-4cb6-b6be-62eb14753441', 1, '7d33c0d1-b2b4-426f-ad21-0b877b882db5', '2023-08-17 06:57:54.10139', NULL, NULL, 1, 1, NULL, NULL, NULL);


--
-- Data for Name: BasvuruBelgeGecmis; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: BasvuruEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: BasvuruLog; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: BasvuruOdeme; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."BasvuruOdeme" VALUES ('ddb8b070-ece9-4ba9-bdff-ae1edfd13cbf', '825f38ee-368d-4f8c-abe0-3787e37e0802', 1, '2023-08-17 09:53:32.574653', '4ff3c191-fe53-4763-9209-76e235c6f8c9', 'ad58e435-a860-464f-957c-90b98416c7a8', '2023-08-17 09:53:26.209414', '1492799474', 10000, true);


--
-- Data for Name: BasvuruOdemeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."BasvuruOdemeEksiklik" VALUES ('709cba09-d239-472e-a99e-9bc00c961b2e', 'ddb8b070-ece9-4ba9-bdff-ae1edfd13cbf', 1, 'b3eba0ba-db58-4543-b1cb-16f1c5426540', '2023-08-17 06:58:02.650683', NULL, NULL, 1, 1, NULL, NULL, NULL);


--
-- Data for Name: BasvuruReferansNo; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."BasvuruReferansNo" VALUES ('d729e068-e448-43e8-8466-b3f31c146b57', 1, 'e18d2013-149e-436d-8737-c638a3939aaf', '2023-08-17 09:53:21.578961', NULL, NULL, '1492799474', '825f38ee-368d-4f8c-abe0-3787e37e0802', false, 10000, 0);


--
-- Data for Name: Ceza; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: CezaTalep; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: CezaTur; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('03b365e2-9241-4444-9313-e63a6d72b7e7', 'ÇED yeterlik belgesi alan kurum/kuruluşun, mevcut personel sayısının eksilmesi halinde otuz gün içerisinde Bakanlığa bildirmemesi', '10', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('0a23c9a2-463c-44f7-9493-29cd8ebc0eca', 'ÇED Başvuru Dosyası/ÇED Raporunda imzaları bulunan 5-1)(a) veya 5-1)(b) veya 5-1)(c) personelinin Halkın Bilgilendirilmesi ve Sürece Katılımının sağlanmaması', '40', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('2742eeaf-6bec-4241-b802-df3b32032996', 'Bakanlık veya İl Müdürlüğünce projenin yeri, türü ve özelliğine göre talep edilen proje personelini görevlendirmemesi/sorumlu olduğu bölümün imzalatılmaması, istenildiğinde Komisyon toplantısına katılımının sağlanmaması', '20
', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('282fa834-4126-42bd-a1ca-7c8424e39dfd', 'ÇED Yeterlik Belgesi alan kurum/kuruluşlar ve personel hazırlayacakları PTD, ÇED Başvuru Dosyası, ÇED Raporu, Proje İlerleme Raporunda ÇED Yönetmeliği kapsamında hazırlanmış herhangi bir rapor ya da dosyadan kaynak göstermeden alıntı yapması', '25', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('2d6cec3f-8f99-40ad-833f-a5098f80a6fb', 'ÇED Yönetmeliği kapsamında formata uygun bulunan PTD inceleme değerlendirme sürecinde, Bakanlıkça veya İl Müdürlüğünce dosyada istenilen eksikliklerin giderilmesi amacı ile aynı konu ile ilgili iki defanın üzerinde eksiklik bildirilmesi', '5', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('37db99de-435e-49f3-b27a-8be923174186', 'ÇED Başvuru Dosyası/ÇED Raporunda imzaları bulunan 5-1)(a) veya 5-1)(b) veya 5-1)(c) personelinin Komisyon toplantısına katılımının sağlanmaması', '40', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('49bd8678-2c95-47af-a53c-3b2ed82ef761', 'ÇED Yeterlik Belgesi Tebliğinin 5 inci maddesinin birinci fıkrasındaki (a), (b), (c) ve (ç) kapsamındaki personel ile proje personeline ilişkin Bakanlığa sunulan belgelerin yanlış, yanıltıcı ya da sahte olduklarının tespit edilmesi', '50', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('4d3448bb-8a6b-487f-ac96-decaccbce9e7', 'ÇED Yeterlik Belgesine sahip kurum/kuruluşa yapılan haberli denetimlerde, imzaya yetkili sorumlunun ve talep edilmesi halinde istenilen personelin hazır bulundurulmaması veya istenilen bilgi ve belgelerin ibraz edilmemesi', '30', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('4f0028b0-9dee-4f24-99b9-031b22dceaaf', 'ÇED Yeterlik Belgesi alan kurum/kuruluşlar ve personel hazırlayacakları PTD, ÇED Başvuru Dosyası, ÇED Raporu, Proje İlerleme Raporunda Projenin konusu ile ilgisi olmayan bilgilere yer verilmesi', '10', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('6ed20196-561b-4ad3-adcb-504474926a7e', 'ÇED Yeterlik Belgesi alan kurum/kuruluşlar sunmuş oldukları dosya/raporla ilgili olarak ÇED Yönetmeliğinde belirtilen süreler içinde gerekli düzenlemeleri yaparak, dosya/raporu ve ilgili belgeleri sunmaması nedeniyle ÇED sürecinin sonlanması', '25', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('5c4752a0-d335-42d8-a24c-70fdcf2fd439', 'ÇED Yeterlik Belgesi alan kurum/kuruluşların, ÇED Başvuru Dosyası, Çevre mevzuatı kapsamında ÇED Başvuru Dosyası hazırlanmasına gerek olmadan sunulan ÇED Raporunu ve PTD’yi hazırlama aşamasında, bu Tebliğin 5 inci maddesinin birinci fıkrasının (a), (b), (c) bentlerinde belirtilen personelden en az birini faaliyet yerini incelemek üzere ve incelemeden en az 5 gün önce İl Müdürlüğüne yazılı bilgi vermek suretiyle proje alanına göndermemesi', '25', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('81f94417-f71f-4851-a951-d35668a7cbcd', 'ÇED Yeterlik Belgesi alan kurum/kuruluşun, resmi yazışmalarda kullanılmak üzere Kayıtlı Elektronik Posta (KEP) adresini temin etmemesi, firmanın faaliyetlerinin yer aldığı ve tanıtımının yapıldığı internet sitesi bulunmaması', '5', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('946d577a-7e54-49bb-aa0a-9d8c0763d6d9', 'Proje İlerleme Raporunun belirlenen sürelerde sunulmaması', '25', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('a58122e9-d6ef-48e2-b7f7-9e13670e9e48', 'ÇED Yeterlik Belgesine sahip kurum/kuruluşların hazırlamış olduğu her bir rapora ait ÇED Süreci Değerlendirme Formlarının yetmiş puanın altında olması', '25', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('d57fe4e1-0cf2-43d9-87d3-5a988834cb38', 'Tebliğin 6’ncı maddesinde sayılan belgelerde meydana gelebilecek değişikliklerin, değişiklik tarihinden itibaren otuz gün içinde Bakanlığa sunulmaması', '10', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('e3f1326d-c0d2-48e6-9294-b209b1bf72ab', 'ÇED Yeterlik Belgesine sahip kurum/kuruluşların veya şubelerinin adres değişikliğini ve/veya kayıtlı eposta, web adresi gibi iletişim bilgilerindeki değişiklikleri otuz gün içerisinde Bakanlığa bildirmemesi', '5', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('f4bfa1aa-1fa6-49dd-b21c-279b5a8ce389', 'ÇED Yeterlik Belgesi alan kurum/kuruluşlar ve personel hazırlayacakları PTD, ÇED Başvuru Dosyası, ÇED Raporu, Proje İlerleme Raporunda İsmi belirtilen yerine başkasının imza atması ', '50', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('f55a42fc-00a0-4ed3-8e83-a0e6b0dcb21b', 'ÇED Yeterlik Belgesi alan kurum/kuruluşlar ve personel hazırlayacakları PTD, ÇED Başvuru Dosyası, ÇED Raporu, Proje İlerleme Raporunda Yanıltıcı bilgi ve/veya belge sunulması', '50', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('f77e6ef0-d1eb-4fb5-9974-1e37a8834880', 'ÇED Yeterlik Belgesine sahip kurum/kuruluşun, Genel Müdürlüğün, ÇED Yeterlik Belgesine sahip kurum/kuruluşlara yönelik kapsamını belirleyeceği konularda düzenleyeceği eğitimlere uygun sayı ve nitelikte personelinin katılımını sağlamaması', '25', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');
INSERT INTO "e-ced-yeterlik"."CezaTur" VALUES ('fe769ccd-bf3e-42ec-8f8b-34ecc24cbf2e', 'ÇED Yeterlik Belgesi alan kurum/kuruluşlar sunmuş oldukları dosya/rapor ekinde bu tebliğin Ek-1’inde yer alan personel tablosunun eklenmemesi', '5', 1, NULL, NULL, '246d577a-7e54-49bb-aa0a-9d8c0763d6dd', '2023-05-09 10:45:43.319645');


--
-- Data for Name: FirmaAdres; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaAdresAtama; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaAdresBelge; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaAdresBelgeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaAdresOdeme; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaAdresOdemeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaUnvan; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."FirmaUnvan" VALUES ('3f5d7968-ce81-4b78-9193-8cc713d8c531', 1, '2023-08-18 13:20:15.023734', '6383ac52-eb08-4b7a-8dd2-fa9646093409', NULL, NULL, '25afde51-1b93-4f80-b9a0-53ea30d43072', NULL, NULL, NULL, NULL, 1, 'WRWAHRV', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: FirmaUnvanAtama; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaUnvanBelge; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaUnvanBelgeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaUnvanOdeme; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: FirmaUnvanOdemeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: Iptal; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: IptalTalep; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."IptalTalep" VALUES ('8c240482-491e-44ca-85fe-06781540ab0e', 0, '2023-08-17 07:07:51.346689', 'ecbd35dd-98b8-4ce5-a1a8-7b0a620ee020', 'fafb1537-ca58-499c-a581-3f42dd75d2d3', '2023-08-17 07:07:24.684116', '825f38ee-368d-4f8c-abe0-3787e37e0802', 'iptal etmek istiyorum', 1, 1, NULL, 2, '040824bf-dade-4667-bcc3-dc7fc943ceb8');


--
-- Data for Name: Personel; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('901f3169-ae9c-4cdd-b4c8-f3071bbb1363', 7, 'Görenler Grup', 'Uzman', '2023-03-02 07:30:56.174', '-infinity', 31, 26, 1, 1, NULL, NULL, 'fd895334-b3fd-426b-950f-83d703fc16a0', '2023-08-17 06:46:46.750261', 'Sezen', 'Yılmaz', 'Çevre Mühendisi', NULL, '58545235896', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'A', 1, NULL, 'Ankara', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('ad3e778d-1ddc-4d8f-b273-2e4720890b3c', 8, 'Danışman Holding', 'Uzman', '2023-03-02 07:30:56.174', '-infinity', 20, 30, 2, 1, NULL, NULL, '863cd23d-f3b1-406d-9cab-a772f64a92fc', '2023-08-17 06:47:39.444511', 'Hasan', 'Demir', 'Jeoloji Mühendisi', NULL, '96310104578', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'B', 2, NULL, 'Ankara', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('63624146-af1f-4c77-a253-64d4428ef1c8', 9, 'Çağatay Holding', 'Mühendis', '2023-03-02 07:30:56.174', '-infinity', 5, 26, 0, 1, '2023-08-17 12:58:43.65071', '04be6225-9ee5-4bb1-816d-1cfbd4598987', 'daa7dab8-8314-465d-96ff-75d68c66099c', '2023-08-17 08:42:02.476042', 'Laren', 'Elmasoğlu', 'Çevre Mühendisi', NULL, '55345717896', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'C', 1, NULL, 'Ankara', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('caba194a-df76-41c6-b71f-368335d6f20f', 9, 'Karahanoğulları Holding', 'Mühendis', '2023-05-19 07:30:56.174', '-infinity', 15, 26, 0, 1, '2023-08-17 13:10:53.007482', '3689ed7b-780a-4d3e-a375-7702782b113f', '27195ff0-37c7-4793-b8f3-69a9b59cd096', '2023-08-17 06:47:55.193758', 'Aziz', 'Düzgün', 'Çevre Mühendisi', NULL, '42145782164', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'C', 2, NULL, 'Ankara', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('6c4b6368-d259-4b38-9038-3639757e7cb6', 8, 'Serenliler Holding', 'Mühendis', '2023-05-16 07:30:56.174', '-infinity', 15, 26, 0, 1, '2023-08-18 08:52:36.150556', '0b8efb48-fd22-481a-9fb1-55a4e4bf5318', 'e5744d13-1c3f-46c9-8e8e-e6a77f43efb1', '2023-08-17 12:59:32.522171', 'Ela', 'Koçak', 'Çevre Mühendisi', NULL, '11445782194', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'C', 1, NULL, 'Ankara', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('1afa2449-ddcd-405b-a224-16f73f771127', 8, 'Doğuş Grubu', 'Mühendis', '2023-05-12 07:30:56.174', '-infinity', 15, 26, 3, 1, NULL, NULL, 'f6d06873-e23d-4e7f-a389-8950add551a9', '2023-08-18 08:53:17.036506', 'Gökçe', 'Aydemir', 'Çevre Mühendisi', NULL, '71245717857', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'C', 1, NULL, 'Ankara', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('84bdf73a-10fa-4ef0-a9ec-681491dd12ed', 5, 'Softer Holding', 'Uzman', '2023-03-09 07:30:56.174', '-infinity', 22, 27, 0, 1, '2023-08-18 12:19:43.740816', '06b19dae-1eee-4d7b-9e27-6815beee24bb', 'cafd0046-7379-45f0-b66c-91b10d51a85c', '2023-08-17 06:47:25.516182', 'Hümeyra', 'Ekiciler', 'Jeofizik  Mühendisi', NULL, '12310104523', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'B', 1, NULL, 'Ankara', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('e20facac-cf5e-4d09-b187-9421a1a5c1de', 8, 'Akar Holding', 'Uzman', '2023-02-09 07:30:56.174', '-infinity', 15, 26, 2, 1, NULL, NULL, '5324af79-bee9-4dac-880c-56e3b97b0da7', '2023-08-18 12:21:35.284656', 'Hakan', 'Altın', 'Jeofizik  Mühendisi', NULL, '65210103295', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'B', 2, NULL, 'Ankara', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."Personel" VALUES ('f40cf9f7-a698-4d92-8c76-23c1daea1356', 9, 'ERC Grup', 'Uzman', '2023-03-02 07:30:56.174', '-infinity', 15, 26, 0, 1, '2023-08-18 13:06:28.221126', 'b5fc6c5d-8b10-4500-8843-8ac5f56d1474', '2db93ec4-1711-4840-919a-1221b48361d0', '2023-08-17 06:47:03.050787', 'Deniz', 'Ufuk', 'Çevre Mühendisi', NULL, '38215235896', 1, NULL, NULL, '825f38ee-368d-4f8c-abe0-3787e37e0802', 'A', 1, NULL, 'Ankara', NULL, NULL, NULL, NULL);


--
-- Data for Name: PersonelBelge; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('3ac1732b-673f-47c4-8f97-daad147392d9', '901f3169-ae9c-4cdd-b4c8-f3071bbb1363', 0, 1, 'c8c75a52-0c12-48f7-979f-6dbe1d47f051', '2023-08-17 06:48:43.460107', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('1f9dd59e-f178-4315-953c-5530d6882533', '901f3169-ae9c-4cdd-b4c8-f3071bbb1363', 1, 1, '5cb6cc0b-703e-430c-98c8-c3692d8ed03c', '2023-08-17 06:48:48.004504', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('d41acf25-edfd-41f7-98dc-962b63b1218c', '901f3169-ae9c-4cdd-b4c8-f3071bbb1363', 2, 1, '544c3b36-802a-43c6-b18f-791f39950f9d', '2023-08-17 06:48:55.908332', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('8b0e2a80-afa0-46c1-aa55-de0bb7a259c8', '901f3169-ae9c-4cdd-b4c8-f3071bbb1363', 3, 1, '38f1bb1a-1f05-4267-af8d-5d99117c2ee6', '2023-08-17 06:48:59.015624', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('a6f89608-af8f-4813-bcfb-ff69857a6dcf', 'f40cf9f7-a698-4d92-8c76-23c1daea1356', 0, 1, '5647c1f6-7385-4690-aa86-9f2d6dd10a21', '2023-08-17 06:49:13.364522', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('d46149b7-174d-4962-8ec6-497656a4ddf6', 'f40cf9f7-a698-4d92-8c76-23c1daea1356', 1, 1, 'dbe872cd-8d7c-4d9c-aea3-93eae1db1f0f', '2023-08-17 06:49:17.360006', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('b5537980-a074-42c8-bffb-7e591f4de1fb', 'f40cf9f7-a698-4d92-8c76-23c1daea1356', 2, 1, 'a1b949e7-9974-4dc4-b734-a478e5d65410', '2023-08-17 06:49:25.287265', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('12edb8d8-67cd-4855-9e79-6912a7c429b1', 'f40cf9f7-a698-4d92-8c76-23c1daea1356', 3, 1, '02ce2ad3-5f89-4da6-835a-a52faf92b6fe', '2023-08-17 06:49:28.122706', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('511b1372-9464-4141-8c4c-990004d7b419', '84bdf73a-10fa-4ef0-a9ec-681491dd12ed', 0, 1, 'dc767433-9e00-41df-b92a-66a1b1c2a290', '2023-08-17 06:49:59.42113', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('372e9ffb-3695-45ed-a274-ead99f3f9540', '84bdf73a-10fa-4ef0-a9ec-681491dd12ed', 1, 1, 'f1fa19e1-395a-4c4a-ab12-8a93c5a6cf99', '2023-08-17 06:50:03.34216', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('c15af574-e889-4808-9c76-08d11d5ae777', '84bdf73a-10fa-4ef0-a9ec-681491dd12ed', 3, 1, '5b5f8cab-1269-4299-8c24-b9ba3cb5e78d', '2023-08-17 06:50:11.5359', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('0a95adb8-a7c1-4330-ad73-c6fd4fddfdcf', '84bdf73a-10fa-4ef0-a9ec-681491dd12ed', 2, 1, 'e5ad94b5-680a-40c8-b0f9-d5cb22f5a6bd', '2023-08-17 06:50:14.4828', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('958e8ea5-d6e6-4198-92f3-4173982e4edb', 'ad3e778d-1ddc-4d8f-b273-2e4720890b3c', 0, 1, '84d023a2-74bf-4569-97d5-9a10333bbc2f', '2023-08-17 06:50:32.990293', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('7a691948-a218-4e79-99fa-573bf2da6ce4', 'ad3e778d-1ddc-4d8f-b273-2e4720890b3c', 1, 1, '93c10275-131a-4596-8c1a-1d7f97758ed7', '2023-08-17 06:50:35.490271', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('6c1fc2f5-eae5-4081-a6f1-62fffdabbecd', 'ad3e778d-1ddc-4d8f-b273-2e4720890b3c', 3, 1, '5aee51e5-64cc-4edb-8a70-e4c867ef0b20', '2023-08-17 06:50:39.463319', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('8c90c8ae-667c-46e0-919c-936118a43461', 'ad3e778d-1ddc-4d8f-b273-2e4720890b3c', 2, 1, 'e65787fd-69c8-4aa6-ab49-7a993b10de02', '2023-08-17 06:50:42.122782', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('6353fdc2-e326-4501-81f9-92c6aa245d80', 'caba194a-df76-41c6-b71f-368335d6f20f', 0, 1, '6df51758-d553-4251-87fc-fb4d7cf8691d', '2023-08-17 06:50:52.100185', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('b49c053d-b150-427f-bf13-ed881901436a', 'caba194a-df76-41c6-b71f-368335d6f20f', 1, 1, 'eeec956f-e29b-4397-95c8-30388f9f6f93', '2023-08-17 06:50:54.792117', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('5c363178-d384-4b43-8217-6f75b10e2cd0', 'caba194a-df76-41c6-b71f-368335d6f20f', 2, 1, '6c767e46-603c-4c9b-be1a-37133de7f8af', '2023-08-17 06:50:58.707071', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('f30b45a9-5346-4a85-8b8a-3ff3b4fc878e', 'caba194a-df76-41c6-b71f-368335d6f20f', 3, 1, 'a963d6a8-4550-40c4-881d-a43272b4efdb', '2023-08-17 06:51:01.349371', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('0cda0abb-6b42-4c09-b126-e168b5948729', '63624146-af1f-4c77-a253-64d4428ef1c8', 0, 1, '9773fb7f-33c0-40e5-9e96-429d604b58b4', '2023-08-17 08:42:17.184872', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('46d58310-2f9f-49f7-b791-04fbc15c9367', '63624146-af1f-4c77-a253-64d4428ef1c8', 1, 1, 'b0f56ac8-5f05-453e-b4c6-e68c692ef042', '2023-08-17 08:42:21.299357', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('b4b89d15-0c27-4bc9-b8a0-339f530c016b', '63624146-af1f-4c77-a253-64d4428ef1c8', 2, 1, '96709730-f29a-43a3-8373-6f632e924913', '2023-08-17 08:42:25.78705', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('464bb241-74ab-42f9-9947-7b7f2131f966', '63624146-af1f-4c77-a253-64d4428ef1c8', 3, 1, '99677eac-302e-4958-8d7a-8b80ff21519a', '2023-08-17 08:42:28.754231', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('2b643e38-cd43-4134-a867-a7d56b3da840', '6c4b6368-d259-4b38-9038-3639757e7cb6', 0, 1, '936b3f85-b3cd-4170-9f3b-b0e3cb2b7f29', '2023-08-17 12:59:47.108325', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('6f49e3a1-ff38-40c0-9cc1-fe9e8522fdd2', '6c4b6368-d259-4b38-9038-3639757e7cb6', 1, 1, '7b3320ad-e037-43d2-a0eb-79ce01b757f8', '2023-08-17 12:59:51.523555', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('3d35339a-48b5-40b9-8582-181701ae3662', '6c4b6368-d259-4b38-9038-3639757e7cb6', 2, 1, '91a584bd-5280-4285-af05-bf1245bb8a12', '2023-08-17 12:59:55.789576', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('55d2cf19-7b25-428a-b581-d2729cf5186d', '6c4b6368-d259-4b38-9038-3639757e7cb6', 3, 1, '38fbb98c-0abf-481a-9d99-7ba51f0a1a40', '2023-08-17 12:59:59.676135', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('28caab49-451f-4ae1-a312-0f0e242d8060', '1afa2449-ddcd-405b-a224-16f73f771127', 0, 1, '9b18c12d-c0cc-42a6-806b-6f2b4add4926', '2023-08-18 10:24:25.181306', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('aa503131-20df-4b2e-946c-5206243f1117', '1afa2449-ddcd-405b-a224-16f73f771127', 1, 1, '952676a3-0307-4738-8b89-13c03e4fe972', '2023-08-18 10:24:29.029848', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('c542fbbe-e991-4bef-8011-139a04d0cfa0', '1afa2449-ddcd-405b-a224-16f73f771127', 2, 1, '18d217ab-409a-49dc-b824-8d9447fd7e87', '2023-08-18 10:24:32.57211', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('f04e738f-f8c0-4ab8-8496-4d351084d945', '1afa2449-ddcd-405b-a224-16f73f771127', 3, 1, '80497e4e-bec2-4d65-b8ce-538b83d05ad8', '2023-08-18 10:24:37.147602', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('2eeea082-bc5b-4ea6-b37d-0314906d6435', 'e20facac-cf5e-4d09-b187-9421a1a5c1de', 0, 1, 'd0854be7-4c61-4431-aea3-0ae9be060773', '2023-08-18 12:25:17.568683', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('d77b010c-9389-4e8c-ae12-b587f254cafc', 'e20facac-cf5e-4d09-b187-9421a1a5c1de', 1, 1, '556972fe-5c22-4671-b51f-0af1f74dad8f', '2023-08-18 12:25:37.868703', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('a37b0358-6b43-4e72-8149-54d5b8da7f4f', 'e20facac-cf5e-4d09-b187-9421a1a5c1de', 2, 1, 'a47ff5e8-ff34-4a79-a6a5-51740f31da35', '2023-08-18 12:26:32.795784', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelge" VALUES ('c8ec6ef8-0d39-4556-a16d-12dff2de3c84', 'e20facac-cf5e-4d09-b187-9421a1a5c1de', 3, 1, '038f462d-4cab-4f48-8e22-97535c211e22', '2023-08-18 12:26:52.385607', NULL, NULL, NULL, NULL);


--
-- Data for Name: PersonelBelgeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('25bfe44b-f8e7-426b-9479-0e851eae0f5c', '8b0e2a80-afa0-46c1-aa55-de0bb7a259c8', 1, 'd2186c00-f7ac-4aaa-b24a-10975832f09c', '2023-08-17 06:58:20.882077', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('71429d24-e8e7-4fb0-baf4-bcd4634be39a', 'd41acf25-edfd-41f7-98dc-962b63b1218c', 1, '401c6f02-ae9e-4134-afe9-eeb4c2ab6bf3', '2023-08-17 06:58:21.224835', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('0d0c0ca9-f2a0-4fe7-a09f-df0ae4f40bcf', '1f9dd59e-f178-4315-953c-5530d6882533', 1, 'e2764343-f208-436f-abf0-a219a29c175a', '2023-08-17 06:58:21.561297', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('6ec17c73-b541-492d-9114-4b41347a7114', '3ac1732b-673f-47c4-8f97-daad147392d9', 1, 'f9b50d16-1c92-4719-9f2a-c1bd2338fc3a', '2023-08-17 06:58:21.919489', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('de947cad-a7ba-43a7-98b9-8923999600de', '12edb8d8-67cd-4855-9e79-6912a7c429b1', 1, 'd227ceec-24ae-4e8e-b39f-c7761ecb7eb4', '2023-08-17 06:58:27.656084', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('8b096596-3353-4036-b63c-104ef3bfc428', 'b5537980-a074-42c8-bffb-7e591f4de1fb', 1, '78a5c979-98e7-442d-9303-af00f81059d2', '2023-08-17 06:58:28.010369', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('9987e9a5-b85a-41b8-a3ab-79339aba264c', 'd46149b7-174d-4962-8ec6-497656a4ddf6', 1, 'bb84494b-01d5-476b-be32-98256ed4f150', '2023-08-17 06:58:28.345739', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('cda42091-3154-4bd2-89e7-116756e10f63', 'a6f89608-af8f-4813-bcfb-ff69857a6dcf', 1, '34a2e8fd-415c-48bd-9f95-c35abb3c041e', '2023-08-17 06:58:28.675335', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('ca5c403d-9553-4ab2-a8af-7392e63ebcba', '0a95adb8-a7c1-4330-ad73-c6fd4fddfdcf', 1, '77675142-97da-47df-920c-8e1b611b2221', '2023-08-17 06:58:49.216349', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('3d564305-c84f-4b9a-86f2-c78f5c9788c1', 'c15af574-e889-4808-9c76-08d11d5ae777', 1, '8f38ab58-73b5-47a1-9922-7cb31da80684', '2023-08-17 06:58:49.599216', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('b20a6c63-7f7b-41cc-b1a9-6c63c1ea83e1', '372e9ffb-3695-45ed-a274-ead99f3f9540', 1, 'f99c1045-9e82-4772-8939-04895e00d171', '2023-08-17 06:58:49.939493', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('987275b9-330f-41f2-ac2e-776fbff4d637', '511b1372-9464-4141-8c4c-990004d7b419', 1, 'b615ce3e-7f2e-4826-9fc0-8b8481a45849', '2023-08-17 06:58:50.291272', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('9743fae2-476a-4291-9a1c-1f5c43997929', '8c90c8ae-667c-46e0-919c-936118a43461', 1, 'ff844251-f1c6-4c8f-890f-a0769c4c56c3', '2023-08-17 06:58:58.999475', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('78cfb2f3-cd74-41f9-87a7-a3fbe713fbe8', '6c1fc2f5-eae5-4081-a6f1-62fffdabbecd', 1, 'f5c51e0d-8ad9-4d44-801b-a11978e547ae', '2023-08-17 06:58:59.682399', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('31c73fce-f768-43a2-a016-b40d66d35840', '7a691948-a218-4e79-99fa-573bf2da6ce4', 1, '3cec239a-11ec-4edd-aa81-7c2005026b53', '2023-08-17 06:58:59.722864', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('480bb3da-e4f4-48b8-92d9-9f9e5eaacb60', '958e8ea5-d6e6-4198-92f3-4173982e4edb', 1, 'c1c5504d-5522-497a-802f-58e52ecccfc8', '2023-08-17 06:59:00.052957', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('199c0e88-73a3-4d9d-8c52-6e5b53ecab82', 'f30b45a9-5346-4a85-8b8a-3ff3b4fc878e', 1, 'a169b4af-35f5-4a99-92a0-8c5b13dbb162', '2023-08-17 06:59:24.323587', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('5d0980d8-bd3b-491f-937a-7e10cc359d92', '5c363178-d384-4b43-8217-6f75b10e2cd0', 1, 'ae01062a-cbef-4568-a907-78cf8b3c64e4', '2023-08-17 06:59:24.763984', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('53505843-4e79-4460-8742-979b70dd458e', '6353fdc2-e326-4501-81f9-92c6aa245d80', 1, '94701199-e08b-4289-b586-470f5c56e3ae', '2023-08-17 06:59:25.685294', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('eee00dae-a150-460a-9dc7-917ac8616ee6', 'b49c053d-b150-427f-bf13-ed881901436a', 1, '8d780e83-40e8-4427-9998-629a5d9520c4', '2023-08-17 06:59:26.07214', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('1aa86483-5681-4100-9fe9-abea2f55f640', '464bb241-74ab-42f9-9947-7b7f2131f966', 1, 'cee24778-45e2-4091-88e5-5ec2de4b0553', '2023-08-17 10:09:54.84652', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('f4a7ce98-d36f-4598-b599-503514a2c741', '46d58310-2f9f-49f7-b791-04fbc15c9367', 1, '293585d2-5576-48cf-bf53-07a3bf1a91a5', '2023-08-17 10:09:55.510194', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('47884a54-3225-4a0a-a3ab-be64529cdb32', '0cda0abb-6b42-4c09-b126-e168b5948729', 1, '09f40ceb-1048-42e7-a78f-4b24e30ca239', '2023-08-17 10:09:55.900273', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('bb6f7477-a083-41ad-a7d2-382c2ec3ae39', 'b4b89d15-0c27-4bc9-b8a0-339f530c016b', 1, '35b004ca-4664-4cae-b7bd-a162594c3017', '2023-08-17 10:09:56.660737', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('113dc585-6212-4255-8018-06342a4adf3a', 'f04e738f-f8c0-4ab8-8496-4d351084d945', 1, '8b5d067e-adf3-44c7-ba3a-6f82e4c92417', '2023-08-18 10:26:27.285086', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('13b99028-830d-4f59-a497-705f8929841e', 'c542fbbe-e991-4bef-8011-139a04d0cfa0', 1, 'b414a81b-a5a2-41c0-9bda-2fe1ac25cb6f', '2023-08-18 10:26:27.830062', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('e148f4d8-25fd-4a53-b77d-3a40553def55', 'aa503131-20df-4b2e-946c-5206243f1117', 1, 'a9fe3876-c32c-481a-85c6-9abb613e322b', '2023-08-18 10:26:28.694566', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelBelgeEksiklik" VALUES ('251ca9ba-1738-484e-a5f5-c9826e2cbf51', '28caab49-451f-4ae1-a312-0f0e242d8060', 1, '818ae1f1-e8e5-4ff8-a04c-a02aabff700b', '2023-08-18 10:26:29.042824', NULL, NULL, 1, 1, NULL, NULL, NULL);


--
-- Data for Name: PersonelBelgeGecmis; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: PersonelDeneyim; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('8cb56648-64db-484a-ba9c-5997be9d10c6', '901f3169-ae9c-4cdd-b4c8-f3071bbb1363', NULL, 1, '29a24203-cc3e-463b-9285-bfafcd86b8fc', '2023-08-17 09:53:57.764083', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');
INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('8a466594-650c-4401-a91d-4639453ed94e', 'f40cf9f7-a698-4d92-8c76-23c1daea1356', NULL, 1, '65039682-f3e9-4c74-9d82-22bc1319ad04', '2023-08-17 09:54:12.697763', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');
INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('f0d362bf-dd64-4721-90c7-677b4de93532', '84bdf73a-10fa-4ef0-a9ec-681491dd12ed', NULL, 1, '9355e322-3e61-4acd-993a-8cad39131cb3', '2023-08-17 09:54:25.599704', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');
INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('25cf7528-6d9f-4209-8075-73817f25740c', 'caba194a-df76-41c6-b71f-368335d6f20f', NULL, 1, 'afa3e4b1-791f-4abf-a3c5-ae3543f33ca5', '2023-08-17 09:54:38.603096', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');
INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('2d912b67-3601-4c0f-a2e3-4e3684e05b94', 'ad3e778d-1ddc-4d8f-b273-2e4720890b3c', NULL, 1, '71f589c7-d34d-4718-9997-895b4ef8950c', '2023-08-17 09:54:55.7087', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');
INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('adeb4d6e-2176-49ea-b18d-03580f61d71e', '63624146-af1f-4c77-a253-64d4428ef1c8', NULL, 1, 'edf25a0a-15ea-40b2-83a1-925fb24dcbb6', '2023-08-17 13:05:46.849083', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');
INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('f93aeb40-21ec-4ce2-b507-1cf9f355d4e1', '6c4b6368-d259-4b38-9038-3639757e7cb6', NULL, 1, 'af2d2fd6-05f8-4d02-9309-c212cba2b3a0', '2023-08-18 08:48:56.680756', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');
INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('a70ba298-b285-4f49-8335-ee2d0c78ee17', '1afa2449-ddcd-405b-a224-16f73f771127', NULL, 1, '665cd006-73cb-478f-9779-688524f97b9e', '2023-08-18 10:24:21.825205', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');
INSERT INTO "e-ced-yeterlik"."PersonelDeneyim" VALUES ('2e6bf7a0-826d-4c25-8d4d-29858ebde669', 'e20facac-cf5e-4d09-b187-9421a1a5c1de', NULL, 1, 'e165e846-5b3b-465f-ab25-936652fdc365', '2023-08-18 12:27:08.4276', NULL, NULL, NULL, NULL, 'INFOLINE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', 'Yazılım Geliştiricisi', NULL, NULL, '2009158070601');


--
-- Data for Name: PersonelDeneyimEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelDeneyimEksiklik" VALUES ('d0950371-e004-4640-a7cd-ae87fd612138', '8cb56648-64db-484a-ba9c-5997be9d10c6', 1, 'b4bec33c-5c6c-4690-88ba-67a8658b72d7', '2023-08-17 06:58:15.131701', '4e182585-d766-4858-9341-dc39b3aa5ee9', '2023-08-17 06:58:17.187902', 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelDeneyimEksiklik" VALUES ('f20aa106-d038-4827-8b76-1385f96bdfcb', '8a466594-650c-4401-a91d-4639453ed94e', 1, 'f4cc4abe-3dfe-4a2e-a1cc-b585ec227f62', '2023-08-17 06:58:32.021702', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelDeneyimEksiklik" VALUES ('6133a3d0-f6ac-4adc-b0fe-d6d810e8ffc9', 'f0d362bf-dd64-4721-90c7-677b4de93532', 1, '077e636f-03f9-46a8-a3f1-ac8a805653aa', '2023-08-17 06:58:46.242451', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelDeneyimEksiklik" VALUES ('72f17c5b-e52b-4115-b685-d93a22b3dd48', '2d912b67-3601-4c0f-a2e3-4e3684e05b94', 1, '2cda77c6-0f34-4b6b-bc06-17148ab2d641', '2023-08-17 06:59:02.226581', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelDeneyimEksiklik" VALUES ('740df15b-de64-4d2e-9f02-ae4346e4183d', '25cf7528-6d9f-4209-8075-73817f25740c', 1, '74fa9a92-2271-46e0-9484-42a0078fd45d', '2023-08-17 06:59:17.725359', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelDeneyimEksiklik" VALUES ('cf155039-1492-4d4c-919a-674bc1a17a07', 'adeb4d6e-2176-49ea-b18d-03580f61d71e', 1, '225f9d13-4967-44dd-99c5-50f0a86d3b2a', '2023-08-17 10:09:52.529199', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelDeneyimEksiklik" VALUES ('60ff70c3-f2d3-46f6-99d7-a1045b5a7498', 'a70ba298-b285-4f49-8335-ee2d0c78ee17', 1, 'bb2a6502-7054-4d09-b564-7b5c1d57e18f', '2023-08-18 10:26:24.650253', NULL, NULL, 1, 1, NULL, NULL, NULL);


--
-- Data for Name: PersonelDeneyimGecmis; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: PersonelEgitim; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('3958fb9b-40c7-4959-9095-a0c7d29f6e4d', '901f3169-ae9c-4cdd-b4c8-f3071bbb1363', '1111b0e7-7aef-4475-ae7c-bf61b6378ea9', 1, 'cde06852-fe4b-49da-944e-e29828f7ac24', '2023-08-17 06:48:35.110476', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('bde9d432-c640-4d3f-a5dc-86624e4d4f12', 'f40cf9f7-a698-4d92-8c76-23c1daea1356', '1111b0e7-7aef-4475-da8c-0311b6026b21', 1, 'ebba98fb-7805-4aed-a7c8-ec3d7109a16a', '2023-08-17 06:49:37.116881', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('7d64fb31-31e4-476c-a6b0-5b2ec00c2bc1', '84bdf73a-10fa-4ef0-a9ec-681491dd12ed', '1167b0e7-7aef-4475-ae7c-0311b6378ef2', 1, 'fb171f47-e3b2-4fd2-a2a4-3dcbdf261da0', '2023-08-17 06:49:53.973078', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('bdca49df-301b-4b53-b4c8-ff03e77a5c24', 'ad3e778d-1ddc-4d8f-b273-2e4720890b3c', '9111b0e7-7aef-4bb5-ae7c-0311b6378af5', 1, '555d14c2-d5b9-4266-9dd7-889e3f415648', '2023-08-17 06:50:28.064179', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('e9378857-73f5-4c1d-8b72-dad9506b0afd', 'caba194a-df76-41c6-b71f-368335d6f20f', 'a511b1e7-7aef-4f1c-ae7c-d411b6372af7', 1, 'f8f66447-2f4b-4fda-8665-db1400701b00', '2023-08-17 06:51:06.55801', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('c4e83b02-828c-491a-a938-a72e373a4a31', '63624146-af1f-4c77-a253-64d4428ef1c8', '6711b0e7-7aef-4475-ae7c-0311b6378bd2', 1, 'cd4f9e5a-0cbc-4660-b68a-97077cba595b', '2023-08-17 08:42:12.368643', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('caf49b25-0eb8-4aa7-9846-3b3c9a5ee044', '6c4b6368-d259-4b38-9038-3639757e7cb6', '5116b0e7-7aef-a675-da8c-c3f1b6026b2b', 1, '59145f3a-20a7-451e-bc35-b9c5b4b6dc45', '2023-08-17 12:59:42.226398', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('16eef414-5a00-442f-9950-2bf8b8b512dc', '1afa2449-ddcd-405b-a224-16f73f771127', '4c11b0e7-7ae1-46b5-ae7c-43c1b6178afe', 1, 'd3eac18f-ba21-4847-8978-1fca62cb903e', '2023-08-18 10:24:17.678941', NULL, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitim" VALUES ('592aaebf-6352-41f1-989d-87a4dfa75c65', 'e20facac-cf5e-4d09-b187-9421a1a5c1de', '6111b0f7-7a5f-4475-da8c-2311b6378b40', 1, 'c9f83110-cfc3-40da-93a4-2e8a01e8741d', '2023-08-18 12:27:15.476643', NULL, NULL, NULL, NULL);


--
-- Data for Name: PersonelEgitimEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelEgitimEksiklik" VALUES ('f8ae57dc-70a7-4f98-8a36-60de51e43bb4', '3958fb9b-40c7-4959-9095-a0c7d29f6e4d', 1, '80cf0301-3b13-4d21-afe5-5ca6cacb9074', '2023-08-17 06:58:12.703812', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitimEksiklik" VALUES ('6b509c83-bf84-4f4d-963b-470e91e46419', 'bde9d432-c640-4d3f-a5dc-86624e4d4f12', 1, '45812df7-f1b5-4ce5-86f7-ee72061147f2', '2023-08-17 06:58:34.614896', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitimEksiklik" VALUES ('1a8d4958-b43b-4fde-9669-0e43b0386567', '7d64fb31-31e4-476c-a6b0-5b2ec00c2bc1', 1, 'aee81d8a-e215-4ef6-a0b7-7c009ef3fa2d', '2023-08-17 06:58:44.19759', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitimEksiklik" VALUES ('70850caf-6121-4cb6-9d67-51407bcfb6e9', 'bdca49df-301b-4b53-b4c8-ff03e77a5c24', 1, '6bf8fce0-b794-4f02-879f-976857361e28', '2023-08-17 06:59:04.626211', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitimEksiklik" VALUES ('cb6b8b5c-1300-42cc-8145-9774a90b19af', 'e9378857-73f5-4c1d-8b72-dad9506b0afd', 1, '63288e42-bb02-4dad-94fb-7fc30bbaf130', '2023-08-17 06:59:15.764587', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitimEksiklik" VALUES ('dac5804e-157f-4f97-9583-c66b0854b2b4', 'c4e83b02-828c-491a-a938-a72e373a4a31', 1, '51f04059-084e-48d7-9ca2-66380d49d733', '2023-08-17 10:09:50.255704', NULL, NULL, 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEgitimEksiklik" VALUES ('676ef74d-1085-4423-9f89-84cbbd1b1ce0', '16eef414-5a00-442f-9950-2bf8b8b512dc', 1, '0c0bfceb-4702-44fb-a836-83c7152e9f3d', '2023-08-18 10:26:22.46517', NULL, NULL, 1, 1, NULL, NULL, NULL);


--
-- Data for Name: PersonelEgitimGecmis; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: PersonelEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelEksiklik" VALUES ('de5a5693-ae40-48c3-a17a-06504c4526db', 'f40cf9f7-a698-4d92-8c76-23c1daea1356', 1, NULL, NULL, '757fed14-83d7-47e7-9004-c053b3edf3ce', '2023-08-17 06:58:36.676898', 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEksiklik" VALUES ('f2d795f1-c57f-4bb9-a17c-1f991e1429a8', '84bdf73a-10fa-4ef0-a9ec-681491dd12ed', 1, NULL, NULL, '3a65fa79-505d-4438-bdb2-8c4f8a7aeffe', '2023-08-17 06:58:41.905361', 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEksiklik" VALUES ('43143917-b2cb-48d9-8418-e1dd3bfe60a0', 'ad3e778d-1ddc-4d8f-b273-2e4720890b3c', 1, NULL, NULL, '16840fb8-43a8-4cc2-94c2-e9c7bc015e28', '2023-08-17 06:59:07.046308', 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEksiklik" VALUES ('5361fd4b-e38f-4552-b113-209fbf84fcd7', 'caba194a-df76-41c6-b71f-368335d6f20f', 1, NULL, NULL, 'c0138f76-f5ae-45cc-be00-6c6af058ef91', '2023-08-17 06:59:13.140836', 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEksiklik" VALUES ('07784522-3762-4cf5-a5fd-deb4b625367b', '63624146-af1f-4c77-a253-64d4428ef1c8', 1, NULL, NULL, '4eb01aaf-cf35-46bc-9205-644e98961199', '2023-08-17 10:09:48.064107', 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEksiklik" VALUES ('8640c953-e300-4f7a-b204-f34d07a2231a', '1afa2449-ddcd-405b-a224-16f73f771127', 1, NULL, NULL, '75edcabe-6bc4-4a85-a844-84c91f302cf4', '2023-08-18 10:26:20.176859', 1, 1, NULL, NULL, NULL);
INSERT INTO "e-ced-yeterlik"."PersonelEksiklik" VALUES ('09369350-a0e4-42a5-bf61-05cb75d08a98', '901f3169-ae9c-4cdd-b4c8-f3071bbb1363', 1, '2023-08-18 12:44:38.486433', '8047c470-40ae-4b78-81ce-fbfdceecf1b5', '76afc5ed-5a99-49d9-bcfd-05e0faf3a21b', '2023-08-17 06:58:09.329446', 1, 1, NULL, NULL, NULL);


--
-- Data for Name: PersonelGecmis; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: PersonelTalepIslem; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelTalepIslem" VALUES ('281a8ca3-e7b3-492b-9896-ae04ef767aa4', 'caba194a-df76-41c6-b71f-368335d6f20f', 1, 'cac26333-6000-46df-98d5-465c8e6c4101', '2023-08-17 08:40:08.954925', '8994557b-4600-40c3-b2b6-00a0e768835d', '2023-08-17 08:41:28.465204', 5, NULL, NULL, 'Aziz', 'Düzgün', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, 1, '');


--
-- Data for Name: PersonelTalepIslemAtama; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."PersonelTalepIslemAtama" VALUES ('679c19b3-6c07-4e93-a051-746734a80542', '281a8ca3-e7b3-492b-9896-ae04ef767aa4', 1, '598594b1-9465-4477-a29c-8c462b1b6692', '2023-08-17 08:40:09.850522', '4185378f-ce44-4c75-b102-74f2b7d2480c', '2023-08-17 08:40:40.213057', 'Atandı', '040824bf-dade-4667-bcc3-dc7fc943ceb8', '5fd5d9d9-0e13-4095-915e-c93ca1d37717');


--
-- Data for Name: SektorCED; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--

INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d74', 2, 'B', 3, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b6f', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d76', 2, 'A', 3, 1, '2023-03-25 14:09:37.186728', '12b0d899-c286-41cc-9796-c51a41428b6f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-25 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d78', 1, 'C', 3, 1, '2023-03-24 14:09:37.186728', '12a1d899-c286-41cc-9796-c51a41428b6f', '13a0d899-c286-41cc-9796-c51a41428b6f', '2023-03-24 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d79', 2, 'B', 10, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d80', 2, 'A', 10, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d81', 1, 'C', 10, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d82', 2, 'A', 19, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d83', 2, 'B', 19, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d84', 1, 'C', 19, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d85', 2, 'A', 20, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d86', 2, 'B', 20, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d87', 1, 'C', 20, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d88', 2, 'A', 22, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d89', 2, 'B', 22, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');
INSERT INTO "e-ced-yeterlik"."SektorCED" VALUES ('1111b0e7-7aef-4475-ae7c-0311b6375d90', 1, 'C', 22, 1, '2023-03-26 14:09:37.186728', '12a0d899-c286-41cc-9796-c51a41428b5f', '12a0d899-c286-41cc-9796-c51a41428b67', '2023-03-26 14:09:37.186728');


--
-- Data for Name: TestData; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: Vize; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: VizeAtama; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: VizeBelge; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: VizeBelgeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: VizeOdeme; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: VizeOdemeEksiklik; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: e-ced-yeterlik; Owner: -
--



--
-- Data for Name: BakanlikPersonelOdeme; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: BasvuruBelgeEksiklik; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--

INSERT INTO "e-yeterlik"."BasvuruBelgeEksiklik" VALUES ('8245873c-00a3-49b0-9d2b-e364c876e981', '3f4f35c7-7839-4c7c-ac67-f991bb450fa9', 1, NULL, NULL, NULL, 1, NULL, 1, '2023-08-20 01:26:07.24396', '81816826-5830-4da0-934c-8238ad1f01d0', NULL, NULL);
INSERT INTO "e-yeterlik"."BasvuruBelgeEksiklik" VALUES ('b4fbf9ed-c86f-4f53-94ec-ce8767980984', '49d8fa96-cf91-4960-ae88-dffc289d9f5c', 1, NULL, NULL, NULL, 1, NULL, 1, '2023-08-20 01:26:08.0887', 'aec19536-f928-4319-a906-1e3e1f38f121', NULL, NULL);


--
-- Data for Name: BasvuruDeneyimEksiklik; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--

INSERT INTO "e-yeterlik"."BasvuruDeneyimEksiklik" VALUES ('2d23281b-9d67-428c-a2a6-0f7531f04b1e', '077f7bc6-13ae-47b7-8a63-3e54ac4c726b', 1, NULL, NULL, NULL, 1, 1, '2023-08-20 01:25:58.129321', '48926484-428d-4fa5-9822-3d530e8c8773', NULL, NULL);


--
-- Data for Name: BasvuruEgitimEksiklik; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--

INSERT INTO "e-yeterlik"."BasvuruEgitimEksiklik" VALUES ('674d9b9a-5a9a-42aa-9845-37df8684d9b2', '21ad2034-1c42-4dc9-9fd0-d501e4efffcf', 1, NULL, NULL, NULL, 1, 1, '2023-08-20 01:25:47.397153', 'b8c6489a-e25f-4497-a761-59e4be7c03d7', NULL, NULL);


--
-- Data for Name: Belge; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--

INSERT INTO "e-yeterlik"."Belge" VALUES ('49d8fa96-cf91-4960-ae88-dffc289d9f5c', 'ec480425-d44d-4b38-9985-8cfd22848c12', 0, '2023-08-20 00:48:26.786853', '6d41d202-4976-453f-aa93-cb74bae4af2b', NULL, NULL, 'a24429b7-dd98-4663-a9a9-4d136b258d9b', 'Vesikalık', 'Fotoğraf');
INSERT INTO "e-yeterlik"."Belge" VALUES ('3f4f35c7-7839-4c7c-ac67-f991bb450fa9', '1d44a629-6ece-44d5-a842-0e509dd87398', 0, '2023-08-20 00:48:26.815266', 'b7a0ba9c-0f5c-4a3c-ae2b-45f99bce046a', NULL, NULL, 'a24429b7-dd98-4663-a9a9-4d136b258d9b', 'Dekont', 'Dekont');
INSERT INTO "e-yeterlik"."Belge" VALUES ('bc8b0245-cb8f-4df6-94cb-9a3b590f7af2', '97e46888-8943-4e72-8e38-fbe438326079', 0, '2023-08-20 22:45:48.547356', '272e0991-c16f-42cd-b7cf-67a4c2ced69e', NULL, NULL, '5f4c275d-98bc-4ccf-a6b5-07e202ba0644', 'Vesikalık', 'Fotoğraf');
INSERT INTO "e-yeterlik"."Belge" VALUES ('af3ba1bb-6e4b-4519-9450-6d1c61f23e4a', '7ea8491e-941b-4688-8d16-efd6cb06b2b7', 0, '2023-08-20 22:45:48.56906', 'c3aabada-3084-47ad-8a98-55959cf2c10e', NULL, NULL, '5f4c275d-98bc-4ccf-a6b5-07e202ba0644', 'Dekont', 'Dekont');


--
-- Data for Name: CevreYonetimBirimiBasvuru; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: CevreYonetimBirimiPersonelTesis; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: CevreYonetimBirimiTesis; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: CevreYonetimPersonel; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: CevreYonetimPersonelEksiklik; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: DanismanFirmaBasvuru; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: DanismanFirmaPersonel; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: DanismanPersonelEksiklik; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: Deneyim; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--

INSERT INTO "e-yeterlik"."Deneyim" VALUES ('077f7bc6-13ae-47b7-8a63-3e54ac4c726b', 'deneme', 'deneme', 'deneme', '2023-08-04 00:00:00', '2023-08-20 00:00:00', false, NULL, 0, '2023-08-20 00:48:15.972557', 'ec11d9e5-bb21-4666-b282-29cfeb62539a', NULL, NULL, 'a24429b7-dd98-4663-a9a9-4d136b258d9b');
INSERT INTO "e-yeterlik"."Deneyim" VALUES ('f94f50ad-ccca-4b5f-9ddb-3e9e24e3fef1', 'test görev', 'test kurum', 'test adres', '2023-04-01 00:00:00', '2023-08-20 22:45:37.589941', true, NULL, 0, '2023-08-20 22:45:37.589934', '553411db-41c5-4586-b0a3-7c6a2ca42c36', NULL, NULL, '5f4c275d-98bc-4ccf-a6b5-07e202ba0644');


--
-- Data for Name: Egitim; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--

INSERT INTO "e-yeterlik"."Egitim" VALUES ('21ad2034-1c42-4dc9-9fd0-d501e4efffcf', 'b6786f59-7059-45ef-99bd-77856dd92a0d', 0, 0, '2023-08-20 00:47:59.758226', 'e6ba876f-402a-489f-84be-c97dd8559d7d', NULL, NULL, 'a24429b7-dd98-4663-a9a9-4d136b258d9b', 'YuksekLisans', 'Hacettepe Üniversitesi', 'Bilgisayar Mühendisliği', '2018-12-08 00:00:00', 1, 'Mühendislik Fakültesi', '3.06');
INSERT INTO "e-yeterlik"."Egitim" VALUES ('8be9294a-3997-481a-bbd4-01cc89353f8d', 'd6c4ed14-98b7-415e-8330-9c6883ce9f18', 0, 0, '2023-08-20 22:46:00.759728', '3d757cbb-4348-4eca-bdfe-5e6c3b4fd6b6', NULL, NULL, '5f4c275d-98bc-4ccf-a6b5-07e202ba0644', 'Lisans', 'test', 'test', '2023-03-20 00:00:00', 0, 'test', '4.00');


--
-- Data for Name: KisiBasvuru; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--

INSERT INTO "e-yeterlik"."KisiBasvuru" VALUES ('225bf01e-680a-4225-9dae-fd1d32975ab0', 0, 0, '2023-08-20 00:48:50.076827', '9a09fc63-1f0f-4ca1-8e37-0dfa4555b1ee', '2023-08-21 10:06:53.307241', 'ae5cdf2a-6373-42cb-810b-aae3fe6e5bab', 7, 'a24429b7-dd98-4663-a9a9-4d136b258d9b', 'test', '040824bf-dade-4667-bcc3-dc7fc943ceb8', NULL, true, '2023-08-20 00:48:50.076787', '81607', '21.08.2023 10:06:53');
INSERT INTO "e-yeterlik"."KisiBasvuru" VALUES ('9664cf4d-e3c0-4991-b9e3-dd9e8a5048b2', 0, 0, '2023-08-20 22:46:44.236218', '221495ea-947f-4d5e-8237-a255907decff', NULL, NULL, 3, '5f4c275d-98bc-4ccf-a6b5-07e202ba0644', 'x', NULL, NULL, true, '2023-08-20 22:46:44.236128', NULL, NULL);


--
-- Data for Name: Not; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: ReferansNumarasi; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--

INSERT INTO "e-yeterlik"."ReferansNumarasi" VALUES ('0402a2c5-8fc5-47d7-be01-d0d45003437f', 'a24429b7-dd98-4663-a9a9-4d136b258d9b', '1492799474', 0, 1, -1, '2023-08-18 15:08:23.375761', 'a863d3a1-fde3-4b98-9d7a-dc2016f5c84d', '2023-08-20 00:47:42.539118', 'f32825ef-3e4d-4ab8-8c21-7947996cb43b', true, 10000, NULL);
INSERT INTO "e-yeterlik"."ReferansNumarasi" VALUES ('528c8980-1241-4db2-b1f4-0f583e55b10d', '5f4c275d-98bc-4ccf-a6b5-07e202ba0644', '1492799474', 0, 1, 1, '2023-08-20 22:20:23.509658', 'fb02ffdc-e89e-46cf-9996-12d01df56fc0', '2023-08-20 22:20:33.331695', '6a39e99b-7147-4d55-a9f5-7e06b338601d', true, 10000, NULL);
INSERT INTO "e-yeterlik"."ReferansNumarasi" VALUES ('0e8eb1e8-5f71-4ae5-a6c1-b164386b3628', '5f4c275d-98bc-4ccf-a6b5-07e202ba0644', '1492799474', 0, 1, 1, '2023-08-20 22:20:38.000783', '7733db65-8839-4d7d-bf68-8f9475a05266', '2023-08-20 22:46:12.667468', 'bdfb7d2e-61e1-4882-ab18-a0eaf838bb18', true, 10000, NULL);
INSERT INTO "e-yeterlik"."ReferansNumarasi" VALUES ('bd4e3b6f-39c1-4436-9ffb-138356e8ec32', '16f6593a-ef96-4d02-8e63-066d0c15f9b8', '1492799474', 0, 5, 0, '2023-08-21 06:07:33.809944', '06b3c83d-21b1-4288-9faf-e8027e633685', NULL, NULL, false, 10000, NULL);


--
-- Data for Name: TamZamanliPersonel; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: e-yeterlik; Owner: -
--



--
-- Data for Name: BakanlikPersonelOdeme; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: BasvuruBelgeEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: BasvuruDeneyimEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: BasvuruEgitimEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Belge; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: CevreYonetimBirimiBasvuru; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: CevreYonetimBirimiPersonelTesis; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: CevreYonetimBirimiTesis; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."CevreYonetimBirimiTesis" VALUES ('1e25939e-2236-4c51-b552-68efe2374090', 0, '1a3cd70b-308a-4b2c-ae7c-8cb39e74959e', '2023-05-10 11:46:00.04018', NULL, NULL, '152856127682', '143454356355', '4780558379', '852acd3a-d9d1-4170-be8f-8acf580d04e7', '00000000-0000-0000-0000-000000000000', 'Infoline Bilgi Teknolojileri Tic. A.Ş.', 'İstanbul Şube');
INSERT INTO public."CevreYonetimBirimiTesis" VALUES ('60bf764f-8550-4943-90a6-9f0c98c5b438', 0, '1d5463ba-f9bd-4aa4-9bc0-542e9477b234', '2023-05-10 11:46:00.040172', NULL, NULL, '152856127683', '143454356355', '4780558379', '852acd3a-d9d1-4170-be8f-8acf580d04e7', '00000000-0000-0000-0000-000000000000', 'Infoline Bilgi Teknolojileri Tic. A.Ş.', 'Ankara Şube');
INSERT INTO public."CevreYonetimBirimiTesis" VALUES ('5fa1cbbe-35e2-4957-b6fb-9c4372854a18', 0, '45ab4edb-c9ff-4fa3-880b-b9eb0c215b53', '2023-05-10 11:46:38.586083', NULL, NULL, '152856127683', '143454356355', '4780558379', '852acd3a-d9d1-4170-be8f-8acf580d04e7', '00000000-0000-0000-0000-000000000000', 'Infoline Bilgi Teknolojileri Tic. A.Ş.', 'Ankara Şube');
INSERT INTO public."CevreYonetimBirimiTesis" VALUES ('7a6e40f0-0171-4a31-a6ae-ef60ab78f035', 0, '65c94825-2a69-4fc5-a656-9a3c255ee091', '2023-05-10 11:46:51.947081', NULL, NULL, '152856127685', '143454356355', '4780558379', '852acd3a-d9d1-4170-be8f-8acf580d04e7', '00000000-0000-0000-0000-000000000000', 'Infoline Bilgi Teknolojileri Tic. A.Ş.', 'izmir Şube');


--
-- Data for Name: CevreYonetimPersonel; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: CevreYonetimPersonelEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: DanismanFirmaBasvuru; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: DanismanFirmaPersonel; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: DanismanPersonelEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Deneyim; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Egitim; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: KisiBasvuru; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Not; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ReferansNumarasi; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ReferansNumarasi" VALUES ('1bbe3d11-7748-4474-b54e-15526f8cb6a9', '252f3ac6-5063-48f9-986e-fb62217afd61', '1492799474', 0, 4, 1, '2023-06-21 11:41:51.485054', '53308023-507f-432a-8203-392eefc1a55b', '2023-06-21 17:29:29.516438', '17bb266f-32b7-4888-9602-f47e57c4563c', true, 10000, NULL);


--
-- Data for Name: TamZamanliPersonel; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."__EFMigrationsHistory" VALUES ('20230126114943_first migration', '7.0.2');
INSERT INTO public."__EFMigrationsHistory" VALUES ('20230130113611_first-migration', '7.0.2');
INSERT INTO public."__EFMigrationsHistory" VALUES ('20230203082753_basemodel-migration', '7.0.1');
INSERT INTO public."__EFMigrationsHistory" VALUES ('20230203111921_Base model degistirildi', '7.0.1');


--
-- Name: AskiTalep AskiTalep_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."AskiTalep"
    ADD CONSTRAINT "AskiTalep_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Aski Aski_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Aski"
    ADD CONSTRAINT "Aski_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruAtama BasvuruAtama_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruAtama"
    ADD CONSTRAINT "BasvuruAtama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruBelgeEksiklik BasvuruBelgeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruBelgeEksiklik"
    ADD CONSTRAINT "BasvuruBelgeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruBelgeGecmis BasvuruBelgeLog_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruBelgeGecmis"
    ADD CONSTRAINT "BasvuruBelgeLog_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruBelge BasvuruBelge_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruBelge"
    ADD CONSTRAINT "BasvuruBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruEksiklik BasvuruEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruEksiklik"
    ADD CONSTRAINT "BasvuruEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruLog BasvuruLog_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruLog"
    ADD CONSTRAINT "BasvuruLog_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruOdemeEksiklik BasvuruOdemeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruOdemeEksiklik"
    ADD CONSTRAINT "BasvuruOdemeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruOdeme BasvuruOdeme_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruOdeme"
    ADD CONSTRAINT "BasvuruOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruReferansNo BasvuruReferansNo_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruReferansNo"
    ADD CONSTRAINT "BasvuruReferansNo_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Basvuru Basvuru_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Basvuru"
    ADD CONSTRAINT "Basvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CezaTalep CezaTalep_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."CezaTalep"
    ADD CONSTRAINT "CezaTalep_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CezaTur CezaTur_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."CezaTur"
    ADD CONSTRAINT "CezaTur_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Ceza Ceza_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Ceza"
    ADD CONSTRAINT "Ceza_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaAdresAtama FirmaAdresAtama_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresAtama"
    ADD CONSTRAINT "FirmaAdresAtama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaAdresBelgeEksiklik FirmaAdresBelgeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresBelgeEksiklik"
    ADD CONSTRAINT "FirmaAdresBelgeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaAdresBelge FirmaAdresBelge_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresBelge"
    ADD CONSTRAINT "FirmaAdresBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaAdresOdemeEksiklik FirmaAdresOdemeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresOdemeEksiklik"
    ADD CONSTRAINT "FirmaAdresOdemeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaAdresOdeme FirmaAdresOdeme_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresOdeme"
    ADD CONSTRAINT "FirmaAdresOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaAdres FirmaAdres_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdres"
    ADD CONSTRAINT "FirmaAdres_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaUnvanAtama FirmaUnvanAtama_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanAtama"
    ADD CONSTRAINT "FirmaUnvanAtama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaUnvanBelgeEksiklik FirmaUnvanBelgeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik"
    ADD CONSTRAINT "FirmaUnvanBelgeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaUnvanBelge FirmaUnvanBelge_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanBelge"
    ADD CONSTRAINT "FirmaUnvanBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaUnvanOdemeEksiklik FirmaUnvanOdemeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanOdemeEksiklik"
    ADD CONSTRAINT "FirmaUnvanOdemeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaUnvanOdeme FirmaUnvanOdeme_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanOdeme"
    ADD CONSTRAINT "FirmaUnvanOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: FirmaUnvan FirmaUnvan_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvan"
    ADD CONSTRAINT "FirmaUnvan_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: IptalTalep IptalTalep_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."IptalTalep"
    ADD CONSTRAINT "IptalTalep_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Iptal Iptal_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Iptal"
    ADD CONSTRAINT "Iptal_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TestData PK_TestData; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."TestData"
    ADD CONSTRAINT "PK_TestData" PRIMARY KEY ("Id");


--
-- Name: Personel PK_YeterlikBasvuru; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Personel"
    ADD CONSTRAINT "PK_YeterlikBasvuru" PRIMARY KEY ("Kimlik");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: PersonelBelgeEksiklik PersonelBelgeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelBelgeEksiklik"
    ADD CONSTRAINT "PersonelBelgeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelBelgeGecmis PersonelBelgeLog_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelBelgeGecmis"
    ADD CONSTRAINT "PersonelBelgeLog_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelBelge PersonelBelge_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelBelge"
    ADD CONSTRAINT "PersonelBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelDeneyimEksiklik PersonelDeneyimEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelDeneyimEksiklik"
    ADD CONSTRAINT "PersonelDeneyimEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelDeneyimGecmis PersonelDeneyimLog_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelDeneyimGecmis"
    ADD CONSTRAINT "PersonelDeneyimLog_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelDeneyim PersonelDeneyim_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelDeneyim"
    ADD CONSTRAINT "PersonelDeneyim_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelEgitimEksiklik PersonelEgitimEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelEgitimEksiklik"
    ADD CONSTRAINT "PersonelEgitimEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelEgitimGecmis PersonelEgitimLog_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelEgitimGecmis"
    ADD CONSTRAINT "PersonelEgitimLog_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelEgitim PersonelEgitim_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelEgitim"
    ADD CONSTRAINT "PersonelEgitim_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelEksiklik PersonelEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelEksiklik"
    ADD CONSTRAINT "PersonelEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelGecmis PersonelLog_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelGecmis"
    ADD CONSTRAINT "PersonelLog_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelTalepIslemAtama PersonelTalepIslemAtama_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelTalepIslemAtama"
    ADD CONSTRAINT "PersonelTalepIslemAtama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: PersonelTalepIslem PersonelTalepIslem_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelTalepIslem"
    ADD CONSTRAINT "PersonelTalepIslem_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: SektorCED SektorCED_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."SektorCED"
    ADD CONSTRAINT "SektorCED_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: VizeAtama VizeAtama_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeAtama"
    ADD CONSTRAINT "VizeAtama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: VizeBelgeEksiklik VizeBelgeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeBelgeEksiklik"
    ADD CONSTRAINT "VizeBelgeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: VizeBelge VizeBelge_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeBelge"
    ADD CONSTRAINT "VizeBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: VizeOdemeEksiklik VizeOdemeEksiklik_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeOdemeEksiklik"
    ADD CONSTRAINT "VizeOdemeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: VizeOdeme VizeOdeme_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeOdeme"
    ADD CONSTRAINT "VizeOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Vize Vize_pkey; Type: CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Vize"
    ADD CONSTRAINT "Vize_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BakanlikPersonelOdeme BakanlikPersonelOdeme_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."BakanlikPersonelOdeme"
    ADD CONSTRAINT "BakanlikPersonelOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruBelgeEksiklik BasvuruBelgeEksiklik_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."BasvuruBelgeEksiklik"
    ADD CONSTRAINT "BasvuruBelgeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruDeneyimEksiklik BasvuruDeneyimEksiklik_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."BasvuruDeneyimEksiklik"
    ADD CONSTRAINT "BasvuruDeneyimEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruEgitimEksiklik BasvuruEgitimEksiklik_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."BasvuruEgitimEksiklik"
    ADD CONSTRAINT "BasvuruEgitimEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimBirimiBasvuru CevreYonetimBirimiBasvuru_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."CevreYonetimBirimiBasvuru"
    ADD CONSTRAINT "CevreYonetimBirimiBasvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimBirimiPersonelTesis CevreYonetimBirimiPersonelTesis_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."CevreYonetimBirimiPersonelTesis"
    ADD CONSTRAINT "CevreYonetimBirimiPersonelTesis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimBirimiTesis CevreYonetimBirimiTesis_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."CevreYonetimBirimiTesis"
    ADD CONSTRAINT "CevreYonetimBirimiTesis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimPersonelEksiklik CevreYonetimPersonelEksiklik_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."CevreYonetimPersonelEksiklik"
    ADD CONSTRAINT "CevreYonetimPersonelEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimPersonel CevreYonetimiPersonel_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."CevreYonetimPersonel"
    ADD CONSTRAINT "CevreYonetimiPersonel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: DanismanFirmaBasvuru DanismanFirmaBasvuru_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."DanismanFirmaBasvuru"
    ADD CONSTRAINT "DanismanFirmaBasvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: DanismanFirmaPersonel DanismanFirmaPersonel_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."DanismanFirmaPersonel"
    ADD CONSTRAINT "DanismanFirmaPersonel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: DanismanPersonelEksiklik DanismanPersonelEksiklik_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."DanismanPersonelEksiklik"
    ADD CONSTRAINT "DanismanPersonelEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Deneyim Deneyim_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."Deneyim"
    ADD CONSTRAINT "Deneyim_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Egitim Egitim_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."Egitim"
    ADD CONSTRAINT "Egitim_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Belge KisiBelge_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."Belge"
    ADD CONSTRAINT "KisiBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Not Not_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."Not"
    ADD CONSTRAINT "Not_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: KisiBasvuru PK_Basvuru; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."KisiBasvuru"
    ADD CONSTRAINT "PK_Basvuru" PRIMARY KEY ("Kimlik");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: ReferansNumarasi ReferansNo_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."ReferansNumarasi"
    ADD CONSTRAINT "ReferansNo_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TamZamanliPersonel TamZamanliPersonel_pkey; Type: CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."TamZamanliPersonel"
    ADD CONSTRAINT "TamZamanliPersonel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BakanlikPersonelOdeme BakanlikPersonelOdeme_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BakanlikPersonelOdeme"
    ADD CONSTRAINT "BakanlikPersonelOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruBelgeEksiklik BasvuruBelgeEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruBelgeEksiklik"
    ADD CONSTRAINT "BasvuruBelgeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruDeneyimEksiklik BasvuruDeneyimEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruDeneyimEksiklik"
    ADD CONSTRAINT "BasvuruDeneyimEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruEgitimEksiklik BasvuruEgitimEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruEgitimEksiklik"
    ADD CONSTRAINT "BasvuruEgitimEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimBirimiBasvuru CevreYonetimBirimiBasvuru_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreYonetimBirimiBasvuru"
    ADD CONSTRAINT "CevreYonetimBirimiBasvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimBirimiPersonelTesis CevreYonetimBirimiPersonelTesis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreYonetimBirimiPersonelTesis"
    ADD CONSTRAINT "CevreYonetimBirimiPersonelTesis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimBirimiTesis CevreYonetimBirimiTesis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreYonetimBirimiTesis"
    ADD CONSTRAINT "CevreYonetimBirimiTesis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimPersonelEksiklik CevreYonetimPersonelEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreYonetimPersonelEksiklik"
    ADD CONSTRAINT "CevreYonetimPersonelEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreYonetimPersonel CevreYonetimiPersonel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreYonetimPersonel"
    ADD CONSTRAINT "CevreYonetimiPersonel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: DanismanFirmaBasvuru DanismanFirmaBasvuru_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DanismanFirmaBasvuru"
    ADD CONSTRAINT "DanismanFirmaBasvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: DanismanFirmaPersonel DanismanFirmaPersonel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DanismanFirmaPersonel"
    ADD CONSTRAINT "DanismanFirmaPersonel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: DanismanPersonelEksiklik DanismanPersonelEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DanismanPersonelEksiklik"
    ADD CONSTRAINT "DanismanPersonelEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Deneyim Deneyim_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Deneyim"
    ADD CONSTRAINT "Deneyim_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Egitim Egitim_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Egitim"
    ADD CONSTRAINT "Egitim_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Belge KisiBelge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Belge"
    ADD CONSTRAINT "KisiBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Not Not_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Not"
    ADD CONSTRAINT "Not_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: KisiBasvuru PK_Basvuru; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."KisiBasvuru"
    ADD CONSTRAINT "PK_Basvuru" PRIMARY KEY ("Kimlik");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: ReferansNumarasi ReferansNo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ReferansNumarasi"
    ADD CONSTRAINT "ReferansNo_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TamZamanliPersonel TamZamanliPersonel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TamZamanliPersonel"
    ADD CONSTRAINT "TamZamanliPersonel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: fki_AskiTalep_Aski; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_AskiTalep_Aski" ON "e-ced-yeterlik"."Aski" USING btree ("AskiTalepKimlik");


--
-- Name: fki_BasvuruAtama_Basvuru; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_BasvuruAtama_Basvuru" ON "e-ced-yeterlik"."BasvuruAtama" USING btree ("BasvuruKimlik");


--
-- Name: fki_BasvuruBelge_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_BasvuruBelge_Eksiklik" ON "e-ced-yeterlik"."BasvuruBelgeEksiklik" USING btree ("BasvuruBelgeKimlik");


--
-- Name: fki_BasvuruOdeme_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_BasvuruOdeme_Eksiklik" ON "e-ced-yeterlik"."BasvuruOdemeEksiklik" USING btree ("BasvuruOdemeKimlik");


--
-- Name: fki_Basvuru_BasvuruAtama; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Basvuru_BasvuruAtama" ON "e-ced-yeterlik"."BasvuruAtama" USING btree ("BasvuruKimlik");


--
-- Name: fki_Basvuru_BasvuruBelge; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Basvuru_BasvuruBelge" ON "e-ced-yeterlik"."BasvuruBelge" USING btree ("BasvuruKimlik");


--
-- Name: fki_Basvuru_BasvuruEksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Basvuru_BasvuruEksiklik" ON "e-ced-yeterlik"."BasvuruEksiklik" USING btree ("BasvuruKimlik");


--
-- Name: fki_Basvuru_BasvuruOdeme; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Basvuru_BasvuruOdeme" ON "e-ced-yeterlik"."BasvuruOdeme" USING btree ("BasvuruKimlik");


--
-- Name: fki_Basvuru_BasvuruReferans; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Basvuru_BasvuruReferans" ON "e-ced-yeterlik"."BasvuruReferansNo" USING btree ("BasvuruKimlik");


--
-- Name: fki_Basvuru_askiTalep; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Basvuru_askiTalep" ON "e-ced-yeterlik"."AskiTalep" USING btree ("BasvuruKimlik");


--
-- Name: fki_Ceza_CezaTalep; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Ceza_CezaTalep" ON "e-ced-yeterlik"."Ceza" USING btree ("CezaTalepKimlik");


--
-- Name: fki_FirmaAdresBelge_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaAdresBelge_Eksiklik" ON "e-ced-yeterlik"."FirmaAdresBelgeEksiklik" USING btree ("FirmaAdresBelgeKimlik");


--
-- Name: fki_FirmaAdresOdeme_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaAdresOdeme_Eksiklik" ON "e-ced-yeterlik"."FirmaAdresOdemeEksiklik" USING btree ("FirmaAdresOdemeKimlik");


--
-- Name: fki_FirmaAdres_Atama; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaAdres_Atama" ON "e-ced-yeterlik"."FirmaAdresAtama" USING btree ("FirmaAdresKimlik");


--
-- Name: fki_FirmaAdres_Belge; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaAdres_Belge" ON "e-ced-yeterlik"."FirmaAdresBelge" USING btree ("FirmaAdresKimlik");


--
-- Name: fki_FirmaAdres_Odeme; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaAdres_Odeme" ON "e-ced-yeterlik"."FirmaAdresOdeme" USING btree ("FirmaAdresKimlik");


--
-- Name: fki_FirmaUnvanBelgeEksiklik_FirmaUnvanBelge; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaUnvanBelgeEksiklik_FirmaUnvanBelge" ON "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik" USING btree ("FirmaUnvanBelgeKimlik");


--
-- Name: fki_FirmaUnvanBelge_FirmaUnvanBelgeEksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaUnvanBelge_FirmaUnvanBelgeEksiklik" ON "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik" USING btree ("FirmaUnvanBelgeKimlik");


--
-- Name: fki_FirmaUnvan_Atama; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaUnvan_Atama" ON "e-ced-yeterlik"."FirmaUnvanAtama" USING btree ("FirmaUnvanKimlik");


--
-- Name: fki_FirmaUnvan_Belge; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaUnvan_Belge" ON "e-ced-yeterlik"."FirmaUnvanBelge" USING btree ("FirmaUnvanKimlik");


--
-- Name: fki_FirmaUnvan_FirmaUnvanOdeme; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_FirmaUnvan_FirmaUnvanOdeme" ON "e-ced-yeterlik"."FirmaUnvanOdeme" USING btree ("FirmaUnvanKimlik");


--
-- Name: fki_Iptal_Basvuru; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Iptal_Basvuru" ON "e-ced-yeterlik"."IptalTalep" USING btree ("BasvuruKimlik");


--
-- Name: fki_Iptal_IptalTalep; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Iptal_IptalTalep" ON "e-ced-yeterlik"."Iptal" USING btree ("IptalTalepKimlik");


--
-- Name: fki_PersonelBelge_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_PersonelBelge_Eksiklik" ON "e-ced-yeterlik"."PersonelBelgeEksiklik" USING btree ("PersonelBelgeKimlik");


--
-- Name: fki_PersonelDeneyim_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_PersonelDeneyim_Eksiklik" ON "e-ced-yeterlik"."PersonelDeneyimEksiklik" USING btree ("PersonelDeneyimKimlik");


--
-- Name: fki_PersonelEgitim_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_PersonelEgitim_Eksiklik" ON "e-ced-yeterlik"."PersonelEgitimEksiklik" USING btree ("PersonelEgitimKimlik");


--
-- Name: fki_Personel_Basvuru; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Personel_Basvuru" ON "e-ced-yeterlik"."Personel" USING btree ("BasvuruKimlik");


--
-- Name: fki_Personel_PersonelBege; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Personel_PersonelBege" ON "e-ced-yeterlik"."PersonelBelge" USING btree ("KullaniciKimlik");


--
-- Name: fki_Personel_PersonelEgitim; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Personel_PersonelEgitim" ON "e-ced-yeterlik"."PersonelEgitim" USING btree ("KullaniciKimlik");


--
-- Name: fki_Personel_PersonelEksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Personel_PersonelEksiklik" ON "e-ced-yeterlik"."PersonelEksiklik" USING btree ("PersonelKimlik");


--
-- Name: fki_Personel_PersonelTalep; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Personel_PersonelTalep" ON "e-ced-yeterlik"."PersonelTalepIslem" USING btree ("PersonelKimlik");


--
-- Name: fki_TalepIslem_TalepIslemAtama; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_TalepIslem_TalepIslemAtama" ON "e-ced-yeterlik"."PersonelTalepIslemAtama" USING btree ("PersonelTalepIslemKimlik");


--
-- Name: fki_VizeBelge_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_VizeBelge_Eksiklik" ON "e-ced-yeterlik"."VizeBelgeEksiklik" USING btree ("VizeBelgeKimlik");


--
-- Name: fki_VizeOdeme_Eksiklik; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_VizeOdeme_Eksiklik" ON "e-ced-yeterlik"."VizeOdemeEksiklik" USING btree ("VizeOdemeKimlik");


--
-- Name: fki_Vize_Basvuru; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Vize_Basvuru" ON "e-ced-yeterlik"."Vize" USING btree ("BasvuruKimlik");


--
-- Name: fki_Vize_VizeAtama; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Vize_VizeAtama" ON "e-ced-yeterlik"."VizeAtama" USING btree ("VizeKimlik");


--
-- Name: fki_Vize_VizeBelge; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Vize_VizeBelge" ON "e-ced-yeterlik"."VizeBelge" USING btree ("VizeKimlik");


--
-- Name: fki_Vize_VizeOdeme; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Vize_VizeOdeme" ON "e-ced-yeterlik"."VizeOdeme" USING btree ("VizeKimlik");


--
-- Name: fki_f; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX fki_f ON "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik" USING btree ("FirmaUnvanBelgeKimlik");


--
-- Name: fki_Ğ; Type: INDEX; Schema: e-ced-yeterlik; Owner: -
--

CREATE INDEX "fki_Ğ" ON "e-ced-yeterlik"."PersonelDeneyim" USING btree ("KullaniciKimlik");


--
-- Name: Aski AskiTalep_Aski; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Aski"
    ADD CONSTRAINT "AskiTalep_Aski" FOREIGN KEY ("AskiTalepKimlik") REFERENCES "e-ced-yeterlik"."AskiTalep"("Kimlik");


--
-- Name: BasvuruBelgeEksiklik BasvuruBelge_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruBelgeEksiklik"
    ADD CONSTRAINT "BasvuruBelge_Eksiklik" FOREIGN KEY ("BasvuruBelgeKimlik") REFERENCES "e-ced-yeterlik"."BasvuruBelge"("Kimlik");


--
-- Name: BasvuruOdemeEksiklik BasvuruOdeme_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruOdemeEksiklik"
    ADD CONSTRAINT "BasvuruOdeme_Eksiklik" FOREIGN KEY ("BasvuruOdemeKimlik") REFERENCES "e-ced-yeterlik"."BasvuruOdeme"("Kimlik");


--
-- Name: BasvuruAtama Basvuru_BasvuruAtama; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruAtama"
    ADD CONSTRAINT "Basvuru_BasvuruAtama" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: BasvuruBelge Basvuru_BasvuruBelge; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruBelge"
    ADD CONSTRAINT "Basvuru_BasvuruBelge" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: BasvuruEksiklik Basvuru_BasvuruEksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruEksiklik"
    ADD CONSTRAINT "Basvuru_BasvuruEksiklik" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: BasvuruOdeme Basvuru_BasvuruOdeme; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruOdeme"
    ADD CONSTRAINT "Basvuru_BasvuruOdeme" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: BasvuruReferansNo Basvuru_BasvuruReferans; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."BasvuruReferansNo"
    ADD CONSTRAINT "Basvuru_BasvuruReferans" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: AskiTalep Basvuru_askiTalep; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."AskiTalep"
    ADD CONSTRAINT "Basvuru_askiTalep" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: Ceza Ceza_CezaTalep; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Ceza"
    ADD CONSTRAINT "Ceza_CezaTalep" FOREIGN KEY ("CezaTalepKimlik") REFERENCES "e-ced-yeterlik"."CezaTalep"("Kimlik");


--
-- Name: FirmaAdresBelgeEksiklik FirmaAdresBelge_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresBelgeEksiklik"
    ADD CONSTRAINT "FirmaAdresBelge_Eksiklik" FOREIGN KEY ("FirmaAdresBelgeKimlik") REFERENCES "e-ced-yeterlik"."FirmaAdresBelge"("Kimlik");


--
-- Name: FirmaAdresOdemeEksiklik FirmaAdresOdeme_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresOdemeEksiklik"
    ADD CONSTRAINT "FirmaAdresOdeme_Eksiklik" FOREIGN KEY ("FirmaAdresOdemeKimlik") REFERENCES "e-ced-yeterlik"."FirmaAdresOdeme"("Kimlik");


--
-- Name: FirmaAdresAtama FirmaAdres_Atama; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresAtama"
    ADD CONSTRAINT "FirmaAdres_Atama" FOREIGN KEY ("FirmaAdresKimlik") REFERENCES "e-ced-yeterlik"."FirmaAdres"("Kimlik");


--
-- Name: FirmaAdresBelge FirmaAdres_Belge; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresBelge"
    ADD CONSTRAINT "FirmaAdres_Belge" FOREIGN KEY ("FirmaAdresKimlik") REFERENCES "e-ced-yeterlik"."FirmaAdres"("Kimlik");


--
-- Name: FirmaAdresOdeme FirmaAdres_Odeme; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaAdresOdeme"
    ADD CONSTRAINT "FirmaAdres_Odeme" FOREIGN KEY ("FirmaAdresKimlik") REFERENCES "e-ced-yeterlik"."FirmaAdres"("Kimlik");


--
-- Name: FirmaUnvanBelgeEksiklik FirmaUnvanBelgeEksiklik_FirmaUnvanBelge; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanBelgeEksiklik"
    ADD CONSTRAINT "FirmaUnvanBelgeEksiklik_FirmaUnvanBelge" FOREIGN KEY ("FirmaUnvanBelgeKimlik") REFERENCES "e-ced-yeterlik"."FirmaUnvanBelge"("Kimlik");


--
-- Name: FirmaUnvanOdemeEksiklik FirmaUnvanOdeme_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanOdemeEksiklik"
    ADD CONSTRAINT "FirmaUnvanOdeme_Eksiklik" FOREIGN KEY ("FirmaUnvanOdemeKimlik") REFERENCES "e-ced-yeterlik"."FirmaUnvanOdeme"("Kimlik");


--
-- Name: FirmaUnvanAtama FirmaUnvan_Atama; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanAtama"
    ADD CONSTRAINT "FirmaUnvan_Atama" FOREIGN KEY ("FirmaUnvanKimlik") REFERENCES "e-ced-yeterlik"."FirmaUnvan"("Kimlik");


--
-- Name: FirmaUnvanBelge FirmaUnvan_Belge; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanBelge"
    ADD CONSTRAINT "FirmaUnvan_Belge" FOREIGN KEY ("FirmaUnvanKimlik") REFERENCES "e-ced-yeterlik"."FirmaUnvan"("Kimlik");


--
-- Name: FirmaUnvanOdeme FirmaUnvan_FirmaUnvanOdeme; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."FirmaUnvanOdeme"
    ADD CONSTRAINT "FirmaUnvan_FirmaUnvanOdeme" FOREIGN KEY ("FirmaUnvanKimlik") REFERENCES "e-ced-yeterlik"."FirmaUnvan"("Kimlik");


--
-- Name: IptalTalep Iptal_Basvuru; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."IptalTalep"
    ADD CONSTRAINT "Iptal_Basvuru" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: Iptal Iptal_IptalTalep; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Iptal"
    ADD CONSTRAINT "Iptal_IptalTalep" FOREIGN KEY ("IptalTalepKimlik") REFERENCES "e-ced-yeterlik"."IptalTalep"("Kimlik");


--
-- Name: PersonelBelgeEksiklik PersonelBelge_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelBelgeEksiklik"
    ADD CONSTRAINT "PersonelBelge_Eksiklik" FOREIGN KEY ("PersonelBelgeKimlik") REFERENCES "e-ced-yeterlik"."PersonelBelge"("Kimlik");


--
-- Name: PersonelDeneyimEksiklik PersonelDeneyim_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelDeneyimEksiklik"
    ADD CONSTRAINT "PersonelDeneyim_Eksiklik" FOREIGN KEY ("PersonelDeneyimKimlik") REFERENCES "e-ced-yeterlik"."PersonelDeneyim"("Kimlik");


--
-- Name: PersonelEgitimEksiklik PersonelEgitim_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelEgitimEksiklik"
    ADD CONSTRAINT "PersonelEgitim_Eksiklik" FOREIGN KEY ("PersonelEgitimKimlik") REFERENCES "e-ced-yeterlik"."PersonelEgitim"("Kimlik");


--
-- Name: Personel Personel_BasvuruKimlik_fkey; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Personel"
    ADD CONSTRAINT "Personel_BasvuruKimlik_fkey" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: PersonelBelge Personel_PersonelBege; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelBelge"
    ADD CONSTRAINT "Personel_PersonelBege" FOREIGN KEY ("KullaniciKimlik") REFERENCES "e-ced-yeterlik"."Personel"("Kimlik");


--
-- Name: PersonelDeneyim Personel_PersonelDeneyim; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelDeneyim"
    ADD CONSTRAINT "Personel_PersonelDeneyim" FOREIGN KEY ("KullaniciKimlik") REFERENCES "e-ced-yeterlik"."Personel"("Kimlik");


--
-- Name: PersonelEgitim Personel_PersonelEgitim; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelEgitim"
    ADD CONSTRAINT "Personel_PersonelEgitim" FOREIGN KEY ("KullaniciKimlik") REFERENCES "e-ced-yeterlik"."Personel"("Kimlik");


--
-- Name: PersonelEksiklik Personel_PersonelEksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelEksiklik"
    ADD CONSTRAINT "Personel_PersonelEksiklik" FOREIGN KEY ("PersonelKimlik") REFERENCES "e-ced-yeterlik"."Personel"("Kimlik");


--
-- Name: PersonelTalepIslem Personel_PersonelTalep; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelTalepIslem"
    ADD CONSTRAINT "Personel_PersonelTalep" FOREIGN KEY ("PersonelKimlik") REFERENCES "e-ced-yeterlik"."Personel"("Kimlik");


--
-- Name: PersonelTalepIslemAtama TalepIslem_TalepIslemAtama; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."PersonelTalepIslemAtama"
    ADD CONSTRAINT "TalepIslem_TalepIslemAtama" FOREIGN KEY ("PersonelTalepIslemKimlik") REFERENCES "e-ced-yeterlik"."PersonelTalepIslem"("Kimlik");


--
-- Name: VizeBelgeEksiklik VizeBelge_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeBelgeEksiklik"
    ADD CONSTRAINT "VizeBelge_Eksiklik" FOREIGN KEY ("VizeBelgeKimlik") REFERENCES "e-ced-yeterlik"."VizeBelge"("Kimlik");


--
-- Name: VizeOdemeEksiklik VizeOdeme_Eksiklik; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeOdemeEksiklik"
    ADD CONSTRAINT "VizeOdeme_Eksiklik" FOREIGN KEY ("VizeOdemeKimlik") REFERENCES "e-ced-yeterlik"."VizeOdeme"("Kimlik");


--
-- Name: Vize Vize_Basvuru; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."Vize"
    ADD CONSTRAINT "Vize_Basvuru" FOREIGN KEY ("BasvuruKimlik") REFERENCES "e-ced-yeterlik"."Basvuru"("Kimlik");


--
-- Name: VizeAtama Vize_VizeAtama; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeAtama"
    ADD CONSTRAINT "Vize_VizeAtama" FOREIGN KEY ("VizeKimlik") REFERENCES "e-ced-yeterlik"."Vize"("Kimlik");


--
-- Name: VizeBelge Vize_VizeBelge; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeBelge"
    ADD CONSTRAINT "Vize_VizeBelge" FOREIGN KEY ("VizeKimlik") REFERENCES "e-ced-yeterlik"."Vize"("Kimlik");


--
-- Name: VizeOdeme Vize_VizeOdeme; Type: FK CONSTRAINT; Schema: e-ced-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-ced-yeterlik"."VizeOdeme"
    ADD CONSTRAINT "Vize_VizeOdeme" FOREIGN KEY ("VizeKimlik") REFERENCES "e-ced-yeterlik"."Vize"("Kimlik");


--
-- Name: BasvuruBelgeEksiklik BasvuruBelgeEksiklik_BasvuruBelgeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."BasvuruBelgeEksiklik"
    ADD CONSTRAINT "BasvuruBelgeEksiklik_BasvuruBelgeKimlikRef_fkey" FOREIGN KEY ("BasvuruBelgeKimlikRef") REFERENCES "e-yeterlik"."Belge"("Kimlik");


--
-- Name: BasvuruDeneyimEksiklik BasvuruDeneyimEksiklik_BasvuruDeneyimKimlik_fkey; Type: FK CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."BasvuruDeneyimEksiklik"
    ADD CONSTRAINT "BasvuruDeneyimEksiklik_BasvuruDeneyimKimlik_fkey" FOREIGN KEY ("BasvuruDeneyimKimlik") REFERENCES "e-yeterlik"."Deneyim"("Kimlik");


--
-- Name: BasvuruEgitimEksiklik BasvuruEgitimEksiklik_BasvuruEgitimKimlik_fkey; Type: FK CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."BasvuruEgitimEksiklik"
    ADD CONSTRAINT "BasvuruEgitimEksiklik_BasvuruEgitimKimlik_fkey" FOREIGN KEY ("BasvuruEgitimKimlik") REFERENCES "e-yeterlik"."Egitim"("Kimlik");


--
-- Name: CevreYonetimBirimiPersonelTesis CevreYonetimBirimiPersonelTesis_PersonelKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."CevreYonetimBirimiPersonelTesis"
    ADD CONSTRAINT "CevreYonetimBirimiPersonelTesis_PersonelKimlikRef_fkey" FOREIGN KEY ("PersonelKimlikRef") REFERENCES "e-yeterlik"."CevreYonetimPersonel"("Kimlik");


--
-- Name: CevreYonetimBirimiPersonelTesis CevreYonetimBirimiPersonelTesis_TesisKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."CevreYonetimBirimiPersonelTesis"
    ADD CONSTRAINT "CevreYonetimBirimiPersonelTesis_TesisKimlikRef_fkey" FOREIGN KEY ("TesisKimlikRef") REFERENCES "e-yeterlik"."CevreYonetimBirimiTesis"("Kimlik");


--
-- Name: CevreYonetimPersonelEksiklik CevreYonetimPersonelEksiklik_BasvuruPersonelKimlik_fkey; Type: FK CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."CevreYonetimPersonelEksiklik"
    ADD CONSTRAINT "CevreYonetimPersonelEksiklik_BasvuruPersonelKimlik_fkey" FOREIGN KEY ("BasvuruPersonelKimlik") REFERENCES "e-yeterlik"."CevreYonetimPersonel"("Kimlik");


--
-- Name: DanismanPersonelEksiklik DanismanPersonelEksiklik_BasvuruPersonelKimlik_fkey; Type: FK CONSTRAINT; Schema: e-yeterlik; Owner: -
--

ALTER TABLE ONLY "e-yeterlik"."DanismanPersonelEksiklik"
    ADD CONSTRAINT "DanismanPersonelEksiklik_BasvuruPersonelKimlik_fkey" FOREIGN KEY ("BasvuruPersonelKimlik") REFERENCES "e-yeterlik"."DanismanFirmaPersonel"("Kimlik");


--
-- Name: BasvuruBelgeEksiklik BasvuruBelgeEksiklik_BasvuruBelgeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruBelgeEksiklik"
    ADD CONSTRAINT "BasvuruBelgeEksiklik_BasvuruBelgeKimlikRef_fkey" FOREIGN KEY ("BasvuruBelgeKimlikRef") REFERENCES public."Belge"("Kimlik");


--
-- Name: BasvuruDeneyimEksiklik BasvuruDeneyimEksiklik_BasvuruDeneyimKimlik_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruDeneyimEksiklik"
    ADD CONSTRAINT "BasvuruDeneyimEksiklik_BasvuruDeneyimKimlik_fkey" FOREIGN KEY ("BasvuruDeneyimKimlik") REFERENCES public."Deneyim"("Kimlik") NOT VALID;


--
-- Name: BasvuruEgitimEksiklik BasvuruEgitimEksiklik_BasvuruEgitimKimlik_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruEgitimEksiklik"
    ADD CONSTRAINT "BasvuruEgitimEksiklik_BasvuruEgitimKimlik_fkey" FOREIGN KEY ("BasvuruEgitimKimlik") REFERENCES public."Egitim"("Kimlik") NOT VALID;


--
-- Name: CevreYonetimBirimiPersonelTesis CevreYonetimBirimiPersonelTesis_PersonelKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreYonetimBirimiPersonelTesis"
    ADD CONSTRAINT "CevreYonetimBirimiPersonelTesis_PersonelKimlikRef_fkey" FOREIGN KEY ("PersonelKimlikRef") REFERENCES public."CevreYonetimPersonel"("Kimlik") NOT VALID;


--
-- Name: CevreYonetimBirimiPersonelTesis CevreYonetimBirimiPersonelTesis_TesisKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreYonetimBirimiPersonelTesis"
    ADD CONSTRAINT "CevreYonetimBirimiPersonelTesis_TesisKimlikRef_fkey" FOREIGN KEY ("TesisKimlikRef") REFERENCES public."CevreYonetimBirimiTesis"("Kimlik") NOT VALID;


--
-- Name: CevreYonetimPersonelEksiklik CevreYonetimPersonelEksiklik_BasvuruPersonelKimlik_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreYonetimPersonelEksiklik"
    ADD CONSTRAINT "CevreYonetimPersonelEksiklik_BasvuruPersonelKimlik_fkey" FOREIGN KEY ("BasvuruPersonelKimlik") REFERENCES public."CevreYonetimPersonel"("Kimlik") NOT VALID;


--
-- Name: DanismanPersonelEksiklik DanismanPersonelEksiklik_BasvuruPersonelKimlik_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DanismanPersonelEksiklik"
    ADD CONSTRAINT "DanismanPersonelEksiklik_BasvuruPersonelKimlik_fkey" FOREIGN KEY ("BasvuruPersonelKimlik") REFERENCES public."DanismanFirmaPersonel"("Kimlik") NOT VALID;


--
-- PostgreSQL database dump complete
--

