--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."TasimaAracGecmis" DROP CONSTRAINT IF EXISTS "TasimaAracGecmis_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."TasimaAracBelge" DROP CONSTRAINT IF EXISTS "TasimaAracBelge_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."SurucuGecmis" DROP CONSTRAINT IF EXISTS "SurucuGecmis_SurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."SurucuBelge" DROP CONSTRAINT IF EXISTS "SurucuBelge_SurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."IlDegisikligiBasvuru" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuru_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."IlDegisikligiBasvuru" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuru_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."IlDegisikligiBasvuruAsama" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuruAsama_IlDegisikligiBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "BasvuruTasimaArac_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "BasvuruTasimaArac_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruTasimaAracEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruTasimaAracEksiklik_BasvuruTasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruSurucu" DROP CONSTRAINT IF EXISTS "BasvuruSurucu_SurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruSurucu" DROP CONSTRAINT IF EXISTS "BasvuruSurucu_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruSurucuEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruSurucuEksiklik_BasvuruSurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruOdeme" DROP CONSTRAINT IF EXISTS "BasvuruOdeme_OdemeReferansNumarasiKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruOdeme" DROP CONSTRAINT IF EXISTS "BasvuruOdeme_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruOdemeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruOdemeEksiklik_BasvuruOdemeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruGecmis" DROP CONSTRAINT IF EXISTS "BasvuruGecmis_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruCevreMuhendisiEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruCevreMuhendisiEksiklik_BasvuruCevreMuhendisiKimlikR_fkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruAsama" DROP CONSTRAINT IF EXISTS "BasvuruAsama_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AtyonBasvuruCevreMuhendisi" DROP CONSTRAINT IF EXISTS "AtyonBasvuruCevreMuhendisi_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AtyonBasvuruBelge" DROP CONSTRAINT IF EXISTS "AtyonBasvuruBelge_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AtyonAtikKod" DROP CONSTRAINT IF EXISTS "AtyonAtikKod_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AtikTehlikelilikOzellik" DROP CONSTRAINT IF EXISTS "AtikTehlikelilikOzellik_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaArac_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruTasimaAracOdeme" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracOdeme_OdemeReferansNumarasiKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruTasimaAracOdeme" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracOdeme_AltBasvuruTasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruTasimaAracAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracAsama_AltBasvuruTasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruSurucu" DROP CONSTRAINT IF EXISTS "AltBasvuruSurucu_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruSurucuAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruSurucuAsama_AltBasvuruSurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruLisansVize" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansVize_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruLisansVizeAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansVizeAsama_AltBasvuruLisansVizeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruLisansIptal" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansIptal_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruLisansIptalAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansIptalAsama_AltBasvuruLisansIptalKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruAtikKodu" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKodu_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruAtikKodu" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKodu_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruAtikKoduAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKoduAsama_AltBasvuruAtikKoduKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."LisansKonu" DROP CONSTRAINT IF EXISTS "LisansKonu_UstKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruLisansKonu" DROP CONSTRAINT IF EXISTS "LisansKonu_LisansKonuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."Kapsam" DROP CONSTRAINT IF EXISTS "Kapsam_UstKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."IsAkisi" DROP CONSTRAINT IF EXISTS "IsAkisi_UstKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."IsAkisi" DROP CONSTRAINT IF EXISTS "IsAkisi_KapsamKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."IlMudurluguUygunluk" DROP CONSTRAINT IF EXISTS "IlMudurluguUygunluk_UstKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."ILMudurluguUygunlukUzmanKonu" DROP CONSTRAINT IF EXISTS "IlMudurluguUygunluk_IlMudurluguUygunlukKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."Kapsam" DROP CONSTRAINT IF EXISTS "EkTur_EkTurKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3AYillikTuketimKapasite" DROP CONSTRAINT IF EXISTS "EK3A_EK3AKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3AYillikUretimKapasite" DROP CONSTRAINT IF EXISTS "EK3A_EK3AKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3ANaceBilgi" DROP CONSTRAINT IF EXISTS "EK3A_EK3AKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3ATesisFaaliyetBolge" DROP CONSTRAINT IF EXISTS "EK3A_EK3AKimlikRef";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruDRKod" DROP CONSTRAINT IF EXISTS "DRKod_DRKodKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."Basvuru" DROP CONSTRAINT IF EXISTS "Basvuru_UstKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruIzinKonu" DROP CONSTRAINT IF EXISTS "Basvuru_KimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruNot" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruOzet" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."IlMudurluguUygunluk" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruDRKod" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruAtikKod" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruLisansKonu" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3A" DROP CONSTRAINT IF EXISTS "Basvuru_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruOzet" DROP CONSTRAINT IF EXISTS "BasvuruOzet_UstKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."AtikKod" DROP CONSTRAINT IF EXISTS "AtikKod_UstKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruKapsam" DROP CONSTRAINT IF EXISTS " Kapsam_KapsamKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruKapsam" DROP CONSTRAINT IF EXISTS " Basvuru_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."TasimaAracGecmis" DROP CONSTRAINT IF EXISTS "TasimaAracGecmis_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."TasimaAracBelge" DROP CONSTRAINT IF EXISTS "TasimaAracBelge_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."SurucuGecmis" DROP CONSTRAINT IF EXISTS "SurucuGecmis_SurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."SurucuBelge" DROP CONSTRAINT IF EXISTS "SurucuBelge_SurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."IlDegisikligiBasvuru" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuru_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."IlDegisikligiBasvuru" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuru_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."IlDegisikligiBasvuruAsama" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuruAsama_IlDegisikligiBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "BasvuruTasimaArac_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "BasvuruTasimaArac_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruTasimaAracEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruTasimaAracEksiklik_BasvuruTasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruSurucu" DROP CONSTRAINT IF EXISTS "BasvuruSurucu_SurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruSurucu" DROP CONSTRAINT IF EXISTS "BasvuruSurucu_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruSurucuEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruSurucuEksiklik_BasvuruSurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruOdeme" DROP CONSTRAINT IF EXISTS "BasvuruOdeme_OdemeReferansNumarasiKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruOdeme" DROP CONSTRAINT IF EXISTS "BasvuruOdeme_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruOdemeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruOdemeEksiklik_BasvuruOdemeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruGecmis" DROP CONSTRAINT IF EXISTS "BasvuruGecmis_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruCevreMuhendisiEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruCevreMuhendisiEksiklik_BasvuruCevreMuhendisiKimlikR_fkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruAsama" DROP CONSTRAINT IF EXISTS "BasvuruAsama_BasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AtyonBasvuruCevreMuhendisi" DROP CONSTRAINT IF EXISTS "AtyonBasvuruCevreMuhendisi_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AtyonBasvuruBelge" DROP CONSTRAINT IF EXISTS "AtyonBasvuruBelge_AtyonBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AtyonAtikKod" DROP CONSTRAINT IF EXISTS "AtyonAtikKod_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AtikTehlikelilikOzellik" DROP CONSTRAINT IF EXISTS "AtikTehlikelilikOzellik_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaArac_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruTasimaAracOdeme" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracOdeme_OdemeReferansNumarasiKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruTasimaAracOdeme" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracOdeme_AltBasvuruTasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruTasimaAracAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracAsama_AltBasvuruTasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruSurucu" DROP CONSTRAINT IF EXISTS "AltBasvuruSurucu_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruSurucuAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruSurucuAsama_AltBasvuruSurucuKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruLisansVize" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansVize_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruLisansVizeAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansVizeAsama_AltBasvuruLisansVizeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruLisansIptal" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansIptal_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruLisansIptalAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansIptalAsama_AltBasvuruLisansIptalKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruAtikKodu" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKodu_TasimaAracKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruAtikKodu" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKodu_AnaBasvuruKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruAtikKoduAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKoduAsama_AltBasvuruAtikKoduKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."TasimaArac" DROP CONSTRAINT IF EXISTS "TasimaArac_pkey";
ALTER TABLE IF EXISTS ONLY public."TasimaAracGecmis" DROP CONSTRAINT IF EXISTS "TasimaAracGecmis_pkey";
ALTER TABLE IF EXISTS ONLY public."TasimaAracBelge" DROP CONSTRAINT IF EXISTS "TasimaAracBelge_pkey";
ALTER TABLE IF EXISTS ONLY public."Surucu" DROP CONSTRAINT IF EXISTS "Surucu_pkey";
ALTER TABLE IF EXISTS ONLY public."SurucuTasimaArac" DROP CONSTRAINT IF EXISTS "SurucuTasimaArac_pkey";
ALTER TABLE IF EXISTS ONLY public."SurucuGecmis" DROP CONSTRAINT IF EXISTS "SurucuGecmis_pkey";
ALTER TABLE IF EXISTS ONLY public."SurucuBelge" DROP CONSTRAINT IF EXISTS "SurucuBelge_pkey";
ALTER TABLE IF EXISTS ONLY public."Personel" DROP CONSTRAINT IF EXISTS "Personel_pkey";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY public."OdemeReferansNumarasi" DROP CONSTRAINT IF EXISTS "OdemeReferansNumarasi_pkey";
ALTER TABLE IF EXISTS ONLY public."IlDegisikligiBasvuru" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuru_pkey";
ALTER TABLE IF EXISTS ONLY public."IlDegisikligiBasvuruAsama" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuruAsama_pkey";
ALTER TABLE IF EXISTS ONLY public."EK1EK2" DROP CONSTRAINT IF EXISTS "EK1Ek2_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "BasvuruTasimaArac_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruTasimaAracEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruTasimaAracEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruSurucu" DROP CONSTRAINT IF EXISTS "BasvuruSurucu_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruSurucuEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruSurucuEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruOdeme" DROP CONSTRAINT IF EXISTS "BasvuruOdeme_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruOdemeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruOdemeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruGecmis" DROP CONSTRAINT IF EXISTS "BasvuruGecmis_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruCevreMuhendisiEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruCevreMuhendisiEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY public."BasvuruAsama" DROP CONSTRAINT IF EXISTS "BasvuruAsama_pkey";
ALTER TABLE IF EXISTS ONLY public."AtyonBasvuruCevreMuhendisi" DROP CONSTRAINT IF EXISTS "AtyonCevreMuhendisi_pkey";
ALTER TABLE IF EXISTS ONLY public."AtyonBasvuru" DROP CONSTRAINT IF EXISTS "AtyonBasvuru_pkey";
ALTER TABLE IF EXISTS ONLY public."AtyonBasvuruBelge" DROP CONSTRAINT IF EXISTS "AtyonBasvuruBelge_pkey";
ALTER TABLE IF EXISTS ONLY public."AtyonAtikKod" DROP CONSTRAINT IF EXISTS "AtyonAtikKod_pkey";
ALTER TABLE IF EXISTS ONLY public."AtikTehlikelilikOzellik" DROP CONSTRAINT IF EXISTS "AtikTehlikelilikOzellik_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaArac_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruTasimaAracOdeme" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracOdeme_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruTasimaAracAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracAsama_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruSurucu" DROP CONSTRAINT IF EXISTS "AltBasvuruSurucu_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruSurucuAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruSurucuAsama_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruLisansVize" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansVize_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruLisansVizeAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansVizeAsama_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruLisansIptal" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansIptal_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruLisansIptalAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansIptalAsama_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruAtikKodu" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKodu_pkey";
ALTER TABLE IF EXISTS ONLY public."AltBasvuruAtikKoduAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKoduAsama_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."IsAkisi" DROP CONSTRAINT IF EXISTS "İsAkisi_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."atikKodGecici" DROP CONSTRAINT IF EXISTS "atikKodGecici_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."LisansKonu" DROP CONSTRAINT IF EXISTS "LisansKonu_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."Kapsam" DROP CONSTRAINT IF EXISTS "Kapsam_pkey1";
ALTER TABLE IF EXISTS ONLY "e-izin"."EkTuru" DROP CONSTRAINT IF EXISTS "Kapsam_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."IlMudurluguUygunluk" DROP CONSTRAINT IF EXISTS "IlMudurluguUygunluk_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."ILMudurluguUygunlukUzmanKonu" DROP CONSTRAINT IF EXISTS "ILMudurluguUygunlukUzmanKonu_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3A" DROP CONSTRAINT IF EXISTS "EK3A_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3AYillikUretimKapasite" DROP CONSTRAINT IF EXISTS "EK3AYillikUretimKapasite_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3AYillikTuketimKapasite" DROP CONSTRAINT IF EXISTS "EK3AYillikTuketimKapasite_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3ATesisFaaliyetBolge" DROP CONSTRAINT IF EXISTS "EK3ATesisFaaliyetBölge_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."EK3ANaceBilgi" DROP CONSTRAINT IF EXISTS "EK3ANaceBilgi_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."DRKod" DROP CONSTRAINT IF EXISTS "DRKod_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."Basvuru" DROP CONSTRAINT IF EXISTS "Basvuru_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruOzet" DROP CONSTRAINT IF EXISTS "BasvuruOzet_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruNot" DROP CONSTRAINT IF EXISTS "BasvuruNotlar_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruLisansKonu" DROP CONSTRAINT IF EXISTS "BasvuruKonu_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruKapsam" DROP CONSTRAINT IF EXISTS "BasvuruKapsam_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruIzinKonu" DROP CONSTRAINT IF EXISTS "BasvuruIzinKonu_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruDRKod" DROP CONSTRAINT IF EXISTS "BasvuruDRKod_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."BasvuruAtikKod" DROP CONSTRAINT IF EXISTS "BasvuruAtikKod_pkey";
ALTER TABLE IF EXISTS ONLY "e-izin"."AtikKod" DROP CONSTRAINT IF EXISTS "AtikKod_pkey";
ALTER TABLE IF EXISTS ONLY atyon."TasimaArac" DROP CONSTRAINT IF EXISTS "TasimaArac_pkey";
ALTER TABLE IF EXISTS ONLY atyon."TasimaAracGecmis" DROP CONSTRAINT IF EXISTS "TasimaAracGecmis_pkey";
ALTER TABLE IF EXISTS ONLY atyon."TasimaAracBelge" DROP CONSTRAINT IF EXISTS "TasimaAracBelge_pkey";
ALTER TABLE IF EXISTS ONLY atyon."Surucu" DROP CONSTRAINT IF EXISTS "Surucu_pkey";
ALTER TABLE IF EXISTS ONLY atyon."SurucuTasimaArac" DROP CONSTRAINT IF EXISTS "SurucuTasimaArac_pkey";
ALTER TABLE IF EXISTS ONLY atyon."SurucuGecmis" DROP CONSTRAINT IF EXISTS "SurucuGecmis_pkey";
ALTER TABLE IF EXISTS ONLY atyon."SurucuBelge" DROP CONSTRAINT IF EXISTS "SurucuBelge_pkey";
ALTER TABLE IF EXISTS ONLY atyon."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY atyon."OdemeReferansNumarasi" DROP CONSTRAINT IF EXISTS "OdemeReferansNumarasi_pkey";
ALTER TABLE IF EXISTS ONLY atyon."IlDegisikligiBasvuru" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuru_pkey";
ALTER TABLE IF EXISTS ONLY atyon."IlDegisikligiBasvuruAsama" DROP CONSTRAINT IF EXISTS "IlDegisikligiBasvuruAsama_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "BasvuruTasimaArac_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruTasimaAracEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruTasimaAracEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruSurucu" DROP CONSTRAINT IF EXISTS "BasvuruSurucu_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruSurucuEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruSurucuEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruOdeme" DROP CONSTRAINT IF EXISTS "BasvuruOdeme_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruOdemeEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruOdemeEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruGecmis" DROP CONSTRAINT IF EXISTS "BasvuruGecmis_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruCevreMuhendisiEksiklik" DROP CONSTRAINT IF EXISTS "BasvuruCevreMuhendisiEksiklik_pkey";
ALTER TABLE IF EXISTS ONLY atyon."BasvuruAsama" DROP CONSTRAINT IF EXISTS "BasvuruAsama_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AtyonBasvuruCevreMuhendisi" DROP CONSTRAINT IF EXISTS "AtyonCevreMuhendisi_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AtyonBasvuru" DROP CONSTRAINT IF EXISTS "AtyonBasvuru_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AtyonBasvuruBelge" DROP CONSTRAINT IF EXISTS "AtyonBasvuruBelge_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AtyonAtikKod" DROP CONSTRAINT IF EXISTS "AtyonAtikKod_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AtikTehlikelilikOzellik" DROP CONSTRAINT IF EXISTS "AtikTehlikelilikOzellik_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruTasimaArac" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaArac_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruTasimaAracOdeme" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracOdeme_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruTasimaAracAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruTasimaAracAsama_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruSurucu" DROP CONSTRAINT IF EXISTS "AltBasvuruSurucu_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruSurucuAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruSurucuAsama_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruLisansVize" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansVize_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruLisansVizeAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansVizeAsama_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruLisansIptal" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansIptal_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruLisansIptalAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruLisansIptalAsama_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruAtikKodu" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKodu_pkey";
ALTER TABLE IF EXISTS ONLY atyon."AltBasvuruAtikKoduAsama" DROP CONSTRAINT IF EXISTS "AltBasvuruAtikKoduAsama_pkey";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS public."TasimaAracGecmis";
DROP TABLE IF EXISTS public."TasimaAracBelge";
DROP TABLE IF EXISTS public."TasimaArac";
DROP TABLE IF EXISTS public."SurucuTasimaArac";
DROP TABLE IF EXISTS public."SurucuGecmis";
DROP TABLE IF EXISTS public."SurucuBelge";
DROP TABLE IF EXISTS public."Surucu";
DROP TABLE IF EXISTS public."Personel";
DROP TABLE IF EXISTS public."OdemeReferansNumarasi";
DROP TABLE IF EXISTS public."NaceKodu";
DROP TABLE IF EXISTS public."IlDegisikligiBasvuruAsama";
DROP TABLE IF EXISTS public."IlDegisikligiBasvuru";
DROP TABLE IF EXISTS public."EK1EK2";
DROP TABLE IF EXISTS public."BasvuruTasimaAracEksiklik";
DROP TABLE IF EXISTS public."BasvuruTasimaArac";
DROP TABLE IF EXISTS public."BasvuruSurucuEksiklik";
DROP TABLE IF EXISTS public."BasvuruSurucu";
DROP TABLE IF EXISTS public."BasvuruOdemeEksiklik";
DROP TABLE IF EXISTS public."BasvuruOdeme";
DROP TABLE IF EXISTS public."BasvuruGecmis";
DROP TABLE IF EXISTS public."BasvuruCevreMuhendisiEksiklik";
DROP TABLE IF EXISTS public."BasvuruAsama";
DROP TABLE IF EXISTS public."AtyonBasvuruCevreMuhendisi";
DROP TABLE IF EXISTS public."AtyonBasvuruBelge";
DROP TABLE IF EXISTS public."AtyonBasvuru";
DROP TABLE IF EXISTS public."AtyonAtikKod";
DROP TABLE IF EXISTS public."AtikTehlikelilikOzellik";
DROP TABLE IF EXISTS public."AltBasvuruTasimaAracOdeme";
DROP TABLE IF EXISTS public."AltBasvuruTasimaAracAsama";
DROP TABLE IF EXISTS public."AltBasvuruTasimaArac";
DROP TABLE IF EXISTS public."AltBasvuruSurucuAsama";
DROP TABLE IF EXISTS public."AltBasvuruSurucu";
DROP TABLE IF EXISTS public."AltBasvuruLisansVizeAsama";
DROP TABLE IF EXISTS public."AltBasvuruLisansVize";
DROP TABLE IF EXISTS public."AltBasvuruLisansIptalAsama";
DROP TABLE IF EXISTS public."AltBasvuruLisansIptal";
DROP TABLE IF EXISTS public."AltBasvuruAtikKoduAsama";
DROP TABLE IF EXISTS public."AltBasvuruAtikKodu";
DROP TABLE IF EXISTS "e-izin"."atikKodGecici";
DROP TABLE IF EXISTS "e-izin"."LisansKonu";
DROP TABLE IF EXISTS "e-izin"."Kapsam";
DROP TABLE IF EXISTS "e-izin"."IsAkisi";
DROP TABLE IF EXISTS "e-izin"."IlMudurluguUygunluk";
DROP TABLE IF EXISTS "e-izin"."ILMudurluguUygunlukUzmanKonu";
DROP TABLE IF EXISTS "e-izin"."EkTuru";
DROP TABLE IF EXISTS "e-izin"."EK3AYillikUretimKapasite";
DROP TABLE IF EXISTS "e-izin"."EK3AYillikTuketimKapasite";
DROP TABLE IF EXISTS "e-izin"."EK3ATesisFaaliyetBolge";
DROP TABLE IF EXISTS "e-izin"."EK3ANaceBilgi";
DROP TABLE IF EXISTS "e-izin"."EK3A";
DROP TABLE IF EXISTS "e-izin"."DRKod";
DROP TABLE IF EXISTS "e-izin"."BasvuruOzet";
DROP TABLE IF EXISTS "e-izin"."BasvuruNot";
DROP TABLE IF EXISTS "e-izin"."BasvuruLisansKonu";
DROP TABLE IF EXISTS "e-izin"."BasvuruKapsam";
DROP TABLE IF EXISTS "e-izin"."BasvuruIzinKonu";
DROP TABLE IF EXISTS "e-izin"."BasvuruDRKod";
DROP TABLE IF EXISTS "e-izin"."BasvuruAtikKod";
DROP TABLE IF EXISTS "e-izin"."Basvuru";
DROP TABLE IF EXISTS "e-izin"."AtikKod";
DROP TABLE IF EXISTS atyon."__EFMigrationsHistory";
DROP TABLE IF EXISTS atyon."TasimaAracGecmis";
DROP TABLE IF EXISTS atyon."TasimaAracBelge";
DROP TABLE IF EXISTS atyon."TasimaArac";
DROP TABLE IF EXISTS atyon."SurucuTasimaArac";
DROP TABLE IF EXISTS atyon."SurucuGecmis";
DROP TABLE IF EXISTS atyon."SurucuBelge";
DROP TABLE IF EXISTS atyon."Surucu";
DROP TABLE IF EXISTS atyon."OdemeReferansNumarasi";
DROP TABLE IF EXISTS atyon."IlDegisikligiBasvuruAsama";
DROP TABLE IF EXISTS atyon."IlDegisikligiBasvuru";
DROP TABLE IF EXISTS atyon."BasvuruTasimaAracEksiklik";
DROP TABLE IF EXISTS atyon."BasvuruTasimaArac";
DROP TABLE IF EXISTS atyon."BasvuruSurucuEksiklik";
DROP TABLE IF EXISTS atyon."BasvuruSurucu";
DROP TABLE IF EXISTS atyon."BasvuruOdemeEksiklik";
DROP TABLE IF EXISTS atyon."BasvuruOdeme";
DROP TABLE IF EXISTS atyon."BasvuruGecmis";
DROP TABLE IF EXISTS atyon."BasvuruCevreMuhendisiEksiklik";
DROP TABLE IF EXISTS atyon."BasvuruAsama";
DROP TABLE IF EXISTS atyon."AtyonBasvuruCevreMuhendisi";
DROP TABLE IF EXISTS atyon."AtyonBasvuruBelge";
DROP TABLE IF EXISTS atyon."AtyonBasvuru";
DROP TABLE IF EXISTS atyon."AtyonAtikKod";
DROP TABLE IF EXISTS atyon."AtikTehlikelilikOzellik";
DROP TABLE IF EXISTS atyon."AltBasvuruTasimaAracOdeme";
DROP TABLE IF EXISTS atyon."AltBasvuruTasimaAracAsama";
DROP TABLE IF EXISTS atyon."AltBasvuruTasimaArac";
DROP TABLE IF EXISTS atyon."AltBasvuruSurucuAsama";
DROP TABLE IF EXISTS atyon."AltBasvuruSurucu";
DROP TABLE IF EXISTS atyon."AltBasvuruLisansVizeAsama";
DROP TABLE IF EXISTS atyon."AltBasvuruLisansVize";
DROP TABLE IF EXISTS atyon."AltBasvuruLisansIptalAsama";
DROP TABLE IF EXISTS atyon."AltBasvuruLisansIptal";
DROP TABLE IF EXISTS atyon."AltBasvuruAtikKoduAsama";
DROP TABLE IF EXISTS atyon."AltBasvuruAtikKodu";
DROP SCHEMA IF EXISTS "e-izin";
DROP SCHEMA IF EXISTS atyon;
--
-- Name: atyon; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA atyon;


--
-- Name: e-izin; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "e-izin";


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AltBasvuruAtikKodu; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruAtikKodu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "AtikKodlari" character varying,
    "LisansEklemeDurum" integer,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruAtikKoduAsama; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruAtikKoduAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruAtikKoduKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruLisansIptal; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruLisansIptal" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruLisansIptalAsama; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruLisansIptalAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruLisansIptalKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruLisansVize; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruLisansVize" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruLisansVizeAsama; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruLisansVizeAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruLisansVizeKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruSurucu; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruSurucu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "SurucuKimlikRef" uuid,
    "Ad" character varying,
    "Soyad" character varying,
    "TCKimlik" character varying,
    "Telefon" character varying,
    "Eposta" character varying,
    "LisansEklemeDurum" integer,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid,
    "SilinmeDurum" integer
);


--
-- Name: AltBasvuruSurucuAsama; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruSurucuAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruSurucuKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruTasimaArac; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruTasimaArac" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AracTuru" integer,
    "TeminTuru" integer,
    "TasinacakAtikTuru" integer,
    "TehlikeliAtikGrubu" integer,
    "AracTasimaKapasitesi" character varying,
    "AmbalajTuru" integer,
    "Plaka" character varying,
    "SaseNumara" character varying,
    "AracSinifi" integer,
    "İlkTescilTarihi" timestamp without time zone,
    "MobilCihazId" character varying,
    "MaliSorumlulukSigortasiPoliceNo" character varying,
    "TasitADRUygunlukBelgeNo" character varying,
    "IlKodu" character varying,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "LisansEklemeDurum" integer,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruTasimaAracAsama; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruTasimaAracAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruTasimaAracKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruTasimaAracOdeme; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AltBasvuruTasimaAracOdeme" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruTasimaAracKimlikRef" uuid NOT NULL,
    "OdemeReferansNumarasiKimlikRef" uuid
);


--
-- Name: AtikTehlikelilikOzellik; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AtikTehlikelilikOzellik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "TehlikelilikOzellik" integer,
    "TehlikelilikOzellikUygunluk" integer,
    "TehlikelilikOzellikUygunlukNot" character varying,
    "TasimaAracKimlikRef" uuid NOT NULL
);


--
-- Name: AtyonAtikKod; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AtyonAtikKod" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "TasimaAracKimlikRef" uuid,
    "AtikKodu" integer
);


--
-- Name: AtyonBasvuru; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AtyonBasvuru" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "KurulusKullaniciKimlikRef" uuid NOT NULL,
    "FirmaKimlikRef" uuid NOT NULL,
    "LisansDurum" integer,
    "LisansTarihi" timestamp without time zone,
    "VizeDurum" integer,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid,
    "GorevliIlMudurYardimcisiKimlikRef" uuid
);


--
-- Name: AtyonBasvuruBelge; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AtyonBasvuruBelge" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "BelgeKimlikRef" uuid NOT NULL,
    "BelgeUygunluk" integer,
    "BelgeUygunlukNot" character varying,
    "BelgeTuru" integer,
    "SonGecerlilikTarihi" timestamp without time zone
);


--
-- Name: AtyonBasvuruCevreMuhendisi; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."AtyonBasvuruCevreMuhendisi" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "PersonelTCKimlik" character varying NOT NULL
);


--
-- Name: BasvuruAsama; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer,
    "YeniVeri" character varying
);


--
-- Name: BasvuruCevreMuhendisiEksiklik; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruCevreMuhendisiEksiklik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruCevreMuhendisiKimlikRef" uuid NOT NULL,
    "UygunlukDurum" integer,
    "UygunlukNot" character varying,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "EksiklikDurum" integer
);


--
-- Name: BasvuruGecmis; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruGecmis" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: BasvuruOdeme; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruOdeme" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "OdemeReferansNumarasiKimlikRef" uuid
);


--
-- Name: BasvuruOdemeEksiklik; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruOdemeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruOdemeKimlikRef" uuid NOT NULL,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukDurum" integer,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer
);


--
-- Name: BasvuruSurucu; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruSurucu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "SurucuKimlikRef" uuid NOT NULL,
    "SurucuUygunlukNot" character varying,
    "SurucuUygunluk" integer
);


--
-- Name: BasvuruSurucuEksiklik; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruSurucuEksiklik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruSurucuKimlikRef" uuid NOT NULL,
    "UygunlukDurum" integer,
    "UygunlukNot" character varying,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "EksiklikDurum" integer
);


--
-- Name: BasvuruTasimaArac; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruTasimaArac" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "TasimaAracUygunlukNot" character varying,
    "TasimaAracUygunluk" integer
);


--
-- Name: BasvuruTasimaAracEksiklik; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."BasvuruTasimaAracEksiklik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruTasimaAracKimlikRef" uuid NOT NULL,
    "UygunlukDurum" integer,
    "UygunlukNot" character varying,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "EksiklikDurum" integer
);


--
-- Name: IlDegisikligiBasvuru; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."IlDegisikligiBasvuru" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "IlKodu" character varying,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: IlDegisikligiBasvuruAsama; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."IlDegisikligiBasvuruAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "IlDegisikligiBasvuruKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: OdemeReferansNumarasi; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."OdemeReferansNumarasi" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ReferansNumarasiTuru" integer NOT NULL,
    "ReferansNumarasi" character varying NOT NULL,
    "OdenenTutar" numeric,
    "OdemeDurum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL
);


--
-- Name: Surucu; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."Surucu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "Ad" character varying,
    "Soyad" character varying,
    "TCKimlik" character varying,
    "Telefon" character varying,
    "Eposta" character varying
);


--
-- Name: SurucuBelge; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."SurucuBelge" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer,
    "BelgeKimlikRef" uuid NOT NULL,
    "SurucuKimlikRef" uuid NOT NULL,
    "BelgeTuru" integer,
    "SonGecerlilikTarihi" timestamp without time zone
);


--
-- Name: SurucuGecmis; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."SurucuGecmis" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "SurucuKimlikRef" uuid NOT NULL,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: SurucuTasimaArac; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."SurucuTasimaArac" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "SurucuKimlikRef" uuid NOT NULL,
    "TasimaAracKimlikRef" uuid NOT NULL
);


--
-- Name: TasimaArac; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."TasimaArac" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AracTuru" integer,
    "AracTuruUygunluk" integer,
    "AracTuruUygunlukNot" character varying,
    "TeminTuru" integer,
    "TeminTuruUygunluk" integer,
    "TeminTuruUygunlukNot" character varying,
    "TasinacakAtikTuru" integer,
    "TasinacakAtikTuruUygunluk" integer,
    "TasinacakAtikTuruUygunlukNot" character varying,
    "TehlikeliAtikGrubu" integer,
    "TehlikeliAtikGrubuUygunluk" integer,
    "TehlikeliAtikGrubuUygunlukNot" character varying,
    "AracTasimaKapasitesi" character varying,
    "AracTasimaKapasitesiUygunluk" integer,
    "AracTasimaKapasitesiUygunlukNot" character varying,
    "AmbalajTuru" integer,
    "AmbalajTuruUygunluk" integer,
    "AmbalajTuruUygunlukNot" character varying,
    "Plaka" character varying,
    "PlakaUygunluk" integer,
    "PlakaUygunlukNot" character varying,
    "SaseNumarasi" character varying,
    "SaseNumarasiUygunluk" integer,
    "SaseNumarasiUygunlukNot" character varying,
    "AracSinifi" integer,
    "AracSinifiUygunluk" integer,
    "AracSinifiUygunlukNot" character varying,
    "İlkTescilTarihi" timestamp without time zone,
    "TescilTarihiUygunluk" integer,
    "TescilTarihiUygunlukNot" character varying,
    "MobilCihazId" character varying,
    "CihazIdUygunluk" integer,
    "CihazIdUygunlukNot" character varying,
    "YetkiBelge" integer,
    "YetkiBelgeUygunluk" integer,
    "YetkiBelgeUygunlukNot" character varying,
    "AtikKod" integer,
    "AtikKodUygunluk" integer,
    "AtikKodUygunlukNot" character varying,
    "MaliSorumlulukSigortasiPoliceNo" character varying,
    "TasitADRUygunlukBelgeNo" character varying,
    "IlKodu" character varying,
    "AracSahibiAd" character varying,
    "AracSahibiSoyad" character varying,
    "AracSahibiTelefon" character varying,
    "AracSahibiEposta" character varying,
    "AracSahibiAdres" character varying
);


--
-- Name: TasimaAracBelge; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."TasimaAracBelge" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BelgeKimlikRef" uuid NOT NULL,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "BelgeTuru" integer,
    "SonGecerlilikTarihi" timestamp without time zone
);


--
-- Name: TasimaAracGecmis; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."TasimaAracGecmis" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: atyon; Owner: -
--

CREATE TABLE atyon."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Name: AtikKod; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."AtikKod" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "Adi" character varying NOT NULL,
    "Tip" integer,
    "UstKimlikRef" uuid,
    "Kodu" character varying NOT NULL,
    "TehlikeliMi" boolean DEFAULT false NOT NULL,
    "AktifMi" boolean DEFAULT false NOT NULL,
    "YagMi" boolean,
    "UzakKimlikRef" integer NOT NULL,
    "UzakUstKimlikRef" integer
);


--
-- Name: Basvuru; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."Basvuru" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer NOT NULL,
    "BasvuranKimlikRef" uuid NOT NULL,
    "TesisKimlikRef" uuid NOT NULL,
    "UstKimlikRef" uuid,
    "Ek1" boolean NOT NULL,
    "Ek2" boolean NOT NULL,
    "BasvuruTip" integer NOT NULL,
    "OnayAciklamasi" character varying(255)
);


--
-- Name: BasvuruAtikKod; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."BasvuruAtikKod" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "AtikKodKimlikRef" uuid NOT NULL
);


--
-- Name: BasvuruDRKod; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."BasvuruDRKod" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "DRKodKimlikRef" uuid NOT NULL
);


--
-- Name: BasvuruIzinKonu; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."BasvuruIzinKonu" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "HavaEmisyonu" boolean NOT NULL,
    "GurultuKontrolu" boolean NOT NULL,
    "AtıkSuDesarji" boolean NOT NULL,
    "DerinDenizDesarji" boolean NOT NULL,
    "HavaEmisyonuMuafiyeti" character varying(1000),
    "GurultuKontroluMuafiyeti" character varying(1000),
    "AtıkSuDesarjiMuafiyeti" character varying(1000),
    "DerinDenizDesarjiMuafiyeti" character varying(1000),
    "BasvuruKimlikRef" uuid NOT NULL
);


--
-- Name: BasvuruKapsam; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."BasvuruKapsam" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "KapsamKimlikRef" uuid NOT NULL,
    "EkTuru" smallint NOT NULL
);


--
-- Name: BasvuruLisansKonu; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."BasvuruLisansKonu" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "LisansKonuKimlikRef" uuid NOT NULL
);


--
-- Name: BasvuruNot; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."BasvuruNot" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "Konu" character varying NOT NULL,
    "Icerik" character varying,
    "FirmaGoruntulesinMi" boolean NOT NULL
);


--
-- Name: TABLE "BasvuruNot"; Type: COMMENT; Schema: e-izin; Owner: -
--

COMMENT ON TABLE "e-izin"."BasvuruNot" IS 'Basvuru Notlarının Kaydedildiği Tablo';


--
-- Name: BasvuruOzet; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."BasvuruOzet" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "OzetTip" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "Baslik" character varying NOT NULL,
    "Aciklama" character varying,
    "UstKimlikRef" uuid
);


--
-- Name: DRKod; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."DRKod" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer DEFAULT 1 NOT NULL,
    "Kod" character varying NOT NULL,
    "Ad" character varying NOT NULL,
    "Aciklama" character varying NOT NULL,
    "DRKOD_UzakKlimlikRef" integer NOT NULL,
    "Tip" integer NOT NULL,
    "TipAciklama" character varying NOT NULL,
    "AktifMi" boolean NOT NULL
);


--
-- Name: EK3A; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."EK3A" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer DEFAULT 1 NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "Ada" character varying NOT NULL,
    "Parsel" character varying NOT NULL,
    "KadastroPaftasi" character varying NOT NULL,
    "KoordinatSagDeger" character varying NOT NULL,
    "KoordinatYukariDeger" character varying NOT NULL,
    "KoordinatDilimNo" character varying NOT NULL,
    "KoordinatPafta" character varying NOT NULL,
    "KayitliBulunanOda" character varying NOT NULL,
    "OdaSicilNo" character varying NOT NULL,
    "UretimFaaliyetKodu" character varying NOT NULL,
    "TesisToplamAlan" double precision NOT NULL,
    "TesisKapaliAlan" double precision NOT NULL,
    "TesisCalisanSayisi" double precision NOT NULL,
    "TesisToplamCalismaSuresi" double precision NOT NULL,
    "TesisVardiyaSayisi" integer NOT NULL,
    "TesisCalismaSekli" integer NOT NULL,
    "CED_Izin" integer NOT NULL,
    "TehlikeliMaddeAtik" integer NOT NULL,
    "BekraBildirim" integer NOT NULL,
    "SeraGaziEmisyonTakip" integer NOT NULL,
    "SeraGaziIzlemeRapor" integer NOT NULL,
    "TesisOrtalamaCalismaSuresi" double precision NOT NULL
);


--
-- Name: EK3ANaceBilgi; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."EK3ANaceBilgi" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "EK3AKimlikRef" uuid NOT NULL,
    "NaceKimlikRef" uuid NOT NULL
);


--
-- Name: EK3ATesisFaaliyetBolge; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."EK3ATesisFaaliyetBolge" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "EK3AKimlikRef" uuid NOT NULL,
    "Bolge" integer NOT NULL
);


--
-- Name: EK3AYillikTuketimKapasite; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."EK3AYillikTuketimKapasite" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer DEFAULT 1 NOT NULL,
    "UrunCinsi" character varying NOT NULL,
    "Kapasite" character varying NOT NULL,
    "OlcuBirimi" integer NOT NULL,
    "EK3AKimlikRef" uuid NOT NULL
);


--
-- Name: EK3AYillikUretimKapasite; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."EK3AYillikUretimKapasite" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer DEFAULT 1 NOT NULL,
    "UrunCinsi" character varying NOT NULL,
    "Kapasite" character varying NOT NULL,
    "OlcuBirimi" integer NOT NULL,
    "EK3AKimlikRef" uuid NOT NULL
);


--
-- Name: EkTuru; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."EkTuru" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "EkTur" integer NOT NULL,
    "IlgiliKurum" integer NOT NULL,
    "Ad" character varying NOT NULL
);


--
-- Name: ILMudurluguUygunlukUzmanKonu; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."ILMudurluguUygunlukUzmanKonu" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "Konu" integer NOT NULL,
    "IlMudurluguUygunlukKimlikRef" uuid NOT NULL,
    "Karar" integer NOT NULL,
    "EksiklikBildirimiDetay" character varying
);


--
-- Name: IlMudurluguUygunluk; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."IlMudurluguUygunluk" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "Durum" integer DEFAULT 1 NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "AtananKimlikRef" uuid NOT NULL,
    "AtayanKimlikRef" uuid,
    "KoordinatorMu" boolean DEFAULT false NOT NULL,
    "Rol" integer NOT NULL,
    "UstKimlikRef" uuid,
    "DegerlendirmeDurum" integer NOT NULL
);


--
-- Name: IsAkisi; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."IsAkisi" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Durum" integer NOT NULL,
    "Unvan" integer NOT NULL,
    "UstKimlikRef" uuid,
    "KapsamKimlikRef" uuid NOT NULL,
    "Oncelik" integer DEFAULT 0 NOT NULL,
    "IlkAtamaMi" boolean DEFAULT false NOT NULL,
    "RoleKimlikRef" uuid,
    "Guncelleyen" uuid
);


--
-- Name: Kapsam; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."Kapsam" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Durum" integer DEFAULT 1 NOT NULL,
    "Guncelleyen" uuid,
    "Guncelleme" timestamp without time zone,
    "EkTuruKimlikRef" uuid NOT NULL,
    "EkTuruDetay" character varying NOT NULL,
    "GurultudenMuaf" boolean DEFAULT false NOT NULL,
    "UstKimlikRef" uuid,
    "SiraNo" integer NOT NULL,
    "EkTuruDetay_UzakKimlikRef" integer NOT NULL,
    "EkTuruDetay_UstUzakKimlikRef" integer,
    "LisansKonusunaTabiMi" boolean NOT NULL
);


--
-- Name: LisansKonu; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."LisansKonu" (
    "Kimlik" uuid NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Ad" character varying NOT NULL,
    "Durum" integer DEFAULT 1 NOT NULL,
    "UstKimlikRef" uuid
);


--
-- Name: atikKodGecici; Type: TABLE; Schema: e-izin; Owner: -
--

CREATE TABLE "e-izin"."atikKodGecici" (
    atikkodid integer NOT NULL,
    adi character varying,
    yagmi integer,
    tip integer,
    aktifmi integer,
    atikkodadi character varying,
    parentatikkodid integer,
    tehlikelimi integer,
    adi_en character varying,
    parentatikkod character varying,
    turkce_adi character varying
);


--
-- Name: AltBasvuruAtikKodu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruAtikKodu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "AtikKodlari" character varying,
    "LisansEklemeDurum" integer,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruAtikKoduAsama; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruAtikKoduAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruAtikKoduKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruLisansIptal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruLisansIptal" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruLisansIptalAsama; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruLisansIptalAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruLisansIptalKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruLisansVize; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruLisansVize" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruLisansVizeAsama; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruLisansVizeAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruLisansVizeKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruSurucu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruSurucu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "SurucuKimlikRef" uuid,
    "Ad" character varying,
    "Soyad" character varying,
    "TCKimlik" character varying,
    "Telefon" character varying,
    "Eposta" character varying,
    "LisansEklemeDurum" integer,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruSurucuAsama; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruSurucuAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruSurucuKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruTasimaArac; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruTasimaArac" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AracTuru" integer,
    "TeminTuru" integer,
    "TasinacakAtikTuru" integer,
    "TehlikeliAtikGrubu" integer,
    "AracTasimaKapasitesi" character varying,
    "AmbalajTuru" integer,
    "Plaka" character varying,
    "SaseNumara" character varying,
    "AracSinifi" integer,
    "İlkTescilTarihi" timestamp without time zone,
    "MobilCihazId" character varying,
    "MaliSorumlulukSigortasiPoliceNo" character varying,
    "TasitADRUygunlukBelgeNo" character varying,
    "IlKodu" character varying,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "LisansEklemeDurum" integer,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: AltBasvuruTasimaAracAsama; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruTasimaAracAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruTasimaAracKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: AltBasvuruTasimaAracOdeme; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltBasvuruTasimaAracOdeme" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AltBasvuruTasimaAracKimlikRef" uuid NOT NULL,
    "OdemeReferansNumarasiKimlikRef" uuid
);


--
-- Name: AtikTehlikelilikOzellik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AtikTehlikelilikOzellik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "TehlikelilikOzellik" integer,
    "TehlikelilikOzellikUygunluk" integer,
    "TehlikelilikOzellikUygunlukNot" character varying,
    "TasimaAracKimlikRef" uuid NOT NULL
);


--
-- Name: AtyonAtikKod; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AtyonAtikKod" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "TasimaAracKimlikRef" uuid,
    "AtikKodu" integer
);


--
-- Name: AtyonBasvuru; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AtyonBasvuru" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "KurulusKullaniciKimlikRef" uuid NOT NULL,
    "FirmaKimlikRef" uuid NOT NULL,
    "LisansDurum" integer,
    "LisansTarihi" timestamp without time zone,
    "VizeDurum" integer,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid,
    "GorevliIlMudurYardimcisiKimlikRef" uuid
);


--
-- Name: AtyonBasvuruBelge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AtyonBasvuruBelge" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "BelgeKimlikRef" uuid NOT NULL,
    "BelgeUygunluk" integer,
    "BelgeUygunlukNot" character varying,
    "BelgeTuru" integer,
    "SonGecerlilikTarihi" timestamp without time zone
);


--
-- Name: AtyonBasvuruCevreMuhendisi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AtyonBasvuruCevreMuhendisi" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "PersonelTCKimlik" character varying NOT NULL
);


--
-- Name: BasvuruAsama; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer,
    "YeniVeri" character varying
);


--
-- Name: BasvuruCevreMuhendisiEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruCevreMuhendisiEksiklik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruCevreMuhendisiKimlikRef" uuid NOT NULL,
    "UygunlukDurum" integer,
    "UygunlukNot" character varying,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "EksiklikDurum" integer
);


--
-- Name: BasvuruGecmis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruGecmis" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: BasvuruOdeme; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruOdeme" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "OdemeReferansNumarasiKimlikRef" uuid
);


--
-- Name: BasvuruOdemeEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruOdemeEksiklik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruOdemeKimlikRef" uuid NOT NULL,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "UygunlukDurum" integer,
    "UygunlukNot" character varying,
    "EksiklikDurum" integer
);


--
-- Name: BasvuruSurucu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruSurucu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "SurucuKimlikRef" uuid NOT NULL,
    "SurucuUygunlukNot" character varying,
    "SurucuUygunluk" integer
);


--
-- Name: BasvuruSurucuEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruSurucuEksiklik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruSurucuKimlikRef" uuid NOT NULL,
    "UygunlukDurum" integer,
    "UygunlukNot" character varying,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "EksiklikDurum" integer
);


--
-- Name: BasvuruTasimaArac; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruTasimaArac" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "AtyonBasvuruKimlikRef" uuid NOT NULL,
    "TasimaAracUygunlukNot" character varying,
    "TasimaAracUygunluk" integer
);


--
-- Name: BasvuruTasimaAracEksiklik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BasvuruTasimaAracEksiklik" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruTasimaAracKimlikRef" uuid NOT NULL,
    "UygunlukDurum" integer,
    "UygunlukNot" character varying,
    "EskiVeri" character varying,
    "YeniVeri" character varying,
    "EksiklikDurum" integer
);


--
-- Name: EK1EK2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EK1EK2" (
    "Kimlik" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer DEFAULT 1 NOT NULL,
    "EkTuruDetayId" integer,
    "Aciklama" character varying,
    "ParantDetayId" integer,
    "GurultudenMuaf" integer,
    "SiraNo" integer,
    "EkTuruId" integer
);


--
-- Name: IlDegisikligiBasvuru; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."IlDegisikligiBasvuru" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BasvuruDurum" integer,
    "AnaBasvuruKimlikRef" uuid NOT NULL,
    "IlKodu" character varying,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "GorevliUzmanKimlikRef" uuid,
    "GorevliSubeMuduruKimlikRef" uuid
);


--
-- Name: IlDegisikligiBasvuruAsama; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."IlDegisikligiBasvuruAsama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "IlDegisikligiBasvuruKimlikRef" uuid NOT NULL,
    "Aciklama" character varying,
    "AciklamaDurum" integer,
    "EskiBasvuruDurum" integer,
    "YeniBasvuruDurum" integer
);


--
-- Name: NaceKodu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NaceKodu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL
);


--
-- Name: OdemeReferansNumarasi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OdemeReferansNumarasi" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ReferansNumarasiTuru" integer NOT NULL,
    "ReferansNumarasi" character varying NOT NULL,
    "Tutar" integer NOT NULL,
    "OdemeDurum" integer NOT NULL,
    "BasvuruKimlikRef" uuid NOT NULL
);


--
-- Name: Personel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Personel" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer,
    "Ad" character varying,
    "Soyad" character varying,
    "TCKimlik" character varying,
    "Görevi" integer,
    "GirisTarihi" timestamp without time zone,
    "CikisTarihi" timestamp without time zone,
    "CevreGorevlisiBelgeNo" character varying,
    "GuvenlikDanismaniBelgeNo" character varying,
    "CevreGorevlisiBelgeBaslangicTarihi" timestamp without time zone,
    "CevreGorevlisiBelgeBitisTarihi" timestamp without time zone,
    "GuvenlikDanismaniBelgeBaslangicTarihi" timestamp without time zone,
    "GuvenlikDanismaniBelgeBitisTarihi" timestamp without time zone
);


--
-- Name: Surucu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Surucu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "Ad" character varying,
    "Soyad" character varying,
    "TCKimlik" character varying,
    "Telefon" character varying,
    "Eposta" character varying
);


--
-- Name: SurucuBelge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurucuBelge" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer,
    "BelgeKimlikRef" uuid NOT NULL,
    "SurucuKimlikRef" uuid NOT NULL,
    "BelgeTuru" integer,
    "SonGecerlilikTarihi" timestamp without time zone
);


--
-- Name: SurucuGecmis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurucuGecmis" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "SurucuKimlikRef" uuid NOT NULL,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: SurucuTasimaArac; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurucuTasimaArac" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "SurucuKimlikRef" uuid NOT NULL,
    "TasimaAracKimlikRef" uuid NOT NULL
);


--
-- Name: TasimaArac; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TasimaArac" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "AracTuru" integer,
    "AracTuruUygunluk" integer,
    "AracTuruUygunlukNot" character varying,
    "TeminTuru" integer,
    "TeminTuruUygunluk" integer,
    "TeminTuruUygunlukNot" character varying,
    "TasinacakAtikTuru" integer,
    "TasinacakAtikTuruUygunluk" integer,
    "TasinacakAtikTuruUygunlukNot" character varying,
    "TehlikeliAtikGrubu" integer,
    "TehlikeliAtikGrubuUygunluk" integer,
    "TehlikeliAtikGrubuUygunlukNot" character varying,
    "AracTasimaKapasitesi" character varying,
    "AracTasimaKapasitesiUygunluk" integer,
    "AracTasimaKapasitesiUygunlukNot" character varying,
    "AmbalajTuru" integer,
    "AmbalajTuruUygunluk" integer,
    "AmbalajTuruUygunlukNot" character varying,
    "Plaka" character varying,
    "PlakaUygunluk" integer,
    "PlakaUygunlukNot" character varying,
    "SaseNumarasi" character varying,
    "SaseNumarasiUygunluk" integer,
    "SaseNumarasiUygunlukNot" character varying,
    "AracSinifi" integer,
    "AracSinifiUygunluk" integer,
    "AracSinifiUygunlukNot" character varying,
    "İlkTescilTarihi" timestamp without time zone,
    "TescilTarihiUygunluk" integer,
    "TescilTarihiUygunlukNot" character varying,
    "MobilCihazId" character varying,
    "CihazIdUygunluk" integer,
    "CihazIdUygunlukNot" character varying,
    "YetkiBelge" integer,
    "YetkiBelgeUygunluk" integer,
    "YetkiBelgeUygunlukNot" character varying,
    "AtikKod" integer,
    "AtikKodUygunluk" integer,
    "AtikKodUygunlukNot" character varying,
    "MaliSorumlulukSigortasiPoliceNo" character varying,
    "TasitADRUygunlukBelgeNo" character varying,
    "IlKodu" character varying,
    "AracSahibiAd" character varying,
    "AracSahibiSoyad" character varying,
    "AracSahibiTelefon" character varying,
    "AracSahibiEposta" character varying,
    "AracSahibiAdres" character varying
);


--
-- Name: TasimaAracBelge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TasimaAracBelge" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BelgeKimlikRef" uuid NOT NULL,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "BelgeTuru" integer,
    "SonGecerlilikTarihi" timestamp without time zone
);


--
-- Name: TasimaAracGecmis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TasimaAracGecmis" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "TasimaAracKimlikRef" uuid NOT NULL,
    "EskiVeri" character varying,
    "YeniVeri" character varying
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Data for Name: AltBasvuruAtikKodu; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruAtikKoduAsama; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruLisansIptal; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruLisansIptalAsama; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruLisansVize; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruLisansVizeAsama; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruSurucu; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruSurucuAsama; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruTasimaArac; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruTasimaAracAsama; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AltBasvuruTasimaAracOdeme; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AtikTehlikelilikOzellik; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AtyonAtikKod; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AtyonBasvuru; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AtyonBasvuruBelge; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AtyonBasvuruCevreMuhendisi; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruAsama; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruCevreMuhendisiEksiklik; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruGecmis; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruOdeme; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruOdemeEksiklik; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruSurucu; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruSurucuEksiklik; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruTasimaArac; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: BasvuruTasimaAracEksiklik; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: IlDegisikligiBasvuru; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: IlDegisikligiBasvuruAsama; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: OdemeReferansNumarasi; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: Surucu; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: SurucuBelge; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: SurucuGecmis; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: SurucuTasimaArac; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: TasimaArac; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: TasimaAracBelge; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: TasimaAracGecmis; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: atyon; Owner: -
--



--
-- Data for Name: AtikKod; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."AtikKod" VALUES ('0058b96b-d695-4095-a185-132f753311cc', '2023-07-24 11:06:19.276016', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Temel Organik Kimyasal Maddelerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, '2ed155b3-66a6-455e-9b6f-f2af44d782c9', '0701', false, true, NULL, 701, 7);
INSERT INTO "e-izin"."AtikKod" VALUES ('00e6e211-81db-4c59-a001-17d19ff960ef', '2023-07-24 11:06:19.230372', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Benzin', 1, '7b8d483e-9d6f-4f7e-80da-7676fdcfd941', '130702', true, true, NULL, 130702, 1307);
INSERT INTO "e-izin"."AtikKod" VALUES ('010299f9-68a1-496f-b7e2-0704afccc9a6', '2023-07-24 11:06:19.216881', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kalsiyum arsenat', 1, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100403', true, true, NULL, 100403, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('011c36f5-2a9f-419b-8278-11a16ddecbe4', '2023-07-24 11:06:19.21748', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '20 01 21 ve 20 01 23 dışındaki tehlikeli parçalar6 içeren ve ıskartaya çıkmış elektrikli ve elektronik ekipmanlar', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200135', true, true, NULL, 200135, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('012d200e-c91d-4186-b764-6cccca4b416e', '2023-07-24 11:06:19.200783', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sıvı halde olmayan çözücüler içeren yağ giderme atıkları', 1, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040103', true, true, NULL, 40103, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('027982e3-1975-4831-91be-f45bce694965', '2023-07-24 11:06:19.238065', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'AHŞAP İŞLEME VE KAĞIT, KARTON, KAĞIT HAMURU, PANEL(SUNTA) VE MOBİLYA ÜRETİMİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '03', false, true, NULL, 3, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('027be83d-4396-4f36-aff2-cf439429bfb6', '2023-07-24 11:06:19.23894', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağır metaller içeren sırlama atıkları', 1, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101211', true, true, NULL, 101211, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('02890c62-fdea-4520-a830-5462e228d706', '2023-07-24 11:06:19.276212', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Plastiklerin, Sentetik Kauçuk ve Yapay Elyafların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, '2ed155b3-66a6-455e-9b6f-f2af44d782c9', '0702', false, true, NULL, 702, 7);
INSERT INTO "e-izin"."AtikKod" VALUES ('029e919b-0a6a-452b-9119-e90ac56be1f4', '2023-07-24 11:06:19.230431', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sentetik hidrolik yağlar', 2, '676c52f5-81e5-4570-8135-2f3324688790', '130111', true, true, true, 130111, 1301);
INSERT INTO "e-izin"."AtikKod" VALUES ('02ad50ac-b89e-4b16-a98e-1931776eea3b', '2023-07-24 11:06:19.24822', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İnsan Tüketimi ve Endüstriyel Kullanım İçin Gereken Suyun Hazırlanmasından Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1909', false, true, NULL, 1909, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('03335645-37b7-4498-9b12-5cfe1e93119f', '2023-07-24 11:06:19.241511', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mineral esaslı klor içeren hidrolik yağlar', 2, '676c52f5-81e5-4570-8135-2f3324688790', '130109', true, true, true, 130109, 1301);
INSERT INTO "e-izin"."AtikKod" VALUES ('5ce42bb9-6207-44e5-be45-21eddc4238b9', '2023-07-24 11:06:19.234353', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Plastik', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160119', false, false, NULL, 160119, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('267342cb-f0f6-44df-ba6b-548c3ebb96ea', '2023-07-24 11:06:19.226563', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kompozit ambalaj', NULL, '8f20317c-2895-43f2-a702-b02b71336086', '150105', false, false, NULL, 150105, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('036fc917-1705-43ab-bff2-88be76f77c72', '2023-07-24 11:06:19.259619', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren zirai kimyasal atıklar', 1, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020108', true, true, NULL, 20108, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('037ac6a7-b186-40ea-bba5-5f699b64b151', '2023-07-24 11:06:19.235453', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '3f6a127a-afa3-4ec3-b92a-0b42f0c91478', '060999', false, false, NULL, 60999, 609);
INSERT INTO "e-izin"."AtikKod" VALUES ('03bcd772-17b5-48e4-ba7a-50c12239c89f', '2023-07-24 11:06:19.243127', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 02 09''dan 16 02 12''ye kadar olanların dışındaki tehlikeli parçalar2 içeren ıskarta ekipmanlar', 1, 'fcf7052f-6471-4238-bfd9-a9b918f118ce', '160213', true, true, NULL, 160213, 1602);
INSERT INTO "e-izin"."AtikKod" VALUES ('040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '2023-07-24 11:06:19.233632', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'LİSTEDE BAŞKA BİR ŞEKİLDE BELİRTİLMEMİŞ ATIKLAR', NULL, NULL, '16', false, true, NULL, 16, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('042109d1-020d-4d82-b9c4-32eb635f54e0', '2023-07-24 11:06:19.245108', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Alüminyum', NULL, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170402', false, false, NULL, 170402, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('04a55869-1883-4a3a-af2d-da4c2c2ca138', '2023-07-24 11:06:19.238345', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağaç kabuğu ve odun atıkları', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030301', false, false, NULL, 30301, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('056f4c4d-3d2e-4faa-8665-aac0d7631739', '2023-07-24 11:06:19.247861', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Elek üstü maddeler', NULL, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190801', false, false, NULL, 190801, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('05f219fe-21e2-4128-95eb-65b72829b3fa', '2023-07-24 11:06:19.266817', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık Astarlar ve Refraktörler', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1611', false, true, NULL, 1611, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('0616d181-bdb8-454f-af80-0a765b0d6086', '2023-07-24 11:06:19.230491', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık Yalıtım ve Isı İletim Yağları', NULL, 'd7bf6b00-841e-4840-ba5b-3e2c3b77bf21', '1303', false, true, NULL, 1303, 13);
INSERT INTO "e-izin"."AtikKod" VALUES ('063e9a81-bafb-4d47-a083-72a13a709c92', '2023-07-24 11:06:19.282378', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer atıklar', 1, 'a0cd50e6-460f-406f-a27c-07d2e27630d4', '110302', true, true, NULL, 110302, 1103);
INSERT INTO "e-izin"."AtikKod" VALUES ('0665023e-8be9-4695-a3c0-11084c75e5f1', '2023-07-24 11:06:19.22868', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '98beda5b-44c8-4aee-afd8-24c61d6fe067', '110599', false, false, NULL, 110599, 1105);
INSERT INTO "e-izin"."AtikKod" VALUES ('067388ed-ad82-4155-9adc-1d04187e8c70', '2023-07-24 11:06:19.242828', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Karışık ambalaj', NULL, '8f20317c-2895-43f2-a702-b02b71336086', '150106', false, false, NULL, 150106, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('0679c123-9c79-4909-ba99-fa94e8d68951', '2023-07-24 11:06:19.244871', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bitümlü Karışımlar, Kömür Katranı ve Katranlı Ürünler', NULL, 'c4d6b5a4-b326-453e-a375-286212bd4d29', '1703', false, true, NULL, 1703, 17);
INSERT INTO "e-izin"."AtikKod" VALUES ('06a942da-166d-41bc-8dde-de05d1034674', '2023-07-24 11:06:19.234716', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 02 15 dışındaki ıskarta ekipmanlardan çıkartılmış parçalar', NULL, 'fcf7052f-6471-4238-bfd9-a9b918f118ce', '160216', false, false, NULL, 160216, 1602);
INSERT INTO "e-izin"."AtikKod" VALUES ('06f187b9-b301-48ec-9e76-839641bc0d07', '2023-07-24 11:06:19.237084', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '08697385-2b61-4344-afd0-169b00c005ea', '020299', false, false, NULL, 20299, 202);
INSERT INTO "e-izin"."AtikKod" VALUES ('079e8777-e624-4a0f-9669-a32b5c39ddad', '2023-07-24 11:06:19.283518', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağaç İşlemeden ve Sunta ve Mobilya Üretiminden Kaynaklanan Atıklar', NULL, '027982e3-1975-4831-91be-f45bce694965', '0301', false, true, NULL, 301, 3);
INSERT INTO "e-izin"."AtikKod" VALUES ('07a8b9c4-da35-4838-86e3-a340636a4aa7', '2023-07-24 11:06:19.206614', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kömürün Pirolitik İşlenmesinden Kaynaklanan Atıklar', NULL, '5ccc997c-1c3a-4640-8f1a-d9cb0f0f4290', '0506', false, true, NULL, 506, 5);
INSERT INTO "e-izin"."AtikKod" VALUES ('07cb1991-1231-4faa-9197-ab29951bc58f', '2023-07-24 11:06:19.235634', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070409', true, true, NULL, 70409, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('08697385-2b61-4344-afd0-169b00c005ea', '2023-07-24 11:06:19.237024', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Et, balık ve diğer hayvansal kökenli gıda maddelerinin hazırlanmasından ve işlenmesinden kaynaklanan atıklar', NULL, 'a80a1d5d-070c-488c-bd1b-4fb2bd4b420f', '0202', false, true, NULL, 202, 2);
INSERT INTO "e-izin"."AtikKod" VALUES ('08d397f7-0368-467f-8e51-589775556c12', '2023-07-24 11:06:19.282197', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık izosiyanatlar', 1, '97206922-2204-4e53-8d2e-0e55dde62be0', '080501', true, true, NULL, 80501, 805);
INSERT INTO "e-izin"."AtikKod" VALUES ('09208f4f-62bf-4065-a6f7-01ba68190520', '2023-07-24 11:06:19.283885', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kesiciler (18 02 02 hariç)', 2, '33e02f8e-69f7-4898-bae5-35e162129f2c', '180201', false, false, NULL, 180201, 1802);
INSERT INTO "e-izin"."AtikKod" VALUES ('0957643a-45f9-40c6-aea4-1972d64af734', '2023-07-24 11:06:19.234175', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sıvılaştırılmış gaz tankları', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160116', false, false, NULL, 160116, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('09581870-127b-46e1-90a3-e65e62d8be16', '2023-07-24 11:06:19.277582', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve verniğin sökülmesinden kaynaklanan atıklar', 1, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080117', true, true, NULL, 80117, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('095d031d-3652-4300-aabe-a832ce597318', '2023-07-24 11:06:19.229468', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'PCB (1) içeren hidrolik yağlar', 2, '676c52f5-81e5-4570-8135-2f3324688790', '130101', true, true, true, 130101, 1301);
INSERT INTO "e-izin"."AtikKod" VALUES ('09620607-d79c-446f-8091-e42c5a4fcea7', '2023-07-24 11:06:19.261663', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '079e8777-e624-4a0f-9669-a32b5c39ddad', '030199', false, false, NULL, 30199, 301);
INSERT INTO "e-izin"."AtikKod" VALUES ('098cc347-5ef5-4f1b-9c32-50b45b7dcd40', '2023-07-24 11:06:19.271909', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '20 01 31 dışındaki ilaçlar', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200132', false, false, NULL, 200132, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('0992b899-80a5-429f-b40d-b28c7ecd3504', '2023-07-24 11:06:19.237572', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Unlu mamuller ve şekerleme endüstrisinden kaynaklanan atıklar', NULL, 'a80a1d5d-070c-488c-bd1b-4fb2bd4b420f', '0206', false, true, NULL, 206, 2);
INSERT INTO "e-izin"."AtikKod" VALUES ('0a25ee0f-4638-415e-aeda-fdc803839357', '2023-07-24 11:06:19.236415', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atıkların birlikte yakılmasından (co-incineration) kaynaklanan ve tehlikeli maddeler içeren dip külü, cüruf ve kazan tozu', 1, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100114', true, true, NULL, 100114, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('0a47b035-1dd5-4f49-bc62-adf5812fd5fa', '2023-07-24 11:06:19.20424', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asit ziftleri', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050107', true, true, NULL, 50107, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('0a5d84d7-93d3-4124-b26c-a9db39c378a2', '2023-07-24 11:06:19.231707', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren boya, mürekkepler, yapıştırıcılar ve reçineler', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200127', true, true, NULL, 200127, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('0a6682e9-2768-4621-b3cf-7255157173d0', '2023-07-24 11:06:19.226311', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Isıl işlem öncesi karışım hazırlama atıkları', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101301', false, false, NULL, 101301, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('0a67820a-41b6-4edf-aea0-2a8d18a50e24', '2023-07-24 11:06:19.233692', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ömrünü tamamlamış araçlar', 2, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160104', true, true, NULL, 160104, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('0a699adf-2194-4f0e-bf02-4fa658077812', '2023-07-24 11:06:19.231885', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Krom içeren tabaklanmış atık deri (çivitli parçalar, tıraşlamalar, kesmeler, parlatma tozu)', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040108', false, false, NULL, 40108, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('0a6ff0a4-a983-4a95-835f-d47adeb70376', '2023-07-24 11:06:19.236133', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer partiküller', 1, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101011', true, true, NULL, 101011, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('0ac14f0a-af4b-4a14-a646-f1f8a8eca126', '2023-07-24 11:06:19.242948', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddelerle kirlenmiş emiciler, filtre malzemeleri (başka şekilde tanımlanmamış ise yağ filtreleri), temizleme bezleri, koruyucu giysiler', 1, '1d2fe472-acf4-44a7-8b21-07f15e6c3fd5', '150202', true, true, NULL, 150202, 1502);
INSERT INTO "e-izin"."AtikKod" VALUES ('0acb529e-730c-430a-9b4e-d3d781fc638a', '2023-07-24 11:06:19.231168', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 04 10 dışındaki kablolar', NULL, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170411', false, false, NULL, 170411, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('0ae00dbb-1531-4243-86b1-e86277c07a64', '2023-07-24 11:06:19.259798', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yıkama ve temizlemeden kaynaklanan çamurlar', NULL, '08697385-2b61-4344-afd0-169b00c005ea', '020201', false, false, NULL, 20201, 202);
INSERT INTO "e-izin"."AtikKod" VALUES ('0af4e68d-af19-4916-8b24-394aa1808dac', '2023-07-24 11:06:19.227711', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İkincil üretimden kaynaklanan tuz cürufları', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100308', true, true, NULL, 100308, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('0b6ef69f-a758-4a56-ba43-f2e851eca5ea', '2023-07-24 11:06:19.279205', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağır metaller içeren küçük parçacıklar ve cam tozu halinde atık cam(örneğin katot ışın tüplerinden)', 1, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101111', true, true, NULL, 101111, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('0bc8cef9-25c4-4b8c-82b6-444a228ff398', '2023-07-24 11:06:19.258086', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalik olmayan maden kazılarından kaynaklanan atıklar', NULL, '9b24859a-69f5-4b25-818f-f09f47b20fc6', '010102', false, false, NULL, 10102, 101);
INSERT INTO "e-izin"."AtikKod" VALUES ('0c2d44f6-5fee-444f-beb8-5ad3318f616a', '2023-07-24 11:06:19.272357', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer Belediye Atıkları', NULL, 'f5600253-c2df-4afc-8897-a196fe5280a6', '2003', false, true, NULL, 2003, 20);
INSERT INTO "e-izin"."AtikKod" VALUES ('0c6f2107-4c71-4bd8-8c4d-896fd6a201e9', '2023-07-24 11:06:19.281044', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'MADENLERİN ARANMASI, ÇIKARILMASI, İŞLETİLMESİ, FİZİKİ VE KİMYASAL İŞLEME TABİ TUTULMASI SIRASINDA ORTAYA ÇIKAN ATIKLAR', NULL, NULL, '01', false, true, NULL, 1, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('0c744e8c-4c87-4d7b-a950-7b86910e8cf5', '2023-07-24 11:06:19.25514', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'FOTOĞRAF ENDÜSTRİSİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '09', false, true, NULL, 9, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('0c74ab22-30b7-44fd-8a78-91dc30bf4f41', '2023-07-24 11:06:19.235328', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bazların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0602', false, true, NULL, 602, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('0c8a9300-aa6c-43cf-b3de-0158bacd4d63', '2023-07-24 11:06:19.229528', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer hidrolik yağlar', 2, '676c52f5-81e5-4570-8135-2f3324688790', '130113', true, true, true, 130113, 1301);
INSERT INTO "e-izin"."AtikKod" VALUES ('0ca4f5b9-6427-4023-84fd-0d9085eb304d', '2023-07-24 11:06:19.250998', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı tozu', 1, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100603', true, true, NULL, 100603, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('18c30097-def9-492d-b700-7fce7a0c8032', '2023-07-24 11:06:19.225981', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çözücü bazlı banyo solüsyonları', 1, '8693d445-ccb1-423b-8380-a415bab62bb1', '090103', true, true, NULL, 90103, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('0cdc83f4-b290-44ce-84e3-984143b2dabf', '2023-07-24 11:06:19.247494', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Vitrifiye atık tavlanmasından çıkan sulu sıvı', NULL, '7f1f469e-1575-4540-b427-5f91228fad9d', '190404', false, false, NULL, 190404, 1904);
INSERT INTO "e-izin"."AtikKod" VALUES ('0cefc90a-99bb-47ba-a4bc-917ce41c300b', '2023-07-24 11:06:19.229715', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kolayca biyolojik olarak bozunabilir motor, şanzıman ve yağlama yağları', 2, 'dff8bb04-5506-4de9-980b-42baa9dd737b', '130207', true, true, true, 130207, 1302);
INSERT INTO "e-izin"."AtikKod" VALUES ('0d28a1ae-6ecf-4c43-81e6-e8a144012118', '2023-07-24 11:06:19.211214', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İnorganik Pigmentlerin ve Opaklaştırıcıların İmalatından Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0611', false, true, NULL, 611, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '2023-07-24 11:06:19.251905', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir Döküm İşleminden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1009', false, true, NULL, 1009, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('0d537417-fccc-47e6-8779-4a4a7f7587b9', '2023-07-24 11:06:19.252937', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 11 15 dışında baca gazı arıtımından kaynaklanan katı atıklar', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101116', false, false, NULL, 101116, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('0d7011d6-55d7-4659-ba77-c7a36013b638', '2023-07-24 11:06:19.228871', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Plastik yongalar ve çapaklar', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120105', false, false, NULL, 120105, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('0d789780-c492-49c5-8136-4ed6f97a4629', '2023-07-24 11:06:19.2507', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar', 1, '3b4a20a2-c147-4b99-b9bb-750194453116', '100508', true, true, NULL, 100508, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('0dade502-558b-4824-a348-b47100784927', '2023-07-24 11:06:19.22905', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kullanılmış (mum) parafin ve yağlar (Atık Ara Depolama tesisleri sadece kullanılmış parafin atıklarını kabul edebilir.)', 1, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120112', true, true, true, 120112, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('0db894e6-7476-4ba9-a789-f021d5cae115', '2023-07-24 11:06:19.261114', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '0992b899-80a5-429f-b40d-b28c7ecd3504', '020699', false, false, NULL, 20699, 206);
INSERT INTO "e-izin"."AtikKod" VALUES ('0dea6854-aa5e-41c9-8646-9a7361e23e7a', '2023-07-24 11:06:19.276151', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer filtre kekleri ve kullanılmış absorbanlar', 1, '0058b96b-d695-4095-a185-132f753311cc', '070110', true, true, NULL, 70110, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('0e6db868-8729-4442-bcde-caff31f6b941', '2023-07-24 11:06:19.214599', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070603', true, true, NULL, 70603, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('0e8fb37d-f4dc-4314-8aaa-749c545660c5', '2023-07-24 11:06:19.276525', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'faf9d336-4990-4298-a50a-b56af7884053', '070303', true, true, NULL, 70303, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('0e9664ac-6062-434c-b294-68cc3cb7f933', '2023-07-24 11:06:19.267387', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ayrı Toplanan Fraksiyonlar (15 01 Hariç)', NULL, 'f5600253-c2df-4afc-8897-a196fe5280a6', '2001', false, true, NULL, 2001, 20);
INSERT INTO "e-izin"."AtikKod" VALUES ('0edacd0b-349f-4854-9d03-994ec406443a', '2023-07-24 11:06:19.269521', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Alçı Bazlı İnşaat Malzemeleri', NULL, 'c4d6b5a4-b326-453e-a375-286212bd4d29', '1708', false, true, NULL, 1708, 17);
INSERT INTO "e-izin"."AtikKod" VALUES ('0f307e30-6ebe-4b5b-9768-d84ab204ebc6', '2023-07-24 11:06:19.26421', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kum odacığından ve yağ/su ayırıcılarından çıkan karışık atıklar', 1, '7b1f3519-e16b-445c-b927-d70255f332d9', '130508', true, true, NULL, 130508, 1305);
INSERT INTO "e-izin"."AtikKod" VALUES ('0fe18af7-8dfc-4216-b537-b3d0ff6b61d2', '2023-07-24 11:06:19.278843', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren atık bağlayıcılar', 1, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100913', true, true, NULL, 100913, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('0fedb6e3-24f8-4825-a5c5-69bb0f605ff5', '2023-07-24 11:06:19.26592', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer patlayıcı atıklar', 1, 'f8e2cc9c-b5d7-4b2a-8cf8-c1dba53e6432', '160403', true, true, NULL, 160403, 1604);
INSERT INTO "e-izin"."AtikKod" VALUES ('1022496f-9d0b-4c3f-bbf2-aeadb80de7eb', '2023-07-24 11:06:19.228318', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '489a8b03-d530-40e7-b85e-fffbb62081ec', '110299', false, false, NULL, 110299, 1102);
INSERT INTO "e-izin"."AtikKod" VALUES ('104269d1-f5cf-41b4-835f-1f18a552ff03', '2023-07-24 11:06:19.266323', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Altın, gümüş, renyum, rodyum, paladyum, iridyum ya da platin içeren bitik katalizörler (16 08 07 hariç)', NULL, '927df4de-1098-43b7-a071-8c1877c8b691', '160801', false, false, NULL, 160801, 1608);
INSERT INTO "e-izin"."AtikKod" VALUES ('10439cd2-141c-41e8-b9cd-4f0aedc2fac1', '2023-07-24 11:06:19.263307', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz temizlemeden kaynaklanan cıva içeren atıklar', 1, '75941206-07c6-4bfc-8bf6-2de03de411a7', '101401', true, true, NULL, 101401, 1014);
INSERT INTO "e-izin"."AtikKod" VALUES ('1069679a-e630-4a99-80f4-10896952c884', '2023-07-24 11:06:19.277462', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 01 13 dışındaki boya ve vernik çamurları', NULL, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080114', false, false, NULL, 80114, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('10cb57ca-d3db-4fdc-833e-6ac8397e3d43', '2023-07-24 11:06:19.26412', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İnorganik ahşap koruyucu maddeler', 1, '32fa13d4-52f1-4c6e-9513-15ee2274d4c2', '030204', true, true, NULL, 30204, 302);
INSERT INTO "e-izin"."AtikKod" VALUES ('1105677a-6ddd-4fb1-95c6-a4c8542cebff', '2023-07-24 11:06:19.232675', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşletme Sahası İçerisindeki Atıksu Arıtımından Kaynaklanan Çamurlar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0605', false, true, NULL, 605, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('11100e6b-6932-49b7-a418-09a93913681d', '2023-07-24 11:06:19.251056', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer partiküller ve toz', NULL, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100604', false, false, NULL, 100604, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('1159295a-0939-4c2d-b707-e37747a5696e', '2023-07-24 11:06:19.232373', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Petrol desülfürizasyonu sonucu oluşan kükürt içeren atıklar', NULL, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050116', false, false, NULL, 50116, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('1171f1df-c475-42b4-a494-ce9c221ae00d', '2023-07-24 11:06:19.237149', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 01 07''den 16 01 11''e ve 16 01 13 ile 16 01 14 dışındaki tehlikeli parçalar', 1, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160121', true, true, NULL, 160121, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('11acefea-a608-4d17-a63c-9419eb10e01d', '2023-07-24 11:06:19.219268', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren baca gazı tozu', 1, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100815', true, true, NULL, 100815, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('129dc5ec-959d-42ac-867c-53c770e47e3e', '2023-07-24 11:06:19.252025', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Döküm yapılmış tehlikeli madde içeren maça ve kum döküm kalıpları', 1, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100907', true, true, NULL, 100907, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('12cf2015-72bb-41a1-ae9e-bfa4198d7e61', '2023-07-24 11:06:19.241149', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojen içeren madeni bazlı işleme yağları (emülsiyon ve solüsyonlar hariç)', 2, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120106', true, true, true, 120106, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('13483503-0f16-43cc-8de7-f4c84f39352e', '2023-07-24 11:06:19.255364', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağartıcı solüsyonları ve ağartıcı sabitleyici solüsyonlar', 1, '8693d445-ccb1-423b-8380-a415bab62bb1', '090105', true, true, NULL, 90105, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('13804b5d-d812-4e7b-841f-036a03dbdd61', '2023-07-24 11:06:19.234053', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fren sıvıları', 1, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160113', true, true, NULL, 160113, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('139fe8cd-c58a-46f8-93f2-84d16e51a539', '2023-07-24 11:06:19.270229', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olan atıklar', 2, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180103', true, true, NULL, 180103, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('13adf1a0-347d-4b27-82c7-49aac865f3eb', '2023-07-24 11:06:19.210994', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fosforlu cüruf', NULL, '3f6a127a-afa3-4ec3-b92a-0b42f0c91478', '060902', false, false, NULL, 60902, 609);
INSERT INTO "e-izin"."AtikKod" VALUES ('13b34703-1d7b-4f10-9cbb-bcf7b285c83d', '2023-07-24 11:06:19.225856', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '06 03 Dışındaki Metal İçeren Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0604', false, true, NULL, 604, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('14593da1-88ec-4238-9fee-b6f4db6c1e67', '2023-07-24 11:06:19.24798', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kentsel atık suyun arıtılmasından kaynaklanan çamurlar', NULL, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190805', false, false, NULL, 190805, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '2023-07-24 11:06:19.281113', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalik Minerallerin Fiziki ve Kimyasal Olarak İşlenmesinden Kaynaklanan Atıklar', NULL, '0c6f2107-4c71-4bd8-8c4d-896fd6a201e9', '0103', false, true, NULL, 103, 1);
INSERT INTO "e-izin"."AtikKod" VALUES ('1493b286-c3df-4aee-9b28-25cf688a6dac', '2023-07-24 11:06:19.249683', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yeraltı suyunun ıslahından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, '3c8d5e7a-e867-402f-b518-a5cafa387f07', '191305', true, true, NULL, 191305, 1913);
INSERT INTO "e-izin"."AtikKod" VALUES ('14f230d3-16dd-4541-8a38-b4d72fc35347', '2023-07-24 11:06:19.279809', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gümüş veya da gümüş bileşenleri içeren fotoğraf filmi ve kağıdı', NULL, '8693d445-ccb1-423b-8380-a415bab62bb1', '090107', false, false, NULL, 90107, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('152a4630-a79b-4ca5-8ea0-02a3cc191451', '2023-07-24 11:06:19.247071', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren sıvı yanabilir atıklar', 1, '23405de6-af3e-427e-9239-66d58607d7cc', '190208', true, true, NULL, 190208, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('15b7a42d-7d99-4839-968d-919db1997c62', '2023-07-24 11:06:19.210319', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kükürtlü Kimyasallardan, Kükürtleyici Kimyasal İşlemlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0606', false, true, NULL, 606, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('15f7edff-159b-47a0-b126-d979a370c75f', '2023-07-24 11:06:19.274293', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir ve çelik', NULL, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170405', false, false, NULL, 170405, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('162deb1b-4f3f-44df-9bc6-38cec0193be4', '2023-07-24 11:06:19.226755', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tuğlalar', NULL, 'b4c53dbe-7b9e-4d04-9339-95da478bd659', '170102', false, false, NULL, 170102, 1701);
INSERT INTO "e-izin"."AtikKod" VALUES ('165f3644-4976-4d9c-aec7-e191ef079fa2', '2023-07-24 11:06:19.233392', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ahşap ambalaj', NULL, '8f20317c-2895-43f2-a702-b02b71336086', '150103', false, false, NULL, 150103, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('16dc8975-828c-4e5f-8a9c-00ad25610053', '2023-07-24 11:06:19.275096', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Uçucu kül ve diğer baca gazı arıtma atıkları', 1, '7f1f469e-1575-4540-b427-5f91228fad9d', '190402', true, true, NULL, 190402, 1904);
INSERT INTO "e-izin"."AtikKod" VALUES ('171b9418-c8e7-488e-bdb9-ddfb44d645b9', '2023-07-24 11:06:19.227196', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sıyırma ve kireçleme ile deriden et sıyırma işleminden kaynaklanan atıklar', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040101', false, false, NULL, 40101, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('193a0e06-d931-4467-b936-1c592159e760', '2023-07-24 11:06:19.211284', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Titanyum dioksit üretiminden kaynaklanan kalsiyum bazlı reaksiyon atıkları', NULL, '0d28a1ae-6ecf-4c43-81e6-e8a144012118', '061101', false, false, NULL, 61101, 611);
INSERT INTO "e-izin"."AtikKod" VALUES ('1b266822-9359-47c4-92fb-30f08c819d48', '2023-07-24 11:06:19.277887', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil ve ikincil üretim cürufları', NULL, '3b4a20a2-c147-4b99-b9bb-750194453116', '100501', false, false, NULL, 100501, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('1b67b11c-79b3-4b7a-a9b3-c1bcf0a15cb0', '2023-07-24 11:06:19.235814', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar', 1, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100409', true, true, NULL, 100409, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('1bcba6cb-07b2-4a0e-8951-a2d304c46865', '2023-07-24 11:06:19.244574', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kiremitler ve seramikler', NULL, 'b4c53dbe-7b9e-4d04-9339-95da478bd659', '170103', false, false, NULL, 170103, 1701);
INSERT INTO "e-izin"."AtikKod" VALUES ('1be97b05-0d1c-4496-b152-628da0c72171', '2023-07-24 11:06:19.245702', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cıva içeren inşaat ve yıkım atıkları', 1, '6f38b08c-106b-4284-932e-2f21aef998d8', '170901', true, true, NULL, 170901, 1709);
INSERT INTO "e-izin"."AtikKod" VALUES ('1c450abe-04d6-454f-8a01-56e9f1cad39b', '2023-07-24 11:06:19.27677', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer filtre kekleri ve kullanılmış absorbanlar', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070410', true, true, NULL, 70410, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('1c4c2c53-64e2-499e-a19e-cc2d900f0a83', '2023-07-24 11:06:19.25476', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren sulu yapışkan veya dolgu macunu çamurları', 1, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080413', true, true, NULL, 80413, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('1d0de3b7-39a0-429d-ae7f-518bcfa5c9e4', '2023-07-24 11:06:19.249377', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tekstil malzemeleri', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191208', false, false, NULL, 191208, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('1d2fe472-acf4-44a7-8b21-07f15e6c3fd5', '2023-07-24 11:06:19.230669', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Emiciler, Filtre Malzemeleri, Temizleme Bezleri ve Koruyucu Giysiler', NULL, 'b37c3d4c-60be-4f29-ad8b-57ab2ca23366', '1502', false, true, NULL, 1502, 15);
INSERT INTO "e-izin"."AtikKod" VALUES ('1d45cb56-6a98-4d11-8355-98175c795051', '2023-07-24 11:06:19.202487', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040199', false, false, NULL, 40199, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('1dbbb636-a0b9-4b8e-be3c-50c09042dd5f', '2023-07-24 11:06:19.228258', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bakır hidrometalürjisi işlemlerinden kaynaklanan tehlikeli maddeler içeren atıklar', 1, '489a8b03-d530-40e7-b85e-fffbb62081ec', '110205', true, true, NULL, 110205, 1102);
INSERT INTO "e-izin"."AtikKod" VALUES ('1dcced59-2b0e-4155-bd80-bf827f60f120', '2023-07-24 11:06:19.244088', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış oksitleyici malzemeler', 1, '9755a757-20f8-4784-8424-5135b4c3444a', '160904', true, true, NULL, 160904, 1609);
INSERT INTO "e-izin"."AtikKod" VALUES ('1e851bc8-5de5-4695-b792-908cad223e92', '2023-07-24 11:06:19.246537', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan filtre kekleri', 1, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190105', true, true, NULL, 190105, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('1ea61d74-cdc3-46e4-a496-3887e5b1f31b', '2023-07-24 11:06:19.241595', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mineral esaslı klor içeren motor, şanzıman ve yağlama yağları', 2, 'dff8bb04-5506-4de9-980b-42baa9dd737b', '130204', true, true, true, 130204, 1302);
INSERT INTO "e-izin"."AtikKod" VALUES ('1ed46f2b-c31a-4505-b57c-b6b848761971', '2023-07-24 11:06:19.219149', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'e67297f9-9141-4cd9-ac88-e58d52bc88c9', '100799', false, false, NULL, 100799, 1007);
INSERT INTO "e-izin"."AtikKod" VALUES ('1f2257b7-ca58-40ed-9901-aecaaa25b3e4', '2023-07-24 11:06:19.235392', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Klor üretiminden kaynaklanan aktif karbon', 1, '254667d3-3d03-47c4-99ae-85ae4efa0b18', '060702', true, true, NULL, 60702, 607);
INSERT INTO "e-izin"."AtikKod" VALUES ('1f89776e-5c73-4121-b5f7-aef20024eb21', '2023-07-24 11:06:19.273723', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '20 01 27 dışındaki boya, mürekkepler, yapıştırıcılar ve reçineler', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200128', false, false, NULL, 200128, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('20134c9c-7156-4317-8fa5-220e12fce392', '2023-07-24 11:06:19.283339', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 10 09 dışındaki baca gazı tozu', NULL, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101010', false, false, NULL, 101010, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('2061a081-07ea-4c25-889f-8f3590239327', '2023-07-24 11:06:19.253299', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Boya ya da vernik sökücü atıkları', 1, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080121', true, true, NULL, 80121, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('207529a2-4a01-4e0e-8b4f-ecec38a2cda9', '2023-07-24 11:06:19.261019', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Koruyucu katkı maddelerinden kaynaklanan atıklar', NULL, '0992b899-80a5-429f-b40d-b28c7ecd3504', '020602', false, false, NULL, 20602, 206);
INSERT INTO "e-izin"."AtikKod" VALUES ('20c931c9-2810-4d7e-95d3-586323a673cf', '2023-07-24 11:06:19.224067', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070411', true, true, NULL, 70411, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('2191e87d-1178-4870-92b5-e7b94d39a4d3', '2023-07-24 11:06:19.28025', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 01 05, 10 01 07 ve 10 01 18 dışındaki gaz temizleme atıkları', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100119', false, false, NULL, 100119, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('21eae41d-c845-461d-8b61-0ec602286c21', '2023-07-24 11:06:19.209495', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Siyanür içeren katı tuzlar ve solüsyonlar', 1, '5dc8194f-2de7-4707-8fcb-ffac8a0ea72a', '060311', true, true, NULL, 60311, 603);
INSERT INTO "e-izin"."AtikKod" VALUES ('221f80c9-c528-4d0c-a6fa-9cf2bfd0fca9', '2023-07-24 11:06:19.222001', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 13 03 dışındaki toprak ıslahından kaynaklanan çamurlar', NULL, '3c8d5e7a-e867-402f-b518-a5cafa387f07', '191304', false, false, NULL, 191304, 1913);
INSERT INTO "e-izin"."AtikKod" VALUES ('22ff19a5-7b4b-478b-92ee-dbf339c239ec', '2023-07-24 11:06:19.272699', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Isıl işlem öncesi karışım hazırlama atıkları', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101201', false, false, NULL, 101201, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('2302c648-adc9-42b6-9b8f-905f216d9c46', '2023-07-24 11:06:19.273427', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren ya da bunlardan oluşan ıskarta organik kimyasallar', 1, 'd1a799b4-e386-4588-ade4-462395e2d1a5', '160508', true, true, NULL, 160508, 1605);
INSERT INTO "e-izin"."AtikKod" VALUES ('230b9182-0ebd-43b7-be85-f9b15f82de21', '2023-07-24 11:06:19.262667', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 12 09 dışındaki gaz arıtma katı atıkları', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101210', false, false, NULL, 101210, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('23405de6-af3e-427e-9239-66d58607d7cc', '2023-07-24 11:06:19.274654', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atıkların Fiziki/Kimyasal Arıtımından Kaynaklanan Atıklar (Krom Giderme, Siyanür Giderme, Nötralizasyon Dahil)', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1902', false, true, NULL, 1902, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('235a8557-aa28-4c06-9060-16bc23a58c6a', '2023-07-24 11:06:19.274844', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Stabilize Edilmiş/Katılaştırılmış Atıklar4', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1903', false, true, NULL, 1903, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('2375238c-ff34-461b-b32f-f7414004ac2e', '2023-07-24 11:06:19.218898', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli dip tortusu ve reaksiyon kalıntıları', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070507', true, true, NULL, 70507, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('23897c4b-2489-4696-a4a3-4e0bc2447d2e', '2023-07-24 11:06:19.224708', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan atıklar', NULL, '88e7ece3-789d-4b74-bc19-403a3f91dd79', '020305', false, false, NULL, 20305, 203);
INSERT INTO "e-izin"."AtikKod" VALUES ('23923282-a1bb-4b52-8311-e7dc95930db0', '2023-07-24 11:06:19.278477', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil ve ikincil üretimden kaynaklanan tuz cürufu', 1, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100808', true, true, NULL, 100808, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('23b405fe-fa9a-41fb-817f-b42f0402d03b', '2023-07-24 11:06:19.217678', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '20 01 37 dışındaki ahşap', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200138', false, false, NULL, 200138, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('243c6e22-3568-4a32-873c-468e91e0a246', '2023-07-24 11:06:19.280839', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 03 17 dışındaki anot üretiminden kaynaklanan karbon içerikli atıklar', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100318', false, false, NULL, 100318, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('244dab04-58a5-4509-bcd4-db5cef65ca50', '2023-07-24 11:06:19.279326', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 11 17 dışındaki baca gazı arıtımından kaynaklanan çamurlar ve filtre kekleri', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101118', false, false, NULL, 101118, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('245e8154-5b56-4d66-8cc6-dd13afd8b57f', '2023-07-24 11:06:19.269826', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'PCB içeren inşaat ve yıkıntı atıkları (örneğin PCB içeren dolgu macunları, PCB içeren reçine bazlı taban kaplama malzemeleri, PCB içeren kaplanmış sırlama birimleri, PCB içeren kapasitörler)', 2, '6f38b08c-106b-4284-932e-2f21aef998d8', '170902', true, true, NULL, 170902, 1709);
INSERT INTO "e-izin"."AtikKod" VALUES ('24ab41e1-65d8-477c-9ece-cb7ec5ec47e8', '2023-07-24 11:06:19.257219', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil üretim cürufları', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100304', true, true, NULL, 100304, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('24fde314-a8b4-4513-b356-417d09ad1997', '2023-07-24 11:06:19.282615', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalürjik olmayan proseslerden kaynaklanan, tehlikeli maddeler içeren astarlar ve refraktörler', 1, '05f219fe-21e2-4128-95eb-65b72829b3fa', '161105', true, true, NULL, 161105, 1611);
INSERT INTO "e-izin"."AtikKod" VALUES ('254667d3-3d03-47c4-99ae-85ae4efa0b18', '2023-07-24 11:06:19.275709', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Halojenli Kimyasal İşlemlerden Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0607', false, true, NULL, 607, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('25695e53-0be5-402b-aff7-24c39c4743e3', '2023-07-24 11:06:19.254319', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren atık baskı tonerleri', 1, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080317', true, true, NULL, 80317, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('25d81eb9-e76a-48d4-a720-93573685a5ab', '2023-07-24 11:06:19.275589', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ ve su ayrışmasından kaynaklanan sadece yenilebilir yağlar içeren yağ karışımları ve gres', NULL, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190809', false, false, NULL, 190809, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('261f4c4c-7976-4ece-b934-d8f4e9d211d6', '2023-07-24 11:06:19.245819', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İNSAN VE HAYVAN SAĞLIĞI VE/VEYA BU KONULARDAKİ ARAŞTIRMALARDAN KAYNAKLANAN ATIKLAR (DOĞRUDAN SAĞLIĞA İLİŞKİN OLMAYAN MUTFAK VE RESTORAN ATIKLARI HARİÇ)', NULL, NULL, '18', false, true, NULL, 18, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('26530c06-20b4-4730-a196-cde5c44e2af7', '2023-07-24 11:06:19.210797', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Zararlı klorosilan içeren atıklar', 1, '3ae124d5-a162-4d05-8d9f-25e3f41f8ff0', '060802', true, true, NULL, 60802, 608);
INSERT INTO "e-izin"."AtikKod" VALUES ('268c998e-1a83-4732-a3d0-56100895583f', '2023-07-24 11:06:19.204747', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yakıtların bazlar ile temizlemesi sonucu oluşan atıklar', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050111', true, true, NULL, 50111, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('26e1b416-2079-4335-b848-8f694a256c18', '2023-07-24 11:06:19.225736', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri', 1, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100607', true, true, NULL, 100607, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('26fffbdb-1704-425d-ad2f-db6201225ac0', '2023-07-24 11:06:19.279447', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer Kaplama Maddelerinin (Seramik Kaplama Dahil) İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, '65eda575-b204-412b-8918-dbac781a630c', '0802', false, true, NULL, 802, 8);
INSERT INTO "e-izin"."AtikKod" VALUES ('273e8e48-f840-418b-b508-892ce6098eb6', '2023-07-24 11:06:19.217098', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kloroflorokarbonlar içeren ıskartaya çıkartılmış ekipmanlar', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200123', true, true, NULL, 200123, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('274f042a-dfc5-4727-bdae-f5102ad9ac48', '2023-07-24 11:06:19.272612', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 09 05 dışında henüz döküm yapılamamış maça ve kum döküm kalıpları', NULL, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100906', false, false, NULL, 100906, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('27a88561-dbe4-4987-9915-914d0cc5dc6a', '2023-07-24 11:06:19.241824', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'PCB''ler içeren yalıtım ya da ısı iletim yağları', 2, '0616d181-bdb8-454f-af80-0a765b0d6086', '130301', true, true, true, 130301, 1303);
INSERT INTO "e-izin"."AtikKod" VALUES ('27ec71b9-c118-4cd0-a27c-3604c735aa5c', '2023-07-24 11:06:19.234596', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 02 09''dan 16 02 13''e kadar olanların dışındaki ıskarta ekipmanlar', NULL, 'fcf7052f-6471-4238-bfd9-a9b918f118ce', '160214', false, false, NULL, 160214, 1602);
INSERT INTO "e-izin"."AtikKod" VALUES ('283d2d92-b1a8-4381-8c47-2839c1555490', '2023-07-24 11:06:19.232071', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşlenmemiş tekstil elyafı atıkları', NULL, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040221', false, false, NULL, 40221, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('291ae6c3-a038-48df-98da-9ecc7d6b192f', '2023-07-24 11:06:19.229115', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kaynak atıkları', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120113', false, false, NULL, 120113, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('295451fc-3169-43ca-bb10-6fdbd916a560', '2023-07-24 11:06:19.253417', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık kaplama tozları', NULL, '26fffbdb-1704-425d-ad2f-db6201225ac0', '080201', false, false, NULL, 80201, 802);
INSERT INTO "e-izin"."AtikKod" VALUES ('29928816-ad46-4d00-a24c-bde8c1796d76', '2023-07-24 11:06:19.275649', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070611', true, true, NULL, 70611, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('29d15681-36f6-4ddd-aa1f-2fb17162bce5', '2023-07-24 11:06:19.232794', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli kükürt bileşenleri içeren atıklar', 1, '15b7a42d-7d99-4839-968d-919db1997c62', '060602', true, true, NULL, 60602, 606);
INSERT INTO "e-izin"."AtikKod" VALUES ('29d37f0a-c4f6-4fbe-aa54-aacce0f6f26f', '2023-07-24 11:06:19.269057', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atıkların mekanik işlenmesinden kaynaklanan tehlikeli maddeler içeren diğer atıklar (karışık malzemeler dahil)', 1, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191211', true, true, NULL, 191211, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('2a12bc0d-40dd-41b5-86fc-e008b4166649', '2023-07-24 11:06:19.210172', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cıva içeren atıklar', 1, '13b34703-1d7b-4f10-9cbb-bcf7b285c83d', '060404', true, true, NULL, 60404, 604);
INSERT INTO "e-izin"."AtikKod" VALUES ('2a4e94d7-5758-4e58-b6f7-ef64702e7d94', '2023-07-24 11:06:19.257051', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100299', false, false, NULL, 100299, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('2a709887-bcb2-4554-9cec-afebac6cef02', '2023-07-24 11:06:19.268805', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mineraller (örneğin kum, taşlar)', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191209', false, false, NULL, 191209, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('2a9bf3b5-94d1-44fe-8d0c-f0063380d18c', '2023-07-24 11:06:19.242588', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tuz giderim çamurları ya da emülsiyonları', 1, 'ffc856a2-3bb3-4047-9813-2ade31e1f019', '130801', true, true, NULL, 130801, 1308);
INSERT INTO "e-izin"."AtikKod" VALUES ('2b2c7994-4d95-42ee-b558-e8a2774501a2', '2023-07-24 11:06:19.27381', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 11 03 dışındaki metalürjik proseslerden kaynaklanan diğer astar ve refraktörler', NULL, '05f219fe-21e2-4128-95eb-65b72829b3fa', '161104', false, false, NULL, 161104, 1611);
INSERT INTO "e-izin"."AtikKod" VALUES ('2b716f6d-e0b2-4ca8-a4c9-affa8711c1b7', '2023-07-24 11:06:19.255844', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Uçucu yağ külü ve kazan tozu', 1, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100104', true, true, NULL, 100104, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('2b949647-135b-4203-a443-08332747b5ea', '2023-07-24 11:06:19.276833', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli madde içeren katı atıklar', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070413', true, true, NULL, 70413, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('2bf312b5-9509-4efe-812f-0b2d3e72e9b0', '2023-07-24 11:06:19.259709', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020199', false, false, NULL, 20199, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('2bf4a321-3a4c-4906-b0c3-a9ace48ea5ca', '2023-07-24 11:06:19.26864', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren ahşap', 1, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191206', true, true, NULL, 191206, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('2c6077aa-2057-4930-8026-76bdeb612fba', '2023-07-24 11:06:19.256711', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 02 07 dışında gaz arıtımı sonucu ortaya çıkan katı atıklar', NULL, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100208', false, false, NULL, 100208, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('2c63d288-6104-4eeb-807e-f1a0ac4dfa69', '2023-07-24 11:06:19.22386', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '04 02 19 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040220', false, false, NULL, 40220, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('2cc8b711-0e7d-4aeb-a8de-9e7d57836ef5', '2023-07-24 11:06:19.282498', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asitlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0601', false, true, NULL, 601, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('2ce3a2bf-285c-44fe-8dbc-c0459cb13daf', '2023-07-24 11:06:19.228014', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Membran ya da iyon değişim sistemlerinden kaynaklanan tehlikeli maddeler içeren sıvı ve çamurlar', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110115', true, true, NULL, 110115, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('2ce64b67-f671-4552-b62c-3352af914c90', '2023-07-24 11:06:19.247133', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren katı yanabilir atıklar', 1, '23405de6-af3e-427e-9239-66d58607d7cc', '190209', true, true, NULL, 190209, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('2d5c0b02-f86d-4751-8030-1e2f3abd0b02', '2023-07-24 11:06:19.261569', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren talaş, yonga, kıymık, ahşap, kontraplak ve kaplamalar', 1, '079e8777-e624-4a0f-9669-a32b5c39ddad', '030104', true, true, NULL, 30104, 301);
INSERT INTO "e-izin"."AtikKod" VALUES ('2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '2023-07-24 11:06:19.281237', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalik Olmayan Minerallerin Fiziki ve Kimyasal İşlemlerinden Kaynaklanan Atıklar', NULL, '0c6f2107-4c71-4bd8-8c4d-896fd6a201e9', '0104', false, true, NULL, 104, 1);
INSERT INTO "e-izin"."AtikKod" VALUES ('2e85099d-db87-47f0-8dda-a3949d4986d5', '2023-07-24 11:06:19.250106', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Giysiler', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200110', false, false, NULL, 200110, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('2eb7903d-db30-48a6-aa2e-eb4baeae8fff', '2023-07-24 11:06:19.232914', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'ffc856a2-3bb3-4047-9813-2ade31e1f019', '130899', false, true, NULL, 130899, 1308);
INSERT INTO "e-izin"."AtikKod" VALUES ('2ed155b3-66a6-455e-9b6f-f2af44d782c9', '2023-07-24 11:06:19.21158', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'ORGANİK KİMYASAL İŞLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '07', false, true, NULL, 7, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('2f18437c-863f-4cd0-ab67-2fb79a491d22', '2023-07-24 11:06:19.21246', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık plastik', NULL, '02890c62-fdea-4520-a830-5462e228d706', '070213', false, false, NULL, 70213, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('2f57047f-0fcb-4e8b-a252-0c8fd2736b51', '2023-07-24 11:06:19.208621', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Nitrik asit ve nitröz asit', 1, '2cc8b711-0e7d-4aeb-a8de-9e7d57836ef5', '060105', true, true, NULL, 60105, 601);
INSERT INTO "e-izin"."AtikKod" VALUES ('2f6a6666-8757-4a17-9f5b-706b9e8c8760', '2023-07-24 11:06:19.247252', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '23405de6-af3e-427e-9239-66d58607d7cc', '190299', false, false, NULL, 190299, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('2fc1a7b8-967c-4f1a-89d6-88e9ff938b88', '2023-07-24 11:06:19.23055', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Nehir ve göl seyrüseferinden (iç su yolu denizciliğinden) kaynaklanan sintine yağları', 1, '4a6ea286-5629-48e0-9e72-ce8ca286b51f', '130401', true, true, NULL, 130401, 1304);
INSERT INTO "e-izin"."AtikKod" VALUES ('2fcf0704-e41f-4f6b-a292-3503f5a714a8', '2023-07-24 11:06:19.230313', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fuel-oil ve mazot', 1, '7b8d483e-9d6f-4f7e-80da-7676fdcfd941', '130701', true, true, NULL, 130701, 1307);
INSERT INTO "e-izin"."AtikKod" VALUES ('2fd9b466-c166-4099-8e22-9eeb03743780', '2023-07-24 11:06:19.213613', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer dip tortusu ve reaksiyon kalıntıları', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070408', true, true, NULL, 70408, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('2ff781c7-2512-4305-a3b4-52c26296d720', '2023-07-24 11:06:19.22048', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Biyolojik olarak kolay bozunur işleme yağı', 2, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120119', true, true, NULL, 120119, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('2ff9f403-e40e-4176-a2fe-7af3cec67286', '2023-07-24 11:06:19.27365', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Foto kimyasallar', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200117', true, true, NULL, 200117, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('3048e3b8-cd64-43f3-b008-c4c15e94f3ab', '2023-07-24 11:06:19.249131', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir dışı metal', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191203', false, false, NULL, 191203, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('30ba5583-e8c9-44a0-bc74-fcfec2bd2744', '2023-07-24 11:06:19.218697', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '06 09 03 dışındaki kalsiyum bazlı reaksiyon atıkları', NULL, '3f6a127a-afa3-4ec3-b92a-0b42f0c91478', '060904', false, false, NULL, 60904, 609);
INSERT INTO "e-izin"."AtikKod" VALUES ('311fb756-3ac0-4a00-94e8-e590876acb60', '2023-07-24 11:06:19.212534', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren katkı maddelerinin atıkları', 1, '02890c62-fdea-4520-a830-5462e228d706', '070214', true, true, NULL, 70214, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('312d5c87-26f6-4f22-bd39-99735568abd1', '2023-07-24 11:06:19.235996', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 09 09 dışındaki baca gazı tozu', NULL, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100910', false, false, NULL, 100910, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('3138ef97-01a3-40d7-8eef-bc830a0d892b', '2023-07-24 11:06:19.283826', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 07 02 dışındaki düzenli depolama sahası sızıntı suları', NULL, '6e1255cb-10b7-4151-94d4-92eb6bc0ecc5', '190703', false, false, NULL, 190703, 1907);
INSERT INTO "e-izin"."AtikKod" VALUES ('32fa13d4-52f1-4c6e-9513-15ee2274d4c2', '2023-07-24 11:06:19.261753', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ahşap Koruma Atıkları', NULL, '027982e3-1975-4831-91be-f45bce694965', '0302', false, true, NULL, 302, 3);
INSERT INTO "e-izin"."AtikKod" VALUES ('331f8e80-a1ee-4414-a12b-0e984957caf8', '2023-07-24 11:06:19.26823', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 10 03 dışındaki uçucu atık parçacıkları ve tozlar', NULL, '87472e6e-58cd-47da-8f27-282cbb95f77b', '191004', false, false, NULL, 191004, 1910);
INSERT INTO "e-izin"."AtikKod" VALUES ('33597cbb-f1c3-4ebb-9226-1592e99b3c6f', '2023-07-24 11:06:19.248819', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'ba215c7c-63f3-4bf9-b825-30f754e8d40c', '191105', true, true, NULL, 191105, 1911);
INSERT INTO "e-izin"."AtikKod" VALUES ('338b6ba1-fdc3-4a61-b696-20158762ce46', '2023-07-24 11:06:19.27987', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Pilsiz çalışan tek kullanımlık fotoğraf makineleri', NULL, '8693d445-ccb1-423b-8380-a415bab62bb1', '090110', false, false, NULL, 90110, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('33be71d7-ded2-4057-a94b-7bc8d1183cda', '2023-07-24 11:06:19.282077', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 04 07 dışındaki potas ve kaya tuzu işlemesinden kaynaklanan atıklar', NULL, '2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '010411', false, false, NULL, 10411, 104);
INSERT INTO "e-izin"."AtikKod" VALUES ('33cdfc33-e7a3-4926-9bb6-60bc204fb632', '2023-07-24 11:06:19.257389', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir köpükler', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100315', true, true, NULL, 100315, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('33e02f8e-69f7-4898-bae5-35e162129f2c', '2023-07-24 11:06:19.221487', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hayvanlarla İlgili Araştırma, Teşhis, Tedavi ya da Hastalık Önleme Çalışmalarından Kaynaklanan Atıklar', NULL, '261f4c4c-7976-4ece-b934-d8f4e9d211d6', '1802', false, true, NULL, 1802, 18);
INSERT INTO "e-izin"."AtikKod" VALUES ('340591c5-6fbe-4097-b7df-42215f057170', '2023-07-24 11:06:19.271597', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Flüoresan lambalar ve diğer cıva içeren atıklar', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200121', true, true, NULL, 200121, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('340a5a1b-cdeb-4068-a7f8-067dade89177', '2023-07-24 11:06:19.225009', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asbest içeren fren balataları', 1, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160111', true, true, NULL, 160111, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('340ff417-ecc2-44d1-a608-5c005036ff67', '2023-07-24 11:06:19.261298', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tüketime ya da işlenmeye uygun olmayan maddeler', NULL, 'c746097f-76b0-4c0f-9bc2-314e3947c853', '020704', false, false, NULL, 20704, 207);
INSERT INTO "e-izin"."AtikKod" VALUES ('3420b36c-956a-48ac-a2bd-6badfe35a498', '2023-07-24 11:06:19.270849', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'ATIK YÖNETİM TESİSLERİNDEN, TESİS DIŞI ATIK SU ARITMA TESİSLERİNDEN VE İNSAN TÜKETİMİ VE ENDÜSTRİYEL KULLANIM İÇİN SU HAZIRLAMA TESİSLERİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '19', false, true, NULL, 19, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('35870051-39c9-4a7f-8a0a-4553fdfdf563', '2023-07-24 11:06:19.235574', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', 1, 'faf9d336-4990-4298-a50a-b56af7884053', '070309', true, true, NULL, 70309, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('35c025a9-facd-4c0b-abbe-7cc2ce542064', '2023-07-24 11:06:19.278599', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 08 17 dışındaki gaz arıtma çamurları ve filtre kekleri', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100818', false, false, NULL, 100818, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('35d6a0f5-4351-4823-8514-993839d9524c', '2023-07-24 11:06:19.257565', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren baca gazı tozu', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100319', true, true, NULL, 100319, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('360035d2-a784-4f06-a4db-696d795c5112', '2023-07-24 11:06:19.255922', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı kükürt giderme işleminden (desülfrizasyon) çıkan kalsiyum bazlı çamurlar', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100107', false, false, NULL, 100107, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('369538a0-3b78-4867-86e1-ec7a334ea84c', '2023-07-24 11:06:19.251354', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 07 07 dışındaki soğutma suyu arıtma atıkları', NULL, 'e67297f9-9141-4cd9-ac88-e58d52bc88c9', '100708', false, false, NULL, 100708, 1007);
INSERT INTO "e-izin"."AtikKod" VALUES ('36b4c244-c9d8-451c-93a4-40e3a9e73d9e', '2023-07-24 11:06:19.213542', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli dip tortusu ve reaksiyon kalıntıları', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070407', true, true, NULL, 70407, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('37400f0c-1fbc-4e48-9b06-dab22d96dfe3', '2023-07-24 11:06:19.250285', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Alkalinler', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200115', true, true, NULL, 200115, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('375e7708-545d-4a52-aa69-ded2c55fc0ed', '2023-07-24 11:06:19.242708', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer halojenli çözücüler ve çözücü karışımları', 1, '8554b0a1-4347-4a3d-81e5-6eb9bc3216bd', '140602', true, true, NULL, 140602, 1406);
INSERT INTO "e-izin"."AtikKod" VALUES ('37768f44-d17f-4b1b-9eff-0a6db55cd06d', '2023-07-24 11:06:19.227528', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070503', true, true, NULL, 70503, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('387a0453-99f4-4518-9c13-7921a166419f', '2023-07-24 11:06:19.238501', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Geri dönüşüm amaçlı kağıt ve kartonun ayrıştırılmasından kaynaklanan atıklar', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030308', false, false, NULL, 30308, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('38a841ce-ccb5-43ab-8af1-7e2551489bd9', '2023-07-24 11:06:19.235514', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, '0058b96b-d695-4095-a185-132f753311cc', '070111', true, true, NULL, 70111, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('38f589ef-899b-46f5-9ce8-f034206eafe3', '2023-07-24 11:06:19.205173', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kazan besleme suyu çamurları', NULL, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050113', false, false, NULL, 50113, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('3981e3a1-3f4c-4853-b96d-04af07d2fae4', '2023-07-24 11:06:19.229409', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Buhar yağ alma atıkları', 1, 'feb88e5f-8f43-4280-b8c6-fec4f5f378bb', '120302', true, true, NULL, 120302, 1203);
INSERT INTO "e-izin"."AtikKod" VALUES ('39baa7b0-d12b-4e10-8011-36ca55bb9ddb', '2023-07-24 11:06:19.283216', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 08 11 dışındaki endüstriyel atık suyun biyolojik arıtılmasından kaynaklanan çamurlar', NULL, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190812', false, false, NULL, 190812, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('3a07a12f-cc9b-4958-9e17-7734ef3a2afb', '2023-07-24 11:06:19.254401', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Dağıtıcı yağ', 1, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080319', true, true, NULL, 80319, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('3a925205-cfb5-4281-a13b-d8fa57dae579', '2023-07-24 11:06:19.217295', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '20 01 29 dışındaki deterjanlar', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200130', false, false, NULL, 200130, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('3ae124d5-a162-4d05-8d9f-25e3f41f8ff0', '2023-07-24 11:06:19.275769', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Silikon ve Silikon Türevlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0608', false, true, NULL, 608, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('3b039e79-e5ab-43c2-9fb2-b07795f2706b', '2023-07-24 11:06:19.267558', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Endüstriyel atık suyun biyolojik arıtılmasından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190811', true, true, NULL, 190811, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('3b12873b-5faf-4161-af59-15efe6349f54', '2023-07-24 11:06:19.255215', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı banyo ve aktifleştirici solüsyonları', 1, '8693d445-ccb1-423b-8380-a415bab62bb1', '090101', true, true, NULL, 90101, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('3b4a20a2-c147-4b99-b9bb-750194453116', '2023-07-24 11:06:19.250462', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çinko Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1005', false, true, NULL, 1005, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('3b4c6ad7-00f0-4f87-814f-4d80a960ccc2', '2023-07-24 11:06:19.262123', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yeşil sıvı çamuru (pişirme sıvısı geri kazanımından)', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030302', false, false, NULL, 30302, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('3c3092db-6142-4157-961d-d8f1adef8fcd', '2023-07-24 11:06:19.216515', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernik sökülmesinden kaynaklanan sulu süspansiyonlar', 1, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080119', true, true, NULL, 80119, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('3c3b9a04-0969-4352-bbac-939ffd169bc4', '2023-07-24 11:06:19.242102', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer yalıtım ve ısı iletim yağları', 2, '0616d181-bdb8-454f-af80-0a765b0d6086', '130310', true, true, true, 130310, 1303);
INSERT INTO "e-izin"."AtikKod" VALUES ('3c8d5e7a-e867-402f-b518-a5cafa387f07', '2023-07-24 11:06:19.2495', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Toprak ve Yeraltı Suyu Islahından Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1913', false, true, NULL, 1913, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('3d0de81b-b2fe-4bfa-b2f3-1c7309e3abd8', '2023-07-24 11:06:19.246176', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '18 01 08 dışındaki ilaçlar', NULL, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180109', false, false, NULL, 180109, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('3d19779f-4ba5-4f95-aa1b-42e57d633209', '2023-07-24 11:06:19.226883', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 06 01 ve 17 06 03 dışındaki yalıtım malzemeleri', NULL, 'b6620d4c-259c-4452-9220-fc612f8b6e32', '170604', false, false, NULL, 170604, 1706);
INSERT INTO "e-izin"."AtikKod" VALUES ('3d8d0103-701f-4d68-83be-2169250c4335', '2023-07-24 11:06:19.260426', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Şeker pancarının temizlenmesinden ve yıkanmasından kaynaklanan toprak', NULL, 'ee8a45ff-6900-4b42-a4b9-f5c9b64aba5e', '020401', false, false, NULL, 20401, 204);
INSERT INTO "e-izin"."AtikKod" VALUES ('3e98f6b4-d05e-4f8e-9e15-3479f29e7b0f', '2023-07-24 11:06:19.229835', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sentetik yalıtım ve ısı iletim yağları', 2, '0616d181-bdb8-454f-af80-0a765b0d6086', '130308', true, true, true, 130308, 1303);
INSERT INTO "e-izin"."AtikKod" VALUES ('3ec9a539-869f-4997-bb7e-83d1c2737fc6', '2023-07-24 11:06:19.215886', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer filtre kekleri ve kullanılmış absorbanlar', 1, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070710', true, true, NULL, 70710, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('3f6a127a-afa3-4ec3-b92a-0b42f0c91478', '2023-07-24 11:06:19.275833', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fosforlu Kimyasalların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Fosforlu Kimyasal İşlenmesinden Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0609', false, true, NULL, 609, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('3f748e5c-93c2-41dc-ab14-ccca38eb01e1', '2023-07-24 11:06:19.211426', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kullanılmış aktif karbon (06 07 02 hariç)', 1, '62946a2a-b011-4804-b78e-540f50e96d69', '061302', true, true, NULL, 61302, 613);
INSERT INTO "e-izin"."AtikKod" VALUES ('40567f38-e890-44ac-9320-828f36fc47ba', '2023-07-24 11:06:19.228807', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir dışı metal çapakları ve talaşları', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120103', false, false, NULL, 120103, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('407fefe7-4ff0-4f18-b963-2456037c7fae', '2023-07-24 11:06:19.236293', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 03 18 dışındaki atık baskı tonerleri', NULL, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080318', false, false, NULL, 80318, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('40ad32a1-72c4-4d1c-966c-0edb99825326', '2023-07-24 11:06:19.233453', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalik ambalaj', NULL, '8f20317c-2895-43f2-a702-b02b71336086', '150104', false, false, NULL, 150104, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('412246cd-bcb5-4285-8cba-556283a14870', '2023-07-24 11:06:19.263669', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '11 01 09 dışındaki çamurlar ve filtre kekleri', NULL, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110110', false, false, NULL, 110110, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('41ada144-cee0-48b7-b527-399c809271a1', '2023-07-24 11:06:19.207964', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sülfürik asit ve sülfüröz asit', 1, '2cc8b711-0e7d-4aeb-a8de-9e7d57836ef5', '060101', true, true, NULL, 60101, 601);
INSERT INTO "e-izin"."AtikKod" VALUES ('41c22045-13ca-49f2-ab94-35b11eca97ed', '2023-07-24 11:06:19.270444', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olmayan atıklar (örneğin sargılar, vücut alçıları, tek kullanımlık giysiler, alt bezleri)', NULL, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180104', false, false, NULL, 180104, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('41e6c371-0650-4711-8e0c-e0289f10daf2', '2023-07-24 11:06:19.217867', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metaller', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200140', false, false, NULL, 200140, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('426ad355-5295-4678-b1b3-6373dc47b73d', '2023-07-24 11:06:19.227378', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İnorganik bitki koruma ürünleri, ahşap koruma ürünleri ve diğer biositler', 1, '62946a2a-b011-4804-b78e-540f50e96d69', '061301', true, true, NULL, 61301, 613);
INSERT INTO "e-izin"."AtikKod" VALUES ('429ce69a-3b21-403b-8cad-db1a3a04f578', '2023-07-24 11:06:19.213925', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı yıkama sıvıları ve ana çözeltiler', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070501', true, true, NULL, 70501, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('42c3d8ed-a098-44dc-a19b-53006beac1b0', '2023-07-24 11:06:19.214427', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'ec91af60-1678-4b87-bba9-743705a039fd', '070599', false, false, NULL, 70599, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('42d1bafe-4388-40ae-8232-220698210b8b', '2023-07-24 11:06:19.278903', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 09 15 dışındaki çatlak belirleme kimyasalları atığı', NULL, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100916', false, false, NULL, 100916, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('42d675fb-e88d-461c-be6d-5e975e6083b0', '2023-07-24 11:06:19.283767', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sitotoksik ve sitostatik ilaçlar', 1, '33e02f8e-69f7-4898-bae5-35e162129f2c', '180207', true, true, NULL, 180207, 1802);
INSERT INTO "e-izin"."AtikKod" VALUES ('42e78343-e781-4422-92ce-93cedfbf76fc', '2023-07-24 11:06:19.281837', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer dip tortusu ve reaksiyon kalıntıları', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070508', true, true, NULL, 70508, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('434dac94-e293-4586-b5c1-8fa291781f4f', '2023-07-24 11:06:19.248939', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'ba215c7c-63f3-4bf9-b825-30f754e8d40c', '191199', false, false, NULL, 191199, 1911);
INSERT INTO "e-izin"."AtikKod" VALUES ('4352315a-448d-4d2b-86d3-d3a9143f987c', '2023-07-24 11:06:19.24804', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İyon değiştiricilerinin rejenerasyonundan kaynaklanan solüsyonlar ve çamurlar', 1, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190807', true, true, NULL, 190807, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('44d064b4-b33c-4fbb-9e0d-d30e99721f67', '2023-07-24 11:06:19.269157', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Toprak ıslahından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, '3c8d5e7a-e867-402f-b518-a5cafa387f07', '191303', true, true, NULL, 191303, 1913);
INSERT INTO "e-izin"."AtikKod" VALUES ('44fe2fa1-1b93-4684-9a1b-c4c66ffabbfa', '2023-07-24 11:06:19.27534', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Belediye atıklarının anaerobik arıtımından kaynaklanan posalar', NULL, '5b19093f-fdf5-49cb-a324-6c34b05ca258', '190604', false, false, NULL, 190604, 1906);
INSERT INTO "e-izin"."AtikKod" VALUES ('451d0cb0-9c5e-4726-abc7-19d12e26ef08', '2023-07-24 11:06:19.216951', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı tozu', 1, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100404', true, true, NULL, 100404, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('4616fe13-cb36-41f1-8d1b-f5ea4cdcba98', '2023-07-24 11:06:19.225917', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 11 19 dışındaki saha içi atık su arıtımından kaynaklanan katı atıklar', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101120', false, false, NULL, 101120, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('463f3daa-35fb-4946-9e72-9489b21c6d02', '2023-07-24 11:06:19.279388', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Seramik Ürünler, Tuğlalar, Fayanslar ve İnşaat Malzemelerinin Üretiminden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1012', false, true, NULL, 1012, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('4671b20f-f798-49b8-a3d3-ba6bd6647db6', '2023-07-24 11:06:19.214675', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sokak temizleme kalıntıları', NULL, '0c2d44f6-5fee-444f-beb8-5ad3318f616a', '200303', false, false, NULL, 200303, 2003);
INSERT INTO "e-izin"."AtikKod" VALUES ('46876ec0-a095-4ac3-9f93-b6050abbe7f1', '2023-07-24 11:06:19.254842', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren sulu yapışkan veya dolgu macunlarının sıvı atıkları', 1, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080415', true, true, NULL, 80415, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('469a52bd-f6fc-4d58-abb1-759a578f8023', '2023-07-24 11:06:19.23061', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli çözücüler içeren çamurlar veya katı atıklar', 1, '8554b0a1-4347-4a3d-81e5-6eb9bc3216bd', '140604', true, true, NULL, 140604, 1406);
INSERT INTO "e-izin"."AtikKod" VALUES ('46b84e3d-976f-46bc-b92b-6ef50008b267', '2023-07-24 11:06:19.230915', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kromatlar (örneğin potasyum kromat, potasyum veya sodyum dikromat)', 1, '9755a757-20f8-4784-8424-5135b4c3444a', '160902', true, true, NULL, 160902, 1609);
INSERT INTO "e-izin"."AtikKod" VALUES ('47c6396e-dd31-4adb-ae01-f321e474d7cb', '2023-07-24 11:06:19.211502', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Karbon siyahı', NULL, '62946a2a-b011-4804-b78e-540f50e96d69', '061303', false, false, NULL, 61303, 613);
INSERT INTO "e-izin"."AtikKod" VALUES ('4847493c-1c97-4abf-99b5-1fc012b49607', '2023-07-24 11:06:19.245405', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren toprak ve kayalar', 1, '8c13d02a-936e-4a93-8508-8207af2c45d4', '170503', true, true, NULL, 170503, 1705);
INSERT INTO "e-izin"."AtikKod" VALUES ('4870759a-8f8f-488b-ace8-53fdf4202b26', '2023-07-24 11:06:19.247559', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hayvansal ve bitkisel atıklarının kompostlanmamış fraksiyonları', NULL, '5ac0adf7-291d-40f1-abf0-c8243f75abf5', '190502', false, false, NULL, 190502, 1905);
INSERT INTO "e-izin"."AtikKod" VALUES ('487a17bd-ec99-41e1-b695-292fa4e1c53c', '2023-07-24 11:06:19.241211', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojen içermeyen işleme emülsiyon ve solüsyonları', 1, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120109', true, true, NULL, 120109, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('489a8b03-d530-40e7-b85e-fffbb62081ec', '2023-07-24 11:06:19.228139', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir Dışındaki Madenlerin Hidrometalürjik İşlenmesinin Atıkları', NULL, 'ef717c0c-06e1-4ee0-bb46-b5d04f58e738', '1102', false, true, NULL, 1102, 11);
INSERT INTO "e-izin"."AtikKod" VALUES ('48e503dc-88be-45be-b948-0880bb74abda', '2023-07-24 11:06:19.245761', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer inşaat ve yıkıntı atıkları (karışık atıklar dahil)', 1, '6f38b08c-106b-4284-932e-2f21aef998d8', '170903', true, true, NULL, 170903, 1709);
INSERT INTO "e-izin"."AtikKod" VALUES ('4938f3ce-5190-4f2a-bfa8-87108644c463', '2023-07-24 11:06:19.281537', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 05 05 ve 01 05 06 dışındaki klorür içeren sondaj çamurları ve atıkları', NULL, 'a3b7fef0-d9d1-4326-9622-3497df5170aa', '010508', false, false, NULL, 10508, 105);
INSERT INTO "e-izin"."AtikKod" VALUES ('49fbd432-08ec-4b35-8375-c9d7dea406c7', '2023-07-24 11:06:19.212021', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı yıkama sıvıları ve ana çözeltiler', 1, '02890c62-fdea-4520-a830-5462e228d706', '070201', true, true, NULL, 70201, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('4a0a671c-9aa6-4180-a492-47b1364eed06', '2023-07-24 11:06:19.274924', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 03 04 dışındaki stabilize olmuş atıklar', NULL, '235a8557-aa28-4c06-9060-16bc23a58c6a', '190305', false, false, NULL, 190305, 1903);
INSERT INTO "e-izin"."AtikKod" VALUES ('4a2a48da-6299-43d8-947f-04837826ba2a', '2023-07-24 11:06:19.227831', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Klor içermeyen emülsiyonlar', 2, '676c52f5-81e5-4570-8135-2f3324688790', '130105', true, true, true, 130105, 1301);
INSERT INTO "e-izin"."AtikKod" VALUES ('4a4f11c9-9b19-4fe4-a669-cfb549b80e48', '2023-07-24 11:06:19.249317', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 12 06 dışındaki ahşap', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191207', false, false, NULL, 191207, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('4a6ea286-5629-48e0-9e72-ce8ca286b51f', '2023-07-24 11:06:19.229953', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sintine Yağları', NULL, 'd7bf6b00-841e-4840-ba5b-3e2c3b77bf21', '1304', false, true, NULL, 1304, 13);
INSERT INTO "e-izin"."AtikKod" VALUES ('4a7c9368-3d43-4b7e-8019-255d838fe1bf', '2023-07-24 11:06:19.235754', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070799', false, false, NULL, 70799, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('4a9039e5-26cb-4731-a37c-9487edd79c19', '2023-07-24 11:06:19.252154', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer partiküller', 1, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100911', true, true, NULL, 100911, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('4befd00d-bbae-46a4-b70d-67af939d9558', '2023-07-24 11:06:19.282794', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sitotoksik ve sitostatik ilaçlar', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200131', true, true, NULL, 200131, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('4d1e8ac7-10df-4337-a61b-e1e5b1ed8991', '2023-07-24 11:06:19.248879', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı temizleme atıkları', 1, 'ba215c7c-63f3-4bf9-b825-30f754e8d40c', '191107', true, true, NULL, 191107, 1911);
INSERT INTO "e-izin"."AtikKod" VALUES ('4dea842b-a1e6-4404-af81-916148704816', '2023-07-24 11:06:19.258815', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '010499', false, false, NULL, 10499, 104);
INSERT INTO "e-izin"."AtikKod" VALUES ('4e1f1ffb-0cfc-44ab-9254-3a141315dc06', '2023-07-24 11:06:19.244931', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 03 01 dışındaki bitümlü karışımlar', NULL, '0679c123-9c79-4909-ba99-fa94e8d68951', '170302', false, false, NULL, 170302, 1703);
INSERT INTO "e-izin"."AtikKod" VALUES ('4e28e1f8-6d3d-4031-90cf-e484133cb7b2', '2023-07-24 11:06:19.276958', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070509', true, true, NULL, 70509, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('4ef7749a-9d85-4cb6-9669-c451d2c686c2', '2023-07-24 11:06:19.279749', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren yapışkan ve dolgu macunu çamurları', 1, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080411', true, true, NULL, 80411, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('4f230c49-ccb5-4638-8fad-815d2e2f8b12', '2023-07-24 11:06:19.282736', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 08 09 dışındaki yağ ve su ayrışmasından çıkan yağ karışımları ve gres', 1, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190810', true, true, NULL, 190810, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('4f2b6390-7c9b-4d2f-b795-3e3835dca1fd', '2023-07-24 11:06:19.253178', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101205', false, false, NULL, 101205, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('4f324f9b-e07f-45e1-9f13-2dc83e52dafb', '2023-07-24 11:06:19.234776', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren organik atıklar', 1, 'fb657553-47ba-4711-84af-b13e3c533180', '160305', true, true, NULL, 160305, 1603);
INSERT INTO "e-izin"."AtikKod" VALUES ('4f9bae9e-6bb2-49c2-b9a2-3ecb53eef8c1', '2023-07-24 11:06:19.229893', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kolayca biyolojik olarak bozunabilir yalıtım ve ısı iletim yağları', 2, '0616d181-bdb8-454f-af80-0a765b0d6086', '130309', true, true, true, 130309, 1303);
INSERT INTO "e-izin"."AtikKod" VALUES ('50987f39-4dee-4187-8570-2d17526ae398', '2023-07-24 11:06:19.242405', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Belediye ve benzeri atıklarının kompostlanmamış fraksiyonları', NULL, '5ac0adf7-291d-40f1-abf0-c8243f75abf5', '190501', false, false, NULL, 190501, 1905);
INSERT INTO "e-izin"."AtikKod" VALUES ('50b2199b-a8d4-45f5-ae82-6360aecd8627', '2023-07-24 11:06:19.201756', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Krom içeren sepi şerbeti', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040104', false, false, NULL, 40104, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('50b539fd-4f12-42e7-8984-21c16bae6dd9', '2023-07-24 11:06:19.230789', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 02 09 dışındaki PCB içeren ya da PCB ile kontamine olmuş ıskarta ekipmanlar', 2, 'fcf7052f-6471-4238-bfd9-a9b918f118ce', '160210', true, true, NULL, 160210, 1602);
INSERT INTO "e-izin"."AtikKod" VALUES ('50b84f89-eff1-45f4-a038-10c2a1a798a9', '2023-07-24 11:06:19.250936', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', NULL, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100602', false, false, NULL, 100602, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('50d09439-0e29-4c4e-89de-8806087d3e1b', '2023-07-24 11:06:19.227132', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mineral esaslı klor içermeyen hidrolik yağlar', 2, '676c52f5-81e5-4570-8135-2f3324688790', '130110', true, true, true, 130110, 1301);
INSERT INTO "e-izin"."AtikKod" VALUES ('50d0c615-565d-49fb-986c-5dd54b70084b', '2023-07-24 11:06:19.234965', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Havai fişek atıkları', 1, 'f8e2cc9c-b5d7-4b2a-8cf8-c1dba53e6432', '160402', true, true, NULL, 160402, 1604);
INSERT INTO "e-izin"."AtikKod" VALUES ('518e8523-544e-4ff9-a962-32a77262dc5f', '2023-07-24 11:06:19.206907', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer ziftler', 1, '07a8b9c4-da35-4838-86e3-a340636a4aa7', '050603', true, true, NULL, 50603, 506);
INSERT INTO "e-izin"."AtikKod" VALUES ('519ea6eb-ce29-4c8c-aba5-3c58953c6028', '2023-07-24 11:06:19.271399', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 13 07 dışındaki yeraltı suyunun ıslahından kaynaklanan sulu sıvı atıklar ve sulu konsantrasyonlar', NULL, '3c8d5e7a-e867-402f-b518-a5cafa387f07', '191308', false, false, NULL, 191308, 1913);
INSERT INTO "e-izin"."AtikKod" VALUES ('5235ee18-e170-4719-a075-cd5e6e9b4aac', '2023-07-24 11:06:19.249804', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yeraltı suyunun ıslahından kaynaklanan tehlikeli maddeler içeren sulu sıvı atıklar ve sulu konsantrasyonlar', 1, '3c8d5e7a-e867-402f-b518-a5cafa387f07', '191307', true, true, NULL, 191307, 1913);
INSERT INTO "e-izin"."AtikKod" VALUES ('523859f0-21b8-415b-af95-cd9935d0e96b', '2023-07-24 11:06:19.2481', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Endüstriyel atık suyun diğer yöntemlerle arıtılmasından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190813', true, true, NULL, 190813, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('52998d95-c731-4962-9e1f-9c64b0b7c599', '2023-07-24 11:06:19.216808', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil ve ikincil üretim cürufları', 1, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100401', true, true, NULL, 100401, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('52bdd4ec-13ab-4b57-8e91-653df2528473', '2023-07-24 11:06:19.222384', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ocak cürufları', NULL, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101003', false, false, NULL, 101003, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('52e7a59f-74bb-4c8f-9fbf-3452552661fe', '2023-07-24 11:06:19.247311', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli olarak sınıflandırılmış, katılaştırılmış atıklar', 1, '235a8557-aa28-4c06-9060-16bc23a58c6a', '190306', true, true, NULL, 190306, 1903);
INSERT INTO "e-izin"."AtikKod" VALUES ('531884fb-842d-4184-8a25-796daa4ab45a', '2023-07-24 11:06:19.260637', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, 'ee8a45ff-6900-4b42-a4b9-f5c9b64aba5e', '020403', false, false, NULL, 20403, 204);
INSERT INTO "e-izin"."AtikKod" VALUES ('53383253-9464-4f47-899f-a96fc07748ec', '2023-07-24 11:06:19.276645', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtmından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'faf9d336-4990-4298-a50a-b56af7884053', '070311', true, true, NULL, 70311, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('533e94f6-4263-4001-a901-a763795d82ed', '2023-07-24 11:06:19.250641', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan katı atıklar', 1, '3b4a20a2-c147-4b99-b9bb-750194453116', '100505', true, true, NULL, 100505, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('5340cd8d-3611-4b19-ab87-c80bcbad15df', '2023-07-24 11:06:19.237395', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'ee8a45ff-6900-4b42-a4b9-f5c9b64aba5e', '020499', false, false, NULL, 20499, 204);
INSERT INTO "e-izin"."AtikKod" VALUES ('5357b5e2-5902-4994-8141-aaec1e62e2a1', '2023-07-24 11:06:19.251416', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir Dışı Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1008', false, true, NULL, 1008, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('5394c9da-c6ba-437f-a462-d9cd8b2f296a', '2023-07-24 11:06:19.222186', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fosseptik çamurları', NULL, '0c2d44f6-5fee-444f-beb8-5ad3318f616a', '200304', false, false, NULL, 200304, 2003);
INSERT INTO "e-izin"."AtikKod" VALUES ('53cc04bb-944e-4ed7-92b9-d7acd52585b3', '2023-07-24 11:06:19.236477', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 03 23 dışındaki gaz arıtımı katı atıkları', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100324', false, false, NULL, 100324, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('5416da28-20fd-4000-8b95-001bd98d9078', '2023-07-24 11:06:19.279085', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli madde içeren çatlak belirleme kimyasalları atığı', 1, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101015', true, true, NULL, 101015, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('543a6e1c-9778-4301-8797-feae7ecb0aaf', '2023-07-24 11:06:19.281898', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan katı atıklar', NULL, 'e67297f9-9141-4cd9-ac88-e58d52bc88c9', '100703', false, false, NULL, 100703, 1007);
INSERT INTO "e-izin"."AtikKod" VALUES ('544807f1-c123-4922-8ea1-87e18be97c9a', '2023-07-24 11:06:19.246893', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 01 17 dışındaki piroliz atıkları', NULL, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190118', false, false, NULL, 190118, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('54680b49-f005-4112-8061-86e2862ed60f', '2023-07-24 11:06:19.220711', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tekstil ambalaj', NULL, '8f20317c-2895-43f2-a702-b02b71336086', '150109', false, false, NULL, 150109, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('54a21e63-bd7e-4f64-8ce7-1a474c90ce6f', '2023-07-24 11:06:19.213705', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 04 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070412', false, false, NULL, 70412, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('554fcb27-9d63-4195-8848-e76acf8860d8', '2023-07-24 11:06:19.229171', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren işleme çamurları', 1, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120114', true, true, NULL, 120114, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('55ba65c1-cc71-4988-bed7-116ce381cd99', '2023-07-24 11:06:19.250818', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bakır Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1006', false, true, NULL, 1006, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('55c98985-70f7-45a9-8211-d8e675716718', '2023-07-24 11:06:19.219064', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070711', true, true, NULL, 70711, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('562e0718-696d-4bb8-ae00-0617db005331', '2023-07-24 11:06:19.27528', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Belediye atıklarının anaerobik arıtımından kaynaklanan sıvılar', NULL, '5b19093f-fdf5-49cb-a324-6c34b05ca258', '190603', false, false, NULL, 190603, 1906);
INSERT INTO "e-izin"."AtikKod" VALUES ('5660b39a-3843-489f-ab58-ab2444081fdd', '2023-07-24 11:06:19.267048', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalürjik proseslerden kaynaklanan, tehlikeli maddeler içeren karbon bazlı astarlar ve refraktörler', 1, '05f219fe-21e2-4128-95eb-65b72829b3fa', '161101', true, true, NULL, 161101, 1611);
INSERT INTO "e-izin"."AtikKod" VALUES ('56924e2c-8a7c-4be9-b572-06a43cc66eae', '2023-07-24 11:06:19.221778', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Standart dışı kompost', NULL, '5ac0adf7-291d-40f1-abf0-c8243f75abf5', '190503', false, false, NULL, 190503, 1905);
INSERT INTO "e-izin"."AtikKod" VALUES ('56d6b7b9-cb27-4a93-9389-2a6bd29cf1b1', '2023-07-24 11:06:19.208469', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hidroflorik asit', 1, '2cc8b711-0e7d-4aeb-a8de-9e7d57836ef5', '060103', true, true, NULL, 60103, 601);
INSERT INTO "e-izin"."AtikKod" VALUES ('56e6ad53-cb4f-4305-9311-52b29beae0fb', '2023-07-24 11:06:19.255613', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '09 01 06 dışındaki gümüş geri kazanımı için yapılan arıtmadan kalan sulu sıvı atıklar', 1, '8693d445-ccb1-423b-8380-a415bab62bb1', '090113', true, true, NULL, 90113, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('56ef4924-9ba2-4d42-b246-f54d25ebeba0', '2023-07-24 11:06:19.230194', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ/su ayırıcılarından çıkan yağ', 1, '7b1f3519-e16b-445c-b927-d70255f332d9', '130506', true, true, true, 130506, 1305);
INSERT INTO "e-izin"."AtikKod" VALUES ('573f8981-9d9c-4e3a-8143-78c62394351d', '2023-07-24 11:06:19.259531', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ormancılık atıkları', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020107', false, false, NULL, 20107, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('575e893e-6da3-488e-9eed-697920261804', '2023-07-24 11:06:19.237842', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, 'c746097f-76b0-4c0f-9bc2-314e3947c853', '020705', false, false, NULL, 20705, 207);
INSERT INTO "e-izin"."AtikKod" VALUES ('578cb7e9-b4ad-4b32-88e8-be57961615bb', '2023-07-24 11:06:19.214206', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli madde içeren katı atıklar', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070513', true, true, NULL, 70513, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('57aa8132-495a-4e09-a57f-abf3c07c3fa9', '2023-07-24 11:06:19.24427', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli madde içeren sulu derişik maddeler', 1, 'cc572c1d-1fa6-4c3b-b648-74bff3176f98', '161003', true, true, NULL, 161003, 1610);
INSERT INTO "e-izin"."AtikKod" VALUES ('58033283-68bf-4d54-bbd8-2ad9c4a86fa7', '2023-07-24 11:06:19.216666', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 03 29 dışındaki tuz cürufları ve kara cürufların arıtımından çıkan atıklar', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100330', false, false, NULL, 100330, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('58a4d854-f67b-4f81-a187-bf0dd7ba565c', '2023-07-24 11:06:19.211805', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer dip tortusu ve reaksiyon kalıntıları', 1, '0058b96b-d695-4095-a185-132f753311cc', '070108', true, true, NULL, 70108, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('58d6c1f6-153b-455e-bf8b-23897fc1fe3f', '2023-07-24 11:06:19.264029', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 12 11 dışında atıkların mekanik işlenmesinden kaynaklanan diğer atıklar (karışık malzemeler dahil)', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191212', false, false, NULL, 191212, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('58f44bae-75ab-4e77-8013-0cf931f2db40', '2023-07-24 11:06:19.27117', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren taban külü ve cüruf', 1, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190111', true, true, NULL, 190111, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('592152f9-3a4f-4715-9954-fe89e7fbfe45', '2023-07-24 11:06:19.215237', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070703', true, true, NULL, 70703, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('598203e1-134f-4dbb-af7d-ca508a3b4980', '2023-07-24 11:06:19.225286', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 01 11 dışındaki taban külü ve cüruf', NULL, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190112', false, false, NULL, 190112, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('598e07e9-5990-4604-8340-8c544545525b', '2023-07-24 11:06:19.234837', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 03 05 dışındaki organik atıklar', NULL, 'fb657553-47ba-4711-84af-b13e3c533180', '160306', false, false, NULL, 160306, 1603);
INSERT INTO "e-izin"."AtikKod" VALUES ('5a0141fc-f7c8-4fad-bb3d-409c718a79fd', '2023-07-24 11:06:19.273576', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Vitrifiye edilmiş atıklar', NULL, '7f1f469e-1575-4540-b427-5f91228fad9d', '190401', false, false, NULL, 190401, 1904);
INSERT INTO "e-izin"."AtikKod" VALUES ('5ac0adf7-291d-40f1-abf0-c8243f75abf5', '2023-07-24 11:06:19.275158', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Katı Atıkların Aerobik Arıtımından Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1905', false, true, NULL, 1905, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('5ac4214f-9ec6-434d-bfee-8b4409ebf7b5', '2023-07-24 11:06:19.265288', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımı sonucu oluşan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', 1, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100213', true, true, NULL, 100213, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('5b19093f-fdf5-49cb-a324-6c34b05ca258', '2023-07-24 11:06:19.247622', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atığın Anaerobik Arıtımından Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1906', false, true, NULL, 1906, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('5b498acd-54ea-4d29-97c2-e547efd86dad', '2023-07-24 11:06:19.223109', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asit alkil çamurları', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050104', true, true, NULL, 50104, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('5b5ec0b1-dfa1-44ad-9537-b1f130cb9050', '2023-07-24 11:06:19.261479', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağaç kabuğu ve mantar atıkları', NULL, '079e8777-e624-4a0f-9669-a32b5c39ddad', '030101', false, false, NULL, 30101, 301);
INSERT INTO "e-izin"."AtikKod" VALUES ('5b773b88-9648-4f0d-9cf7-19949942f615', '2023-07-24 11:06:19.278164', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir cüruf ve köpükler', 1, '3b4a20a2-c147-4b99-b9bb-750194453116', '100510', true, true, NULL, 100510, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('5c3c95fa-c5b8-482b-b653-d23b14d49e4b', '2023-07-24 11:06:19.236598', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '02 01 08 dışındaki zirai kimyasal atıkları', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020109', false, false, NULL, 20109, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('5c43c22b-ac87-454c-96dc-2edf565863d5', '2023-07-24 11:06:19.234294', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir olmayan metaller', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160118', false, false, NULL, 160118, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('5ccc997c-1c3a-4640-8f1a-d9cb0f0f4290', '2023-07-24 11:06:19.20377', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'PETROL RAFİNASYONU, DOĞAL GAZ SAFLAŞTIRMA VE KÖMÜRÜN PİROLİTİK İŞLENMESİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '05', false, true, NULL, 5, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('5d601044-9640-4cb4-b69e-200a6083d2ce', '2023-07-24 11:06:19.258001', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalik maden kazılarından kaynaklanan atıklar', NULL, '9b24859a-69f5-4b25-818f-f09f47b20fc6', '010101', false, false, NULL, 10101, 101);
INSERT INTO "e-izin"."AtikKod" VALUES ('5dc3fe49-8722-470a-ac62-97d6e2798070', '2023-07-24 11:06:19.210572', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cıva içeren baryum sülfat çamuru', 1, '254667d3-3d03-47c4-99ae-85ae4efa0b18', '060703', true, true, NULL, 60703, 607);
INSERT INTO "e-izin"."AtikKod" VALUES ('5dc8194f-2de7-4707-8fcb-ffac8a0ea72a', '2023-07-24 11:06:19.232615', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tuzların ve Çözeltilerinin ve Metalik Oksitlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0603', false, true, NULL, 603, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('5ea17e7b-66dc-4884-acd2-7ff80af74981', '2023-07-24 11:06:19.210649', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çözeltiler ve asitler, örneğin kontakt asiti', 1, '254667d3-3d03-47c4-99ae-85ae4efa0b18', '060704', true, true, NULL, 60704, 607);
INSERT INTO "e-izin"."AtikKod" VALUES ('5ec596e3-45c8-41be-8b4b-451182bc54db', '2023-07-24 11:06:19.259443', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık plastikler (ambalajlar hariç)', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020104', false, false, NULL, 20104, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('5ed7eac4-866a-4d73-bf53-ab1b7cd1c541', '2023-07-24 11:06:19.26538', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalik minerallerin fiziki ve kimyasal işlenmesinden kaynaklanan tehlikeli maddeler içeren diğer atıklar', 1, '1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '010307', true, true, NULL, 10307, 103);
INSERT INTO "e-izin"."AtikKod" VALUES ('5edc69b2-cc3c-426f-b649-242e41115093', '2023-07-24 11:06:19.21972', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 02 13 dışındaki gaz arıtımı sonucu oluşan çamurlar ve filtre kekleri', NULL, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100214', false, false, NULL, 100214, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('5f698a7c-9552-4587-8c62-7c644edb7a9f', '2023-07-24 11:06:19.244692', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ahşap, Cam ve Plastik', NULL, 'c4d6b5a4-b326-453e-a375-286212bd4d29', '1702', false, true, NULL, 1702, 17);
INSERT INTO "e-izin"."AtikKod" VALUES ('6032cbfc-7c59-469b-9e08-1839c43a1c61', '2023-07-24 11:06:19.278353', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', NULL, 'e67297f9-9141-4cd9-ac88-e58d52bc88c9', '100702', false, false, NULL, 100702, 1007);
INSERT INTO "e-izin"."AtikKod" VALUES ('604a4ed3-7c96-4a12-b928-e143b815e096', '2023-07-24 11:06:19.242648', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'ATIK ORGANİK ÇÖZÜCÜLER, SOĞUTUCULAR VE İTİCİ GAZLAR (07 VE 08 HARİÇ)', NULL, NULL, '14', false, true, NULL, 14, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('604a9e99-fc0a-46ec-b8dc-031147f6e779', '2023-07-24 11:06:19.280188', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atıkların birlikte yakılmasından (co-incineration) kaynaklanan ve tehlikeli maddeler içeren uçucu kül', 1, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100116', true, true, NULL, 100116, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('6071924f-fe85-4d0a-9f4f-47f997b0e22e', '2023-07-24 11:06:19.224857', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren öğütme parçaları ve öğütme maddeleri', 1, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120120', true, true, NULL, 120120, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('6101276e-1d94-4ed5-931a-822afc0e307d', '2023-07-24 11:06:19.217187', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yenilebilir sıvı ve katı yağlar', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200125', false, false, NULL, 200125, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('615cbd92-b85d-4125-9475-547d0c88d90f', '2023-07-24 11:06:19.242334', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ/su ayırıcılarından çıkan yağlı su', 1, '7b1f3519-e16b-445c-b927-d70255f332d9', '130507', true, true, NULL, 130507, 1305);
INSERT INTO "e-izin"."AtikKod" VALUES ('619b6800-76ea-46df-9de7-0a85aeb99a2f', '2023-07-24 11:06:19.229231', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ içeren metalik çamurlar (öğütme, bileme ve freze tortuları)', 1, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120118', true, true, NULL, 120118, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('61ab5ee1-fb7b-48dc-a0eb-7ae03c5aeedb', '2023-07-24 11:06:19.250046', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Biyolojik olarak bozunabilir mutfak ve kantin atıkları', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200108', false, false, NULL, 200108, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('61b82750-28a0-40dd-8947-d115f47fbded', '2023-07-24 11:06:19.215053', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer filtre kekleri ve kullanılmış absorbanlar', 1, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070610', true, true, NULL, 70610, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('62946a2a-b011-4804-b78e-540f50e96d69', '2023-07-24 11:06:19.224009', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka Bir Şekilde Tanımlanmamış İnorganik Kimyasal İşlemlerden Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0613', false, true, NULL, 613, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('6310d92b-a76b-456b-9697-789fb2bb5e9f', '2023-07-24 11:06:19.241271', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '12 01 14 dışındaki işleme çamurları', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120115', false, false, NULL, 120115, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('63285952-d6ae-44a9-b050-332877c02093', '2023-07-24 11:06:19.212692', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '02890c62-fdea-4520-a830-5462e228d706', '070299', false, false, NULL, 70299, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('63506f66-6364-4f98-8472-c85445748992', '2023-07-24 11:06:19.224769', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren yağ alma atıkları', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110113', true, true, NULL, 110113, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('63ab5d58-e7ac-4016-a8b1-ae18f8ea8043', '2023-07-24 11:06:19.225611', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 06 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070612', false, false, NULL, 70612, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('63e1c335-24ee-42a7-9e50-fbb5dc84ca90', '2023-07-24 11:06:19.257135', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Anot hurdaları', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100302', false, false, NULL, 100302, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('645d435f-9202-44ad-8a0f-2c93fd04d1fc', '2023-07-24 11:06:19.211948', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 01 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, '0058b96b-d695-4095-a185-132f753311cc', '070112', false, false, NULL, 70112, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('64907ba7-aa3d-48bb-a6ea-1d74cac8dc5e', '2023-07-24 11:06:19.233753', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 11 11 dışındaki atık camlar', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101112', false, false, NULL, 101112, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('64b43a2a-202d-42fc-94c9-eab13c4f56dc', '2023-07-24 11:06:19.236224', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '26fffbdb-1704-425d-ad2f-db6201225ac0', '080299', false, false, NULL, 80299, 802);
INSERT INTO "e-izin"."AtikKod" VALUES ('65c0b984-ae04-4915-ac3e-1c958bc10014', '2023-07-24 11:06:19.274106', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren beton, tuğla, kiremit ve seramik karışımları ya da ayrılmış grupları', 1, 'b4c53dbe-7b9e-4d04-9339-95da478bd659', '170106', true, true, NULL, 170106, 1701);
INSERT INTO "e-izin"."AtikKod" VALUES ('65eda575-b204-412b-8918-dbac781a630c', '2023-07-24 11:06:19.277402', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'ASTARLAR (BOYALAR, VERNİKLER VE VİTRİFİYE EMAYELER), YAPIŞKANLAR, MACUNLAR VE BASKI MÜREKKEPLERİNİN ÜRETİM, FORMÜLASYON, TEDARİK VE KULLANIMINDAN (İFTK) KAYNAKLANAN ATIKLAR', NULL, NULL, '08', false, true, NULL, 8, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('65eddcf3-7908-4ea2-aca6-35fa2f7b40bf', '2023-07-24 11:06:19.275405', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hayvansal ve bitkisel atıklarını anaerobik arıtımından kaynaklanan posalar', NULL, '5b19093f-fdf5-49cb-a324-6c34b05ca258', '190606', false, false, NULL, 190606, 1906);
INSERT INTO "e-izin"."AtikKod" VALUES ('65f73baf-ab77-43b6-9fd0-a18be83e56e8', '2023-07-24 11:06:19.22759', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan katı atıklar', 1, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100406', true, true, NULL, 100406, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('66ec0022-1147-4d6b-9917-66b03c3d1fda', '2023-07-24 11:06:19.225422', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren deterjanlar', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200129', true, true, NULL, 200129, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('67115266-864c-4f7a-9705-a0720a0c7d2e', '2023-07-24 11:06:19.201996', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan krom içermeyen çamurlar', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040107', false, false, NULL, 40107, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('6720be26-e1a0-4c1b-ad59-e546f462fece', '2023-07-24 11:06:19.228501', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Katı çinko', NULL, '98beda5b-44c8-4aee-afd8-24c61d6fe067', '110501', false, false, NULL, 110501, 1105);
INSERT INTO "e-izin"."AtikKod" VALUES ('676c52f5-81e5-4570-8135-2f3324688790', '2023-07-24 11:06:19.226439', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık Hidrolik Yağlar', NULL, 'd7bf6b00-841e-4840-ba5b-3e2c3b77bf21', '1301', false, true, NULL, 1301, 13);
INSERT INTO "e-izin"."AtikKod" VALUES ('693f7021-4984-4542-9a93-b9fe6b0f708d', '2023-07-24 11:06:19.280981', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100327', true, true, NULL, 100327, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('699f0216-0f09-4802-a8b0-473aefbf4e29', '2023-07-24 11:06:19.282317', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı ofset plakası banyo solüsyonu', 1, '8693d445-ccb1-423b-8380-a415bab62bb1', '090102', true, true, NULL, 90102, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('69d6a50b-6453-437e-9d9b-809fa131281a', '2023-07-24 11:06:19.26303', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asbestli çimento üretiminden kaynaklanan asbest içeren atıklar', 1, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101309', true, true, NULL, 101309, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('6a283bb2-4bff-4cd2-88ae-449ea61faccb', '2023-07-24 11:06:19.236354', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 04 13 dışındaki sulu organik yapışkan veya dolgu macunu çamurları', NULL, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080414', false, false, NULL, 80414, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('6a408614-f759-4aaf-85f6-e05e3a486feb', '2023-07-24 11:06:19.245583', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddelerden oluşan ya da tehlikeli maddeler içeren diğer yalıtım malzemeleri', 1, 'b6620d4c-259c-4452-9220-fc612f8b6e32', '170603', true, true, NULL, 170603, 1706);
INSERT INTO "e-izin"."AtikKod" VALUES ('6a73116d-a711-4fc7-8daf-07ff98e445d1', '2023-07-24 11:06:19.249985', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cam', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200102', false, false, NULL, 200102, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('6aceb2fb-7a94-45fb-bfad-c705bb054f2f', '2023-07-24 11:06:19.209083', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Amonyum hidroksit', 1, '0c74ab22-30b7-44fd-8a78-91dc30bf4f41', '060203', true, true, NULL, 60203, 602);
INSERT INTO "e-izin"."AtikKod" VALUES ('6b41399a-bd38-4f7c-9135-b4c36296d903', '2023-07-24 11:06:19.251784', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı arıtımından kaynaklanan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', 1, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100817', true, true, NULL, 100817, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('6ba1a03c-0fe1-4c3c-ae14-58c38b688f7c', '2023-07-24 11:06:19.267962', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İyon değiştiricilerinin rejenerasyonundan kaynaklanan solüsyonlar ve çamurlar', NULL, '02ad50ac-b89e-4b16-a98e-1931776eea3b', '190906', false, false, NULL, 190906, 1909);
INSERT INTO "e-izin"."AtikKod" VALUES ('6c5330f6-403b-4006-805e-2fadac2c936b', '2023-07-24 11:06:19.209627', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağır metal içeren katı tuzlar ve solüsyonlar', 1, '5dc8194f-2de7-4707-8fcb-ffac8a0ea72a', '060313', true, true, NULL, 60313, 603);
INSERT INTO "e-izin"."AtikKod" VALUES ('6c75b3c8-2a07-47c9-b29b-8cb39a72e972', '2023-07-24 11:06:19.225676', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', 1, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100402', true, true, NULL, 100402, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('6cf718a0-97b8-4013-80a9-77f71817fb0f', '2023-07-24 11:06:19.231102', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kalay', NULL, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170406', false, false, NULL, 170406, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('6d4c9fbc-1a20-4e1c-8c7a-1b7e2d9624be', '2023-07-24 11:06:19.24816', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190899', false, false, NULL, 190899, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('6de5e0cf-c9b4-4947-b03e-1064589cc475', '2023-07-24 11:06:19.281418', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Temizsu sondaj çamurları ve atıkları', NULL, 'a3b7fef0-d9d1-4326-9622-3497df5170aa', '010504', false, false, NULL, 10504, 105);
INSERT INTO "e-izin"."AtikKod" VALUES ('6e1255cb-10b7-4151-94d4-92eb6bc0ecc5', '2023-07-24 11:06:19.247741', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Düzenli Depolama Sahası Süzüntü Suları', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1907', false, true, NULL, 1907, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('6e5850c8-c9ce-4f03-b19e-158f45532712', '2023-07-24 11:06:19.252637', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101099', false, false, NULL, 101099, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('6e7a3729-c8bc-4737-9ef1-70b6f6785d65', '2023-07-24 11:06:19.218451', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '2cc8b711-0e7d-4aeb-a8de-9e7d57836ef5', '060199', false, false, NULL, 60199, 601);
INSERT INTO "e-izin"."AtikKod" VALUES ('6ea908b6-5d55-4cba-b325-a1efd73b4189', '2023-07-24 11:06:19.247921', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kum ayırma işleminden kaynaklanan atıkları', NULL, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190802', false, false, NULL, 190802, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('6ede2923-d550-4286-8107-bdc85c0a8475', '2023-07-24 11:06:19.276276', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli dip tortusu ve reaksiyon kalıntıları', 1, '02890c62-fdea-4520-a830-5462e228d706', '070207', true, true, NULL, 70207, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('6f24cfc1-e2d3-4ef3-b9db-7a8d646445bc', '2023-07-24 11:06:19.227257', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Krom içermeyen sepi şerbeti', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040105', false, false, NULL, 40105, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '2023-07-24 11:06:19.270013', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İnsanlarda Doğum, Teşhis, Tedavi ya da Hastalık Önleme Çalışmalarından Kaynaklanan Atıklar', NULL, '261f4c4c-7976-4ece-b934-d8f4e9d211d6', '1801', false, true, NULL, 1801, 18);
INSERT INTO "e-izin"."AtikKod" VALUES ('6f38b08c-106b-4284-932e-2f21aef998d8', '2023-07-24 11:06:19.269619', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer İnşaat ve Yıkıntı Atıkları', NULL, 'c4d6b5a4-b326-453e-a375-286212bd4d29', '1709', false, true, NULL, 1709, 17);
INSERT INTO "e-izin"."AtikKod" VALUES ('6f936c5c-1ff9-4a70-a246-04dd965decb5', '2023-07-24 11:06:19.257652', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 03 19 dışındaki baca gazı tozu', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100320', false, false, NULL, 100320, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('6fed997d-f584-4983-950c-6f76e74b1a5f', '2023-07-24 11:06:19.276337', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', 1, '02890c62-fdea-4520-a830-5462e228d706', '070209', true, true, NULL, 70209, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('7029eded-07df-48d7-a520-bfd7c1f55c9f', '2023-07-24 11:06:19.211141', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '764121c0-0bfa-4399-a0c0-a983b62115be', '061099', false, false, NULL, 61099, 610);
INSERT INTO "e-izin"."AtikKod" VALUES ('70500197-b521-417d-b424-f4d294317922', '2023-07-24 11:06:19.203596', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşlenmiş tekstil elyafı atıkları', NULL, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040222', false, false, NULL, 40222, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('70b5c7e5-b37c-4c4e-8c79-0bf3c32d8a28', '2023-07-24 11:06:19.211732', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Karışık belediye atıkları', NULL, '0c2d44f6-5fee-444f-beb8-5ad3318f616a', '200301', false, false, NULL, 200301, 2003);
INSERT INTO "e-izin"."AtikKod" VALUES ('70c22189-cc04-4f0a-9d79-37519ea90e27', '2023-07-24 11:06:19.240497', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çinko hidrometalürjisi (jarosid ve goetid dahil) çamurları', 1, '489a8b03-d530-40e7-b85e-fffbb62081ec', '110202', true, true, NULL, 110202, 1102);
INSERT INTO "e-izin"."AtikKod" VALUES ('712604ec-05cf-4ebb-ab0c-37005e2a2cbf', '2023-07-24 11:06:19.220926', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cam', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160120', false, false, NULL, 160120, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('71261ab7-34f1-4751-a640-7a64a6cfb36e', '2023-07-24 11:06:19.257739', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren gaz arıtımı çamurları ve filtre kekleri', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100325', true, true, NULL, 100325, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('7133b9a1-dcc8-4905-9602-6d8faffda037', '2023-07-24 11:06:19.277952', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtım çamurları ve filtre kekleri', 1, '3b4a20a2-c147-4b99-b9bb-750194453116', '100506', true, true, NULL, 100506, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('717f6940-2d8f-4b58-8773-0f42f05340b8', '2023-07-24 11:06:19.246952', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190199', false, false, NULL, 190199, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('72718be8-96f8-4285-9df2-4489e03514b9', '2023-07-24 11:06:19.280501', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren gazların arıtımı sonucu ortaya çıkan katı atıklar', 1, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100207', true, true, NULL, 100207, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('7277287a-69b1-43bd-922f-67195a229548', '2023-07-24 11:06:19.280753', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 03 05 dışındaki köpükler', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100316', false, false, NULL, 100316, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('7289a6ea-46a4-438f-902e-47fcd358bcfd', '2023-07-24 11:06:19.271311', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren piroliz atıkları', 1, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190117', true, true, NULL, 190117, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('7293818d-b46e-4ad6-ac98-aaa545d7d8e9', '2023-07-24 11:06:19.236905', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık beton ve beton çamurları', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101314', false, false, NULL, 101314, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('72975ab0-d46f-435c-a4d6-db73e28ae3ef', '2023-07-24 11:06:19.221588', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Akışkan yatak kumları', NULL, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190119', false, false, NULL, 190119, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('72c55d2d-1419-4e77-b4e6-806a9310bfc6', '2023-07-24 11:06:19.253119', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Partiküller ve toz', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101203', false, false, NULL, 101203, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('72e3bb22-557e-4c82-92bc-1df86b989ccd', '2023-07-24 11:06:19.210417', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '15b7a42d-7d99-4839-968d-919db1997c62', '060699', false, false, NULL, 60699, 606);
INSERT INTO "e-izin"."AtikKod" VALUES ('72fb0cd8-4dec-4965-beb3-f1b225a91c06', '2023-07-24 11:06:19.249257', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cam', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191205', false, false, NULL, 191205, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('73562b26-e26f-44b4-aacd-6ebbfc2bf870', '2023-07-24 11:06:19.257478', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Anot üretiminden kaynaklanan katranlı atıklar', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100317', true, true, NULL, 100317, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('7372847a-2cc5-4c61-992d-f224f220c3f7', '2023-07-24 11:06:19.273271', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kolayca biyolojik olarak bozunabilir hidrolik yağlar', 2, '676c52f5-81e5-4570-8135-2f3324688790', '130112', true, true, true, 130112, 1301);
INSERT INTO "e-izin"."AtikKod" VALUES ('740b0a4f-a641-4299-acc6-c12fe16d5ad6', '2023-07-24 11:06:19.265021', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 08 12 dışındaki anot üretiminden kaynaklanan karbon içerikli atıklar', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100813', false, false, NULL, 100813, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('743ca3ae-d2b8-44e1-a28f-2e9c3b3659f9', '2023-07-24 11:06:19.225796', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100899', false, false, NULL, 100899, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('747f7f1d-09b4-458d-82d5-fe9de00588ec', '2023-07-24 11:06:19.275954', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '62946a2a-b011-4804-b78e-540f50e96d69', '061399', false, false, NULL, 61399, 613);
INSERT INTO "e-izin"."AtikKod" VALUES ('749518c6-e066-4e72-904e-6eaf3b34e7b3', '2023-07-24 11:06:19.218539', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '06 03 15 dışındaki diğer metal oksitler', NULL, '5dc8194f-2de7-4707-8fcb-ffac8a0ea72a', '060316', false, false, NULL, 60316, 603);
INSERT INTO "e-izin"."AtikKod" VALUES ('74d63e2c-3408-42ac-a7ff-fb8b27ba3efd', '2023-07-24 11:06:19.272029', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 06 01, 16 06 02 veya 16 06 03?un altında geçen pil ve akümülatörler ve bu pilleri içeren sınıflandırılmamış karışık pil ve akümülatörler', 2, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200133', true, true, NULL, 200133, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('75941206-07c6-4bfc-8bf6-2de03de411a7', '2023-07-24 11:06:19.282137', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Krematoryum Atıkları', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1014', false, true, NULL, 1014, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('75fa395a-9b99-4692-8859-0334b62d4075', '2023-07-24 11:06:19.272937', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '03 01 04 dışındaki talaş, yonga, kıymık, ahşap, kontraplak ve kaplamalar', NULL, '079e8777-e624-4a0f-9669-a32b5c39ddad', '030105', false, false, NULL, 30105, 301);
INSERT INTO "e-izin"."AtikKod" VALUES ('764121c0-0bfa-4399-a0c0-a983b62115be', '2023-07-24 11:06:19.275893', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gübre Üretimi ve Azotlu Kimyasalların İşlenmesi ve Azot Kimyasalları İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, 'f7e1e0ad-6105-4b47-b402-506edf4480f7', '0610', false, true, NULL, 610, 6);
INSERT INTO "e-izin"."AtikKod" VALUES ('764904e4-9d91-4770-9aee-2072e31117e9', '2023-07-24 11:06:19.235086', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer atıklar', 1, '23405de6-af3e-427e-9239-66d58607d7cc', '190211', true, true, NULL, 190211, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('76517305-da68-4f57-a2eb-2f86d6bfb217', '2023-07-24 11:06:19.246478', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Taban külünden ayrılan demir içerikli maddeler', NULL, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190102', false, false, NULL, 190102, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('7666f919-b72d-4f35-beea-4fabd6a5bc27', '2023-07-24 11:06:19.21496', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', 1, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070609', true, true, NULL, 70609, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('76c67ed8-b7d8-4a8f-85f9-5867af15e385', '2023-07-24 11:06:19.256466', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma suyu işlemlerinden çıkan atıklar', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100126', false, false, NULL, 100126, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('76c99fee-d93e-4f8a-8a59-33dbbd34f2c0', '2023-07-24 11:06:19.281958', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren bağlayıcı atıkları', 1, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101013', true, true, NULL, 101013, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('77166586-6be6-4532-9f15-5318e2afe49e', '2023-07-24 11:06:19.252816', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren cam parlatma ve öğütme çamuru', 1, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101113', true, true, NULL, 101113, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('7739d7d8-9618-411c-a29c-49a340c6e3af', '2023-07-24 11:06:19.243609', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer tehlikeli maddeler içeren atıklar', 1, '7887dde6-0719-4ba8-b05e-8ffee0b419ea', '160709', true, true, NULL, 160709, 1607);
INSERT INTO "e-izin"."AtikKod" VALUES ('77f5a462-b0e2-4983-ad71-f26e86710ede', '2023-07-24 11:06:19.233573', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Boş basınçlı konteynırlar dahil olmak üzere tehlikeli gözenekli katı yapılı (örneğin asbest) metalik ambalajlar', 1, '8f20317c-2895-43f2-a702-b02b71336086', '150111', true, true, NULL, 150111, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('77fc9674-14a6-420d-9c09-2e17fcf7a0b6', '2023-07-24 11:06:19.251295', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri', NULL, 'e67297f9-9141-4cd9-ac88-e58d52bc88c9', '100705', false, false, NULL, 100705, 1007);
INSERT INTO "e-izin"."AtikKod" VALUES ('7887dde6-0719-4ba8-b05e-8ffee0b419ea', '2023-07-24 11:06:19.266234', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Nakliye Tankı, Depolama Tankı ve Varil Temizleme İşlemlerinden Kaynaklanan Atıklar (05 ve 13 hariç)', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1607', false, true, NULL, 1607, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('78d29661-75fd-47ef-aabd-ab081f27dca5', '2023-07-24 11:06:19.277152', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli dip tortuları ve reaksiyon kalıntıları', 1, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070607', true, true, NULL, 70607, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('795b869d-c35d-4018-a142-0625e606af4c', '2023-07-24 11:06:19.255289', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sabitleyici solüsyonlar', 1, '8693d445-ccb1-423b-8380-a415bab62bb1', '090104', true, true, NULL, 90104, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('797a503a-b0e2-4d92-9343-421baca3390c', '2023-07-24 11:06:19.217392', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '20 01 33 dışındaki pil ve akümülatörler', 2, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200134', false, false, NULL, 200134, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('79dff92a-6cfa-4f0d-8349-e1452b22d2eb', '2023-07-24 11:06:19.249007', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kağıt ve karton', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191201', false, false, NULL, 191201, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('7a1db1fe-c0a1-4366-b3c6-470007c1b2da', '2023-07-24 11:06:19.246116', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sitotoksik ve sitostatik ilaçlar', 1, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180108', true, true, NULL, 180108, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('7b1f3519-e16b-445c-b927-d70255f332d9', '2023-07-24 11:06:19.24219', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ/Su Ayırıcısı İçerikleri', NULL, 'd7bf6b00-841e-4840-ba5b-3e2c3b77bf21', '1305', false, true, NULL, 1305, 13);
INSERT INTO "e-izin"."AtikKod" VALUES ('7b8d483e-9d6f-4f7e-80da-7676fdcfd941', '2023-07-24 11:06:19.230254', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sıvı Yakıtların Atıkları', NULL, 'd7bf6b00-841e-4840-ba5b-3e2c3b77bf21', '1307', false, true, NULL, 1307, 13);
INSERT INTO "e-izin"."AtikKod" VALUES ('7bcb6da6-43d2-4336-b3c2-782f2c599e74', '2023-07-24 11:06:19.238693', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'DERİ, KÜRK VE TEKSTİL ENDÜSTRİLERİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '04', false, true, NULL, 4, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('7c38795c-d474-42e1-b2dd-93b79142b910', '2023-07-24 11:06:19.22625', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çözücü ekstraksiyonundan kaynaklanan atıklar', NULL, '88e7ece3-789d-4b74-bc19-403a3f91dd79', '020303', false, false, NULL, 20303, 203);
INSERT INTO "e-izin"."AtikKod" VALUES ('7c79e1a6-e721-46d3-9c5b-445a5b5035b2', '2023-07-24 11:06:19.252513', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 10 11 dışındaki diğer partiküller', NULL, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101012', false, false, NULL, 101012, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('7cd70342-022b-4f27-aa89-370e025254ca', '2023-07-24 11:06:19.254677', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 04 09 dışındaki atık yapışkanlar ve dolgu macunları', NULL, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080410', false, false, NULL, 80410, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('7d8314ae-af18-46ee-9339-298651b36d10', '2023-07-24 11:06:19.204389', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer ziftler', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050108', true, true, NULL, 50108, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('7d901434-730a-4e56-87da-3affbd4ad6d9', '2023-07-24 11:06:19.218345', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmayan atıklar', NULL, '07a8b9c4-da35-4838-86e3-a340636a4aa7', '050699', false, false, NULL, 50699, 506);
INSERT INTO "e-izin"."AtikKod" VALUES ('7d9f0d05-5d6c-4243-961d-d05d313eece1', '2023-07-24 11:06:19.258629', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık kum ve killer', NULL, '2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '010409', false, false, NULL, 10409, 104);
INSERT INTO "e-izin"."AtikKod" VALUES ('7e13f5f0-7743-4336-9802-0c64c4819a45', '2023-07-24 11:06:19.26394', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerden oluşan kimyasallar', 1, '33e02f8e-69f7-4898-bae5-35e162129f2c', '180205', true, true, NULL, 180205, 1802);
INSERT INTO "e-izin"."AtikKod" VALUES ('7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '2023-07-24 11:06:19.215981', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Boya ve Verniğin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Sökülmesinden Kaynaklanan Atıklar', NULL, '65eda575-b204-412b-8918-dbac781a630c', '0801', false, true, NULL, 801, 8);
INSERT INTO "e-izin"."AtikKod" VALUES ('7e23639c-4ac9-4ab3-94a0-d8ad12c0486a', '2023-07-24 11:06:19.235147', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler içeren perdah atıkları', 1, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040214', true, true, NULL, 40214, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('7f1f469e-1575-4540-b427-5f91228fad9d', '2023-07-24 11:06:19.247375', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Vitrifiye Edilmiş Atık ve Vitrifikasyon İşleminden Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1904', false, true, NULL, 1904, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('7f49f087-e25b-4dc4-9ac5-4d90a1691f9a', '2023-07-24 11:06:19.235265', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli madde içeren çamurlar', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050109', true, true, NULL, 50109, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('7fff98fa-8375-47e6-abac-dd67c3033bb8', '2023-07-24 11:06:19.257302', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık alüminyum oksit', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100305', false, false, NULL, 100305, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('801aa00f-4b36-4d68-a9b6-bef0774d90c2', '2023-07-24 11:06:19.252273', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli madde içeren çatlak belirleme kimyasalları atığı', 1, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100915', true, true, NULL, 100915, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('8066c902-0d18-4db7-ae51-028f05c9ecc2', '2023-07-24 11:06:19.242526', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka Bir Şekilde Tanımlanmamış Atıkların Mekanik Arıtımından (Örneğin Ayrıştırılması, Ezilmesi, Sıkıştırılması, Topak Haline Getirilmesi) Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1912', false, true, NULL, 1912, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('808cca23-f715-40ea-b614-98dbe9063cc1', '2023-07-24 11:06:19.273018', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 13 12 dışındaki gaz arıtma katı atıkları', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101313', false, false, NULL, 101313, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('80bfda3f-5235-416f-9157-fd3897c78a3e', '2023-07-24 11:06:19.220014', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kimyasal işlem atıkları', NULL, 'c746097f-76b0-4c0f-9bc2-314e3947c853', '020703', false, false, NULL, 20703, 207);
INSERT INTO "e-izin"."AtikKod" VALUES ('80cddef5-2f29-44ef-adb4-dd0274da3b17', '2023-07-24 11:06:19.241025', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'PCB''ler içeren transformatörler ve kapasitörler', 2, 'fcf7052f-6471-4238-bfd9-a9b918f118ce', '160209', true, true, NULL, 160209, 1602);
INSERT INTO "e-izin"."AtikKod" VALUES ('812d401c-8a92-410a-8fc3-b180658b2640', '2023-07-24 11:06:19.215145', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı yıkama sıvıları ve ana çözeltiler', 1, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070701', true, true, NULL, 70701, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('813060a9-58b7-40e5-b802-978aecd4ac0b', '2023-07-24 11:06:19.246833', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 01 15 dışındaki kazan tozu', NULL, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190116', false, false, NULL, 190116, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('817af670-329b-4fdc-84a2-2bf582fdaa88', '2023-07-24 11:06:19.207364', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kükürt içeren atıklar', NULL, 'cebf823f-b311-4b88-8e34-75f22d25a1a3', '050702', false, false, NULL, 50702, 507);
INSERT INTO "e-izin"."AtikKod" VALUES ('81d6836b-5602-4935-bd0a-f075b71892c2', '2023-07-24 11:06:19.276585', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli dip tortusu ve reaksiyon kalıntıları', 1, 'faf9d336-4990-4298-a50a-b56af7884053', '070307', true, true, NULL, 70307, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('8241f809-7ece-4d45-a11a-eb0aa99e29b2', '2023-07-24 11:06:19.270568', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olan atıklar', 2, '33e02f8e-69f7-4898-bae5-35e162129f2c', '180202', true, true, NULL, 180202, 1802);
INSERT INTO "e-izin"."AtikKod" VALUES ('828f2055-b714-4845-9ca4-03c969eb85d4', '2023-07-24 11:06:19.283459', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 01 14 dışındaki birlikte yakılmadan (co-incineration) kaynaklanan dip külü, cüruf ve kazan tozu', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100115', false, false, NULL, 100115, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('82ec277e-acf6-4b11-aca9-d0f464cf0f9c', '2023-07-24 11:06:19.250878', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil ve ikincil üretim cürufları', NULL, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100601', false, false, NULL, 100601, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('82ec9e9e-036f-4c2b-a363-ca25a99d10a9', '2023-07-24 11:06:19.233092', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer çözücüler ve çözücü karışımları', 1, '8554b0a1-4347-4a3d-81e5-6eb9bc3216bd', '140603', true, true, NULL, 140603, 1406);
INSERT INTO "e-izin"."AtikKod" VALUES ('83ac8a0a-89ff-440b-803c-10a472bc0091', '2023-07-24 11:06:19.231766', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Biyolojik olarak bozunabilir atıklar', NULL, 'f850dc94-1624-44dd-a771-e537933cd4fd', '200201', false, false, NULL, 200201, 2002);
INSERT INTO "e-izin"."AtikKod" VALUES ('83b7f588-2ae4-433d-9b3e-738feffaed14', '2023-07-24 11:06:19.226691', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cıva içeren piller', 2, 'ffee3666-7a2b-4281-8460-44408303217f', '160603', true, true, NULL, 160603, 1606);
INSERT INTO "e-izin"."AtikKod" VALUES ('840fdb51-9475-4220-b67f-df6ac0928263', '2023-07-24 11:06:19.272273', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca temizliğinden kaynaklanan atıklar', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200141', false, false, NULL, 200141, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('908013c8-3159-4d27-865d-187ec01ed6f1', '2023-07-24 11:06:19.22555', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka şekilde tanımlanmayan atıklar', NULL, '0058b96b-d695-4095-a185-132f753311cc', '070199', false, false, NULL, 70199, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('84134d6b-99c0-417a-bc07-a99543d9482f', '2023-07-24 11:06:19.243789', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli geçiş metalleri3 ya da tehlikeli geçiş metal bileşenlerini içeren bitik katalizörler', 1, '927df4de-1098-43b7-a071-8c1877c8b691', '160802', true, true, NULL, 160802, 1608);
INSERT INTO "e-izin"."AtikKod" VALUES ('841b4fa8-df0b-4dfe-82a9-be615e1b918f', '2023-07-24 11:06:19.239114', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çimento, Kireç ve Alçı ve Bunlardan Yapılan Ürünlerin Üretim Atıkları', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1013', false, true, NULL, 1013, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('84909fb1-6c7c-425d-8c7f-59a540cff570', '2023-07-24 11:06:19.221678', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ayrışmadan oluşan yağ ve konsantrasyonlar', 1, '23405de6-af3e-427e-9239-66d58607d7cc', '190207', true, true, NULL, 190207, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('84a2679d-eb0c-49a4-8a5b-81f5dc9c4552', '2023-07-24 11:06:19.264839', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 01 17 dışındaki boya ve vernik sökülmesinden kaynaklanan atıklar', NULL, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080118', false, false, NULL, 80118, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('852bac72-dc82-447f-a3cc-7c96970ea7dd', '2023-07-24 11:06:19.238268', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış ahşap koruyucuları', NULL, '32fa13d4-52f1-4c6e-9513-15ee2274d4c2', '030299', false, false, NULL, 30299, 302);
INSERT INTO "e-izin"."AtikKod" VALUES ('852bf16f-1426-4af2-844b-e38a6ab3c13c', '2023-07-24 11:06:19.213119', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer filtre kekleri ve kullanılmış absorbanlar', 1, 'faf9d336-4990-4298-a50a-b56af7884053', '070310', true, true, NULL, 70310, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('8554b0a1-4347-4a3d-81e5-6eb9bc3216bd', '2023-07-24 11:06:19.232972', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık Organik Çözücüler, Soğutucular ve Köpük/Aerosol İtici Gazlar', NULL, '604a4ed3-7c96-4a12-b928-e143b815e096', '1406', false, true, NULL, 1406, 14);
INSERT INTO "e-izin"."AtikKod" VALUES ('8693d445-ccb1-423b-8380-a415bab62bb1', '2023-07-24 11:06:19.282258', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fotoğraf Endüstrisi Atıkları', NULL, '0c744e8c-4c87-4d7b-a950-7b86910e8cf5', '0901', false, true, NULL, 901, 9);
INSERT INTO "e-izin"."AtikKod" VALUES ('87472e6e-58cd-47da-8f27-282cbb95f77b', '2023-07-24 11:06:19.248456', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metal İçeren Atıkların Parçalanmasından Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1910', false, true, NULL, 1910, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('87554378-20b5-4632-9fbc-e8223ccfff4c', '2023-07-24 11:06:19.220171', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101299', false, false, NULL, 101299, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('880c0898-7f82-414b-ae5f-f91c9a98d367', '2023-07-24 11:06:19.260927', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tüketime ve işlenmeye uygun olmayan maddeler', NULL, '0992b899-80a5-429f-b40d-b28c7ecd3504', '020601', false, false, NULL, 20601, 206);
INSERT INTO "e-izin"."AtikKod" VALUES ('883989a4-1012-4bf0-be7b-eebf676429f0', '2023-07-24 11:06:19.282976', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120199', false, false, NULL, 120199, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('8870c818-911c-4764-a720-eb6ab804b1bf', '2023-07-24 11:06:19.218268', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşletme ya da ekipman bakım çalışmalarından kaynaklanan yağlı çamurlar', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050106', true, true, NULL, 50106, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('88b772bf-3259-4799-bc8b-8c498b33781d', '2023-07-24 11:06:19.246056', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '18 01 06 dışındaki kimyasallar', NULL, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180107', false, false, NULL, 180107, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('88d99e35-fa52-4d8a-99ed-4d3fb24b9e47', '2023-07-24 11:06:19.261205', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hammaddelerin yıkanmasından, temizlenmesinden ve mekanik olarak sıkılmasından kaynaklanan atıklar', NULL, 'c746097f-76b0-4c0f-9bc2-314e3947c853', '020701', false, false, NULL, 20701, 207);
INSERT INTO "e-izin"."AtikKod" VALUES ('88e7ece3-789d-4b74-bc19-403a3f91dd79', '2023-07-24 11:06:19.237249', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Meyve, sebze, tahıl, yenilebilir yağlar, kakao, kahve, çay ve tütünün hazırlanmasından ve işlenmesinden; konserve üretiminden, maya ve maya özütü üretiminden, molas hazırlanması ve fermantasyonundan kaynaklanan atıklar', NULL, 'a80a1d5d-070c-488c-bd1b-4fb2bd4b420f', '0203', false, true, NULL, 203, 2);
INSERT INTO "e-izin"."AtikKod" VALUES ('899f7776-f342-408d-b48f-f86296d54fc3', '2023-07-24 11:06:19.244029', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Permanganatlar (örneğin potasyum permanganat)', 1, '9755a757-20f8-4784-8424-5135b4c3444a', '160901', true, true, NULL, 160901, 1609);
INSERT INTO "e-izin"."AtikKod" VALUES ('89b8992e-049d-450f-af7f-5dc9cbbdcb99', '2023-07-24 11:06:19.279931', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '09 01 11 dışındaki pille çalışan tek kullanımlık fotoğraf makineleri', NULL, '8693d445-ccb1-423b-8380-a415bab62bb1', '090112', false, false, NULL, 90112, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('89eb2bdf-e9f3-460e-9164-22ab200eca82', '2023-07-24 11:06:19.243549', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ içeren atıklar', 1, '7887dde6-0719-4ba8-b05e-8ffee0b419ea', '160708', true, true, NULL, 160708, 1607);
INSERT INTO "e-izin"."AtikKod" VALUES ('8a45b30b-ed8e-4a20-8aba-9e98385bc4f3', '2023-07-24 11:06:19.245878', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kesiciler (18 01 03 hariç)', 2, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180101', false, false, NULL, 180101, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('8aaf8539-8808-4099-93de-2dbd69b19962', '2023-07-24 11:06:19.227651', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Isıl işlemden önce hazırlanan tehlikeli maddeler içeren harman atığı', 1, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101109', true, true, NULL, 101109, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('8b56c798-0416-4c93-ad4a-56b3b5da79c0', '2023-07-24 11:06:19.218986', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer dip tortuları ve reaksiyon kalıntıları', 1, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070608', true, true, NULL, 70608, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('8b9c86a6-8a6a-473e-8895-898d2065c3a2', '2023-07-24 11:06:19.24192', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mineral esaslı klor içermeyen yalıtım ve ısı iletim yağları', 2, '0616d181-bdb8-454f-af80-0a765b0d6086', '130307', true, true, true, 130307, 1303);
INSERT INTO "e-izin"."AtikKod" VALUES ('8c13d02a-936e-4a93-8508-8207af2c45d4', '2023-07-24 11:06:19.274465', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Toprak (Kirlenmiş Yerlerde Yapılan Hafriyat Dahil), Kayalar ve Dip Tarama Çamurları', NULL, 'c4d6b5a4-b326-453e-a375-286212bd4d29', '1705', false, true, NULL, 1705, 17);
INSERT INTO "e-izin"."AtikKod" VALUES ('8c76e56c-078b-4021-a5a0-f1a761d84b30', '2023-07-24 11:06:19.231345', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 02 05 dışındaki fiziksel ve kimyasal işlemlerden kaynaklanan çamurlar', NULL, '23405de6-af3e-427e-9239-66d58607d7cc', '190206', false, false, NULL, 190206, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('8ccde4c3-2b38-40b2-b424-f2f56750d9cc', '2023-07-24 11:06:19.261939', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer ahşap koruyucuları', 1, '32fa13d4-52f1-4c6e-9513-15ee2274d4c2', '030205', true, true, NULL, 30205, 302);
INSERT INTO "e-izin"."AtikKod" VALUES ('8d02ff97-2df9-492b-af34-f0a9e2e011ae', '2023-07-24 11:06:19.220407', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sentetik işleme yağları', 2, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120110', true, true, true, 120110, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('8d03fee9-da22-4e0e-9d33-bc4ba5904a1b', '2023-07-24 11:06:19.254917', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Reçine yağı', 1, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080417', true, true, NULL, 80417, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('8d63a734-3064-49cb-9ca8-12a3253c690a', '2023-07-24 11:06:19.220575', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer denizcilik seyrüseferinden kaynaklanan sintine yağları', 1, '4a6ea286-5629-48e0-9e72-ce8ca286b51f', '130403', true, true, NULL, 130403, 1304);
INSERT INTO "e-izin"."AtikKod" VALUES ('8daece97-94df-43c6-98dc-2c85640ba3cf', '2023-07-24 11:06:19.217027', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren kazan tozu', 1, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190115', true, true, NULL, 190115, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('8dd4d629-0fb1-4b12-96c3-1d65737b4291', '2023-07-24 11:06:19.218185', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kanalizasyon temizliğinden kaynaklanan atıklar', NULL, '0c2d44f6-5fee-444f-beb8-5ad3318f616a', '200306', false, false, NULL, 200306, 2003);
INSERT INTO "e-izin"."AtikKod" VALUES ('8e84d88e-9650-4268-9065-5e25ce8dc1fa', '2023-07-24 11:06:19.209774', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '06 03 11 ve 06 03 13 dışındaki katı tuzlar ve solüsyonlar', NULL, '5dc8194f-2de7-4707-8fcb-ffac8a0ea72a', '060314', false, false, NULL, 60314, 603);
INSERT INTO "e-izin"."AtikKod" VALUES ('8e8d62e4-15b5-44b4-9089-d0b49bda7142', '2023-07-24 11:06:19.27253', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış belediye atıkları', NULL, '0c2d44f6-5fee-444f-beb8-5ad3318f616a', '200399', false, false, NULL, 200399, 2003);
INSERT INTO "e-izin"."AtikKod" VALUES ('8ec4fb8b-2a23-45e3-aac3-37cacf61c2c8', '2023-07-24 11:06:19.23775', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Alkol damıtılmasından kaynaklanan atıklar', NULL, 'c746097f-76b0-4c0f-9bc2-314e3947c853', '020702', false, false, NULL, 20702, 207);
INSERT INTO "e-izin"."AtikKod" VALUES ('8ed392a0-6cc9-49f0-afde-86b1a10a6002', '2023-07-24 11:06:19.263848', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '11 01 13 dışındaki yağ alma atıkları', NULL, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110114', false, false, NULL, 110114, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('8ed8d168-4beb-4078-ad17-fb845bf58965', '2023-07-24 11:06:19.283148', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su berraklaştırılmasından kaynaklanan çamurlar', NULL, '02ad50ac-b89e-4b16-a98e-1931776eea3b', '190902', false, false, NULL, 190902, 1909);
INSERT INTO "e-izin"."AtikKod" VALUES ('8f20317c-2895-43f2-a702-b02b71336086', '2023-07-24 11:06:19.233213', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ambalaj (Belediyenin Ayrı Toplanmış Ambalaj Atıkları Dahil)', NULL, 'b37c3d4c-60be-4f29-ad8b-57ab2ca23366', '1501', false, true, NULL, 1501, 15);
INSERT INTO "e-izin"."AtikKod" VALUES ('8f35cac0-b7b4-4127-a98e-d92b2207baef', '2023-07-24 11:06:19.260531', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Standart dışı kalsiyum karbonat', NULL, 'ee8a45ff-6900-4b42-a4b9-f5c9b64aba5e', '020402', false, false, NULL, 20402, 204);
INSERT INTO "e-izin"."AtikKod" VALUES ('8f8e21fd-929e-4a37-b657-eefa5889e0d0', '2023-07-24 11:06:19.227066', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Toprak ve taşlar', NULL, 'f850dc94-1624-44dd-a771-e537933cd4fd', '200202', false, false, NULL, 200202, 2002);
INSERT INTO "e-izin"."AtikKod" VALUES ('8fd1726a-38df-44e2-88bd-7bebf465eb40', '2023-07-24 11:06:19.214752', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070604', true, true, NULL, 70604, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('8ff2316d-97cf-4ce7-8320-0ea7d8418919', '2023-07-24 11:06:19.280692', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İkincil üretimden kaynaklanan kara cüruflar', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100309', true, true, NULL, 100309, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('8ff5b747-577a-4e1d-a24e-c991c981b9d3', '2023-07-24 11:06:19.281178', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 03 10 dışındaki alüminyum oksit üretiminden çıkan kırmızı çamur', NULL, '1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '010309', false, false, NULL, 10309, 103);
INSERT INTO "e-izin"."AtikKod" VALUES ('9025c33d-8c4c-483c-82e2-cf94809537d0', '2023-07-24 11:06:19.234413', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış parçalar', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160122', false, false, NULL, 160122, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('90264494-5c9b-4b2e-b9ff-d6f13cc0bb3b', '2023-07-24 11:06:19.278228', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan katı atıklar', 1, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100606', true, true, NULL, 100606, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('907ff4ad-c3bd-4310-bf5d-e2c0ef60b30c', '2023-07-24 11:06:19.219543', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yakıt olarak kullanılan emülsifiye hidrokarbonların uçucu külleri', 1, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100113', true, true, NULL, 100113, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('911257c4-7d9f-49e1-8091-76a724d5a5d6', '2023-07-24 11:06:19.254235', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık aşındırma solüsyonları', 1, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080316', true, true, NULL, 80316, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('917ce329-f371-4a8a-802d-95683b224636', '2023-07-24 11:06:19.219461', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 11 09 dışında ısıl işlemden önce hazırlanan harman atığı', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101110', false, false, NULL, 101110, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('91afd546-b5f9-403b-b7e4-b8787cf610d8', '2023-07-24 11:06:19.282915', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 03 03 dışındaki inorganik atıklar', NULL, 'fb657553-47ba-4711-84af-b13e3c533180', '160304', false, false, NULL, 160304, 1603);
INSERT INTO "e-izin"."AtikKod" VALUES ('91e5a7e0-2b2e-4e11-a4c5-b2fb5fb251c6', '2023-07-24 11:06:19.211356', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '0d28a1ae-6ecf-4c43-81e6-e8a144012118', '061199', false, false, NULL, 61199, 611);
INSERT INTO "e-izin"."AtikKod" VALUES ('9215061c-24d2-43f1-a0a1-89f8c55dba49', '2023-07-24 11:06:19.212388', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtmından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, '02890c62-fdea-4520-a830-5462e228d706', '070211', true, true, NULL, 70211, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('92234ccd-da20-4e79-8f65-5bd9e5620c00', '2023-07-24 11:06:19.230136', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yakalayıcı (interseptör) çamurları', 1, '7b1f3519-e16b-445c-b927-d70255f332d9', '130503', true, true, NULL, 130503, 1305);
INSERT INTO "e-izin"."AtikKod" VALUES ('923bc424-3220-46ee-843b-79fbf466d3e0', '2023-07-24 11:06:19.245996', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerden oluşan kimyasallar', 1, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180106', true, true, NULL, 180106, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('927df4de-1098-43b7-a071-8c1877c8b691', '2023-07-24 11:06:19.24373', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bitik Katalizörler', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1608', false, true, NULL, 1608, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('92b0eefb-f0b3-47f8-9199-5c9612713e54', '2023-07-24 11:06:19.256154', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren gaz temizleme atıkları', 1, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100118', true, true, NULL, 100118, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('939f30af-71d0-4990-8390-a3849a9345e9', '2023-07-24 11:06:19.22862', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan katı atıklar', 1, '98beda5b-44c8-4aee-afd8-24c61d6fe067', '110503', true, true, NULL, 110503, 1105);
INSERT INTO "e-izin"."AtikKod" VALUES ('93d07ed6-e0f9-4dea-a503-721615de4e22', '2023-07-24 11:06:19.230852', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Laboratuvar kimyasalları karışımları dahil tehlikeli maddelerden oluşan ya da tehlikeli maddeler içeren laboratuvar kimyasalları', 1, 'd1a799b4-e386-4588-ade4-462395e2d1a5', '160506', true, true, NULL, 160506, 1605);
INSERT INTO "e-izin"."AtikKod" VALUES ('93d444ec-d837-4f46-a11b-818a58d0ca74', '2023-07-24 11:06:19.216316', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernik çamurları', 1, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080113', true, true, NULL, 80113, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('93ec2bf1-8716-4229-bd05-f2ff14290ef3', '2023-07-24 11:06:19.283949', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 03 07 dışındaki alüminyum oksit üretiminden çıkan tehlikeli maddeler içeren kırmızı çamur', NULL, '1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '010310', true, true, NULL, 10310, 103);
INSERT INTO "e-izin"."AtikKod" VALUES ('9436676a-311c-4626-85de-cc8366a42f1f', '2023-07-24 11:06:19.212609', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Zararlı silikonlar içeren atıklar', 1, '02890c62-fdea-4520-a830-5462e228d706', '070216', true, true, NULL, 70216, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('943c7669-9c26-4e80-a26c-c62d64266181', '2023-07-24 11:06:19.222575', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 05 04 dışında basınçlı tanklar içindeki gazlar', NULL, 'd1a799b4-e386-4588-ade4-462395e2d1a5', '160505', false, false, NULL, 160505, 1605);
INSERT INTO "e-izin"."AtikKod" VALUES ('946881a1-c0cf-4236-ad0f-2146fa2f0a15', '2023-07-24 11:06:19.240198', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110199', false, false, NULL, 110199, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('94979dc9-8292-4290-8eb8-2081bb6a503f', '2023-07-24 11:06:19.234538', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kloroflorokarbon, HCFC, HFC içeren ıskarta ekipmanlar', 1, 'fcf7052f-6471-4238-bfd9-a9b918f118ce', '160211', true, true, NULL, 160211, 1602);
INSERT INTO "e-izin"."AtikKod" VALUES ('94b23945-cd56-431e-9457-6767e63bbfc2', '2023-07-24 11:06:19.241759', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sentetik motor, şanzıman ve yağlama yağları', 2, 'dff8bb04-5506-4de9-980b-42baa9dd737b', '130206', true, true, true, 130206, 1302);
INSERT INTO "e-izin"."AtikKod" VALUES ('94beeded-9e01-45f1-a89f-298312e077e9', '2023-07-24 11:06:19.227317', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fosforik ve fosforöz asit', 1, '2cc8b711-0e7d-4aeb-a8de-9e7d57836ef5', '060104', true, true, NULL, 60104, 601);
INSERT INTO "e-izin"."AtikKod" VALUES ('94c9f8c4-6a7f-4556-8087-169a40348982', '2023-07-24 11:06:19.279568', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 05 14 dışındaki mürekkep çamurları', NULL, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080315', false, false, NULL, 80315, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('955bb246-d0a8-43df-9983-a57ad29587ac', '2023-07-24 11:06:19.233513', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cam ambalaj', NULL, '8f20317c-2895-43f2-a702-b02b71336086', '150107', false, false, NULL, 150107, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('957e32d8-4a09-40ef-8692-3930975d225e', '2023-07-24 11:06:19.251844', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar', 1, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100819', true, true, NULL, 100819, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '2023-07-24 11:06:19.279146', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cam ve Cam Ürünleri Üretim Atıkları', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1011', false, true, NULL, 1011, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('95b79baf-b55b-422a-b633-453f373c9a1c', '2023-07-24 11:06:19.213402', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070403', true, true, NULL, 70403, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('95be1993-c47e-454e-9234-9b73275fcf59', '2023-07-24 11:06:19.203152', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '04 02 14 dışındaki perdah atıkları', NULL, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040215', false, false, NULL, 40215, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('95e370ac-bb53-4850-aefd-97c3f2efb606', '2023-07-24 11:06:19.251116', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar', 1, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100609', true, true, NULL, 100609, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('963d8669-21df-4dda-af89-a761f8e013ae', '2023-07-24 11:06:19.249624', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 13 01 dışında toprak ıslahından kaynaklanan atıklar', NULL, '3c8d5e7a-e867-402f-b518-a5cafa387f07', '191302', false, false, NULL, 191302, 1913);
INSERT INTO "e-izin"."AtikKod" VALUES ('96924636-3f0c-449c-ac6b-75a2f286f4a7', '2023-07-24 11:06:19.283399', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren mürekkep çamurları', 1, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080314', true, true, NULL, 80314, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('96b3133c-1270-43e2-971c-cd62ba342bb8', '2023-07-24 11:06:19.23393', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'PCB içeren parçalar', 2, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160109', true, true, NULL, 160109, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('97125dbb-cd78-4cb3-8224-34a91d02f279', '2023-07-24 11:06:19.227772', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sıyırma asitleri (parlatma asitleri)', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110105', true, true, NULL, 110105, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('97206922-2204-4e53-8d2e-0e55dde62be0', '2023-07-24 11:06:19.255067', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08''de Başka Şekilde Tanımlanmamış Atıklar', NULL, '65eda575-b204-412b-8918-dbac781a630c', '0805', false, true, NULL, 805, 8);
INSERT INTO "e-izin"."AtikKod" VALUES ('9755a757-20f8-4784-8424-5135b4c3444a', '2023-07-24 11:06:19.243969', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Oksitleyici Maddeler', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1609', false, true, NULL, 1609, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('97d28306-04b3-4479-b95c-a61891819b90', '2023-07-24 11:06:19.251964', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ocak cürufları', NULL, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100903', false, false, NULL, 100903, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('98530e17-11e0-4e4e-a684-c3d56cf8c138', '2023-07-24 11:06:19.248639', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kullanılmış filtre killeri', 1, 'ba215c7c-63f3-4bf9-b825-30f754e8d40c', '191101', true, true, NULL, 191101, 1911);
INSERT INTO "e-izin"."AtikKod" VALUES ('987b25e7-7a64-457a-8d7a-3d6e27e081cf', '2023-07-24 11:06:19.249438', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yanabilir atıklar (atıktan türetilmiş yakıt)', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191210', false, false, NULL, 191210, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('98beda5b-44c8-4aee-afd8-24c61d6fe067', '2023-07-24 11:06:19.240866', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sıcak Galvanizleme İşlemleri Atıkları', NULL, 'ef717c0c-06e1-4ee0-bb46-b5d04f58e738', '1105', false, true, NULL, 1105, 11);
INSERT INTO "e-izin"."AtikKod" VALUES ('98dc2f64-8d38-41ba-a712-015d26933155', '2023-07-24 11:06:19.277022', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 05 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'ec91af60-1678-4b87-bba9-743705a039fd', '070512', false, false, NULL, 70512, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('98f50ff2-6ca1-49f8-9d58-073e668ce09b', '2023-07-24 11:06:19.280564', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 02 11 dışındaki soğutma suyu arıtma atıkları', NULL, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100212', false, false, NULL, 100212, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('99038aed-f1fb-468b-bbf1-261d15146434', '2023-07-24 11:06:19.280122', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı kükürt giderme işleminden (desülfrizasyon) çıkan kalsiyum bazlı katı atıklar', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100105', false, false, NULL, 100105, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('99103305-7911-49cf-9685-7463c62542db', '2023-07-24 11:06:19.258723', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 04 07 dışındaki taş yontma ve kesme işlemlerinden kaynaklanan atıklar', NULL, '2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '010413', false, false, NULL, 10413, 104);
INSERT INTO "e-izin"."AtikKod" VALUES ('992c449b-addd-4034-b56d-0ce370c517c9', '2023-07-24 11:06:19.246299', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olmayan atıklar', NULL, '33e02f8e-69f7-4898-bae5-35e162129f2c', '180203', false, false, NULL, 180203, 1802);
INSERT INTO "e-izin"."AtikKod" VALUES ('99660b13-e078-49aa-9900-571ce324b542', '2023-07-24 11:06:19.24421', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '18 02 07 dışındaki ilaçlar', NULL, '33e02f8e-69f7-4898-bae5-35e162129f2c', '180208', false, false, NULL, 180208, 1802);
INSERT INTO "e-izin"."AtikKod" VALUES ('998cb024-a330-4261-8574-c327f5f7db98', '2023-07-24 11:06:19.282556', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '15 02 02 dışındaki emiciler, filtre malzemeleri, temizleme bezleri, koruyucu giysiler', NULL, '1d2fe472-acf4-44a7-8b21-07f15e6c3fd5', '150203', false, false, NULL, 150203, 1502);
INSERT INTO "e-izin"."AtikKod" VALUES ('99910a67-bac4-4035-958b-1281ecff448a', '2023-07-24 11:06:19.226943', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli olmayan atıkların önceden karıştırılması ile oluşmuş atıklar', NULL, '23405de6-af3e-427e-9239-66d58607d7cc', '190203', false, false, NULL, 190203, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('99ab4d4b-3405-4c62-9fc3-be887e799c6f', '2023-07-24 11:06:19.231948', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kompozit malzeme atıkları (emprenye edilmiş tekstil, elastomer, plastomer)', NULL, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040209', false, false, NULL, 40209, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('99e2a66c-da85-4e5a-9a5c-8eae6f302ea3', '2023-07-24 11:06:19.281477', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren sondaj çamurları ve diğer sondaj atıkları', 1, 'a3b7fef0-d9d1-4326-9622-3497df5170aa', '010506', true, true, NULL, 10506, 105);
INSERT INTO "e-izin"."AtikKod" VALUES ('99f9412c-aa9a-468c-a8ec-84461371ea06', '2023-07-24 11:06:19.246714', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren uçucu kül', 1, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190113', true, true, NULL, 190113, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('9a8e0d0d-2fba-4c2b-8535-23c2b0a5cf38', '2023-07-24 11:06:19.229775', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '13 03 01 dışındaki mineral esaslı klor içeren yalıtım ve ısı iletim yağları', 2, '0616d181-bdb8-454f-af80-0a765b0d6086', '130306', true, true, true, 130306, 1303);
INSERT INTO "e-izin"."AtikKod" VALUES ('9ac01f69-bedf-4e49-b1c1-95cecefe87b6', '2023-07-24 11:06:19.231408', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '5b19093f-fdf5-49cb-a324-6c34b05ca258', '190699', false, false, NULL, 190699, 1906);
INSERT INTO "e-izin"."AtikKod" VALUES ('9ae57af8-3747-4c16-9697-667b0ceb32b4', '2023-07-24 11:06:19.222094', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış fraksiyonlar', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200199', false, false, NULL, 200199, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('9b24859a-69f5-4b25-818f-f09f47b20fc6', '2023-07-24 11:06:19.257913', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Maden kazılarından kaynaklanan atıklar', NULL, '0c6f2107-4c71-4bd8-8c4d-896fd6a201e9', '0101', false, true, NULL, 101, 1);
INSERT INTO "e-izin"."AtikKod" VALUES ('9b4a9745-0ef3-468b-a307-cfb8a336f464', '2023-07-24 11:06:19.140263', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kireçleme atıkları', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040102', false, false, NULL, 40102, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('9b50a83a-8dba-417e-82f8-f9019b693920', '2023-07-24 11:06:19.202246', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Perdah ve boyama atıkları', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040109', false, false, NULL, 40109, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('9bbd7fd5-64ec-4237-9c05-e3a6431af4cf', '2023-07-24 11:06:19.236537', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'a3b7fef0-d9d1-4326-9622-3497df5170aa', '010599', false, false, NULL, 10599, 105);
INSERT INTO "e-izin"."AtikKod" VALUES ('9bf26d1d-11c2-4802-b98f-857b1df3f7b1', '2023-07-24 11:06:19.235935', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 06 09 dışındaki soğutma suyu arıtma atıkları', NULL, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100610', false, false, NULL, 100610, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('9c3336a5-bce7-48ae-ae8b-191fd27d163b', '2023-07-24 11:06:19.262576', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar', 1, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101209', true, true, NULL, 101209, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('9c34ae5a-4d11-498c-98d3-8287309afe70', '2023-07-24 11:06:19.26074', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Süt ürünleri endüstrisinden kaynaklanan atıklar', NULL, 'a80a1d5d-070c-488c-bd1b-4fb2bd4b420f', '0205', false, true, NULL, 205, 2);
INSERT INTO "e-izin"."AtikKod" VALUES ('9c5dfbfa-6703-4d8a-9ece-85468591eb9a', '2023-07-24 11:06:19.214517', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı yıkama sıvıları ve ana çözeltiler', 1, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070601', true, true, NULL, 70601, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('9c76a95c-ca6d-479e-b4f0-aa9209efb91f', '2023-07-24 11:06:19.240949', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Iskarta flaks malzemeler', 1, '98beda5b-44c8-4aee-afd8-24c61d6fe067', '110504', true, true, NULL, 110504, 1105);
INSERT INTO "e-izin"."AtikKod" VALUES ('9cc50e11-fc69-4251-8217-6c46a357acd6', '2023-07-24 11:06:19.21319', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 03 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'faf9d336-4990-4298-a50a-b56af7884053', '070312', false, false, NULL, 70312, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('9d6d0767-05e6-461d-ae3a-f5ca50a6b30c', '2023-07-24 11:06:19.251726', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 08 15 dışındaki baca gazı tozu', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100816', false, false, NULL, 100816, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('9d714c27-246a-490c-96e7-8012c356285d', '2023-07-24 11:06:19.242888', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddelerin kalıntılarını içeren ya da tehlikeli maddelerle kontamine olmuş ambalajlar', 1, '8f20317c-2895-43f2-a702-b02b71336086', '150110', true, true, NULL, 150110, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('9d8e2464-d061-4f7c-ba5c-22c689ec3f33', '2023-07-24 11:06:19.232854', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer emülsiyonlar', 1, 'ffc856a2-3bb3-4047-9813-2ade31e1f019', '130802', true, true, NULL, 130802, 1308);
INSERT INTO "e-izin"."AtikKod" VALUES ('9df81f1a-18ce-4e64-a8f4-570ae39ecd6a', '2023-07-24 11:06:19.253984', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren mürekkep atıkları', 1, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080312', true, true, NULL, 80312, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('9e016858-78eb-48f9-ab79-05f24503d58b', '2023-07-24 11:06:19.212315', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer filtre kekleri ve kullanılmış absorbanlar', 1, '02890c62-fdea-4520-a830-5462e228d706', '070210', true, true, NULL, 70210, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('9e1aab66-2955-4f91-b492-9f84187ad44e', '2023-07-24 11:06:19.262215', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık kağıt ve kartonun hamur haline getirilmesi sırasında mekanik olarak ayrılan ıskartalar', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030307', false, false, NULL, 30307, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('9e343996-4baa-4107-8b5e-52b408651c54', '2023-07-24 11:06:19.246597', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan sulu sıvı atıklar ile diğer sulu sıvı atıkları', 1, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190106', true, true, NULL, 190106, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('9f289d70-fb00-453f-ac9d-1833adb2fb08', '2023-07-24 11:06:19.207154', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cıva içeren atıklar', 1, 'cebf823f-b311-4b88-8e34-75f22d25a1a3', '050701', true, true, NULL, 50701, 507);
INSERT INTO "e-izin"."AtikKod" VALUES ('9f686d2a-9fdd-4b3e-afcd-d33622996db2', '2023-07-24 11:06:19.232314', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma kolonlarından kaynaklanan atıklar', NULL, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050114', false, false, NULL, 50114, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('9fcf44c2-51b2-45f9-9a60-7d69db9e0076', '2023-07-24 11:06:19.25166', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Anot hurdası', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100814', false, false, NULL, 100814, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('a0065a4b-d554-4f9b-a6cc-951ca866d144', '2023-07-24 11:06:19.248338', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Doymuş ya da kullanılmış iyon değtirme reçinesi', NULL, '02ad50ac-b89e-4b16-a98e-1931776eea3b', '190905', false, false, NULL, 190905, 1909);
INSERT INTO "e-izin"."AtikKod" VALUES ('a0409021-e3ca-4143-84f8-c328b436acf7', '2023-07-24 11:06:19.202687', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tekstil Endüstrisinden Kaynaklanan Atıklar', NULL, '7bcb6da6-43d2-4336-b3c2-782f2c599e74', '0402', false, true, NULL, 402, 4);
INSERT INTO "e-izin"."AtikKod" VALUES ('a04134a4-40a7-4f51-a737-f5eb313527b9', '2023-07-24 11:06:19.236657', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yıkama, temizleme, soyma, santrifüj ve ayırma işlemlerinden kaynaklanan çamurlar', NULL, '88e7ece3-789d-4b74-bc19-403a3f91dd79', '020301', false, false, NULL, 20301, 203);
INSERT INTO "e-izin"."AtikKod" VALUES ('a07474a3-95fb-401c-bb3d-c3802d5fa3e3', '2023-07-24 11:06:19.274202', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerle kontamine olmuş ahşap, cam ve plastik', 1, '5f698a7c-9552-4587-8c62-7c644edb7a9f', '170204', true, true, NULL, 170204, 1702);
INSERT INTO "e-izin"."AtikKod" VALUES ('a08c5fb5-3bbd-41fd-8615-137edf308041', '2023-07-24 11:06:19.281656', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ayrı toplanmış ve saha dışında işlem görecek hayvan pislikleri, idrar ve tezek (pisletilmiş saman dahil), akan sıvılar', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020106', false, false, NULL, 20106, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('a098f518-8267-4f25-9368-378fedb952a2', '2023-07-24 11:06:19.252756', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Partiküller ve toz', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101105', false, false, NULL, 101105, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('a0cd50e6-460f-406f-a27c-07d2e27630d4', '2023-07-24 11:06:19.228377', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tavlama İşlemleri Çamurları ve Katı Maddeleri', NULL, 'ef717c0c-06e1-4ee0-bb46-b5d04f58e738', '1103', false, true, NULL, 1103, 11);
INSERT INTO "e-izin"."AtikKod" VALUES ('a0d1844c-7814-4c81-bdf7-50868a7a47db', '2023-07-24 11:06:19.22856', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çinko külü', NULL, '98beda5b-44c8-4aee-afd8-24c61d6fe067', '110502', false, false, NULL, 110502, 1105);
INSERT INTO "e-izin"."AtikKod" VALUES ('a109e0c7-3bf5-48ce-ad0e-0dff01bb99f5', '2023-07-24 11:06:19.213262', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'faf9d336-4990-4298-a50a-b56af7884053', '070399', false, false, NULL, 70399, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('a1514b50-cd94-49e1-b4d8-e5a7fe6e5915', '2023-07-24 11:06:19.235693', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '070699', false, false, NULL, 70699, 706);
INSERT INTO "e-izin"."AtikKod" VALUES ('a15cc33d-3431-4ed3-8346-d4367fcd10ca', '2023-07-24 11:06:19.263124', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 13 09 ve 10 13 10 dışındaki çimento bazlı kompozit malzeme üretim atıkları', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101311', false, false, NULL, 101311, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('a1f19cf9-89d2-4463-bc30-450854318601', '2023-07-24 11:06:19.277523', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 01 15 dışındaki boya ve vernik içeren sulu çamurlar', NULL, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080116', false, false, NULL, 80116, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('a2a97e3e-5768-4b2c-87c8-a420fbb484fa', '2023-07-24 11:06:19.27553', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Doymuş ya da kullanılmış iyon değiştirici reçineler', 1, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190806', true, true, NULL, 190806, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('a2f08c30-c005-4ea4-8af9-5636162acf52', '2023-07-24 11:06:19.245049', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bakır, bronz, pirinç', NULL, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170401', false, false, NULL, 170401, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('a30075cd-2aba-48e8-ade1-623b706d962d', '2023-07-24 11:06:19.224429', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 04 11 dışındaki yapışkan ve dolgu macunu çamurları', NULL, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080412', false, false, NULL, 80412, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('a34bf048-cf54-4aaa-b5eb-b73c49047f9d', '2023-07-24 11:06:19.272861', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 03 21 dışındaki partiküller ve tozlar (öğütücü değirmen tozu dahil)', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100322', false, false, NULL, 100322, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('a3af8c2f-8acd-4085-b955-535447195c62', '2023-07-24 11:06:19.26376', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '11 01 11 dışındaki sulu durulama sıvıları', NULL, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110112', false, false, NULL, 110112, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('a3b7fef0-d9d1-4326-9622-3497df5170aa', '2023-07-24 11:06:19.258902', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sondaj Çamurları ve Diğer Sondaj Atıkları', NULL, '0c6f2107-4c71-4bd8-8c4d-896fd6a201e9', '0105', false, true, NULL, 105, 1);
INSERT INTO "e-izin"."AtikKod" VALUES ('a3d49603-72b4-48d2-a6bb-11dfa52f9dae', '2023-07-24 11:06:19.225062', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kurşunlu piller', 2, 'ffee3666-7a2b-4281-8460-44408303217f', '160601', true, true, NULL, 160601, 1606);
INSERT INTO "e-izin"."AtikKod" VALUES ('a3f8585c-d01f-433c-ab79-f62cd0c31b27', '2023-07-24 11:06:19.256389', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 01 22 dışındaki kazan temizlemesi sonucu çıkan sulu çamurlar', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100123', false, false, NULL, 100123, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('a4237930-8c7f-41de-815a-99da86578648', '2023-07-24 11:06:19.268358', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yakıtların bazlarla temizlenmesinden kaynaklanan atıklar', 1, 'ba215c7c-63f3-4bf9-b825-30f754e8d40c', '191104', true, true, NULL, 191104, 1911);
INSERT INTO "e-izin"."AtikKod" VALUES ('a42ea499-a4fb-4178-ae7c-20c0360d1790', '2023-07-24 11:06:19.25631', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kazan temizlemesi sonucu çıkan tehlikeli maddeler içeren sulu çamurlar', 1, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100122', true, true, NULL, 100122, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('b9a9370e-4b5c-4342-acf4-5ae4ac2897cd', '2023-07-24 11:06:19.21807', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Biyolojik olarak bozunamayan diğer atıklar', NULL, 'f850dc94-1624-44dd-a771-e537933cd4fd', '200203', false, false, NULL, 200203, 2002);
INSERT INTO "e-izin"."AtikKod" VALUES ('a484c1e1-2691-4bfd-ad70-2d692777815e', '2023-07-24 11:06:19.232254', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '05 01 09 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050110', false, false, NULL, 50110, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('a49c6dfc-fb8c-4d0d-afa7-402aee825c12', '2023-07-24 11:06:19.209906', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağır metal içeren metal oksitler', 1, '5dc8194f-2de7-4707-8fcb-ffac8a0ea72a', '060315', true, true, NULL, 60315, 603);
INSERT INTO "e-izin"."AtikKod" VALUES ('a4ac2453-cff1-439e-ba5a-6249416b0c23', '2023-07-24 11:06:19.216736', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100399', false, false, NULL, 100399, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('a5302fba-59fb-4336-9c10-c674bce536f7', '2023-07-24 11:06:19.256967', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer çamurlar ve filtre kekleri', NULL, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100215', false, false, NULL, 100215, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('a53f3f80-fa72-4922-8406-74fe65cc7fd1', '2023-07-24 11:06:19.276087', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, '0058b96b-d695-4095-a185-132f753311cc', '070104', true, true, NULL, 70104, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('a5707b80-40a3-462c-9c05-c8d9deb67bb3', '2023-07-24 11:06:19.20413', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Petrol döküntüleri', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050105', true, true, NULL, 50105, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('a5a072cf-9fd8-431e-8dbf-c19ad80ed2ea', '2023-07-24 11:06:19.26466', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 02 14 dışındaki katkı maddelerinin atıkları', NULL, '02890c62-fdea-4520-a830-5462e228d706', '070215', false, false, NULL, 70215, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('a5ae63b7-bebe-4d53-9df9-e121f2aa83bb', '2023-07-24 11:06:19.252213', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 09 13 dışındaki atık bağlayıcılar', NULL, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100914', false, false, NULL, 100914, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('a5b9a7a9-132b-486b-9a3e-1d6ee018c33c', '2023-07-24 11:06:19.206368', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050199', false, false, NULL, 50199, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('a5fd185e-f653-4d89-a4af-e57768e3e6c3', '2023-07-24 11:06:19.245346', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ, katran ve diğer tehlikeli maddeler içeren kablolar', 1, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170410', true, true, NULL, 170410, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('a6394de0-7922-4769-b52a-6f65a56396fa', '2023-07-24 11:06:19.283579', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir dışı metal toz ve parçacıklar', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120104', false, false, NULL, 120104, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('a714e160-340e-4bdd-9717-d1e7b145c44c', '2023-07-24 11:06:19.228991', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojen içeren işleme emülsiyon ve solüsyonları', 1, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120108', true, true, NULL, 120108, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('a776be47-707f-4800-b6b1-7649e1a9637c', '2023-07-24 11:06:19.213048', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer dip tortusu ve reaksiyon kalıntıları', 1, 'faf9d336-4990-4298-a50a-b56af7884053', '070308', true, true, NULL, 70308, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('a7d0bb07-0e29-4f9c-a649-8ed423bbc729', '2023-07-24 11:06:19.284009', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalik cıva', NULL, 'fb657553-47ba-4711-84af-b13e3c533180', '160307', true, true, NULL, 160307, 1603);
INSERT INTO "e-izin"."AtikKod" VALUES ('a80a1d5d-070c-488c-bd1b-4fb2bd4b420f', '2023-07-24 11:06:19.259172', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'TARIM, BAHÇIVANLIK, SU KÜLTÜRÜ, ORMANCILIK, AVCILIK VE BALIKÇILIK, GIDA HAZIRLAMA VE İŞLEMEDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '02', false, true, NULL, 2, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('a84fa79c-4520-4377-9832-60d9c6b8944c', '2023-07-24 11:06:19.226375', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Doymuş ya da bitik iyon değişim reçineleri', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110116', true, true, NULL, 110116, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('a878c9dd-b13f-4fc1-b6ff-2835aabec9a8', '2023-07-24 11:06:19.232136', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040299', false, false, NULL, 40299, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('a8cde6dc-2d7f-4274-9202-f87a6295acb4', '2023-07-24 11:06:19.247193', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 02 08 ve 19 02 09 dışında yanabilir atıklar', NULL, '23405de6-af3e-427e-9239-66d58607d7cc', '190210', false, false, NULL, 190210, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('a9314e62-c2b7-4172-818f-472026aa5f1e', '2023-07-24 11:06:19.244754', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cam', NULL, '5f698a7c-9552-4587-8c62-7c644edb7a9f', '170202', false, false, NULL, 170202, 1702);
INSERT INTO "e-izin"."AtikKod" VALUES ('a985ac97-f87d-431c-8d87-ae27477767a1', '2023-07-24 11:06:19.279508', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baskı Mürekkeplerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, '65eda575-b204-412b-8918-dbac781a630c', '0803', false, true, NULL, 803, 8);
INSERT INTO "e-izin"."AtikKod" VALUES ('a9bb7269-26de-442f-a142-5ba66e643510', '2023-07-24 11:06:19.277276', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', 1, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070709', true, true, NULL, 70709, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('a9cd2bf0-3ae2-445b-b8d0-0bb09751ef1a', '2023-07-24 11:06:19.226104', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sülfürlü cevherlerin işlenmesinden kaynaklanan asit üretici maden atıkları', 1, '1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '010304', true, true, NULL, 10304, 103);
INSERT INTO "e-izin"."AtikKod" VALUES ('aa1a9ee8-2718-48c8-bb7d-8a50e3aeba47', '2023-07-24 11:06:19.253479', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Seramik malzemeler içeren sulu  çamurlar', NULL, '26fffbdb-1704-425d-ad2f-db6201225ac0', '080202', false, false, NULL, 80202, 802);
INSERT INTO "e-izin"."AtikKod" VALUES ('aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '2023-07-24 11:06:19.280629', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Alüminyum Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1003', false, true, NULL, 1003, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('aa42a16d-7e31-4329-ad82-ae6966aa9037', '2023-07-24 11:06:19.215477', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli dip tortusu ve reaksiyon kalıntıları', 1, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070707', true, true, NULL, 70707, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('aa567653-28b3-41bd-9794-9de4d30ea2a2', '2023-07-24 11:06:19.273158', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir metal çapakları ve talaşları', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120101', false, false, NULL, 120101, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('aaab18c1-bbc0-4742-a5f1-3931de5c4d30', '2023-07-24 11:06:19.243909', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fosforik asit içeren bitik katalizörler', 1, '927df4de-1098-43b7-a071-8c1877c8b691', '160805', true, true, NULL, 160805, 1608);
INSERT INTO "e-izin"."AtikKod" VALUES ('aaaec103-ca52-40ef-a5a7-0bb7ae0851ca', '2023-07-24 11:06:19.250521', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı tozu', 1, '3b4a20a2-c147-4b99-b9bb-750194453116', '100503', true, true, NULL, 100503, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('ab1afe92-04ad-4f5c-8337-b24f78fc403d', '2023-07-24 11:06:19.249743', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 09 11 dışındaki diğer partiküller', NULL, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100912', false, false, NULL, 100912, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('ab727ee8-0d7a-4a26-92d2-e3c5c8cd78e6', '2023-07-24 11:06:19.268096', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir ve çelik atıkları', NULL, '87472e6e-58cd-47da-8f27-282cbb95f77b', '191001', false, false, NULL, 191001, 1910);
INSERT INTO "e-izin"."AtikKod" VALUES ('abb7ffe4-3b75-4050-997a-5f506c5956d5', '2023-07-24 11:06:19.263399', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış asitler', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110106', true, true, NULL, 110106, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('abf2b7fc-a1d5-46d1-b002-ac43366c6ff8', '2023-07-24 11:06:19.247434', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Vitrifiye olmamış katılar', 1, '7f1f469e-1575-4540-b427-5f91228fad9d', '190403', true, true, NULL, 190403, 1904);
INSERT INTO "e-izin"."AtikKod" VALUES ('ac1f5a91-f4d2-4618-bca7-47d154396dd5', '2023-07-24 11:06:19.252393', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Döküm yapılmış tehlikeli madde içeren maça ve kum döküm kalıpları', 1, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101007', true, true, NULL, 101007, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('ac520412-f67b-4c72-93e5-a522dc553835', '2023-07-24 11:06:19.233273', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kağıt ve karton ambalaj', NULL, '8f20317c-2895-43f2-a702-b02b71336086', '150101', false, false, NULL, 150101, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('ad6be7b2-5093-4fb6-9380-1856067a2da9', '2023-07-24 11:06:19.209388', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer bazlar', 1, '0c74ab22-30b7-44fd-8a78-91dc30bf4f41', '060205', true, true, NULL, 60205, 602);
INSERT INTO "e-izin"."AtikKod" VALUES ('addda9d9-d381-4cc3-920f-4bfcc7f2e3ac', '2023-07-24 11:06:19.254992', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080499', false, false, NULL, 80499, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('adf01153-874d-4e40-92c0-6a7b3756a185', '2023-07-24 11:06:19.231226', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asbest içeren yalıtım malzemeleri', 1, 'b6620d4c-259c-4452-9220-fc612f8b6e32', '170601', true, true, NULL, 170601, 1706);
INSERT INTO "e-izin"."AtikKod" VALUES ('ae2c97b6-7025-4bcd-a883-b9235b8fffd0', '2023-07-24 11:06:19.245523', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 05 05 dışındaki dip tarama çamuru', NULL, '8c13d02a-936e-4a93-8508-8207af2c45d4', '170506', false, false, NULL, 170506, 1705);
INSERT INTO "e-izin"."AtikKod" VALUES ('ae668c0c-6a2b-4dc4-904c-304b5fc2f2fb', '2023-07-24 11:06:19.2349', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mühimmat Atığı', 1, 'f8e2cc9c-b5d7-4b2a-8cf8-c1dba53e6432', '160401', true, true, NULL, 160401, 1604);
INSERT INTO "e-izin"."AtikKod" VALUES ('aeb00ca7-3013-4780-b84d-afafc44eb791', '2023-07-24 11:06:19.259082', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 05 05 ve 01 05 06 dışındaki barit içeren sondaj çamurları ve atıkları', NULL, 'a3b7fef0-d9d1-4326-9622-3497df5170aa', '010507', false, false, NULL, 10507, 105);
INSERT INTO "e-izin"."AtikKod" VALUES ('aeb1a183-f3cc-4f8e-b8cc-efdf29c8ce3f', '2023-07-24 11:06:19.214288', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 05 13 dışındaki katı atıklar', NULL, 'ec91af60-1678-4b87-bba9-743705a039fd', '070514', false, false, NULL, 70514, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('aed5b611-51e8-4320-aab1-fd0a629b0755', '2023-07-24 11:06:19.273353', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 01 11 dışındaki fren balataları', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160112', false, false, NULL, 160112, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('aeeab175-8c0d-4929-bf8c-8b943221429e', '2023-07-24 11:06:19.221095', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160199', false, false, NULL, 160199, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('af2145e9-4a7c-4419-9b01-077ff6232f32', '2023-07-24 11:06:19.236839', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atık su arıtımından kaynaklanan çamur', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101213', false, false, NULL, 101213, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('af6a9f04-c098-4aab-ba10-ef2ca6b2f045', '2023-07-24 11:06:19.244633', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 01 06 dışındaki beton, tuğla kiremit ve seramik karışımları ya da ayrılmış grupları', NULL, 'b4c53dbe-7b9e-4d04-9339-95da478bd659', '170107', false, false, NULL, 170107, 1701);
INSERT INTO "e-izin"."AtikKod" VALUES ('af78ea0c-f202-4479-8c09-64f363f57879', '2023-07-24 11:06:19.212168', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, '02890c62-fdea-4520-a830-5462e228d706', '070204', true, true, NULL, 70204, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('afd81d7d-1db3-42cc-acb9-3ce01803e239', '2023-07-24 11:06:19.256', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sülfürik asit', 1, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100109', true, true, NULL, 100109, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('b00faf75-9b57-4800-973e-6608b642da81', '2023-07-24 11:06:19.236718', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, '0992b899-80a5-429f-b40d-b28c7ecd3504', '020603', false, false, NULL, 20603, 206);
INSERT INTO "e-izin"."AtikKod" VALUES ('b07f7db9-ce00-454d-b679-bd36ee9b5e25', '2023-07-24 11:06:19.251601', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Anot üretiminden kaynaklanan katran içeren atıklar', 1, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100812', true, true, NULL, 100812, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('b0cc3c6b-4a15-4b53-9183-a7e99c8e74d9', '2023-07-24 11:06:19.252696', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cam elyaf atıkları', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101103', false, false, NULL, 101103, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('b0d7ba3a-be54-4d01-a5f7-ff6d0dcbbd03', '2023-07-24 11:06:19.258539', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 04 07 dışındaki atık kaya ve çakıl taşı atıkları', NULL, '2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '010408', false, false, NULL, 10408, 104);
INSERT INTO "e-izin"."AtikKod" VALUES ('b140f0dc-5c7d-4e83-bd7d-3525be94cd65', '2023-07-24 11:06:19.258348', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '010399', false, false, NULL, 10399, 103);
INSERT INTO "e-izin"."AtikKod" VALUES ('b149d2d3-4bf3-4651-b995-2e3b2b610f50', '2023-07-24 11:06:19.224567', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 03 07 dışındaki diğer tozumsu ve pudramsı atıklar', NULL, '1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '010308', false, false, NULL, 10308, 103);
INSERT INTO "e-izin"."AtikKod" VALUES ('b1afa02e-7b46-4989-90f4-d3aff61daa63', '2023-07-24 11:06:19.235874', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '3b4a20a2-c147-4b99-b9bb-750194453116', '100599', false, false, NULL, 100599, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '2023-07-24 11:06:19.281596', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tarım, Bahçıvanlık, Su Ürünleri Üretimi, Ormancılık, Avcılık ve Balıkçılıktan Kaynaklanan Atıklar', NULL, 'a80a1d5d-070c-488c-bd1b-4fb2bd4b420f', '0201', false, true, NULL, 201, 2);
INSERT INTO "e-izin"."AtikKod" VALUES ('b1cbe509-23c5-45f7-b3ef-17c4a24808ef', '2023-07-24 11:06:19.227454', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli dip tortusu ve reaksiyon kalıntıları', 1, '0058b96b-d695-4095-a185-132f753311cc', '070107', true, true, NULL, 70107, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('b1fee3d9-b8d8-44c8-9ff4-a98cfaa7cc36', '2023-07-24 11:06:19.276461', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 02 16 dışında zararlı silikon içeren atıklar', NULL, '02890c62-fdea-4520-a830-5462e228d706', '070217', false, false, NULL, 70217, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('b243c2b9-5f06-437a-afae-3559046eccf6', '2023-07-24 11:06:19.278413', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar', 1, 'e67297f9-9141-4cd9-ac88-e58d52bc88c9', '100707', true, true, NULL, 100707, 1007);
INSERT INTO "e-izin"."AtikKod" VALUES ('b2894e2f-215c-4fa4-b121-ecea79a46e1f', '2023-07-24 11:06:19.262301', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '03 03 10 dışındaki saha içi atık su arıtımından kaynaklanan çamurlar', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030311', false, false, NULL, 30311, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('b2d54aa7-a4fd-4645-994e-36c54773b037', '2023-07-24 11:06:19.275219', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '5ac0adf7-291d-40f1-abf0-c8243f75abf5', '190599', false, false, NULL, 190599, 1905);
INSERT INTO "e-izin"."AtikKod" VALUES ('b30aeb3d-69a4-4d30-9762-ef49d8a370ff', '2023-07-24 11:06:19.232433', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma kolonlarından kaynaklanan atıklar', NULL, '07a8b9c4-da35-4838-86e3-a340636a4aa7', '050604', false, false, NULL, 50604, 506);
INSERT INTO "e-izin"."AtikKod" VALUES ('b30f1cb6-d698-40b7-80e4-f6c7fc8d1756', '2023-07-24 11:06:19.231468', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ağır metaller içeren membran sistemi atıkları', 1, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190808', true, true, NULL, 190808, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('b3256521-985a-4cf5-a5e6-b513a8205f58', '2023-07-24 11:06:19.281297', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 04 07 dışındaki tozumsu ve pudramsı atıklar', NULL, '2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '010410', false, false, NULL, 10410, 104);
INSERT INTO "e-izin"."AtikKod" VALUES ('b3625bfe-8fbf-4c82-b6b2-159f776b2e9e', '2023-07-24 11:06:19.247802', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren düzenli depolama sahası sızıntı suları', 1, '6e1255cb-10b7-4151-94d4-92eb6bc0ecc5', '190702', true, true, NULL, 190702, 1907);
INSERT INTO "e-izin"."AtikKod" VALUES ('b37c3d4c-60be-4f29-ad8b-57ab2ca23366', '2023-07-24 11:06:19.242768', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'ATIK AMBALAJLAR; BAŞKA BİR ŞEKİLDE BELİRTİLMEMİŞ EMİCİLER, SİLME BEZLERİ, FİLTRE MALZEMELERİ VE KORUYUCU GİYSİLER', NULL, NULL, '15', false, true, NULL, 15, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('b38f6fa9-4f57-4a05-a648-90d2bfd3d097', '2023-07-24 11:06:19.250167', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tekstil ürünleri', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200111', false, false, NULL, 200111, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('b390822c-452b-4f4a-a3f4-a068be5c24dd', '2023-07-24 11:06:19.22515', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren sulu sıvı atıklar', 1, 'cc572c1d-1fa6-4c3b-b648-74bff3176f98', '161001', true, true, NULL, 161001, 1610);
INSERT INTO "e-izin"."AtikKod" VALUES ('b3aee07f-0c76-4150-95e4-500bd0d25c26', '2023-07-24 11:06:19.224925', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer yakıtlar (karışımlar dahil)', 1, '7b8d483e-9d6f-4f7e-80da-7676fdcfd941', '130703', true, true, NULL, 130703, 1307);
INSERT INTO "e-izin"."AtikKod" VALUES ('b3e90732-2c2a-48a3-a6a6-cf57de7bb15e', '2023-07-24 11:06:19.253061', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101199', false, false, NULL, 101199, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('b3f112ef-4a99-4981-82b8-4c034e0f8414', '2023-07-24 11:06:19.219947', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '9c34ae5a-4d11-498c-98d3-8287309afe70', '020599', false, false, NULL, 20599, 205);
INSERT INTO "e-izin"."AtikKod" VALUES ('b498c9fb-152d-46e2-a90f-ce92692601e8', '2023-07-24 11:06:19.242264', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ/su ayırıcısından çıkan çamurlar', 1, '7b1f3519-e16b-445c-b927-d70255f332d9', '130502', true, true, NULL, 130502, 1305);
INSERT INTO "e-izin"."AtikKod" VALUES ('b49feb56-f99a-4190-9f58-55c53fd0a4d2', '2023-07-24 11:06:19.225201', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren demiryolu çakılı', 1, '8c13d02a-936e-4a93-8508-8207af2c45d4', '170507', true, true, NULL, 170507, 1705);
INSERT INTO "e-izin"."AtikKod" VALUES ('b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '2023-07-24 11:06:19.280061', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Enerji Santrallerinden ve Diğer Yakma Tesislerinden Kaynaklanan Atıklar (19 Hariç)', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1001', false, true, NULL, 1001, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('b4c53dbe-7b9e-4d04-9339-95da478bd659', '2023-07-24 11:06:19.273999', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Beton, Tuğla, Kiremit ve Seramik', NULL, 'c4d6b5a4-b326-453e-a375-286212bd4d29', '1701', false, true, NULL, 1701, 17);
INSERT INTO "e-izin"."AtikKod" VALUES ('b4deb956-86c7-4c00-bf3b-85cad48b00e3', '2023-07-24 11:06:19.26015', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Koruyucu katkı maddelerinden kaynaklanan atıklar', NULL, '88e7ece3-789d-4b74-bc19-403a3f91dd79', '020302', false, false, NULL, 20302, 203);
INSERT INTO "e-izin"."AtikKod" VALUES ('b4e9515a-1306-47ec-9400-e610a91ea330', '2023-07-24 11:06:19.221219', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Katalizör olarak bitik sıvılar', 1, '927df4de-1098-43b7-a071-8c1877c8b691', '160806', true, true, NULL, 160806, 1608);
INSERT INTO "e-izin"."AtikKod" VALUES ('b5574e10-9d4e-4880-aaac-ca0de472afa7', '2023-07-24 11:06:19.282438', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren kumlama maddeleri atıkları', 1, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120116', true, true, NULL, 120116, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('b5578f7f-42c8-42bc-8f8c-054e4d7a5108', '2023-07-24 11:06:19.249564', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Toprak ıslahından kaynaklanan tehlikeli maddeler içeren atıklar', 1, '3c8d5e7a-e867-402f-b518-a5cafa387f07', '191301', true, true, NULL, 191301, 1913);
INSERT INTO "e-izin"."AtikKod" VALUES ('b5ea42af-0b97-4078-b13a-7cc28ec1226f', '2023-07-24 11:06:19.245168', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kurşun', NULL, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170403', false, false, NULL, 170403, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('b62f9dc2-d8f7-48fc-a125-a85552e13db6', '2023-07-24 11:06:19.254587', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren atık yapışkanlar ve dolgu macunları', 1, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080409', true, true, NULL, 80409, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('b64cfdf4-9349-4719-9c1b-aed3185e087f', '2023-07-24 11:06:19.274379', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddelerle kontamine olmuş metal atıkları', 1, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170409', true, true, NULL, 170409, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('b6620d4c-259c-4452-9220-fc612f8b6e32', '2023-07-24 11:06:19.269413', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yalıtım Malzemeleri ve Asbest İçeren İnşaat Malzemeleri', NULL, 'c4d6b5a4-b326-453e-a375-286212bd4d29', '1706', false, true, NULL, 1706, 17);
INSERT INTO "e-izin"."AtikKod" VALUES ('b6c369e7-37d9-4842-b192-5a88ca4008b8', '2023-07-24 11:06:19.258261', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 03 04 ve 01 03 05 dışındaki diğer maden atıkları', NULL, '1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '010306', false, false, NULL, 10306, 103);
INSERT INTO "e-izin"."AtikKod" VALUES ('b74d2187-431f-434b-9d84-2931b8fccb0f', '2023-07-24 11:06:19.23073', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren antifriz sıvıları', 1, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160114', true, true, NULL, 160114, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('b7c7b725-6053-4d5d-ab72-0c262314bf27', '2023-07-24 11:06:19.247682', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hayvansal ve bitkisel atıkların anaerobik arıtımından kaynaklanan sıvılar', NULL, '5b19093f-fdf5-49cb-a324-6c34b05ca258', '190605', false, false, NULL, 190605, 1906);
INSERT INTO "e-izin"."AtikKod" VALUES ('b82f5c31-b665-4e83-90a8-860ccc1960a6', '2023-07-24 11:06:19.266012', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Basınçlı tanklar içinde tehlikeli maddeler içeren gazlar (halonlar dahil)', 1, 'd1a799b4-e386-4588-ade4-462395e2d1a5', '160504', true, true, NULL, 160504, 1605);
INSERT INTO "e-izin"."AtikKod" VALUES ('b831b592-f284-4169-b162-a7820f0b854f', '2023-07-24 11:06:19.203373', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '04 02 16 dışındaki boya maddeleri ve pigmentler', NULL, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040217', false, false, NULL, 40217, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('b84ec42b-78a0-44f4-8f30-41a1635580a1', '2023-07-24 11:06:19.279628', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080399', false, false, NULL, 80399, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('b8c23e2c-72c6-48aa-b860-67814e72650d', '2023-07-24 11:06:19.272441', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Pazarlardan kaynaklanan atıklar', NULL, '0c2d44f6-5fee-444f-beb8-5ad3318f616a', '200302', false, false, NULL, 200302, 2003);
INSERT INTO "e-izin"."AtikKod" VALUES ('b8f60308-0317-4629-919d-ebad641f4558', '2023-07-24 11:06:19.213793', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070499', false, false, NULL, 70499, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('b9008c07-c9c7-441b-a386-cd8ac2aee26a', '2023-07-24 11:06:19.275022', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 03 06 dışındaki katılaştırılmış atıklar', NULL, '235a8557-aa28-4c06-9060-16bc23a58c6a', '190307', false, false, NULL, 190307, 1903);
INSERT INTO "e-izin"."AtikKod" VALUES ('b9117b11-00a3-47fc-9503-40430050698b', '2023-07-24 11:06:19.222932', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 05 07 dışındaki demiryolu çakılı', NULL, '8c13d02a-936e-4a93-8508-8207af2c45d4', '170508', false, false, NULL, 170508, 1705);
INSERT INTO "e-izin"."AtikKod" VALUES ('b9194cc0-ae02-4d8e-99aa-c624e5362ae7', '2023-07-24 11:06:19.263215', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101399', false, false, NULL, 101399, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '2023-07-24 11:06:19.275465', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka Bir Şekilde Tanımlanmamış Atık Su Arıtma Tesisi Atıkları', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1908', false, true, NULL, 1908, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('f696ddfc-e0f4-4c90-bd3f-12177e82b7f5', '2023-07-24 11:06:19.231826', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hacimli atıklar', NULL, '0c2d44f6-5fee-444f-beb8-5ad3318f616a', '200307', false, false, NULL, 200307, 2003);
INSERT INTO "e-izin"."AtikKod" VALUES ('b9f3a179-938b-4a60-a6a5-3fb339e24395', '2023-07-24 11:06:19.248278', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İlk filtreleme ve süzme işlemlerinden kaynaklanan katı atıklar', NULL, '02ad50ac-b89e-4b16-a98e-1931776eea3b', '190901', false, false, NULL, 190901, 1909);
INSERT INTO "e-izin"."AtikKod" VALUES ('b9f43eb8-1ba5-45cf-9d64-446b50c72fb3', '2023-07-24 11:06:19.229652', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mineral esaslı klor içermeyen motor, şanzıman ve yağlama yağları', 2, 'dff8bb04-5506-4de9-980b-42baa9dd737b', '130205', true, true, true, 130205, 1302);
INSERT INTO "e-izin"."AtikKod" VALUES ('ba1938a9-c807-4a0d-8d84-85fdee0b1bb8', '2023-07-24 11:06:19.26653', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Peroksitler(örneğin hidrojen peroksit)', 1, '9755a757-20f8-4784-8424-5135b4c3444a', '160903', true, true, NULL, 160903, 1609);
INSERT INTO "e-izin"."AtikKod" VALUES ('ba1ea34a-ce19-4565-a202-84b398d21ca7', '2023-07-24 11:06:19.216589', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 01 19 dışındaki sulu boya ya da vernik içeren sulu süspansiyonlar', NULL, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080120', false, false, NULL, 80120, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('ba215c7c-63f3-4bf9-b825-30f754e8d40c', '2023-07-24 11:06:19.248577', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağın Yeniden Üretiminden Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1911', false, true, NULL, 1911, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('ba86a37a-8392-4b66-88e7-db3ab33ba49e', '2023-07-24 11:06:19.248517', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir olmayan atıklar', NULL, '87472e6e-58cd-47da-8f27-282cbb95f77b', '191002', false, false, NULL, 191002, 1910);
INSERT INTO "e-izin"."AtikKod" VALUES ('baacffba-cf00-4784-9d58-cb6b5f27879e', '2023-07-24 11:06:19.283054', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 03 27 dışındaki soğutma suyu arıtma atıkları', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100328', false, false, NULL, 100328, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('bae3c111-8d6e-4b2e-84c5-836df7fcbb46', '2023-07-24 11:06:19.233333', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Plastik ambalaj', NULL, '8f20317c-2895-43f2-a702-b02b71336086', '150102', false, false, NULL, 150102, 1501);
INSERT INTO "e-izin"."AtikKod" VALUES ('bb381bcb-7a30-4fed-8729-98760b99a5ed', '2023-07-24 11:06:19.244147', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 10 01 dışındaki sulu sıvı atıklar', NULL, 'cc572c1d-1fa6-4c3b-b648-74bff3176f98', '161002', false, false, NULL, 161002, 1610);
INSERT INTO "e-izin"."AtikKod" VALUES ('bb73ae78-c3d8-4a6b-937e-771e9da71f48', '2023-07-24 11:06:19.216069', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren atık boya ve vernikler', 1, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080111', true, true, NULL, 80111, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('bbd31e56-da1c-4184-ba7a-b4dc4a930308', '2023-07-24 11:06:19.232194', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tuz arındırma(tuz giderici) çamurları', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050102', true, true, NULL, 50102, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('bbdc929f-3a02-4e11-94e2-9789670a05c9', '2023-07-24 11:06:19.212869', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı yıkama sıvıları ve ana çözeltiler', 1, 'faf9d336-4990-4298-a50a-b56af7884053', '070301', true, true, NULL, 70301, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('bc093307-83e3-4a87-9005-e74137eac2a3', '2023-07-24 11:06:19.266414', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış ara metaller ve ara metal bileşenleri içeren bitik katalizörler', NULL, '927df4de-1098-43b7-a071-8c1877c8b691', '160803', false, false, NULL, 160803, 1608);
INSERT INTO "e-izin"."AtikKod" VALUES ('bc3a232f-5220-4e15-9789-70ec822f7802', '2023-07-24 11:06:19.247011', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'En az bir tehlikeli atık ile önceden karıştırılması ile oluşmuş atıklar', 1, '23405de6-af3e-427e-9239-66d58607d7cc', '190204', true, true, NULL, 190204, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('bc97ede3-7cef-4cfe-81b8-e550529db923', '2023-07-24 11:06:19.281777', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı yıkama sıvıları ve ana çözeltiler', 1, '0058b96b-d695-4095-a185-132f753311cc', '070101', true, true, NULL, 70101, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('bc992f18-f517-46ea-af4e-369471fc5df5', '2023-07-24 11:06:19.243425', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer piller ve akümülatörler', 2, 'ffee3666-7a2b-4281-8460-44408303217f', '160605', false, false, NULL, 160605, 1606);
INSERT INTO "e-izin"."AtikKod" VALUES ('bccbab2f-2865-4d68-b56d-9cdea1f8ad5d', '2023-07-24 11:06:19.278538', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir cüruf ve köpükler', 1, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100810', true, true, NULL, 100810, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('bd6e4114-c05a-48e3-93ec-0a55cd9c9214', '2023-07-24 11:06:19.244513', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Beton', NULL, 'b4c53dbe-7b9e-4d04-9339-95da478bd659', '170101', false, false, NULL, 170101, 1701);
INSERT INTO "e-izin"."AtikKod" VALUES ('bdc0fa9f-01fc-4154-9de0-a494b82e930d', '2023-07-24 11:06:19.213472', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070404', true, true, NULL, 70404, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '2023-07-24 11:06:19.262032', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kağıt hamuru, kağıt ve kağıt karton üretim ve işlenmesinden kaynaklanan atıklar', NULL, '027982e3-1975-4831-91be-f45bce694965', '0303', false, true, NULL, 303, 3);
INSERT INTO "e-izin"."AtikKod" VALUES ('be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '2023-07-24 11:06:19.243008', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çeşitli Taşıma Türlerindeki (İş Makineleri Dahil) Ömrünü Tamamlamış Araçlar ve Ömrünü Tamamlamış Araçların Sökülmesi ile Araç Bakımından (13, 14, 16 06 ve 16 08 hariç) Kaynaklanan Atıklar', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1601', false, true, NULL, 1601, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('be1265ae-7418-4002-9248-7deceddaf19c', '2023-07-24 11:06:19.26294', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Partiküller ve toz (10 13 12 ve 10 13 13 hariç)', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101306', false, false, NULL, 101306, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('be2300b0-9e19-4008-8296-9000519858c1', '2023-07-24 11:06:19.281357', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '01 04 07 ve 01 04 11 dışındaki minerallerin yıkanması ve temizlenmesinden kaynaklanan ince taneli atıklar ve diğer atıklar', NULL, '2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '010412', false, false, NULL, 10412, 104);
INSERT INTO "e-izin"."AtikKod" VALUES ('be603e7d-de1c-4c30-9286-1f3a535c6f46', '2023-07-24 11:06:19.252999', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı arıtımından kaynaklanan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', 1, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101117', true, true, NULL, 101117, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('be9fea19-dfc3-4385-b166-01f2f6bc6443', '2023-07-24 11:06:19.272166', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren ahşap', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200137', true, true, NULL, 200137, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('bf132cd6-6d13-4c1b-9f3a-95b01fabf27d', '2023-07-24 11:06:19.21049', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Elektrolizden kaynaklanan asbest içeren atıklar', 1, '254667d3-3d03-47c4-99ae-85ae4efa0b18', '060701', true, true, NULL, 60701, 607);
INSERT INTO "e-izin"."AtikKod" VALUES ('bf1d1973-bde1-4a30-babe-c49c4bae82fb', '2023-07-24 11:06:19.241332', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '12 01 16 dışındaki kumlama maddeleri atıkları', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120117', false, false, NULL, 120117, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('bf75ca42-839d-48bb-9c52-cda83c0ee6f5', '2023-07-24 11:06:19.217572', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '20 01 21, 20 01 23 ve 20 01 35 dışındaki ıskarta elektrikli ve elektronik ekipmanlar', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200136', false, false, NULL, 200136, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('bfd260fc-2f82-4d9e-97f0-730e9e161392', '2023-07-24 11:06:19.234655', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Iskarta ekipmanlardan çıkartılmış tehlikeli parçalar', 1, 'fcf7052f-6471-4238-bfd9-a9b918f118ce', '160215', true, true, NULL, 160215, 1602);
INSERT INTO "e-izin"."AtikKod" VALUES ('c0881f9d-16a8-439b-903e-ea57edabd713', '2023-07-24 11:06:19.207577', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'cebf823f-b311-4b88-8e34-75f22d25a1a3', '050799', false, false, NULL, 50799, 507);
INSERT INTO "e-izin"."AtikKod" VALUES ('c0985014-9726-4a5e-8b8f-77c5af6800cb', '2023-07-24 11:06:19.28202', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '(10 01 04?ün altındaki kazan tozu hariç) dip külü, cüruf ve kazan tozu', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100101', false, false, NULL, 100101, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('c09c4eda-50c9-4c2b-84e5-e8cb19d68c49', '2023-07-24 11:06:19.211656', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, '0058b96b-d695-4095-a185-132f753311cc', '070103', true, true, NULL, 70103, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('c0d684d6-4b3b-4576-981c-e16c55fa0100', '2023-07-24 11:06:19.264299', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren uçucu atık parçacıkları ve tozlar', 1, '87472e6e-58cd-47da-8f27-282cbb95f77b', '191003', true, true, NULL, 191003, 1910);
INSERT INTO "e-izin"."AtikKod" VALUES ('c0eade5c-13f0-4591-b067-aec5ce4b4e82', '2023-07-24 11:06:19.202913', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Doğal ürünlerden oluşan organik maddeler (örneğin yağ, mum)', NULL, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040210', false, false, NULL, 40210, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('c0f21ae6-314a-49e3-877a-ce4954d97199', '2023-07-24 11:06:19.280437', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir ve Çelik Endüstrisinden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1002', false, true, NULL, 1002, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('c11a00ea-da73-450e-a132-527d0b269245', '2023-07-24 11:06:19.250404', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100499', false, false, NULL, 100499, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('c16c834e-04eb-443b-acb2-e09d5f0d4eed', '2023-07-24 11:06:19.223654', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kalsiyum hidroksit', 1, '0c74ab22-30b7-44fd-8a78-91dc30bf4f41', '060201', true, true, NULL, 60201, 602);
INSERT INTO "e-izin"."AtikKod" VALUES ('c16e7cd1-61a2-484e-801e-fe48662ee198', '2023-07-24 11:06:19.265648', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metallerin ve Plastiklerin Fiziki ve Mekanik Yüzey İşlemlerinden ve Biçimlendirilmesinden Kaynaklanan Atıklar', NULL, 'f523a624-adf1-4c08-ac9f-9e822c12d922', '1201', false, true, NULL, 1201, 12);
INSERT INTO "e-izin"."AtikKod" VALUES ('c18c33df-29e7-4a30-84d3-d0694bc464ef', '2023-07-24 11:06:19.228074', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer atıklar', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110198', true, true, NULL, 110198, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('c1b3ab76-f4d9-4199-bc43-2917d8c6a878', '2023-07-24 11:06:19.252454', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 10 07 dışındaki döküm yapılmış maça ve kum döküm kalıpları', NULL, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101008', false, false, NULL, 101008, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('c1c4cb87-2f1c-4044-96dd-a6a8ffd871bd', '2023-07-24 11:06:19.251479', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer cüruflar', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100809', false, false, NULL, 100809, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('c2643628-f23b-4cc6-94ad-ab0d29d006e1', '2023-07-24 11:06:19.212097', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, '02890c62-fdea-4520-a830-5462e228d706', '070203', true, true, NULL, 70203, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('c284c197-3a4f-4200-96bc-ad8219fb104a', '2023-07-24 11:06:19.219824', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '88e7ece3-789d-4b74-bc19-403a3f91dd79', '020399', false, false, NULL, 20399, 203);
INSERT INTO "e-izin"."AtikKod" VALUES ('c31a0070-77df-455f-bad1-42676c4f2bc6', '2023-07-24 11:06:19.230979', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ahşap', NULL, '5f698a7c-9552-4587-8c62-7c644edb7a9f', '170201', false, false, NULL, 170201, 1702);
INSERT INTO "e-izin"."AtikKod" VALUES ('c3334db9-3cdb-49e0-9d70-7cf2730282c2', '2023-07-24 11:06:19.250225', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asitler', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200114', true, true, NULL, 200114, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('c3425e5e-630b-4df4-89d5-f7cd011de88e', '2023-07-24 11:06:19.226819', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kömür katranı ve katranlı ürünler', 1, '0679c123-9c79-4909-ba99-fa94e8d68951', '170303', true, true, NULL, 170303, 1703);
INSERT INTO "e-izin"."AtikKod" VALUES ('c344b59b-e625-4d2e-bcdf-9a5fe0a29e81', '2023-07-24 11:06:19.282855', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Uçucu kömür külü', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100102', false, false, NULL, 100102, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('c3f2e872-5b04-406f-aaf7-6f40128629be', '2023-07-24 11:06:19.279688', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yapışkanlar ve Yalıtıcıların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar (Su Geçirmeyen Ürünler Dahil)', NULL, '65eda575-b204-412b-8918-dbac781a630c', '0804', false, true, NULL, 804, 8);
INSERT INTO "e-izin"."AtikKod" VALUES ('c45b3944-e0ee-4ae1-bac6-e83cde62ccd6', '2023-07-24 11:06:19.279024', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren baca gazı tozu', 1, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101009', true, true, NULL, 101009, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('c4622483-c624-4f84-a869-e4d93ca90aeb', '2023-07-24 11:06:19.277828', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 04 09 dışındaki soğutma suyu arıtma atıkları', NULL, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100410', false, false, NULL, 100410, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('c48b7a36-d031-47d3-8f2d-9a788df9a13f', '2023-07-24 11:06:19.226627', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Serbest asbest içeren ıskarta ekipman', 1, 'fcf7052f-6471-4238-bfd9-a9b918f118ce', '160212', true, true, NULL, 160212, 1602);
INSERT INTO "e-izin"."AtikKod" VALUES ('c4d6b5a4-b326-453e-a375-286212bd4d29', '2023-07-24 11:06:19.244453', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İNŞAAT VE YIKINTI ATIKLARI (KİRLENMİŞ ALANLARDAN ÇIKARTILAN HAFRİYAT DAHİL)', NULL, NULL, '17', false, true, NULL, 17, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('c4eaf79e-246d-43f1-b94e-7449d09cdf6e', '2023-07-24 11:06:19.253738', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mürekkep içeren sulu çamurlar', NULL, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080307', false, false, NULL, 80307, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('c4f99875-3f44-42b6-9fdf-19bf4ecbe4d3', '2023-07-24 11:06:19.220089', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mekanik ayırma sonucu oluşan elyaf ıskartaları, elyaf, dolgu ve yüzey kaplama maddesi çamuru', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030310', false, false, NULL, 30310, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('c50973f8-5259-4f6f-89ea-cc26b9a491cb', '2023-07-24 11:06:19.23818', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organoklorlu ahşap koruyucu maddeler', 1, '32fa13d4-52f1-4c6e-9513-15ee2274d4c2', '030202', true, true, NULL, 30202, 302);
INSERT INTO "e-izin"."AtikKod" VALUES ('c55e0c5b-ff34-473c-97f3-4f9c33bf7d20', '2023-07-24 11:06:19.238766', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık seramikler, tuğlalar, fayanslar ve inşaat malzemeleri (ısıl işlem sonrası)', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101208', false, false, NULL, 101208, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('c575a564-c030-4b3a-9af0-e0c3f546bfd7', '2023-07-24 11:06:19.22893', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojen içermeyen madeni bazlı işleme yağları (emülsiyon ve solüsyonlar hariç)', 2, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120107', true, true, true, 120107, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('c583a290-fb05-4106-bcaf-33b338fbe2d0', '2023-07-24 11:06:19.246774', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 01 13 dışındaki uçucu kül', NULL, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190114', false, false, NULL, 190114, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('c5a6ccf7-6582-4e5e-852e-cbed4417454d', '2023-07-24 11:06:19.277764', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer partiküller ve toz', 1, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100405', true, true, NULL, 100405, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('c5a71d1f-8f94-48f2-9208-bb9028bcc45b', '2023-07-24 11:06:19.250759', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 05 10 dışındaki cüruf ve köpükler', NULL, '3b4a20a2-c147-4b99-b9bb-750194453116', '100511', false, false, NULL, 100511, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('c5aa6e5e-f6ac-4b04-890a-5b2c3c2f0c52', '2023-07-24 11:06:19.243187', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren ya da bunlardan oluşan ıskarta inorganik kimyasallar', 1, 'd1a799b4-e386-4588-ade4-462395e2d1a5', '160507', true, true, NULL, 160507, 1605);
INSERT INTO "e-izin"."AtikKod" VALUES ('c5dcb670-f8b6-4878-84c9-e70117c349ea', '2023-07-24 11:06:19.237496', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tüketime ya da işlenmeye uygun olmayan maddeler', NULL, '9c34ae5a-4d11-498c-98d3-8287309afe70', '020501', false, false, NULL, 20501, 205);
INSERT INTO "e-izin"."AtikKod" VALUES ('c5ea2314-aef9-4f68-9efa-e19675b3d041', '2023-07-24 11:06:19.225485', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren atıklar', 1, '764121c0-0bfa-4399-a0c0-a983b62115be', '061002', true, true, NULL, 61002, 610);
INSERT INTO "e-izin"."AtikKod" VALUES ('c5ed7f1b-25f3-4158-a89c-27ffbc0be1ab', '2023-07-24 11:06:19.215793', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer dip tortusu ve reaksiyon kalıntıları', 1, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070708', true, true, NULL, 70708, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('c603169b-adc8-4d37-964b-fe861dcff500', '2023-07-24 11:06:19.264752', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070511', true, true, NULL, 70511, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('c6045c26-ae63-4222-a558-daa41b4af271', '2023-07-24 11:06:19.228743', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir metal toz ve parçacıklar', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120102', false, false, NULL, 120102, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('c6818d6e-e277-4549-8e17-3c1a89e5c4f2', '2023-07-24 11:06:19.239625', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar', 1, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101312', true, true, NULL, 101312, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('c6936205-af62-4743-9249-6604b221404b', '2023-07-24 11:06:19.219649', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Klor içeren emülsiyonlar', 2, '676c52f5-81e5-4570-8135-2f3324688790', '130104', true, true, true, 130104, 1301);
INSERT INTO "e-izin"."AtikKod" VALUES ('c697218e-5610-47e3-b6b9-1891b92b3ab8', '2023-07-24 11:06:19.266144', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 05 06, 16 05 07 ya da 16 05 08 dışındaki ıskarta kimyasallar', NULL, 'd1a799b4-e386-4588-ade4-462395e2d1a5', '160509', false, false, NULL, 160509, 1605);
INSERT INTO "e-izin"."AtikKod" VALUES ('c69937d1-c4b6-4955-83d2-343b93d0b13e', '2023-07-24 11:06:19.223922', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Arsenik içeren atıklar', 1, '13b34703-1d7b-4f10-9cbb-bcf7b285c83d', '060403', true, true, NULL, 60403, 604);
INSERT INTO "e-izin"."AtikKod" VALUES ('c6cd5216-968b-4d53-b3be-f59d22243c11', '2023-07-24 11:06:19.253856', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Mürekkep içeren sulu sıvı atıklar', NULL, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080308', false, false, NULL, 80308, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('c70419f8-12b6-4cf8-a1fc-7f4c23c9267e', '2023-07-24 11:06:19.243669', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '7887dde6-0719-4ba8-b05e-8ffee0b419ea', '160799', false, false, NULL, 160799, 1607);
INSERT INTO "e-izin"."AtikKod" VALUES ('c7098fea-a5f1-4edb-8f66-86165d0bef63', '2023-07-24 11:06:19.245464', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 05 03 dışındaki toprak ve kayalar', NULL, '8c13d02a-936e-4a93-8508-8207af2c45d4', '170504', false, false, NULL, 170504, 1705);
INSERT INTO "e-izin"."AtikKod" VALUES ('c719dee7-6238-43ff-b96a-a0a6fb2e2ae5', '2023-07-24 11:06:19.249923', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kâğıt ve karton', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200101', false, false, NULL, 200101, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('c746097f-76b0-4c0f-9bc2-314e3947c853', '2023-07-24 11:06:19.23767', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Alkollü ve alkolsüz içeceklerin (kahve, çay ve kakao hariç) üretiminden kaynaklanan atıklar', NULL, 'a80a1d5d-070c-488c-bd1b-4fb2bd4b420f', '0207', false, true, NULL, 207, 2);
INSERT INTO "e-izin"."AtikKod" VALUES ('c7d99e5e-66a2-459e-9b32-b62e847a9a2a', '2023-07-24 11:06:19.259353', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bitki dokusu atıkları', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020103', false, false, NULL, 20103, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('c8162df9-369a-432a-9c36-8276ac77372f', '2023-07-24 11:06:19.216437', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernikli sulu çamurlar', 1, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080115', true, true, NULL, 80115, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('c86fac5d-9a8e-4feb-935e-322917095367', '2023-07-24 11:06:19.217773', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Plastikler', NULL, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200139', false, false, NULL, 200139, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('c8a82f97-6783-466f-836b-1773e5ff7541', '2023-07-24 11:06:19.234116', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 01 14 dışındaki antifriz sıvıları', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160115', false, false, NULL, 160115, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('c8ec43e0-d19f-4a42-a4d0-d248f8a1c655', '2023-07-24 11:06:19.210916', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '3ae124d5-a162-4d05-8d9f-25e3f41f8ff0', '060899', false, false, NULL, 60899, 608);
INSERT INTO "e-izin"."AtikKod" VALUES ('c964f4c3-7efa-49dc-8777-66441494f2d7', '2023-07-24 11:06:19.268505', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 11 05 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'ba215c7c-63f3-4bf9-b825-30f754e8d40c', '191106', false, false, NULL, 191106, 1911);
INSERT INTO "e-izin"."AtikKod" VALUES ('c97ed34e-9ff5-4beb-9b17-f506f1366cdd', '2023-07-24 11:06:19.232555', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '0c74ab22-30b7-44fd-8a78-91dc30bf4f41', '060299', false, false, NULL, 60299, 602);
INSERT INTO "e-izin"."AtikKod" VALUES ('c9a3864b-2be1-4f2a-b772-2d2466c8868c', '2023-07-24 11:06:19.276705', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik Bitki Koruma Ürünlerinin (02 01 08 ve 02 01 09 hariç), Ahşap Koruyucu Olarak Kullanılan Maddelerin ( Ajanlarının) (03 02 Hariç) ve Diğer Biositlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, '2ed155b3-66a6-455e-9b6f-f2af44d782c9', '0704', false, true, NULL, 704, 7);
INSERT INTO "e-izin"."AtikKod" VALUES ('ca3ce6c0-c430-4117-bf39-b1fb69a802fd', '2023-07-24 11:06:19.267687', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 08 13 dışındaki endüstriyel atık suyun diğer yöntemlerle arıtılmasından kaynaklanan çamurlar', NULL, 'b9a037c9-a7d5-4469-af08-7ab9dc8e855c', '190814', false, false, NULL, 190814, 1908);
INSERT INTO "e-izin"."AtikKod" VALUES ('ca7336dc-283d-41fa-beeb-a2d45a023dee', '2023-07-24 11:06:19.204896', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ içeren asitler', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050112', true, true, NULL, 50112, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('cae1d8ce-483b-42ba-b1d9-85cdc5e20826', '2023-07-24 11:06:19.273917', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 11 05 dışındaki metalürjik olmayan proseslerden kaynaklanan astar ve refraktörler', NULL, '05f219fe-21e2-4128-95eb-65b72829b3fa', '161106', false, false, NULL, 161106, 1611);
INSERT INTO "e-izin"."AtikKod" VALUES ('caed964d-80a2-4231-992b-d9e5e54cadb5', '2023-07-24 11:06:19.224296', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 10 13 dışındaki bağlayıcı atıkları', NULL, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101014', false, false, NULL, 101014, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('cbade07f-6c50-4b1c-98fc-c0b6a9e0717b', '2023-07-24 11:06:19.278782', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren baca gazı tozu', 1, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100909', true, true, NULL, 100909, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('cbc246bc-edc6-44be-93ad-e5cb72b47bd7', '2023-07-24 11:06:19.250344', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtım çamurları ve filtre kekleri', 1, 'fb948f75-4819-49ba-895d-b495f0a5e675', '100407', true, true, NULL, 100407, 1004);
INSERT INTO "e-izin"."AtikKod" VALUES ('cc0dc5e0-a93c-4109-8d2c-b16dc320fa89', '2023-07-24 11:06:19.228441', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Siyanür içeren atıklar', 1, 'a0cd50e6-460f-406f-a27c-07d2e27630d4', '110301', true, true, NULL, 110301, 1103);
INSERT INTO "e-izin"."AtikKod" VALUES ('cc572c1d-1fa6-4c3b-b648-74bff3176f98', '2023-07-24 11:06:19.266697', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha Dışı Arıtmaya Gönderilecek Sulu Sıvı Atıklar', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1610', false, true, NULL, 1610, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('cc826f83-42d5-43e5-a909-9e798e9eb935', '2023-07-24 11:06:19.252084', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 09 07 dışında döküm yapılmış maça ve kum döküm kalıpları', NULL, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100908', false, false, NULL, 100908, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('cced8f87-071d-4cd3-ac70-3baeeddedde3', '2023-07-24 11:06:19.255523', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 06 01, 16 06 02 ya da 16 06 03?ün altında geçen pillerle çalışan tek kullanımlık fotoğraf makineleri', 1, '8693d445-ccb1-423b-8380-a415bab62bb1', '090111', true, true, NULL, 90111, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('cd4e64ae-c78f-49c3-835f-aa9a50a0c397', '2023-07-24 11:06:19.220253', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren sulu durulama sıvıları', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110111', true, true, NULL, 110111, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('cd5bcaa4-0c3d-4033-8cdc-e404a187c110', '2023-07-24 11:06:19.23399', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Patlayıcı parçalar (örneğin hava yastıkları)', 1, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160110', true, true, NULL, 160110, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('cd96e2cb-1ad4-4b66-aece-0159e05a1c0d', '2023-07-24 11:06:19.245287', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Karışık metaller', NULL, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170407', false, false, NULL, 170407, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('cda5c758-c0f7-4e8f-90f9-d5abfee29c4a', '2023-07-24 11:06:19.244394', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalürjik proseslerden kaynaklanan, tehlikeli maddeler içeren diğer astarlar ve refraktörler', 1, '05f219fe-21e2-4128-95eb-65b72829b3fa', '161103', true, true, NULL, 161103, 1611);
INSERT INTO "e-izin"."AtikKod" VALUES ('cebf823f-b311-4b88-8e34-75f22d25a1a3', '2023-07-24 11:06:19.26439', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Doğal Gaz Saflaştırma ve Nakliyesinde Oluşan Atıklar', NULL, '5ccc997c-1c3a-4640-8f1a-d9cb0f0f4290', '0507', false, true, NULL, 507, 5);
INSERT INTO "e-izin"."AtikKod" VALUES ('cf241c2c-27d7-439d-a912-b17b737d1709', '2023-07-24 11:06:19.252877', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 11 13 dışındaki cam parlatma ve öğütme çamuru', NULL, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101114', false, false, NULL, 101114, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('cf83cdd9-7be0-4a9b-ae9c-8e066da75731', '2023-07-24 11:06:19.280375', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Akışkan yatak kumları', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100124', false, false, NULL, 100124, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('cfa3b5da-6a64-4ba4-a95b-01607776f5e5', '2023-07-24 11:06:19.214056', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070504', true, true, NULL, 70504, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('d07b4264-4354-4e68-936e-76f8dd1a4dc8', '2023-07-24 11:06:19.262483', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Deri ve Kürk Endüstrisinden Kaynaklanan Atıklar', NULL, '7bcb6da6-43d2-4336-b3c2-782f2c599e74', '0401', false, true, NULL, 401, 4);
INSERT INTO "e-izin"."AtikKod" VALUES ('d1130030-860a-4c1b-b820-5c3fc1e10ff3', '2023-07-24 11:06:19.239924', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metal ve Diğer Malzemelerin Kimyasal Yüzey İşlemi ve Kaplanmasından Kaynaklanan Atıklar (Örn: Galvanizleme, Çinko Kaplama, Dekapaj, Asitle Sıyırma, Fosfatlama, Alkalin Degradasyonu, Anotlama)', NULL, 'ef717c0c-06e1-4ee0-bb46-b5d04f58e738', '1101', false, true, NULL, 1101, 11);
INSERT INTO "e-izin"."AtikKod" VALUES ('d1618528-23e6-4e53-8ca3-2a516cd2ef9b', '2023-07-24 11:06:19.211068', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerle kontamine olmuş kalsiyum bazlı reaksiyon atıkları', 1, '3f6a127a-afa3-4ec3-b92a-0b42f0c91478', '060903', true, true, NULL, 60903, 609);
INSERT INTO "e-izin"."AtikKod" VALUES ('d1a799b4-e386-4588-ade4-462395e2d1a5', '2023-07-24 11:06:19.235025', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Basınçlı Tank İçindeki Gazlar ve Iskartaya Çıkmış Kimyasallar', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1605', false, true, NULL, 1605, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('d1ad69b6-fdf3-4c76-bce5-8decd8f49ad2', '2023-07-24 11:06:19.246358', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '18 02 05 dışındaki kimyasallar', NULL, '33e02f8e-69f7-4898-bae5-35e162129f2c', '180206', false, false, NULL, 180206, 1802);
INSERT INTO "e-izin"."AtikKod" VALUES ('d1ced365-50a4-47e4-9d45-6c8fe35b361d', '2023-07-24 11:06:19.260833', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, '9c34ae5a-4d11-498c-98d3-8287309afe70', '020502', false, false, NULL, 20502, 205);
INSERT INTO "e-izin"."AtikKod" VALUES ('d1fffe50-460d-4bf3-aab3-f122a547459f', '2023-07-24 11:06:19.209291', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sodyum ve potasyum hidroksit', 1, '0c74ab22-30b7-44fd-8a78-91dc30bf4f41', '060204', true, true, NULL, 60204, 602);
INSERT INTO "e-izin"."AtikKod" VALUES ('d225a1aa-e7d5-4cb6-9f6a-bb984ed719a2', '2023-07-24 11:06:19.256232', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100120', true, true, NULL, 100120, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('d334be9f-145c-4924-bb7b-a099464ae82f', '2023-07-24 11:06:19.243366', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Alkali piller (16 06 03 hariç)', 2, 'ffee3666-7a2b-4281-8460-44408303217f', '160604', false, false, NULL, 160604, 1606);
INSERT INTO "e-izin"."AtikKod" VALUES ('d369dee8-e8ff-48de-b7f3-22701004e738', '2023-07-24 11:06:19.239289', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtma çamuru ve filtre kekleri', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101307', false, false, NULL, 101307, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('d3847781-ea58-4a48-b50c-b51b0b7becc9', '2023-07-24 11:06:19.265109', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar', 1, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101119', true, true, NULL, 101119, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('d3928a7f-72be-4653-9a40-e16d5ac42d03', '2023-07-24 11:06:19.251234', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer partiküller ve toz', NULL, 'e67297f9-9141-4cd9-ac88-e58d52bc88c9', '100704', false, false, NULL, 100704, 1007);
INSERT INTO "e-izin"."AtikKod" VALUES ('d3f9a2f9-571a-48d1-86ee-16b7671121b2', '2023-07-24 11:06:19.231647', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hayvan dokusu atıkları', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020102', false, false, NULL, 20102, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('d3feaa80-7658-4e94-b3b4-faa376f69781', '2023-07-24 11:06:19.263489', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sıyırma bazları', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110107', true, true, NULL, 110107, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('d4ad3dac-3e54-4aca-937f-12cae38310a7', '2023-07-24 11:06:19.241392', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '12 01 20 dışındaki öğütme parçaları ve öğütme maddeleri', NULL, 'c16e7cd1-61a2-484e-801e-fe48662ee198', '120121', false, false, NULL, 120121, 1201);
INSERT INTO "e-izin"."AtikKod" VALUES ('d4ba0267-7449-4c07-a3b7-5b7a2894dd81', '2023-07-24 11:06:19.205459', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kullanılmış filtre killeri', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050115', true, true, NULL, 50115, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('d4ca8202-c223-4049-91c3-21af8a3a46c0', '2023-07-24 11:06:19.205766', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bitüm', NULL, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050117', false, false, NULL, 50117, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('d567ee07-f9ae-4a17-8d37-dbc3cee2ac4a', '2023-07-24 11:06:19.245642', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 08 01 dışındaki alçı bazlı inşaat malzemeleri', NULL, '0edacd0b-349f-4854-9d03-994ec406443a', '170802', false, false, NULL, 170802, 1708);
INSERT INTO "e-izin"."AtikKod" VALUES ('d5c4a508-4018-4a85-941a-9202ceddd0d9', '2023-07-24 11:06:19.279266', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar', 1, '95aa2a5c-1d47-4014-b1a6-64a8868bc9ad', '101115', true, true, NULL, 101115, 1011);
INSERT INTO "e-izin"."AtikKod" VALUES ('d62bfd4f-a6df-4da3-a182-5eb3cc9caca6', '2023-07-24 11:06:19.248759', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sulu sıvı atıklar', 1, 'ba215c7c-63f3-4bf9-b825-30f754e8d40c', '191103', true, true, NULL, 191103, 1911);
INSERT INTO "e-izin"."AtikKod" VALUES ('d63f3c27-24c9-4af8-bcb6-fb3c84242cd3', '2023-07-24 11:06:19.253358', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080199', false, false, NULL, 80199, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('d6ba3e43-0121-4ba3-a769-6f4acc7112e6', '2023-07-24 11:06:19.259265', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yıkama ve temizleme işlemlerinden kaynaklanan çamurlar', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020101', false, false, NULL, 20101, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('d6c4b552-ae2b-477c-958d-64878a7afa4d', '2023-07-24 11:06:19.264479', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka ağır metaller içeren atıklar', 1, '13b34703-1d7b-4f10-9cbb-bcf7b285c83d', '060405', true, true, NULL, 60405, 604);
INSERT INTO "e-izin"."AtikKod" VALUES ('d6e4134e-f61b-41e4-8f02-12f1f4896a4a', '2023-07-24 11:06:19.256546', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cüruf işleme atıkları', NULL, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100201', false, false, NULL, 100201, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('d6f7ac6b-214f-4b98-ba7e-b4ca80717eab', '2023-07-24 11:06:19.233032', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kloroflorokarbonlar, HCFC, HFC', 1, '8554b0a1-4347-4a3d-81e5-6eb9bc3216bd', '140601', true, true, NULL, 140601, 1406);
INSERT INTO "e-izin"."AtikKod" VALUES ('d78ce4c2-c88a-441b-a4c3-09a5f9482526', '2023-07-24 11:06:19.258991', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ içeren sondaj çamurları ve atıkları', 1, 'a3b7fef0-d9d1-4326-9622-3497df5170aa', '010505', true, true, NULL, 10505, 105);
INSERT INTO "e-izin"."AtikKod" VALUES ('d7bf6b00-841e-4840-ba5b-3e2c3b77bf21', '2023-07-24 11:06:19.241451', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'YAĞ ATIKLARI VE SIVI YAKIT ATIKLARI (YENİLEBİLİR YAĞLAR, 05 VE 12 HARİÇ)', NULL, NULL, '13', false, true, NULL, 13, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('d823d37a-9ad3-4839-b15d-c62369d77065', '2023-07-24 11:06:19.227891', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren inorganik atıklar', 1, 'fb657553-47ba-4711-84af-b13e3c533180', '160303', true, true, NULL, 160303, 1603);
INSERT INTO "e-izin"."AtikKod" VALUES ('d832fb21-e576-4644-86dd-460d6d19e6d0', '2023-07-24 11:06:19.220334', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer atıklar', 1, '489a8b03-d530-40e7-b85e-fffbb62081ec', '110207', true, true, NULL, 110207, 1102);
INSERT INTO "e-izin"."AtikKod" VALUES ('d93cf3f1-843d-404d-af03-3f6eb264a19c', '2023-07-24 11:06:19.277643', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tuz cürufları ve kara cürufların arıtımından çıkan ve tehlikeli maddeler içeren atıklar', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100329', true, true, NULL, 100329, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('d96113d9-1775-41e0-a3d1-a11c54495510', '2023-07-24 11:06:19.25154', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 08 10 dışındaki cüruf, toz ve kırpıntılar', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100811', false, false, NULL, 100811, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('d974df5f-2970-4db2-8555-2baf270c81ed', '2023-07-24 11:06:19.260243', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tüketime ya da işlenmeye uygun olmayan maddeler', NULL, '88e7ece3-789d-4b74-bc19-403a3f91dd79', '020304', false, false, NULL, 20304, 203);
INSERT INTO "e-izin"."AtikKod" VALUES ('d9ab919a-51a5-4887-b452-f49b644f23d6', '2023-07-24 11:06:19.233153', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer çözücüleri içeren çamurlar veya katı atıklar', 1, '8554b0a1-4347-4a3d-81e5-6eb9bc3216bd', '140605', true, true, NULL, 140605, 1406);
INSERT INTO "e-izin"."AtikKod" VALUES ('d9d06288-e147-4cf7-864a-a19b6c29d05c', '2023-07-24 11:06:19.236965', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sulu elektrolitik işlemleri için üretilen anot üretim atıkları', NULL, '489a8b03-d530-40e7-b85e-fffbb62081ec', '110203', false, false, NULL, 110203, 1102);
INSERT INTO "e-izin"."AtikKod" VALUES ('da2ff5a7-879b-4042-a4c1-c33b1901a3a2', '2023-07-24 11:06:19.261848', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organometal içeren ahşap koruyucu maddeler', 1, '32fa13d4-52f1-4c6e-9513-15ee2274d4c2', '030203', true, true, NULL, 30203, 302);
INSERT INTO "e-izin"."AtikKod" VALUES ('da4b53d0-360e-4631-9e63-406ff7859f90', '2023-07-24 11:06:19.243849', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bitik katalitik ?cracking? katalizör sıvısı (16 08 07 hariç)', NULL, '927df4de-1098-43b7-a071-8c1877c8b691', '160804', false, false, NULL, 160804, 1608);
INSERT INTO "e-izin"."AtikKod" VALUES ('da7a8f0e-8c28-4694-a975-5312193dcfce', '2023-07-24 11:06:19.278099', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 04 15 dışındaki yapışkan veya dolgu macunlarının sulu atıkları', NULL, 'c3f2e872-5b04-406f-aaf7-6f40128629be', '080416', false, false, NULL, 80416, 804);
INSERT INTO "e-izin"."AtikKod" VALUES ('daba88cf-f004-42fe-9e64-273bc4d9702b', '2023-07-24 11:06:19.234235', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir metaller', NULL, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160117', false, false, NULL, 160117, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '2023-07-24 11:06:19.24499', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metaller (Alaşımları Dahil)', NULL, 'c4d6b5a4-b326-453e-a375-286212bd4d29', '1704', false, true, NULL, 1704, 17);
INSERT INTO "e-izin"."AtikKod" VALUES ('dbe6ff80-a015-40bb-af7f-24860cd30e85', '2023-07-24 11:06:19.279992', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '8693d445-ccb1-423b-8380-a415bab62bb1', '090199', false, false, NULL, 90199, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('dc5edbf5-26da-4d21-abb9-0d3dab206e42', '2023-07-24 11:06:19.255695', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'ISIL İŞLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '10', false, true, NULL, 10, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('dc7f8ce5-a01c-48d3-8e46-e04294a562bd', '2023-07-24 11:06:19.250582', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer partiküller ve toz', NULL, '3b4a20a2-c147-4b99-b9bb-750194453116', '100504', false, false, NULL, 100504, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('dcdf70d7-2b63-42a0-a848-f700a0120169', '2023-07-24 11:06:19.222276', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan krom içeren çamurlar', NULL, 'd07b4264-4354-4e68-936e-76f8dd1a4dc8', '040106', false, false, NULL, 40106, 401);
INSERT INTO "e-izin"."AtikKod" VALUES ('dd000bee-06b4-431e-8870-2e8763436470', '2023-07-24 11:06:19.25577', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Turba ve işlenmenmiş odundan kaynaklanan uçucu kül', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100103', false, false, NULL, 100103, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('dd0a41ef-72af-4030-b4d1-794d0610aeeb', '2023-07-24 11:06:19.277337', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 07 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070712', false, false, NULL, 70712, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('dd11b507-0641-4a8e-98a5-635b4787cf0e', '2023-07-24 11:06:19.248699', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asit katranları', 1, 'ba215c7c-63f3-4bf9-b825-30f754e8d40c', '191102', true, true, NULL, 191102, 1911);
INSERT INTO "e-izin"."AtikKod" VALUES ('dd18d463-2e14-4df2-a219-cbc1f4383dee', '2023-07-24 11:06:19.223523', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asit ziftleri', 1, '07a8b9c4-da35-4838-86e3-a340636a4aa7', '050601', true, true, NULL, 50601, 506);
INSERT INTO "e-izin"."AtikKod" VALUES ('dd62d435-9daa-41a7-855c-6a6ac132242d', '2023-07-24 11:06:19.253238', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Iskarta kalıplar', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101206', false, false, NULL, 101206, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('de08a03a-d39b-4af1-9528-a1db39f8c6fe', '2023-07-24 11:06:19.227951', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asbest içeren inşaat malzemeleri', 1, 'b6620d4c-259c-4452-9220-fc612f8b6e32', '170605', true, true, NULL, 170605, 1706);
INSERT INTO "e-izin"."AtikKod" VALUES ('de578664-85aa-4b04-9d5e-a26c602010c5', '2023-07-24 11:06:19.283703', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddelerle kontamine olmuş bitik katalizörler', 1, '927df4de-1098-43b7-a071-8c1877c8b691', '160807', true, true, NULL, 160807, 1608);
INSERT INTO "e-izin"."AtikKod" VALUES ('de8b7cb2-93fa-48d6-95f5-196f2eedbade', '2023-07-24 11:06:19.278293', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '55ba65c1-cc71-4988-bed7-116ce381cd99', '100699', false, false, NULL, 100699, 1006);
INSERT INTO "e-izin"."AtikKod" VALUES ('df7919b8-f821-4442-a41f-769296868dfc', '2023-07-24 11:06:19.273502', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler ile kontamine olmuş alçı bazlı inşaat malzemeleri', 1, '0edacd0b-349f-4854-9d03-994ec406443a', '170801', true, true, NULL, 170801, 1708);
INSERT INTO "e-izin"."AtikKod" VALUES ('dff8bb04-5506-4de9-980b-42baa9dd737b', '2023-07-24 11:06:19.229592', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık Motor, Şanzıman ve Yağlama Yağları', NULL, 'd7bf6b00-841e-4840-ba5b-3e2c3b77bf21', '1302', false, true, NULL, 1302, 13);
INSERT INTO "e-izin"."AtikKod" VALUES ('e020667f-c0e0-46ac-8aae-00d5632b27aa', '2023-07-24 11:06:19.257827', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 03 25 dışındaki gaz arıtımı çamurları ve filtre kekleri', NULL, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100326', false, false, NULL, 100326, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('e028b2f3-972c-4acd-9ab5-e2a2abaf42be', '2023-07-24 11:06:19.214135', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer filtre tabakaları kekleri, kullanılmış absorbanlar', 1, 'ec91af60-1678-4b87-bba9-743705a039fd', '070510', true, true, NULL, 70510, 705);
INSERT INTO "e-izin"."AtikKod" VALUES ('e0849e14-1412-4502-af6d-646c1c68a683', '2023-07-24 11:06:19.219364', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 10 05 dışındaki henüz döküm yapılamamış maça ve kum döküm kalıpları', NULL, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101006', false, false, NULL, 101006, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('e0c18375-abfe-4596-9ecc-293b099654b7', '2023-07-24 11:06:19.2652', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fotoğrafçılık atıklarının saha içi arıtılmasından oluşan gümüş içeren atıklar', 1, '8693d445-ccb1-423b-8380-a415bab62bb1', '090106', true, true, NULL, 90106, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('e0deb4e0-416e-477f-be5c-b898ad9fbc78', '2023-07-24 11:06:19.236779', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kireç çamuru atığı', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030309', false, false, NULL, 30309, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('e19ca42f-4bca-47cd-b429-de99a18b5de5', '2023-07-24 11:06:19.231285', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '17 09 01, 17 09 02 ve 17 09 03 dışındaki karışık inşaat ve yıkıntı atıkları', NULL, '6f38b08c-106b-4284-932e-2f21aef998d8', '170904', false, false, NULL, 170904, 1709);
INSERT INTO "e-izin"."AtikKod" VALUES ('e220afc0-da04-414d-9fef-8254d286828e', '2023-07-24 11:06:19.240631', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '11 02 05 dışındaki bakır hidrometalürjisi atıkları', NULL, '489a8b03-d530-40e7-b85e-fffbb62081ec', '110206', false, false, NULL, 110206, 1102);
INSERT INTO "e-izin"."AtikKod" VALUES ('e2e8738f-32a7-406a-978f-88e5daf198cb', '2023-07-24 11:06:19.210039', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '5dc8194f-2de7-4707-8fcb-ffac8a0ea72a', '060399', false, false, NULL, 60399, 603);
INSERT INTO "e-izin"."AtikKod" VALUES ('e3044e5d-eed1-4214-8ea2-57fb1330ae60', '2023-07-24 11:06:19.235206', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Petrol Rafinasyon Atıkları', NULL, '5ccc997c-1c3a-4640-8f1a-d9cb0f0f4290', '0501', false, true, NULL, 501, 5);
INSERT INTO "e-izin"."AtikKod" VALUES ('e33db85d-ae04-40b9-a059-b5235f5dd381', '2023-07-24 11:06:19.28424', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kısmen stabilize olmuş cıva', NULL, '235a8557-aa28-4c06-9060-16bc23a58c6a', '190308', true, true, NULL, 190308, 1903);
INSERT INTO "e-izin"."AtikKod" VALUES ('e34631eb-09be-43ce-9b7a-3e6992f8a289', '2023-07-24 11:06:19.231528', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 10 05 dışındaki diğer kalıntılar', NULL, '87472e6e-58cd-47da-8f27-282cbb95f77b', '191006', false, false, NULL, 191006, 1910);
INSERT INTO "e-izin"."AtikKod" VALUES ('e34cc32e-eff3-43f6-a081-6c90b270228e', '2023-07-24 11:06:19.208289', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hidroklorik asit', 1, '2cc8b711-0e7d-4aeb-a8de-9e7d57836ef5', '060102', true, true, NULL, 60102, 601);
INSERT INTO "e-izin"."AtikKod" VALUES ('e374b604-7837-407a-9fd7-d55ae23f96fe', '2023-07-24 11:06:19.249069', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir metali', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191202', false, false, NULL, 191202, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('e3c09b4b-722f-4ba2-89ca-c2d7ff89dd8a', '2023-07-24 11:06:19.256626', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşlenmemiş cüruf', NULL, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100202', false, false, NULL, 100202, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('e3caf1a9-52a6-4bf8-add5-4c9a471645c1', '2023-07-24 11:06:19.265468', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenlenmemiş organik ahşap koruyucu maddeler', 1, '32fa13d4-52f1-4c6e-9513-15ee2274d4c2', '030201', true, true, NULL, 30201, 302);
INSERT INTO "e-izin"."AtikKod" VALUES ('e46df7db-28d8-4e1d-9f7b-e25c597890b0', '2023-07-24 11:06:19.256884', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar', 1, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100211', true, true, NULL, 100211, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('e49d03e8-a062-429f-aa30-ac136b284605', '2023-07-24 11:06:19.262851', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kirecin kalsinasyon ve hidratasyonundan kaynaklanan atıklar', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101304', false, false, NULL, 101304, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('e4e9b143-78f6-417e-9c3d-cad83e89e227', '2023-07-24 11:06:19.211878', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Halojenli filtre keki ve kullanılmış absorbanlar', 1, '0058b96b-d695-4095-a185-132f753311cc', '070109', true, true, NULL, 70109, 701);
INSERT INTO "e-izin"."AtikKod" VALUES ('e567447a-fb44-4431-8641-5463d7c74e30', '2023-07-24 11:06:19.212968', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'faf9d336-4990-4298-a50a-b56af7884053', '070304', true, true, NULL, 70304, 703);
INSERT INTO "e-izin"."AtikKod" VALUES ('e58342d0-1cef-4204-9efe-9e302742ca8e', '2023-07-24 11:06:19.252576', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 10 15 dışındaki çatlak belirleme kimyasalları atığı', NULL, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101016', false, false, NULL, 101016, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('e67297f9-9141-4cd9-ac88-e58d52bc88c9', '2023-07-24 11:06:19.224165', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gümüş, Altın ve Platin Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1007', false, true, NULL, 1007, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('e682523f-623e-4ffa-9f3f-8df0825e569f', '2023-07-24 11:06:19.264928', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Partiküller ve toz', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100804', false, false, NULL, 100804, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('e6c76645-54a6-4a59-bf28-54157cee606a', '2023-07-24 11:06:19.245937', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kan torbaları ve kan yedekleri dahil vücut parçaları ve organları (18 01 03 hariç)', 2, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180102', false, false, NULL, 180102, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('e6fe84f7-cd06-4830-90c2-1729dbe0edc1', '2023-07-24 11:06:19.226184', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık metal', NULL, 'b1ba743a-ee1e-4c2a-954e-25b03504e7c7', '020110', false, false, NULL, 20110, 201);
INSERT INTO "e-izin"."AtikKod" VALUES ('e75c1d73-1593-492b-8d6b-63b2dd36c070', '2023-07-24 11:06:19.229349', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sulu yıkama sıvıları', 1, 'feb88e5f-8f43-4280-b8c6-fec4f5f378bb', '120301', true, true, NULL, 120301, 1203);
INSERT INTO "e-izin"."AtikKod" VALUES ('e7ba2ce2-a02e-4010-ae14-d4706788fdad', '2023-07-24 11:06:19.233811', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Sıvı ya da tehlikeli maddeler içermeyen ömrünü tamamlamış araçlar', 2, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160106', false, false, NULL, 160106, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('e8710e07-5236-4d7c-a1d5-502ea2e9d29b', '2023-07-24 11:06:19.231588', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Pestisitler', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200119', true, true, NULL, 200119, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('e8d642eb-60d4-4282-86b6-95d6fe0ce4fa', '2023-07-24 11:06:19.282675', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 03 08 dışındaki tehlikeli olarak işaretlenmiş kısmen (6) stabilize olmuş atıklar', 1, '235a8557-aa28-4c06-9060-16bc23a58c6a', '190304', true, true, NULL, 190304, 1903);
INSERT INTO "e-izin"."AtikKod" VALUES ('e90c75b3-e52c-46b4-a760-b5b14a222534', '2023-07-24 11:06:19.26358', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fosfatlama çamurları', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110108', true, true, NULL, 110108, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('e965a4b3-5f02-49e9-823b-28d1749941d6', '2023-07-24 11:06:19.238423', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kağıt geri kazanım işleminden kaynaklanan mürekkep giderme çamurları', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030305', false, false, NULL, 30305, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('e99a4788-05a1-433f-8098-61fca2f112af', '2023-07-24 11:06:19.226042', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer partiküller ve tozlar (öğütücü değirmen tozu dahil)', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100321', true, true, NULL, 100321, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('e99fc288-debc-4095-a9b4-fe403ce77153', '2023-07-24 11:06:19.283643', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Cıva içeren parçalar', 1, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160108', true, true, NULL, 160108, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('e9db0c53-3c83-43b2-954c-39de95741c61', '2023-07-24 11:06:19.256797', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Haddehane tufalı', NULL, 'c0f21ae6-314a-49e3-877a-ce4954d97199', '100210', false, false, NULL, 100210, 1002);
INSERT INTO "e-izin"."AtikKod" VALUES ('e9ea9f35-9f9b-4afb-a253-713b711bc8cb', '2023-07-24 11:06:19.224484', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Termik santrallerin yakıt depolama ve hazırlama işlemlerinden çıkan atıklar', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100125', false, false, NULL, 100125, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('ea0113c1-66c5-4d7f-a8e4-94bb7f35b121', '2023-07-24 11:06:19.243068', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren dip tarama çamuru', 1, '8c13d02a-936e-4a93-8508-8207af2c45d4', '170505', true, true, NULL, 170505, 1705);
INSERT INTO "e-izin"."AtikKod" VALUES ('ea02a9a1-4b85-4edc-86a0-4cccdf38c4db', '2023-07-24 11:06:19.244335', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 11 01 dışındaki metalürjik proseslerden kaynaklanan karbon bazlı astar ve refraktörler', NULL, '05f219fe-21e2-4128-95eb-65b72829b3fa', '161102', false, false, NULL, 161102, 1611);
INSERT INTO "e-izin"."AtikKod" VALUES ('ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '2023-07-24 11:06:19.246418', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Atık Yakma veya Piroliz?den Kaynaklanan Atıklar', NULL, '3420b36c-956a-48ac-a2bd-6badfe35a498', '1901', false, true, NULL, 1901, 19);
INSERT INTO "e-izin"."AtikKod" VALUES ('eacbe301-36ad-4179-8fcf-103af38e98dd', '2023-07-24 11:06:19.239465', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 13 09 dışındaki asbestli çimento üretimi atıkları', NULL, '841b4fa8-df0b-4dfe-82a9-be615e1b918f', '101310', false, false, NULL, 101310, 1013);
INSERT INTO "e-izin"."AtikKod" VALUES ('ead48628-5cba-48d9-b2c2-743b568e6f8d', '2023-07-24 11:06:19.22131', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '16 10 03 dışındaki sulu derişik maddeler', NULL, 'cc572c1d-1fa6-4c3b-b648-74bff3176f98', '161004', false, false, NULL, 161004, 1610);
INSERT INTO "e-izin"."AtikKod" VALUES ('eae060d4-b0b3-4663-b403-f0f681f4afff', '2023-07-24 11:06:19.272779', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100199', false, false, NULL, 100199, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('eb06527a-9368-45fc-bb70-1b107a355eec', '2023-07-24 11:06:19.253537', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Seramik malzemeler içeren sulu süspansiyonlar', NULL, '26fffbdb-1704-425d-ad2f-db6201225ac0', '080203', false, false, NULL, 80203, 802);
INSERT INTO "e-izin"."AtikKod" VALUES ('eb6c3b3e-f4e1-450a-a585-4d00ec383008', '2023-07-24 11:06:19.233871', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ filtreleri', 1, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160107', true, true, NULL, 160107, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('ec7982f0-12a8-4b07-8d2e-51fd8dfb9dc8', '2023-07-24 11:06:19.280919', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren gaz arıtımı katı atıkları', 1, 'aa1b5b29-7e98-4979-b1a5-9e396d212ae8', '100323', true, true, NULL, 100323, 1003);
INSERT INTO "e-izin"."AtikKod" VALUES ('ec91af60-1678-4b87-bba9-743705a039fd', '2023-07-24 11:06:19.276897', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İlaçların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, '2ed155b3-66a6-455e-9b6f-f2af44d782c9', '0705', false, true, NULL, 705, 7);
INSERT INTO "e-izin"."AtikKod" VALUES ('ece93fa3-ca7e-4be5-ab06-01e5950e496f', '2023-07-24 11:06:19.212241', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer dip tortusu ve reaksiyon kalıntıları', 1, '02890c62-fdea-4520-a830-5462e228d706', '070208', true, true, NULL, 70208, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('ecf9c199-fd2c-4b89-8865-66b6213a78fa', '2023-07-24 11:06:19.251175', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Birincil ve ikincil üretim cürufları', NULL, 'e67297f9-9141-4cd9-ac88-e58d52bc88c9', '100701', false, false, NULL, 100701, 1007);
INSERT INTO "e-izin"."AtikKod" VALUES ('ed8f12db-c175-4588-b343-454487bbf0bf', '2023-07-24 11:06:19.274743', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Fiziksel ve kimyasal işlemlerden kaynaklanan tehlikeli maddeler içeren çamurlar', 1, '23405de6-af3e-427e-9239-66d58607d7cc', '190205', true, true, NULL, 190205, 1902);
INSERT INTO "e-izin"."AtikKod" VALUES ('edb07bc4-bdbf-44a8-a958-fe58a0cfba47', '2023-07-24 11:06:19.277087', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Yağ, Gres, Sabun, Deterjan, Dezenfektan ve Kozmetiklerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, '2ed155b3-66a6-455e-9b6f-f2af44d782c9', '0706', false, true, NULL, 706, 7);
INSERT INTO "e-izin"."AtikKod" VALUES ('edba1adc-e66f-477e-9235-8d1a3f9e5e61', '2023-07-24 11:06:19.216141', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 01 11 dışındaki atık boya ve vernikler', NULL, '7e1e8be5-d97f-4899-8fc4-bf579a2254e9', '080112', false, false, NULL, 80112, 801);
INSERT INTO "e-izin"."AtikKod" VALUES ('ee014e43-3894-4662-9d60-01da10463647', '2023-07-24 11:06:19.259975', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tüketime ya da işlenmeye uygun olmayan maddeler', NULL, '08697385-2b61-4344-afd0-169b00c005ea', '020203', false, false, NULL, 20203, 202);
INSERT INTO "e-izin"."AtikKod" VALUES ('ee3f9db6-fdcd-48da-9ab2-687c95b73d54', '2023-07-24 11:06:19.276396', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '07 02 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, '02890c62-fdea-4520-a830-5462e228d706', '070212', false, false, NULL, 70212, 702);
INSERT INTO "e-izin"."AtikKod" VALUES ('ee8a45ff-6900-4b42-a4b9-f5c9b64aba5e', '2023-07-24 11:06:19.260331', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Şeker üretiminden kaynaklanan atıklar', NULL, 'a80a1d5d-070c-488c-bd1b-4fb2bd4b420f', '0204', false, true, NULL, 204, 2);
INSERT INTO "e-izin"."AtikKod" VALUES ('eed8d1f2-1993-4717-aaa0-1bcf5e9f2790', '2023-07-24 11:06:19.24349', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Piller ve akümülatörlerden ayrı toplanmış elektrolitler', 2, 'ffee3666-7a2b-4281-8460-44408303217f', '160606', true, true, NULL, 160606, 1606);
INSERT INTO "e-izin"."AtikKod" VALUES ('ef67943e-f986-4b71-9349-0f7efc374f26', '2023-07-24 11:06:19.230017', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İskele kanalizasyonlarından(mendirekten) kaynaklanan sintine yağları', 1, '4a6ea286-5629-48e0-9e72-ce8ca286b51f', '130402', true, true, NULL, 130402, 1304);
INSERT INTO "e-izin"."AtikKod" VALUES ('ef717c0c-06e1-4ee0-bb46-b5d04f58e738', '2023-07-24 11:06:19.23976', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'METAL VE DİĞER MALZEMELERİN KİMYASAL YÜZEY İŞLEMİ VE KAPLANMASI İŞLEMLERİNDEN KAYNAKLANAN ATIKLAR; DEMİR DIŞI HİDROMETALURJİ', NULL, NULL, '11', false, true, NULL, 11, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('efd56816-66a2-4715-9fa4-838b2a68bbc0', '2023-07-24 11:06:19.232007', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren boya maddeleri ve pigmentler', 1, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040216', true, true, NULL, 40216, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('f0781f08-e3e9-419d-8ff4-526b06ee9315', '2023-07-24 11:06:19.203896', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tank dibi çamurları', 1, 'e3044e5d-eed1-4214-8ea2-57fb1330ae60', '050103', true, true, NULL, 50103, 501);
INSERT INTO "e-izin"."AtikKod" VALUES ('f0c88121-3f39-4f22-a8da-9a9ea3b16a18', '2023-07-24 11:06:19.242466', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Karbonat gidermeden kaynaklanan çamurlar', NULL, '02ad50ac-b89e-4b16-a98e-1931776eea3b', '190903', false, false, NULL, 190903, 1909);
INSERT INTO "e-izin"."AtikKod" VALUES ('f0e2198e-40b2-4633-b624-b0b5ad88adcd', '2023-07-24 11:06:19.249192', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Plastik ve lastik', NULL, '8066c902-0d18-4db7-ae51-028f05c9ecc2', '191204', false, false, NULL, 191204, 1912);
INSERT INTO "e-izin"."AtikKod" VALUES ('f1601b86-3a4c-4f94-979b-a0e3c7ff91e0', '2023-07-24 11:06:19.218777', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kurum', 1, '62946a2a-b011-4804-b78e-540f50e96d69', '061305', true, true, NULL, 61305, 613);
INSERT INTO "e-izin"."AtikKod" VALUES ('f21612e9-8e9c-4b97-84d8-4fadde6e74e7', '2023-07-24 11:06:19.26783', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kullanılmış aktif karbon', NULL, '02ad50ac-b89e-4b16-a98e-1931776eea3b', '190904', false, false, NULL, 190904, 1909);
INSERT INTO "e-izin"."AtikKod" VALUES ('f2bf8fc9-e37b-4439-a416-ec536dd1a972', '2023-07-24 11:06:19.231038', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kömür katranı içeren bitümlü karışımlar', 1, '0679c123-9c79-4909-ba99-fa94e8d68951', '170301', true, true, NULL, 170301, 1703);
INSERT INTO "e-izin"."AtikKod" VALUES ('f2fa8ba1-2e22-40f5-b8f6-fa765baa2004', '2023-07-24 11:06:19.213332', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su bazlı yıkama sıvıları ve ana çözeltiler', 1, 'c9a3864b-2be1-4f2a-b772-2d2466c8868c', '070401', true, true, NULL, 70401, 704);
INSERT INTO "e-izin"."AtikKod" VALUES ('f30a2a2b-59b8-4391-9e1b-533447229a6e', '2023-07-24 11:06:19.26926', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '19 13 05 dışındaki yeraltı suyunun ıslahından kaynaklanan çamurlar', NULL, '3c8d5e7a-e867-402f-b518-a5cafa387f07', '191306', false, false, NULL, 191306, 1913);
INSERT INTO "e-izin"."AtikKod" VALUES ('f44ef808-2dd5-4489-9ee8-ca6b0c89babb', '2023-07-24 11:06:19.232735', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '06 05 02 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, '1105677a-6ddd-4fb1-95c6-a4c8542cebff', '060503', false, false, NULL, 60503, 605);
INSERT INTO "e-izin"."AtikKod" VALUES ('f47f83b4-6493-4088-bc34-681782536c48', '2023-07-24 11:06:19.256077', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 01 16 dışındaki birlikte yakılmadan (co-incineration) kaynaklanan uçucu kül', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100117', false, false, NULL, 100117, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('f47ff20b-270d-434e-b848-51f9ce4b6dde', '2023-07-24 11:06:19.206057', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çözücüler', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200113', true, true, NULL, 200113, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('f4e6acda-cd30-4ea7-97fd-abfe4b127dee', '2023-07-24 11:06:19.215356', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', 1, 'fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '070704', true, true, NULL, 70704, 707);
INSERT INTO "e-izin"."AtikKod" VALUES ('f512fee2-0f44-4036-a57d-b5b285437952', '2023-07-24 11:06:19.262758', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 12 11 dışındaki sırlama atıkları', NULL, '463f3daa-35fb-4946-9e72-9489b21c6d02', '101212', false, false, NULL, 101212, 1012);
INSERT INTO "e-izin"."AtikKod" VALUES ('f523a624-adf1-4c08-ac9f-9e822c12d922', '2023-07-24 11:06:19.241088', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'METALLERİN VE PLASTİKLERİN FİZİKİ VE MEKANİK YÜZEY İŞLEMLERİNDEN VE ŞEKİLLENDİRİLMESİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '12', false, true, NULL, 12, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('f54ffb64-2f89-4e1f-adf4-67fc1140ab76', '2023-07-24 11:06:19.230076', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kum odacığından ve yağ/su ayırıcısından çıkan katılar', 1, '7b1f3519-e16b-445c-b927-d70255f332d9', '130501', true, true, NULL, 130501, 1305);
INSERT INTO "e-izin"."AtikKod" VALUES ('f555608a-c702-43bc-9446-9f22f3e2dab2', '2023-07-24 11:06:19.245228', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Çinko', NULL, 'dad385b5-6ef7-410b-adc6-fd5d7c8eb6ed', '170404', false, false, NULL, 170404, 1704);
INSERT INTO "e-izin"."AtikKod" VALUES ('f5600253-c2df-4afc-8897-a196fe5280a6', '2023-07-24 11:06:19.249864', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'AYRI TOPLANMIŞ FRAKSİYONLAR DAHİL BELEDİYE ATIKLARI (EVSEL ATIKLAR VE BENZER TİCARİ, ENDÜSTRİYEL VE KURUMSAL ATIKLAR)', NULL, NULL, '20', false, true, NULL, 20, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('f57764d0-0426-443c-8ad2-616e46932562', '2023-07-24 11:06:19.259887', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Hayvan dokusu atığı', NULL, '08697385-2b61-4344-afd0-169b00c005ea', '020202', false, false, NULL, 20202, 202);
INSERT INTO "e-izin"."AtikKod" VALUES ('f5e6d81c-b71a-4a33-9add-1b89a6ad6329', '2023-07-24 11:06:19.262391', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, 'bdd24027-1c6a-49e8-955e-1b2fbd6e4ec5', '030399', false, false, NULL, 30399, 303);
INSERT INTO "e-izin"."AtikKod" VALUES ('f60c1e8e-6d68-48f9-ac10-17c568685d4e', '2023-07-24 11:06:19.236054', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Demir Dışı Döküm Atıkları', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1010', false, true, NULL, 1010, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('f63a0b43-df61-407e-b076-6e0c17fd8a50', '2023-07-24 11:06:19.254111', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '08 03 12 dışındaki mürekkep atıkları', NULL, 'a985ac97-f87d-431c-8d87-ae27477767a1', '080313', false, false, NULL, 80313, 803);
INSERT INTO "e-izin"."AtikKod" VALUES ('f684e0a1-542f-42dd-9623-a35210154efe', '2023-07-24 11:06:19.243306', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Nikel kadmiyum piller', 2, 'ffee3666-7a2b-4281-8460-44408303217f', '160602', true, true, NULL, 160602, 1606);
INSERT INTO "e-izin"."AtikKod" VALUES ('f73d0c97-2493-4165-bea3-c9c4aa5d8518', '2023-07-24 11:06:19.210723', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '254667d3-3d03-47c4-99ae-85ae4efa0b18', '060799', false, false, NULL, 60799, 607);
INSERT INTO "e-izin"."AtikKod" VALUES ('f75207fd-8e09-4f0a-b745-7ff227aa2989', '2023-07-24 11:06:19.271764', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '20 01 25 dışındaki sıvı ve katı yağlar', 1, '0e9664ac-6062-434c-b294-68cc3cb7f933', '200126', true, true, NULL, 200126, 2001);
INSERT INTO "e-izin"."AtikKod" VALUES ('f78d7e6e-1f3f-4076-b0ee-0ca3455cead7', '2023-07-24 11:06:19.22377', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '13b34703-1d7b-4f10-9cbb-bcf7b285c83d', '060499', false, false, NULL, 60499, 604);
INSERT INTO "e-izin"."AtikKod" VALUES ('f7e1e0ad-6105-4b47-b402-506edf4480f7', '2023-07-24 11:06:19.232497', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İNORGANİK KİMYASAL İŞLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, NULL, '06', false, true, NULL, 6, NULL);
INSERT INTO "e-izin"."AtikKod" VALUES ('f800ea92-912f-4a99-adc6-7240d60d8965', '2023-07-24 11:06:19.258438', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Metalik olmayan minerallerin fiziki ve kimyasal işlenmesinden kaynaklanan tehlikeli maddeler içeren atıklar', 1, '2e0d5b91-4e46-4f6f-8e7a-78075e5bbefa', '010407', true, true, NULL, 10407, 104);
INSERT INTO "e-izin"."AtikKod" VALUES ('f81a64ce-4cb4-4d08-91d1-112fe444c66d', '2023-07-24 11:06:19.264572', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Asbest işlenmesinden kaynaklanan atıklar', 1, '62946a2a-b011-4804-b78e-540f50e96d69', '061304', true, true, NULL, 61304, 613);
INSERT INTO "e-izin"."AtikKod" VALUES ('f831f1f8-fb66-4e06-ae6c-1195bc33c7e1', '2023-07-24 11:06:19.210248', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, '1105677a-6ddd-4fb1-95c6-a4c8542cebff', '060502', true, true, NULL, 60502, 605);
INSERT INTO "e-izin"."AtikKod" VALUES ('f850dc94-1624-44dd-a771-e537933cd4fd', '2023-07-24 11:06:19.217961', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Bahçe ve Park Atıkları (Mezarlık Atıkları Dahil)', NULL, 'f5600253-c2df-4afc-8897-a196fe5280a6', '2002', false, true, NULL, 2002, 20);
INSERT INTO "e-izin"."AtikKod" VALUES ('f8e2cc9c-b5d7-4b2a-8cf8-c1dba53e6432', '2023-07-24 11:06:19.26583', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Patlayıcı Atıklar', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1604', false, true, NULL, 1604, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('f9de9d4f-1a61-4f57-893b-68597e027fda', '2023-07-24 11:06:19.278659', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 08 19 dışındaki soğutma suyu arıtma atıkları', NULL, '5357b5e2-5902-4994-8141-aaec1e62e2a1', '100820', false, false, NULL, 100820, 1008);
INSERT INTO "e-izin"."AtikKod" VALUES ('faf9d336-4990-4298-a50a-b56af7884053', '2023-07-24 11:06:19.283278', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Organik Boyaların ve Pigmentlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar(06 11 dışındaki)', NULL, '2ed155b3-66a6-455e-9b6f-f2af44d782c9', '0703', false, true, NULL, 703, 7);
INSERT INTO "e-izin"."AtikKod" VALUES ('fb2bb42e-dbb5-4480-b67c-9eb47828af9d', '2023-07-24 11:06:19.270941', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gaz arıtımından kaynaklanan katı atıklar', 1, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190107', true, true, NULL, 190107, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('fb2eade8-bc6f-4ebc-8e04-090f973f1fcc', '2023-07-24 11:06:19.21862', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '06 06 02 dışındaki kükürt bileşenlerini içeren atıklar', NULL, '15b7a42d-7d99-4839-968d-919db1997c62', '060603', false, false, NULL, 60603, 606);
INSERT INTO "e-izin"."AtikKod" VALUES ('fb385980-adf8-4d52-990a-319c7bead4bb', '2023-07-24 11:06:19.280314', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 01 20 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, 'b4bad47b-4a96-4f0f-83a9-6dd36a6858e6', '100121', false, false, NULL, 100121, 1001);
INSERT INTO "e-izin"."AtikKod" VALUES ('fb5f77b8-3d87-4b9e-bd44-3dfc732d377f', '2023-07-24 11:06:19.258173', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli madde içeren diğer maden atıkları', 1, '1491cfb8-0c3c-4e7a-9ee8-c9a8fa898197', '010305', true, true, NULL, 10305, 103);
INSERT INTO "e-izin"."AtikKod" VALUES ('fb657553-47ba-4711-84af-b13e3c533180', '2023-07-24 11:06:19.265737', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Standart Dışı Gruplar ve Kullanılmamış Ürünler', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1603', false, true, NULL, 1603, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('fb6df1a9-868f-471e-96a9-28a81b446695', '2023-07-24 11:06:19.226502', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer motor, şanzıman ve yağlama yağları', 2, 'dff8bb04-5506-4de9-980b-42baa9dd737b', '130208', true, true, true, 130208, 1302);
INSERT INTO "e-izin"."AtikKod" VALUES ('fb948f75-4819-49ba-895d-b495f0a5e675', '2023-07-24 11:06:19.277703', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Kurşun Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, 'dc5edbf5-26da-4d21-abb9-0d3dab206e42', '1004', false, true, NULL, 1004, 10);
INSERT INTO "e-izin"."AtikKod" VALUES ('fbe2f9cf-f16e-4760-912e-c69fa1d7f219', '2023-07-24 11:06:19.246655', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Baca gazı arıtımından kaynaklanan kullanılmış aktif karbon', 1, 'ea3f21c6-5ad1-4bd3-bbbd-dc1a9bb0ac73', '190110', true, true, NULL, 190110, 1901);
INSERT INTO "e-izin"."AtikKod" VALUES ('fbe8bfb7-30b1-4121-b893-e6eeb07288ad', '2023-07-24 11:06:19.278723', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Henüz döküm yapılamamış, tehlikeli madde içeren maça ve kum döküm kalıpları', 1, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100905', true, true, NULL, 100905, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('fbfcdf62-5dae-4aff-9228-88e4ec3cf4d0', '2023-07-24 11:06:19.277212', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka Bir Şekilde Tanımlanmamış Kimyasal ve Kimyasal Ürünlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, '2ed155b3-66a6-455e-9b6f-f2af44d782c9', '0707', false, true, NULL, 707, 7);
INSERT INTO "e-izin"."AtikKod" VALUES ('fc2fa866-23dc-41cd-ab6f-b37fb93e4cae', '2023-07-24 11:06:19.255439', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Gümüş veya gümüş bileşenleri içermeyen fotoğraf filmi ve kağıdı', NULL, '8693d445-ccb1-423b-8380-a415bab62bb1', '090108', false, false, NULL, 90108, 901);
INSERT INTO "e-izin"."AtikKod" VALUES ('fc6486a5-e37f-473a-9951-13886138586f', '2023-07-24 11:06:19.244812', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Plastik', NULL, '5f698a7c-9552-4587-8c62-7c644edb7a9f', '170203', false, false, NULL, 170203, 1702);
INSERT INTO "e-izin"."AtikKod" VALUES ('fc9f2ffe-b9e0-4db5-983b-ef430ace89fb', '2023-07-24 11:06:19.265561', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren çamurlar ve filtre kekleri', 1, 'd1130030-860a-4c1b-b820-5c3fc1e10ff3', '110109', true, true, NULL, 110109, 1101);
INSERT INTO "e-izin"."AtikKod" VALUES ('fcf173e3-5390-4771-8893-66cb6c204fa6', '2023-07-24 11:06:19.252333', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '0d2e43b6-d911-48b7-b2f7-e14d3d09d62c', '100999', false, false, NULL, 100999, 1009);
INSERT INTO "e-izin"."AtikKod" VALUES ('fcf7052f-6471-4238-bfd9-a9b918f118ce', '2023-07-24 11:06:19.234477', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Elektrikli ve Elektronik Ekipman Atıkları', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1602', false, true, NULL, 1602, 16);
INSERT INTO "e-izin"."AtikKod" VALUES ('fcfc4ab8-091f-4739-acb2-c35f134f93db', '2023-07-24 11:06:19.220832', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Ömrünü tamamlamış lastikler', 2, 'be0cd99b-3c0d-4669-8755-2e1a5d32e20e', '160103', false, false, NULL, 160103, 1601);
INSERT INTO "e-izin"."AtikKod" VALUES ('fd574f1f-d86b-4860-bff5-f1ada7c0e664', '2023-07-24 11:06:19.248397', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış atıklar', NULL, '02ad50ac-b89e-4b16-a98e-1931776eea3b', '190999', false, false, NULL, 190999, 1909);
INSERT INTO "e-izin"."AtikKod" VALUES ('fd62c928-cb97-4d90-81c8-3af8ccc039e3', '2023-07-24 11:06:19.281717', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', 1, 'a0409021-e3ca-4143-84f8-c328b436acf7', '040219', true, true, NULL, 40219, 402);
INSERT INTO "e-izin"."AtikKod" VALUES ('fd8c7443-a18e-4969-8eb9-70a03ac60fba', '2023-07-24 11:06:19.227006', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Tehlikeli maddeler içeren diğer kalıntılar', 1, '87472e6e-58cd-47da-8f27-282cbb95f77b', '191005', true, true, NULL, 191005, 1910);
INSERT INTO "e-izin"."AtikKod" VALUES ('fd8ec8aa-9bf3-4997-83f8-fd22cf06dc66', '2023-07-24 11:06:19.246235', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diş tedavisinden kaynaklanan amalgam atıkları', 1, '6f26f417-d2b4-4afe-8b1b-a84200e6c80d', '180110', true, true, NULL, 180110, 1801);
INSERT INTO "e-izin"."AtikKod" VALUES ('fd939d70-c8b4-4914-b73e-28057f79915e', '2023-07-24 11:06:19.208982', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Diğer asitler', 1, '2cc8b711-0e7d-4aeb-a8de-9e7d57836ef5', '060106', true, true, NULL, 60106, 601);
INSERT INTO "e-izin"."AtikKod" VALUES ('fe13812b-3689-4f90-a187-8b1728d38a6c', '2023-07-24 11:06:19.26139', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmayan atıklar', NULL, 'c746097f-76b0-4c0f-9bc2-314e3947c853', '020799', false, false, NULL, 20799, 207);
INSERT INTO "e-izin"."AtikKod" VALUES ('fe3eb3cb-7c16-433f-a14a-40b4aa225d15', '2023-07-24 11:06:19.278963', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Henüz döküm yapılamamış, tehlikeli madde içeren maça ve kum döküm kalıpları', 1, 'f60c1e8e-6d68-48f9-ac10-17c568685d4e', '101005', true, true, NULL, 101005, 1010);
INSERT INTO "e-izin"."AtikKod" VALUES ('feb88e5f-8f43-4280-b8c6-fec4f5f378bb', '2023-07-24 11:06:19.22929', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Su ve Buhar Yağ Alma İşlemlerinden Kaynaklanan Atıklar (11 Hariç)', NULL, 'f523a624-adf1-4c08-ac9f-9e822c12d922', '1203', false, true, NULL, 1203, 12);
INSERT INTO "e-izin"."AtikKod" VALUES ('ff548696-5f38-43b2-ac3d-627717cb454c', '2023-07-24 11:06:19.260064', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, '08697385-2b61-4344-afd0-169b00c005ea', '020204', false, false, NULL, 20204, 202);
INSERT INTO "e-izin"."AtikKod" VALUES ('ff766a92-7540-4a06-97f2-f277451cd9e8', '2023-07-24 11:06:19.278017', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, '10 05 08 dışındaki soğutma suyu arıtma atıkları', NULL, '3b4a20a2-c147-4b99-b9bb-750194453116', '100509', false, false, NULL, 100509, 1005);
INSERT INTO "e-izin"."AtikKod" VALUES ('ffc856a2-3bb3-4047-9813-2ade31e1f019', '2023-07-24 11:06:19.228198', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Başka bir şekilde tanımlanmamış yağ atıkları', NULL, 'd7bf6b00-841e-4840-ba5b-3e2c3b77bf21', '1308', false, true, NULL, 1308, 13);
INSERT INTO "e-izin"."AtikKod" VALUES ('ffee3666-7a2b-4281-8460-44408303217f', '2023-07-24 11:06:19.243246', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 'Piller ve Aküler', NULL, '040ec76c-7a24-49c3-8f7d-08e4c347ffc9', '1606', false, true, NULL, 1606, 16);


--
-- Data for Name: Basvuru; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."Basvuru" VALUES ('36f818f3-cee9-4f59-bcaf-7d987ea44ab4', '2023-07-21 08:54:05.553029', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 14:15:18.209559', 'd349697c-9816-417f-a80f-c82475decc4a', 3, 0, 'd349697c-9816-417f-a80f-c82475decc4a', '00000000-0000-0000-0000-000000000000', NULL, true, false, 1, NULL);
INSERT INTO "e-izin"."Basvuru" VALUES ('a2b72c83-d200-4f76-aa0b-6e8626f67fac', '2023-08-08 12:10:51.053574', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 12:16:56.913222', 'd349697c-9816-417f-a80f-c82475decc4a', 3, 0, 'd349697c-9816-417f-a80f-c82475decc4a', 'ff3124f4-ce91-4289-9658-511367978580', NULL, true, true, 1, NULL);
INSERT INTO "e-izin"."Basvuru" VALUES ('be7242d4-f8f1-441d-80bd-5835df40177a', '2023-07-24 09:31:58.745525', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-08-08 13:36:01.125659', 'd349697c-9816-417f-a80f-c82475decc4a', 3, 1, '3fbbe160-6d02-408a-83f5-a556efe95841', 'ff3124f4-ce91-4289-9658-511367978580', NULL, true, true, 1, 'acıklama');
INSERT INTO "e-izin"."Basvuru" VALUES ('eb61c976-3f46-4dc2-b699-7aac154fbcd2', '2023-08-08 08:55:09.572466', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 09:49:49.517313', 'd349697c-9816-417f-a80f-c82475decc4a', 3, 0, 'd349697c-9816-417f-a80f-c82475decc4a', '00000000-0000-0000-0000-000000000000', NULL, false, false, 0, NULL);
INSERT INTO "e-izin"."Basvuru" VALUES ('671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', '2023-08-11 18:07:38.317811', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, NULL, 1, 0, 'd349697c-9816-417f-a80f-c82475decc4a', 'ff3124f4-ce91-4289-9658-511367978581', NULL, true, true, 1, NULL);
INSERT INTO "e-izin"."Basvuru" VALUES ('84bfab1b-cfe6-49bf-b917-102405792afc', '2023-07-19 10:20:35.241933', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-08-13 16:06:54.320864', 'd349697c-9816-417f-a80f-c82475decc4a', 1, 0, '3fbbe160-6d02-408a-83f5-a556efe95841', '32640531-b268-4498-8b23-0ac803093180', NULL, true, true, 1, 'Açıklama');
INSERT INTO "e-izin"."Basvuru" VALUES ('a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', '2023-08-11 16:26:12.471441', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:28:06.768063', 'd349697c-9816-417f-a80f-c82475decc4a', 1, 1, 'd349697c-9816-417f-a80f-c82475decc4a', 'ff3124f4-ce91-4289-9658-511367978581', NULL, true, false, 1, 'Yeni Açıklama');


--
-- Data for Name: BasvuruAtikKod; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."BasvuruAtikKod" VALUES ('4db27cf5-df34-45af-9143-0da82cf3bd7f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-02 14:05:27.149615', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '18c30097-def9-492d-b700-7fce7a0c8032');
INSERT INTO "e-izin"."BasvuruAtikKod" VALUES ('898bd149-58c0-4fd2-8503-b8b1c1772a9f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-02 14:05:27.152114', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '13483503-0f16-43cc-8de7-f4c84f39352e');
INSERT INTO "e-izin"."BasvuruAtikKod" VALUES ('f1236f0a-8160-43e6-b7b5-e6014a370b11', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-04 14:11:14.119712', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '09620607-d79c-446f-8091-e42c5a4fcea7');
INSERT INTO "e-izin"."BasvuruAtikKod" VALUES ('53aa9a44-568e-461b-8a79-3950d7cd2ebf', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:32:51.735841', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', '09620607-d79c-446f-8091-e42c5a4fcea7');
INSERT INTO "e-izin"."BasvuruAtikKod" VALUES ('774fcee9-b523-4156-b6b3-2e85c50f7a8a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:32:51.746434', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', '852bac72-dc82-447f-a3cc-7c96970ea7dd');
INSERT INTO "e-izin"."BasvuruAtikKod" VALUES ('ca681079-17fe-4b67-a43e-53fd731ce8ed', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:32:51.746649', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'c50973f8-5259-4f6f-89ea-cc26b9a491cb');
INSERT INTO "e-izin"."BasvuruAtikKod" VALUES ('163bc015-9f55-467c-adba-e646342d2c9a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:12.6299', NULL, NULL, 1, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', '2d5c0b02-f86d-4751-8030-1e2f3abd0b02');
INSERT INTO "e-izin"."BasvuruAtikKod" VALUES ('585533ce-900f-490b-b421-cc511c10b1a3', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:12.644656', NULL, NULL, 1, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', '5b5ec0b1-dfa1-44ad-9537-b1f130cb9050');


--
-- Data for Name: BasvuruDRKod; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('2833a7ba-8af6-4285-a682-e5670c5f08bc', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:43:18.909653', NULL, NULL, 1, 'be7242d4-f8f1-441d-80bd-5835df40177a', 'b7cc1333-4266-408f-be0a-8f809ab39b3a');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('d1155ad4-297b-49c4-82e7-145267550f8e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:43:18.903493', NULL, NULL, 1, 'be7242d4-f8f1-441d-80bd-5835df40177a', '2681d116-5302-4269-a879-06f8070a6dde');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('2c033c86-8249-4cf2-b190-a5019cc1f9e5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:54:44.208079', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '2681d116-5302-4269-a879-06f8070a6dde');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('46d816a4-6aa0-4e58-94a1-a0b7a8a11c91', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:54:44.21006', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '60083ecf-5628-4f88-8e8a-fdc22f71b522');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('774a0938-2e23-4106-880e-3cb55105fae2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:54:44.209682', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'fd9e626f-4420-4551-a091-dd376cd83f94');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('84ccb72d-5eb4-498f-a779-14807d83df72', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:54:44.209879', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '315628d4-11b0-4c1d-885f-8451798676ee');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('d9908300-4ece-4059-8c0f-309441bd4f5e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:54:44.209359', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'b7cc1333-4266-408f-be0a-8f809ab39b3a');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('50b147a4-5ac7-4995-9b08-b311335241cf', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:33:27.17536', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'e3ddf85b-bf6d-422c-b7e3-989e8e728b53');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('72c574d3-4f41-4b99-a497-70b229efb502', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:33:27.163924', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', '2681d116-5302-4269-a879-06f8070a6dde');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('821b22eb-2f2f-4bd7-8781-e30ad47388cc', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:33:27.175712', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', '315628d4-11b0-4c1d-885f-8451798676ee');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('b8f11375-6d76-4c4e-aa9f-0eb6ea1a1713', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:33:27.174919', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'fd9e626f-4420-4551-a091-dd376cd83f94');
INSERT INTO "e-izin"."BasvuruDRKod" VALUES ('44afcbf2-41a5-4a41-a350-0fe9120cff52', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:16.832927', NULL, NULL, 1, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'b7cc1333-4266-408f-be0a-8f809ab39b3a');


--
-- Data for Name: BasvuruIzinKonu; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."BasvuruIzinKonu" VALUES ('b5ebe0c6-47a9-4787-a742-18ffa07f4ad9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:27:40.099212', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:29:31.31028', 1, true, false, true, false, NULL, 'ttwesa', 'ttwesa', 'ttt', 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6');
INSERT INTO "e-izin"."BasvuruIzinKonu" VALUES ('3ad97b05-d926-44cd-9e06-e67cb9ea49e5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:07:53.287635', NULL, NULL, 1, true, false, true, true, NULL, 'tesr', 'tesr', NULL, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b');
INSERT INTO "e-izin"."BasvuruIzinKonu" VALUES ('160204b4-518a-4f91-b4d1-bd040927398e', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-21 15:54:56.075019', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-13 16:10:44.849825', 1, true, true, false, false, 'Muaf iştetyt', 'Nedencctyt', 'Nedencctyt', 'Neden3cccvv7879', '84bfab1b-cfe6-49bf-b917-102405792afc');
INSERT INTO "e-izin"."BasvuruIzinKonu" VALUES ('36ca58fa-1564-43b8-9836-90649f433e61', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-24 09:33:19.9132', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:39:06.159219', 1, true, true, false, true, 'Muaf', NULL, NULL, NULL, 'be7242d4-f8f1-441d-80bd-5835df40177a');


--
-- Data for Name: BasvuruKapsam; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('87c1b58b-7ee1-4e59-8b13-d9aca7f7c09b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 10:12:10.892233', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'c5bdab95-0899-41e8-946d-afc641065fb4', 2);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('0f7abf73-6677-4dc4-a1d4-8846975ce192', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 10:18:18.81599', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '0a586c20-ad0b-442d-bba5-3c47cab4b20b', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('3f91e678-5113-4a3e-8c53-4c495da88fde', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 10:18:18.804186', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '1c767e07-eed2-4ba3-a171-ca759737010f', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('f9e57e5c-3a88-4348-a014-16a47b37d33b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 10:18:18.816893', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '2f656222-981f-4fdd-8910-8a29fd6e2c95', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('977718c6-5734-4007-ad9c-fc3b04217588', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:10:05.980393', NULL, NULL, 1, 'be7242d4-f8f1-441d-80bd-5835df40177a', 'ef486d4b-830e-49fd-91a1-289e97f9a478', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('63d1a1b1-5410-4eb9-b651-9027856ff316', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:58:42.322276', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '8dd5b85c-3544-40ad-b619-4d28d1f0440c', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('9ac252bc-1b3d-41ca-8c3a-025c9434f1bb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:58:42.311637', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'e5b8b31b-556b-440f-82c7-ee06370f9fdf', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('d0dfab49-b17d-4de5-9dff-bb1b75a331f8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:58:42.32316', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '5c6f69a7-4e36-4b93-93c5-45b61f27d44b', 2);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('29b7f7da-a54b-489a-9245-38405170bd77', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:36:01.172614', NULL, NULL, 1, 'be7242d4-f8f1-441d-80bd-5835df40177a', '41ea061e-1251-429b-8d69-bdc48fb9aed7', 2);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('5bf436b2-49fb-437b-aa17-eb5bc75daf6d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 14:15:18.284751', NULL, NULL, 1, '36f818f3-cee9-4f59-bcaf-7d987ea44ab4', 'ef486d4b-830e-49fd-91a1-289e97f9a478', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('895e5438-9132-4bcf-946c-3b3128f28527', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 14:22:34.992267', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '41ea061e-1251-429b-8d69-bdc48fb9aed7', 2);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('4d5b0363-6fc6-4a81-bc64-406006addc79', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 12:14:19.727545', NULL, NULL, 1, 'a2b72c83-d200-4f76-aa0b-6e8626f67fac', 'e71b2c51-3619-40e1-ac72-062a0a8dcbdb', 2);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('58d3d139-d27d-41ab-a976-66976556489b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 12:14:19.726836', NULL, NULL, 1, 'a2b72c83-d200-4f76-aa0b-6e8626f67fac', '704d489f-67bf-4c45-bc43-43ee88dfb454', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('6f03f807-5c8b-495d-982d-90d44a9667cd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 12:14:19.720977', NULL, NULL, 1, 'a2b72c83-d200-4f76-aa0b-6e8626f67fac', 'ef486d4b-830e-49fd-91a1-289e97f9a478', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('925abc43-2c25-41d1-8d8a-2a9f512891e9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 12:14:19.727314', NULL, NULL, 1, 'a2b72c83-d200-4f76-aa0b-6e8626f67fac', '5c6f69a7-4e36-4b93-93c5-45b61f27d44b', 2);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('0d821754-937c-4c1e-8e1f-34780cdde144', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:26:12.538846', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'e5b8b31b-556b-440f-82c7-ee06370f9fdf', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('f0f24255-b55a-48fd-985d-e0185b64eb71', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:26:12.541658', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', '8dd5b85c-3544-40ad-b619-4d28d1f0440c', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('f57f648c-a017-4db4-ac8d-dec805e2bf77', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:26:53.316959', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'aad3783d-713f-4533-9121-055caefe0144', 1);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('7bbb30da-8519-4a28-81ee-3df1c0992a99', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:07:38.470614', NULL, NULL, 1, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', '876ffd05-5473-4e3f-8cee-6b19d8847704', 2);
INSERT INTO "e-izin"."BasvuruKapsam" VALUES ('984785c7-45b2-4fbe-92d6-ab33be2db182', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:07:38.448873', NULL, NULL, 1, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', '40811975-c92e-4cb2-91e5-bd080024356f', 1);


--
-- Data for Name: BasvuruLisansKonu; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."BasvuruLisansKonu" VALUES ('14a58c0d-5d60-4ed1-8903-ffeb96fcfe60', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:39:06.160041', NULL, NULL, 1, 'be7242d4-f8f1-441d-80bd-5835df40177a', '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."BasvuruLisansKonu" VALUES ('aece9f17-cdda-413e-a277-92bdadd4664f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-10 13:39:46.810138', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."BasvuruLisansKonu" VALUES ('cda3a652-be9c-4912-931b-78c3cce5399c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-10 13:39:46.78732', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."BasvuruLisansKonu" VALUES ('2a9245b9-6994-4920-9acf-05fbfacc8445', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:27:40.115146', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."BasvuruLisansKonu" VALUES ('d84ab16c-9c35-46dd-a8e7-a2b63bcfc45c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:27:40.122035', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', '1a6ee288-dc92-43f8-a055-b48d381d58b5');


--
-- Data for Name: BasvuruNot; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."BasvuruNot" VALUES ('505c1838-194f-42f1-adc7-b0efc0589172', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 12:30:37.327481', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'Deneme Firma', 'Deneme1', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('9fbc56e8-be3f-4ec6-8ad0-13e335159a3a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 12:31:07.252863', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'Firma', 'Deneme2', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('c55c2962-c8e3-46b1-928f-d9bc4c331bfa', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 13:23:40.400325', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'Deneme Firma', 'Firma3', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('c2ab7992-eb81-4550-bf65-955309e06ce8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 17:35:29.828828', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Deneme Uzman', 'Deneme1', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('546868b1-6a24-4e88-98fd-0fc3d88afc76', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 17:44:14.742615', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Deneme Uzman', 'Deneme Uzman 2', false);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('ce8b148d-8a38-4395-8f43-bd4b1335acd1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 17:48:02.84933', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Deneme Uzman Yeni', 'Deneme 3', false);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('a180f78d-c5b4-4cad-950b-211f48a83823', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 17:50:42.282239', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Deneme Yeni', 'Yeni', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('ea8eb2c8-91fc-4eec-a98a-2a93305ef385', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 18:34:44.826475', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Yeni Konu', 'Daha Yeni', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('3ef12d4d-82de-4d2b-a788-41fe0f82caa2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 18:35:49.259444', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Deneme 35', '35', false);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('e0d59899-a2be-4f10-a5d0-c9a548a14cab', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 18:37:29.547756', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Firma', 'Firma Görsün', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('3b22ba83-e6f5-4585-a1d4-ccb9c8b905fd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 19:09:03.166834', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Son Konu', 'Son Not', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('ff0fc748-4ed6-4a4b-a5e4-3fbbbdcb1961', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 19:10:22.397863', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Son Not Yeni', 'en Yeni', false);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('cab49da8-68f9-4131-ada8-7c355ca9e0b9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 19:12:19.425069', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Firma', NULL, true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('c6f826c2-912f-4583-a792-f07a157a004f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 19:13:14.408081', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Merhaba', NULL, true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('8f06ae4a-6848-4784-a708-1e8d04bfcbc1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 19:16:06.635498', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Firmalar', 'Firmalar', true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('5bf0bac0-e56e-494a-8435-fc65ca86d1e6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 19:18:03.081281', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Firma', NULL, true);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('44d59ff7-256a-4069-8085-b3af35fc46b4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 20:01:59.495668', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'Firma4', 'Firma4', false);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('dffd68fe-250b-4b94-b673-db92a74e0bbe', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 20:04:07.245598', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'Firma5', 'Firma55', false);
INSERT INTO "e-izin"."BasvuruNot" VALUES ('15b9fcd5-7ddf-44cf-851f-1ec79fe3e40b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-17 11:17:06.266395', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'Test', 'test test', false);


--
-- Data for Name: BasvuruOzet; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."BasvuruOzet" VALUES ('70403f4a-0739-415a-a496-2e2c0e8032c2', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 11:05:58.548491', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.415381', 1, 3, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Yeni Vaziyet yeni', 'Ankara İli, Çankaya İlçesi, İlker Beldesi, Hacılar Köyü, Test mevkiinde, tapunun 4145616 pafta, 123456 ada, 45646156 parsel numarasında kayıtlı, 750 m2 yüzölçümlü alan üzerinde, 1300 m2 yüzölçümlü kapalı alanda yer almaktadır. İşletme Termik Santral konu/konularında faaliyet göstermekte olup, Hava Emisyonları izin ve Çevresel Gürültü lisans konu/konuları için başvuruda bulunulmuştur. İşletme yukarıda belirtilen adreste bina sahibi/kiracı olarak faaliyet göstermektedir. yeni', 'bb9a030d-a5a5-4d33-bc28-3369f9f489f4');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('71c0ca18-d0ad-459a-ac62-7d1089684f31', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-27 18:11:41.163621', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.346789', 1, 2, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Merhaba', '<p>yuyuyjmökjloıoıuoı</p>', '7f85760b-be97-4628-8458-87b86c34e589');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('75fe7073-711b-4d59-9ca6-c3d11cab39f9', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 11:05:58.549877', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.485452', 1, 4, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Atık Başlık Atık', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('7f85760b-be97-4628-8458-87b86c34e589', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-26 21:27:29.106377', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.34604', 1, 2, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Ana Faaliyet', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('a2fad064-96bb-40b1-9b41-0b5dcfcbe28b', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 11:05:58.502571', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.346794', 1, 2, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Açıklama', 'Ankara İli, Çankaya İlçesi, İlker Beldesi, Hacılar Köyü, Test mevkiinde, tapunun 4145616 pafta, 123456 ada, 45646156 parsel numarasında kayıtlı, 750 m2 yüzölçümlü alan üzerinde, 1300 m2 yüzölçümlü kapalı alanda yer almaktadır. İşletme Termik Santral konu/konularında faaliyet göstermekte olup, Hava Emisyonları izin ve Çevresel Gürültü lisans konu/konuları için başvuruda bulunulmuştur. İşletme yukarıda belirtilen adreste bina sahibi/kiracı olarak faaliyet göstermektedir. bnbmbmb', '7f85760b-be97-4628-8458-87b86c34e589');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('bb9a030d-a5a5-4d33-bc28-3369f9f489f4', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-26 21:27:29.128265', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.414939', 1, 3, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Vaziyet Ana Başlık', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('1eed04d8-ded5-444d-9d35-49b3770e6f74', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 14:35:59.336479', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.486031', 1, 4, '84bfab1b-cfe6-49bf-b917-102405792afc', 'gjhjhjh', 'Ankara İli, Çankaya İlçesi, İlker Beldesi, Hacılar Köyü, Test mevkiinde, tapunun 4145616 pafta, 123456 ada, 45646156 parsel numarasında kayıtlı, 750 m2 yüzölçümlü alan üzerinde, 1300 m2 yüzölçümlü kapalı alanda yer almaktadır. İşletme Termik Santral konu/konularında faaliyet göstermekte olup, Hava Emisyonları izin ve Çevresel Gürültü lisans konu/konuları için başvuruda bulunulmuştur. İşletme yukarıda belirtilen adreste bina sahibi/kiracı olarak faaliyet göstermektedir.', '75fe7073-711b-4d59-9ca6-c3d11cab39f9');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('2363a2a9-d4e1-4cbe-9635-c7b50e51471f', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 15:07:37.532345', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-01 11:21:34.501152', 1, 6, '84bfab1b-cfe6-49bf-b917-102405792afc', '.', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('287bef64-eb07-4dcc-afc9-4b5625740baa', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 14:35:59.336641', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.486038', 1, 4, '84bfab1b-cfe6-49bf-b917-102405792afc', 'tytoyktoyktoky', 'Ankara İli, Çankaya İlçesi, İlker Beldesi, Hacılar Köyü, Test mevkiinde, tapunun 4145616 pafta, 123456 ada, 45646156 parsel numarasında kayıtlı, 750 m2 yüzölçümlü alan üzerinde, 1300 m2 yüzölçümlü kapalı alanda yer almaktadır. İşletme Termik Santral konu/konularında faaliyet göstermekte olup, Hava Emisyonları izin ve Çevresel Gürültü lisans konu/konuları için başvuruda bulunulmuştur. İşletme yukarıda belirtilen adreste bina sahibi/kiracı olarak faaliyet göstermektedir.', '75fe7073-711b-4d59-9ca6-c3d11cab39f9');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('33206bc2-5866-4457-9dce-7167d8d3e0ea', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 12:32:05.998562', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.486043', 1, 4, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Niyazi', 'Ankara İli, Çankaya İlçesi, İlker Beldesi, Hacılar Köyü, Test mevkiinde, tapunun 4145616 pafta, 123456 ada, 45646156 parsel numarasında kayıtlı, 750 m2 yüzölçümlü alan üzerinde, 1300 m2 yüzölçümlü kapalı alanda yer almaktadır. İşletme Termik Santral konu/konularında faaliyet göstermekte olup, Hava Emisyonları izin ve Çevresel Gürültü lisans konu/konuları için başvuruda bulunulmuştur. İşletme yukarıda belirtilen adreste bina sahibi/kiracı olarak faaliyet göstermektedir. nmöç', '75fe7073-711b-4d59-9ca6-c3d11cab39f9');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('533616ea-ec27-48b7-bba8-e110785937a7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-31 17:41:48.332258', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.633057', 1, 7, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Ek Ana Başlık 22', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('5e8230de-9d56-437e-9758-dd3f74aaa539', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 15:07:37.514274', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.564679', 1, 5, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Emisyon', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('9283ac7e-d325-487e-907e-38781146a42a', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 14:34:47.420852', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.486045', 1, 4, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Şemsettin', 'Ankara İli, Çankaya İlçesi, İlker Beldesi, Hacılar Köyü, Test mevkiinde, tapunun 4145616 pafta, 123456 ada, 45646156 parsel numarasında kayıtlı, 750 m2 yüzölçümlü alan üzerinde, 1300 m2 yüzölçümlü kapalı alanda yer almaktadır. İşletme Termik Santral konu/konularında faaliyet göstermekte olup, Hava Emisyonları izin ve Çevresel Gürültü lisans konu/konuları için başvuruda bulunulmuştur. İşletme yukarıda belirtilen adreste bina sahibi/kiracı olarak faaliyet göstermektedir.', '75fe7073-711b-4d59-9ca6-c3d11cab39f9');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('a6945c63-308d-4625-8947-23ec63e8704c', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 14:34:47.234066', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.262108', 1, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'İşletme Özeti', '<span style="letter-spacing: 0.1px;">Ankara İli, Çankaya İlçesi, İlker Beldesi, Hacılar Köyü, Test mevkiinde, tapunun 4145616 pafta, 123456 ada, 45646156 parsel numarasında kayıtlı, 750 m2 yüzölçümlü alan üzerinde, 1300 m2 yüzölçümlü kapalı alanda yer almaktadır. İşletme Termik Santral konu/konularında faaliyet göstermekte olup, Hava Emisyonları izin ve Çevresel Gürültü lisans konu/konuları için başvuruda bulunulmuştur. İşletme yukarıda belirtilen adreste bina sahibi/kiracı olarak faaliyet göstermektedir.</span>', NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('9f79fae3-ff45-4a7d-a538-23e416712c3e', '3fbbe160-6d02-408a-83f5-a556efe95841', '2023-07-28 15:31:22.279938', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-01 11:21:34.501514', 1, 6, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Atık Su', '<p>Atık su Açıklama</p>', '2363a2a9-d4e1-4cbe-9635-c7b50e51471f');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('1c01bdc7-077a-482d-b153-c6fe1f02d844', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:42:10.490403', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 16:30:01.122111', 1, 3, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'ttt', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('30174b56-d5c0-4069-8c5a-87ceb462ac36', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:42:10.491334', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 16:30:01.275839', 1, 5, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'taes', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('4860eebe-d14b-40f5-a86b-89cdafe6e95e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-31 18:01:21.645775', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-01 11:21:34.501517', 1, 6, '84bfab1b-cfe6-49bf-b917-102405792afc', 'başlık', '<p>başlık&nbsp;<img style="width: 703.422px;" src="https://source.ucbs.app/img/ucbs-logo-dark.png"></p>', '2363a2a9-d4e1-4cbe-9635-c7b50e51471f');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('463a98c0-8d41-4cb7-ab72-aab58f6c6e0a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:42:10.463791', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 16:30:00.991124', 1, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'İşletme Özeti', '<p>test</p>', NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('9f23bb3f-d659-4de7-afb8-7c7149a69580', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:42:10.489465', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 16:30:01.047042', 1, 2, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'ttest', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('cbdf9434-2f68-41c2-8dbf-32ec5ab22da5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:42:10.492351', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 16:30:01.350021', 1, 6, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'asdsa', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('d95d82a2-b156-4043-85f7-7d201547f137', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:42:10.491011', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 16:30:01.20255', 1, 4, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'tt1', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('dec628f5-8682-48a4-8d16-424b0441a9f5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:42:10.492705', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 16:30:01.43401', 1, 7, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'tt', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('2c3a6073-ee11-48ed-97b1-a4d3d146cf27', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:48:10.59255', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:44:12.645476', 1, 1, 'be7242d4-f8f1-441d-80bd-5835df40177a', 'İşletme Özeti', '<p><br></p>', NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('36b8491a-f444-45c6-bd9f-a659f9c57d39', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:48:10.592856', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:44:12.718983', 1, 3, 'be7242d4-f8f1-441d-80bd-5835df40177a', 'y', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('b642f02c-b0d7-4715-a69c-d655b80b9ed0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:48:10.593134', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:44:12.78849', 1, 7, 'be7242d4-f8f1-441d-80bd-5835df40177a', 'sadsadsa', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('bc0b2f23-df13-4c11-ad61-c4fc4d03fc54', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:42:38.49228', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:44:12.765783', 1, 5, 'be7242d4-f8f1-441d-80bd-5835df40177a', '', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('bdde6e3b-d1ab-4c30-851b-7458cf79ab6b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:48:10.592764', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:44:12.696843', 1, 2, 'be7242d4-f8f1-441d-80bd-5835df40177a', 'yy', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('ca808d76-882d-48c2-9254-2c736892f9a7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 11:48:10.592994', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:44:12.738808', 1, 4, 'be7242d4-f8f1-441d-80bd-5835df40177a', 'y', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('1b473ab3-ae68-4f19-9eb9-3399c2ed8112', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:13:41.304018', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-15 18:15:30.803851', 1, 5, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'test', '<p>test</p>', '95c4361e-0de8-4b2e-bebf-3dc4420c9278');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('2de5c3e6-1cc1-4fb8-a76a-c8bd8acb7a19', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:40.806618', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-15 18:15:30.922386', 1, 7, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'sadsad', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('47e6eb7c-4a23-472f-8dfa-f15bf6fe352e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:40.787425', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-15 18:15:30.54888', 1, 1, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'İşletme Özeti', '<p>dsadsa</p>', NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('568768a3-f6da-4d1e-9afc-a59145c9c9c5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:40.805927', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-15 18:15:30.613888', 1, 2, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'sadsada', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('7c98f31f-d36e-4903-b076-d9c4fd448e54', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:40.806097', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-15 18:15:30.68217', 1, 3, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'asdsa', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('8321ecb0-709a-420b-9cd5-dc4986b8a996', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:40.80624', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-15 18:15:30.741729', 1, 4, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'sadsa', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('95c4361e-0de8-4b2e-bebf-3dc4420c9278', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:40.806384', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-15 18:15:30.802998', 1, 5, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'sdsadsa', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('e97de76f-0cfd-40e5-8b51-48ef5a53e772', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:40.806532', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-15 18:15:30.862087', 1, 6, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', 'sadsadsa', NULL, NULL);
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('2d6bea75-280d-48c6-8079-c0764f2753b2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-31 17:56:21.938954', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.633464', 1, 7, '84bfab1b-cfe6-49bf-b917-102405792afc', '22 bnmfjf', '<h1><b>tytytyt</b>&nbsp;tty.&nbsp; <a href="https://localhost:7226/DanismanFirma/Ozet?basvuruKimlikRef=84bfab1b-cfe6-49bf-b917-102405792afc" target="_blank">bnbmbm</a>&nbsp;<img style="width: 703.422px;" src="https://source.ucbs.app/img/ucbs-logo-dark.png"></h1>', '533616ea-ec27-48b7-bba8-e110785937a7');
INSERT INTO "e-izin"."BasvuruOzet" VALUES ('3612e8c1-855d-4c9e-8a81-9bb0c3c58cb0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-01 09:38:51.990129', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-16 09:03:29.633468', 1, 7, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Merhaba', '<p>Merhaba&nbsp;&nbsp;<img style="width: 184px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALgAAAC4CAYAAABQMybHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RDhGOEE3RkM4QUFGMTFFQTkwNUZERUI0RjU5RDdDNjgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RDhGOEE3RkQ4QUFGMTFFQTkwNUZERUI0RjU5RDdDNjgiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpEOEY4QTdGQThBQUYxMUVBOTA1RkRFQjRGNTlEN0M2OCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpEOEY4QTdGQjhBQUYxMUVBOTA1RkRFQjRGNTlEN0M2OCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PjJd/UcAAFITSURBVHja7F0HYJPl1j5Jk+7dAi2lZbVQyh6yUUERUVDBgfu6Fff6ETeuq3IVUUQR9x5XwSsoTkD23pRRoHTvvUeS/zznS2ppv7Rpm7YJ9HhzgY7k+773vOd9znqOxmQyUYc0LFXVRsrLLaf0jFIqKqqk8nIDlZZWBxYUVHQvKakOr6ioDquqNoUajabOGg114leQhjT+pCFf/nVvDZEH/+nGL535Lav5qVfwn2VkomL+eyGZTPlGE+VoNZSl02kzXV1d0ry99Sk+Pq5JXl66BA8PXa6Xl546d/KgoCAPcnd36VgYG0TToeD1pbCwklJSiyk5uZgKCip1ZWXVA/hrMaWlVdH87T5aF02Ui1bTW6938dPpNOTiwurMWm0vwZLwZqFq3liVVUYyGowFBqPpOH89zt3N5aivr+thL099rLeP/kBYmHd1tzBvCghwJzteQoeCn05SUWGgpKQiio8vpJzc8gBW5uEFhZXD+NkMddW7DGaL2s/VVUus1PzEFAVsl8XiFys6VbHSQ/n5z0O8Efayld/NSr8rIMBtZ88evnkRET4Ea98hZ7CC5+SUUypb6WPHCyg/v2JYTm7ZGEO1abSbm8sohgdRer1WLKIjPx6Lxa5mwINNyq84/udWVvQt/v5um3t0990V0d2HunT27FDwM0EYboiljj2US+npJeMYepyr1WrOdnfXTWDF9mhthba8v+WZA9bY8zMt71VVZaCyMkMZW/n1fG/rgoLc1/aPCdwY0d2XgoPcOxT8dBKDwURHj+bRCYYf8fEFQ4qLqia76DTn8RE+ibGzHkrWWo9AY/4/POPSkmqqqDTI311ctILbATWAtfnEEEiBr5FJ/mc3624wGKmstLqqotK42sPD5a+IcJ8/ekf674mK9CNPT32HgjurMOygo3H5FBub48/O4lTG0VO9vfRT9K7azm0HITR8alQIXmbFopAQL/L1cyXGy+TupmNntoLy+fuZGWV0MqGQKhlm+Ae4yQZojXUBlCkpqcpkKPNbp04eq/rHBK3q08c/v0sXzw4FdxZJSSmmvfuy6fix/Ji8/IrpbBmn8Wt8rRhFmyg2lDo7u5x69fSlUaNCqE+fgEave/+BHNq+PZ282LJ6+7iKdbfv9WpqrDvDM0SLNnh761f26uW3IqZfYGxj19ih4O0oCYlFtHdvFh05kjemtKRqhn+A+2Vubtqotr49KDccvkK2zOPHd6WJE8Ob9PsHWMl//z2Bqhla+Pm5mZW89a4VeJ1PuzitVvtjVJTf8oEDgzf3iw7sUHBHstgbN6YCY0+oqKi+MjDA/Qq9Xhtqd+NnI+6VpFBeOU2f1ouGDWseGsrKKqMPPzooYUmfGkveitetVeLuebkVaXwP33fr5v3fMWNC158OFt1pFTwjo5Q2b0mjw4fzRrPFvDogwG0W4+yQ9rwfWERc1/nnhdOECWEtei84xV9+eYj8fBmT6zRtdv1QdLbo6fzXbxm6fDNmdOiWHj18OxS8raS8vJrWb0ih7dsyoquqjNf5+btd56rX9jQ6wG0UF1VSUJA73X77QKs/U1paTTm5ZWQ0mNjZdCPemFZ/9tdfT9KWrenEDmGbxuNxEiH6VJBfEc8K/+WgQcFfnjsx/HCAv1uHgrem7N+fTatXJ/nl5JTf6B/gdqObq8sIXL8j3AGSnGlppTRrVh9iHKv6M3//nUw7dmRQZaVRoiR84lCv3n40/eJe5KZSW4KSgcXv7CUPd12bWfG6Ft0AyJVfscPD3eWz8ePDPhs3rmtBh4LbWVJTS2jNmiSGI7nTPT31NzMuneFo1834n/R6F7rzzoHk7q475Xu41P/9dJw2bUqjoED3mkIpRFqQUUWY7qabYsSprCs//BAnjmdgYPslaCxRl4KCiuXdu/t+zI7zishIf6dQcJd58+Y59AWuX59CP/54LDIzs/T/goM9nnNzcxnuiJsyL6+Shg7tRNEqEYg9ezJpxU8nKDzch/SuWgnWQWmQ2EFMHEVdJSVVNGCAmuXX8MmVRR4euna7NzxunDbe3q792AGevHt3ZiBDrQRW9lx83ZFF56gXlp5eQitWxNOx4/mzgoPc72TrNhEOkNHoeMqNDYfrQiKnrgDLApag2k9+1lj/+/g9ZFtxUnXteup7ANN7eOjF2re3MuE+/f3dg/la5rLhGRV3LP+9C6f0+DY6OqBDwZsiW9mx+v33hAg+9md3DfWazSrtB0VwVFEsnIb4dKnveBZXsnWvEFhi7eCBJYfzGR9fUE/BodQo/MIGcoSDC0quZYeja1fviXl55cM+/zx2yDnndHv3ggu6J3YoeCMC5+v774/S3j1ZF/r5u93TuZPnNIPR8X0ELDo2IFLhao6aQCqTxmr6XUMaswKrf99yajkSNMP9+vu7+VVWGub++WfigBPHCxZfNavPr+3pK6g6/45yIajFfnvRbtq3N+v+zl08F3l66KZVG0zm6jvHfkGUCr6qeveFRA37DlTEltxi7U/5XX6Vs4OK9HxUVIAKti+n7OyyfwqxHOgFJccJExrqNS0xqXDRO+/svX/XrswOC15XNm1MpRUrT3TX67QPdgnxelAsotG54vM4tpFVVYtAjB4dyo5mlig7oIxlU2jM3iZKeC+Y3J3Uip5Q8Yc4eGZGKfHGd7gadcu1dO7sGVlYWPnml18e6snPYeH06b0SOqIoLMuXH6Pff0sY5+frOs/H1/Vmo9GxmwysPkgXLeXmlNGw4V0EM9cWXnyJnOzamSkbV292FouLq8SxHDSoE828PFLVicSmGDGii1RHHj6cQ+5u+lM2iaMI1s3N1QXRntGxB3MiUlJLUvpFBybp9NozU8FxvH3ycSxt3ZI2k4+4ea6uLheYjM5bF+PCyommZERE2AGr933AD0RSSkuqpIQWceVA/veoUaF0zTV9G4yQ4HsDBgYLTNm7L0tqVKBMjhYuxeVolfqZfseOFfQ7fCQvLzo68FB7hjjbJdGDyMKHHx6ghITCO1gZ5vAl9CZnL2rUIFVfRb6+enrk0REN/mhaWonUfod1825y6G/LljR2xONYifTk7eXqkGFTgWy8GTMzS497uOvm33b7wKXdunmfGQqOxf3g/f1IQ89hzDmXFyjgdKlIh/XKSC+lkSO70FWz+rba56Bk4SM2EP7+buTppXdIJdeYlTw3pzyP//rK9df3mx/TP+j0hiiJiUX03pJ9bqWlVc+ywzTPaDCdVq0kUDNPDz0dOpQjf1eLitgicEi//uowIR2u1h0PZ7RTJ0/atjVdiZPrXMgRT0Aktfj6PSoqDJO2bUvX8TVvYjhqOC0V/ORJCQN684ExLzjY4wnG4Fo63cSE2mqNpNX37M6UdrR+/QLFstsqa9Ym0bL/HqXUtGLavy+H0CisFltGQsjbW0+sOGzFdfIZjljCgNOFnwfW+pyNG1JcWcm3hIV5V55WCn7sWD4sty8vwjxerEcdOStpL0fLi/Hxsbg8OnAgm51CLfn4ulllowJT1pEjefS/H49L84a3tytiyxJl2bo1jcK7+VAnFeoHKH9lpQGJMalpcdToEyIsaKzm02bcjh3p7r6+blvCI3wqTgsMnpRYSAsX7vbmm3uOlfthdHmfCWKhhEDEBC1siKCgQ6Y7KyXi2dgEWVmlUmgVdzQPDpmcAIFB7jXZT0RNQHUBurgHHhxG1ir4Fr+9R4xICL+vI+cPcM9SD59TtuCmm/o/e9bIkGKnVnBg7kVv7XbjG3s+IMBtzulsua0rumLVoeSIHuHIRkc9vDB8Dc8fFhvWXYEZdY5YVnLEwFFs9fAjI+rVqkBQifjKy9vkZ2DJjQ5sQ3CPCJHm5ZXPv/HGmGdYyVvVkrcaREFf4cIFO7GgzwYGuj1hNJyhFHHm29axonp66iQzieQHkkFwIPFC4kdT62dPddRMUk2IECTgzrhxYUravpbg+IfTiYYKbBbJkDro48aGxr1rNZpx27anmyJ7+68JCvZwLgWHRXnj9Z2ozZgT3MljHhxKSw/wGf0y1YYvmhrM3tjvwep7++il3zMttUQym2qRlTI+/g/szzZ34zv2c0DlJSv7+M2b08r7xQRv9G+ldjit/Xco0TuL9wBn3cGO0VzG3C4dqt3yF3wXOJ5bt6bSOrbUajJjZpRQK6NAS1NzJDjo/fAO9PFxddG6aOa+vWjXHYBhTqHgn392EE7TzJAQrzmMCQMQC+142etlYkfSi35cfkxqzOsKjv5LLuuNZmFpanb0+zFUmygowD2AT5457y3ZN7M1ElZ2VfCfV54ADhzXNcz7Ub7Y3rYcvx0v219Yfw/G8QgNfsGGRE3OOitECr4QR0dM3tHvCSXRXUI8e584nvfoB+/vH+ewGHzf3iz65OOD3UNCPOfpdC4XdPCOt16cHen5uCN51DnEk7p186n3M2Fh3lKzgohFU5JM7emIs3McDh5Jd3fd1shI/wKHsuAoyEd9CTsKD7q56WZKVWCHyW21F1TWP8Cdln0fJzwxdSW0qzedfXY3Sk8rQbTC4e8HmxZOd5cQr5nffXPkwf37shzHgoMCGOHAgoLK+9H1fqYkctrbioNHJT29VEKEffvW7+SHZUetSnW1QcKSjl6tKeFDnRaXOXrXrsy8cePDtqr1uLa5Bf/m68PIol3I0OQ+JBqcocXstHjxKYkalbVrkoRRq64g4TN2XFfKziqXnk9nuCdznyeVllbdx4jgwnaHKMDdq/9MjAgP97mHLy6yAz604bFuJEkc5eaW04oVJ1TX56KLe1JwJw+paSFyjvuCkoeGekfu2plxz4qfjke0m4IjbvnxRwfIz99tNjsy0xQKtY7/2vI/hNXQr7l9Wzrlq4QNwbA1akwob4Iyc0LJCf4TjhkjHOVpy5fFzT4Wl98+Cv7l57F4qLP8/FxnWzg7Ol5t/4ISo2hr/Tr15M8554STp4dOuv6d6b7gW3i462Z/+smBWS0JyDVLwXfvykAvZWTXMO87DdUmvw7I0H4vGBcMltq2LU01ogJmrKHDulBOdhlpyInui6FKYJCHX2JC0Z0/LouLbDMFR0XcZ5/EIkx1q0ZDEzusaHs7mxJDphPHC4R+Q03Ov6A7KmDIWXhmLC9s3s5dPCcyFr8VDTNtouA/LjuGuPd0P1/X2wSadPzX7v+hBhz0Ert3qpPuoAa9d6S/1KY71Z2xliNU6OKiue2bLw9Nb3UFP34sn9asTvILCfW6mb3d4A4L6jgvNFQcPJgtjQ9qAvIh1KhoyLnuC1GVTp08gw8ezLl57Zokv6YquK5pjuUhPJ4bXfUuM1q7k9tkHhiJj6mqNEhCCXMmgc1qs8wiUacxZ+uMpn++BiIeyWS5aJR2Kb2WXDG9WKt02mjoNBvsrlH4xvfsylTt/Bk0pJPgceB0V1ed092bv7/bjGXfx605a2TIoqaMKbf5Ttly09GjudHdwn1utHu20tz1ggVCIVFJcZWZ904jpPJ+fq7SyoXEho+vK/n7uZG7h9JoK06J5tQsHzpGkPzAYqI2vbCgUnwHtH/hM5RZlBpyZqIhtXqOwEAP2rghhSYz5varU1+NZzdmbFdateokhXX1cir2MFwrIFh8fMGNP6848cdVV/c9bFcFR1PsTz8ew0yZ6/ifI0z20Wm5cCg0sKEU3Pi4ytya4cNDCDPWkY3DjaGHUeH1a15UE5sFyY7s7FI5Ab7/7qjwCHp5n16TftH2lphQSEcO59JIhiR1BexYqPg0mRw+c19PzPzrI/78I+G6cRPCnkZBmd0U/M/fT1JqavHoXr38rmspNAFEqKo0Un5euThHUOihQztLQqJrmI+Z8N2+RyisNU4BvND0mpJapGyW06ziEXfjyk4ZeFXUFLxP30DpxAcW93ayzY17w6mdkV5y3f+WH/v57nuHbLGLguflltPvv50E0L+aLWHPZscjWbFhrbOzysjDS0d9+wXS2HFh/NADhJyyreSdt3dTYX4lbyZvh6U9s9WiAW5Z5t2Lb2JSmhx+XnmcJp0XQZFRp2JxRCRGDO9Cby7cReERPlJpaPFh8CeYqCwltvBh0EABQ6A1+y3tLRiIxevWc8um1Kv5/rZE9wtsuYL/9itb75SSCfywZjWnK15j7oAFZRss6fCzQmja9F4StmprwdENQh50xTh6hz+emtEM4fCqZkVGHBt/4nm6uenECiN6AifaHE6TzGZBoULuqZrZnBiuWHr+ncoqA1WUG+RnMXwA2U5wJmLj4KQDrMOkN/gyluyiq6tWPgt/bw8qZ2w83tCzfll54gdW8PUtUnA4aps2pFJIqOeVrBAhzYEGRfyAsnPKaeCgYLr8yj7C9GQ3K4ZxGk0wLStRlGRSLJWjoRM47lAqNA6jXxEWGXADDLRBoQqLlYenXiAcSIDQZAynMoCdR1jaup321gQd7FiHxgSbCsqNYi5wkwPbozwXOgGa6LTUYjk5oOzwnQAr2+KZ4jO7hHiF7NyZcWX8iYL1PXv5NV/B/16bDOw9pldvvyuaepzjgeMh6PQudNPN/WnqxT2bdBN88ZjPyAteJQuP2e9opoXFgbXB2D5YYRyfCAF6sIOlN1syNN7igeOF7hdEELBAB/Zl4eG0OzSx8KSUFFfKvUChwRQL2ATGWTjX8E3wb0xmCwh0qwl7tpXAQmMyBV4y0ts8uRkbLyu7TMiKUpKLKCuzjI4fz5fnCwppdPR7eepa1Yk1R8+u+G1V/Nd33TNkc7MUHOE1BXt7zOCbCrX1gi2soslJxVKqec99QwVnNyYYwJQQXyjTDkB5lpJcLFYE9Aewbgou1IiTCn5swYtmBijLz1iKvgwGUw0zFBTDQpnm5+8uv2NsB/ONox/RImBmWFyEPQcP6awoET+nXr39CdZIr3dsykY8d5wetadRoKNr544MSjxZSEeO5FISrx02CE4bHSCFnZ831rZzF8/QdX8nz5h6ca/N3RsYNW5VwTdvSuNdWRQTGel/ma10YOKwsPJh3g7mRT72xMgGvXXAl9V/JQo2PnokTzCf8Prx7+DY02qVLaMx7xxbn1NtbGgZ8QdfAArfmtRmFrSEz4Mi437KGd/ic4GVzxoVSn2jA4SkJ4KdvNYkvGlLwSadcmEP+Ts28f592VLCu4uVHs8B96lAGPtNijOv5WWr/0r45OZbB8ZaXRNrzcHPPrUR1GuPBQS4vdKUowN9gDhan39pXL2JvxbJzy+nVSvjafv2dDp5olBIbZB8cfShoo3BKsAOhOBwagBmICTXr3+Q8Jng72ozeE5niT2YQ9u2pkkRGPoHULuOseT2suiAq9UG49wFb0581Vp2U1XBjxzOo2ee3ODftavXCjZL421VbpRkgprs9YXnCr2BalRm1Ula/sNRdlzK5GhWuPRMTpd4ANRRrHSlwDlgf2QPY2KCJAbdjbFzWys08HFVtVH8FjiHRUVVhFCaWm/jju0ZtGNbmvgkltMNBgZdQmhoBqyD74J7AtxoicDoAe6u4dO6rMwAmgi7QBccmImJhRtuvX3gdIYq+TZDlF9/OQGFnSrKbeM1iNPECw1YoqbcwMWL3txF69lxxUMD3oRiOxMhJyAIIA4iCYgw+Hi7Uli4N0VGBdCQoZ0JWLC1KMgskA7PGC8YE0Q1MjJKahhsgfMrzC+UJySzPzPvxbGSoq+/XtX0zVeHJSJTm/RTFB1RGczaYeODUlxYR2wS+A29eN2weQEhu5hZchuTED7BbrypP51zbrhkkWHVLSHOlqy/SYPeU7fxf/2ZOPWCC3t+rRZJqqeJSOzs3p2J3TvVZGNOV6BJajFdPL039YupP6YClu6FZzcRZijiAcHbdpbue41SmSUKjewr4s8oIxgzLowmnB3GmDrQ7p+JZ4OEmDKFrZgS2HlDlAKEpjiWMVcT2B7PVUnIKM60xRGHIwgjgzk+Bw9kqyr46DFdlXa2nHJlioSZsNNk9lukNojfPyuzlNL4VIAiwunH10XhzRYe6X+8wropWeiGBAbgkTkjpFH6049kRpMknITpqjnWHDUqvAmTEoumxh7M/nrgoE6NK/iG9SlUVFA5xN/PbYqtn1nECwG4cc31/VS///yzm+kAOx5RfQKkwMkZMog1mdfMMjn2o6L8pUt9yJDONHhoJ7v6C+AG50US44JFRx8iNpPlVBTKZYQ9Gb9CgdGC5s1KpmnEeiJEmp5WatVJQzgV0S78XG1DZslsIg7vWhfemKNUCG0iDIzgwM8rTpCvnysNGtxJDNzgIZ3EOluTcyeGS+hx6bv7aO+eTApn/0TbzMoJjeL/TFn/d8oQVvA9DSo4HuTfa5Nw/ExGJMZWC5eVUUpXXxetOsHgi89iaSc7k6iDcAYKZSwsoEAOWzYsGqwcFm48W2trTnNTBVbxxIkC1FWIv3PieL5wDSIVjeeJKBIgASIPNXTIVixYQwIecnwWTgK1aFb3Hn60ZVNakyuvlPArK7/eReL10BvAo7Wrk+j3X0/KGMWzGY7AIMBCqwkCEYBPb7y2U7B5BFt34PKmWnL8tJ+fW+fDh3Im84m2p26Y9ZQVQ3IlNbkYWOs8Wz8IaV3MiBk/Pqze99Ag8d9vjlCPnr5mq21yUKVWZsUDFiAt3aOnHyt0Nxo7vqtdIAgs8eFDuaLQ+BPRBWQDDeZsJRxtRBjUFbn5oTVXIQcqoWNH82jIsPr2qv+AINlISsKsZUYBkKWLu6c8S5Q7f/V5LK36+QSdPzmCpk7rbRW+PPTocDGMv62KF0venJIXOMbsb5y37u/k/5x3foR1BUdavqysehwfz5Nseqh8NXB2zhoVQt1UdiqcGHjgqOl2NFhiGaNdwQoNxca9jBwVSqNGh8r9NKWoXk2AbeFMnYwvFAsNDI2sJSwMnGxEL+qpsp0fERAMLOuh2FxVBUcxFhzAwsIKiX7ZQ2AYYfB6ePtJjcu3Xx+htWuTafolvenSGeq9w7PvHSL+xB+/nZQaJYOxafW8WEuGjJO2b00bxwq+0aqCs5nHwp4LFi2b9Judg3J+gGAzrSuH2Ept35pOGADqSGFAjdliI7wHzIvU8iTe9ThOh6rcR1ME2dcdO5TY/tEjuRLFgEMNCx3EFtpSN9NmZ5m5QCo5Sb1hF5ALjiJqTTw87Vc+azKz3ON0QIYWMfD3l+yjg/uz6e77h6pGmu57cBgbgwIZbY7ojKEJux0/6uvnpk+ILzyXT4+Ntev8axQcnvrJkwXsebudbWunC34MI6XhYNYVsF4hGiADlRzAelsmKiDJhIgIIMGVs/rSuZPCBQ82O8bLEGDdmiTax040nC7UZqDiDhsHyR1TLQ7ptmbcVaoGtUpDiRVBlhGWNqAVuiDwdkrNv6tEdDZvShUH+slnR9erJsXyzH1yFD1wz2qBOO4eTZv9CQecHfSz169LfunCi3rWV/B17FwWFlQOCwzwmGBrAB49kmgiUDtuMUoDXTjGdi7bs1hsi2IjVHXpzCiplw5sJKxlTRDx2Ls7k3aw84zOIMUC6sjXx1VCiJZwmyPAMoQ1EV7MYcyPqEldierjL44hQnWt1aZqMXC9evlL2PPJx9bTq6+fQ3VrSNC5dcWsPmLtEWVpihWHGde7aifwugxjBd9VT8HRjc04bAwvis0FEmVlVdSzp3+9hgUcSQh9SWeOqf00G6E+YGFUIiI5cQljwEsui6TmsJYiuYN5lGukdiZPRvvBOiKKgIo/k9lkmRwsvI9rxGwfBBDUFByRFDhp1Xza6lq5YhEBidCuXgzlSuj5ZzfRm4snSZSotmB9/uYTMQ9RLEAZG/UHP+bj7eqRmlIyhvH8Lks0RRQcaV1ET7y99aObcoxWVhgllFZXcMRIYb6m7Y9li2Ij1IeoRZ/oILr8qii68KJespBNFTRI7N2dRVs3p4r1QUJFaX72qnmyDh3XNzuaiHePOKv+t7F+ouCsfC5tQJZfXWViSOglEba33thNTzw96pTvK2NYIuk/r2wTBW+K/uAUTUwsHL1rR8ZihHdrFHzX9gzgxwDGjKOaoo94KO4q1tBoruBTm/vY2oqNTF9KShEaVOm6G2Poyqv7Njl+jc2xZXMabWHMuGunUhEHpQ4N9a6pVDQ5EQ06nos1HB7g7y5TmfPyyiSu3RYCvYF/Alg8eUp3Omvkqb00I84K4VPRl0pLqpq0dhpl9uiouKN5AazgeTUKnsReNi/acH5FNUUfFeWtv+u1Zo1rq+5trVnpgI2RhLjiyr40/bLegumaIjjGV/+ZKNgatemwCIBflg4gEzlhn7JJKWEutDLFDPFrwIbk5CLy9HJts2vCmsFH++LTWFHo2jkAVJaOGBVCv6w40aQAANaGnc2otNSS4fzPP2sUHOEtxsvDmgoncKSVllXV/7o0qpqP7tbUCI1GHhRwNmAW+g1nXBFFMf2DmvQ2KNYH7kP9MjJ/KEDq3vOfCIiz86fA50C0x5p07eZN5X9Xt+nuNZoUrpYTDFUwsgTZ4tqCExilEgq9iO3X5eOrR3/BMD6x/kQkS4ewFuoJfHxdhzb1/thrpbzcirrcO1IAA+cGKeKWllo2BEdQcIRSTHjjt945kI+7Hk16m/V/J4vTuGtHJj/MaokGWRINp9NkZoTcMtNLpeVPrUYkvJtP28JJyzLyZyKLinWoq+D9YgIl1KoUlNnuGwDSJCUVDYXfdPa53UiHYpfsrDJdeITP4OZYBmQyc+uEoJAF7NzFizIzs+2WIauNJ/FQkhlnI/yHsNI11/VTCoZslDWrE/n4i6dDsTlyAkCxUTzlbOW7NhsinYtEttJSilUVvEuol8Ax5C3asvcTJyPgCJKCKGeoHd1COTVyFbjupmaV2TgNTkwoBDqp1mE0NB8BA7Bpmrq0SMHDKqSmlNQLQaGTZduWNKJgD7vhcOzkgrwKuekR7Jhcd2M/m2tF4Nj88VsC/ckvZBkBo1AUhA0Dp9hgPP0Uu7ZRKC2tYue7hGIGBNePpPgqXfHV1Sb2N9o4jKnnk56dSaxp7QYRpafTQ6BVU4wXTiG9XtsvL7ccOr1Hh7JMtl4xzSpVZOsHmFCQX14/vipZPPvAOqVuhKSpFSfCHXcPpstm2s6JjiMQNRFxrNiwBqi/EMfRSE5N/tMUSIcNjJNWTZTqRZ10ApFrG2s4Ct3ASckWvF6EJ8idKssNTY5UeHjokdWM4bXdo0tMLMLxFN2sahGNmeLheIFU39WWaMZQUCRYDg/P5peZwmoXF1UJRcHY8WFSmIOkjS2ylU+Q/y07Rrt3ZogVgONo2eVnhGLXilogIKA2AQKCZIsH4/SiIoU/vE0vrVaTRT2ogRomDTX5mlDslZxUFI0CNx0Kcdgq9mnuffmyI4AO6mtu6HdKEwCw3rgJYfT9t0fECWyOJQceTGXcqGMlv+3OQRLXtkXQpb/8+zipTwauw4ZwlJqYdjPirCjgl1GHmgqNRWJCESt7W28+hfFAq4L9kSysGbvSRKNYWlLVJ4Mdax2yjqzgUc29PsQyMT4Ddc5oXaoto8eGSj24hbbB9sVQ6rOBlYGx0eYU2adxbhV0v3z60UHB2SDVQQmvi7mI/kwfLS4VlEVVVr8fyHgXPOxtLYBO2GBeXvVPefh3zY3CVVUZo1AxqmPHAl5a7+auvzl7RLEHcuopOHrkkKUCTwY6qW35DKF7K6okOL8XXtSD7n9ouE0Q55eVJ2jZf49KtVp4hC916uwhERGj8cxW7H8iXso0NpNJ3dh06eIlrXltbQeQrURotm50B7kNhIDdm0UJJwayd1ZmWSAruLE7365fc3OO+HB/f1dx5BCyq9tlfQk7g5s3poqCN/YZsLZYBPCR3//wMJpxeeMHC06OD97bJ9V9OE1g8RHu6hgpXheGaKToDLQNajU5CNcpsXBTmzHJgtIJxkytDh+14WhEgaFqjm7yqeCXlFjYXcc3FW4ialFOHYkd0K0hYVSX0hYWfMDgYEmDh1jhBbRQ+KImHSGrV/4zTkZuNCaAI8D4SAZESOOqRsKBHaISKmTjAQwOYiI1BUdWEck5Sw1R28ATI7m566SDqq5AXxChE9+pGbqJEysjozRcyxgnrKUzDbVmaoXl3x+t/2D5YV11dV8pYKrJDtb6XYsTEX+iULruFy6e1Khyo6fx4fvW0OcfHxSrHWFul5P375idqfrCOBj4W4VWiq7Ac2KmJm6T68G6YzozwsmoE68riYmF/wQtmvH+5iRkmI7/EtpS2IUdBr69DetSpK4FDKm1BSFERFSQ+EFDryVbaLG4KJ1EWvWFl8c3aj0++fAAfff1EbmP7j0V6txqg6M2M5MkT0Cyg80HQh1YFm07DJeAJQQfeM3c+roWz1Xh/MZ1mtokFK6R0+S2uwaRi+7UNYczvG9PlsCm5j4nPOvCgspQLWOVzvbYkvCEUar647I41Q+8/a7BSkaNnQqZJqBV2JXij+eLhX/p1QkNKjdimnMeWksfLd0vmD8sDIOUjPJyJFOpwC2S5FfCyQK2UmVC2YC2Plik9LRiSVjhOSid7G13XYiSWEv2wJnDGhqMbXM9RYUVUuR13uSIeteCdkdUcypQqnnvj2dbWWnorOPd08ke1kQobdmR/OPXk6Kwnep0+YA6YtY10fQpwwrQKSMBhIX+160DJMbdkPz5ewK989ZuaTmL4t/FZzlizYjEXxnnZrD3j0TX9Et7Szc7Ti0UASEdjdAnIk6oNUe3PSI+ljqY1hbEla3Fwi2jS6rbIJKC54TmkXvuH6pa7/33mkSBGC0qT1bGgXfS8dEVZK/kFeoZ0lNL6MOl+2juU6Prff+WOwYKTIEzilLIex8cJoRBDW2aBfN30Mr/HZdpBgq8MToevYp5LicKz5AtROf4NFbuuq1xIfx8kN0FKc4Vs/rSt18dFicZxU4oITAaW7GA3jKq0Up0CZWhgsFNhlZ9vqggRHQEFH4obVZzLtf8lSSMvKYW0g+wExuEQ9LfXgcPrCrIKP/8PZGOHMpV/dDZvPjg4Zh939AGlRsOyMP3rxGyRlg5P8ZjFuviaD6cNDXnlcuMm2eeH0uXX9Wn0b5PGQ7wwFB6ZO5ZgkXLzJa11a7TXNOMCXdqgggKHFGj0diqz8ooNTHldMfdQ1St90/LjwnDF4rhWrLWpOijPxTc177xVmU40ZLFe1S/D9667368RCoBrca2Y3Pprtt+p/17soWOGIVRjpywqWbFxoZ8at4YGjOua5N+d9olvenm2weKj6Fp9YNGI36PqlMG8k55zq33+Si5QEBh4vkRQoVXV2DZf/slXk65lq+3lFX7Ypt423O4uJGPQNR+AIr8+IO6wwkyGGuClrFHH1xLBWwRI3r4mCGJ4w5Th1+MVrkpF/Wg0WO7Nmsp4LOAJg50yGYCldZ58Xsbqk1WDZMSRTG22nMC00JwsLtgbzX5+IP9Al2F8NMO9wrdhgX3sPv98O4L7epNHyzZRxnppTYvNOpWnp67Xo7K0DAfWQwH1m1lmBQvCEoJQCLUErlyVjSVlFSaqYRb6UXWqygRqtMJrbX9nzmOpjIzRR58M7VeWYQF4WuFdPWumbXU4s8ljQcU3O6M7UKl5esmhewLX9thU3bx6y8OiUMJ6y/E6E6SkYRjCf7tHo2Ms2tMYgYGUc9e/lIw1prSUNGZSyuMVwRcNbLfipLqWxiKWegc6sqSt/dIkEIvE6jthsnctEhytYYzAW8dRTQrVxynn386YfUasFvn/3sbvf7qdmlTAkeewcxl6Ayv8jKDUP+2VBBFAdsrHM7Wulbh9m7AbtRYcHt+Jms4xgxezL4Gkjrqxu0w7cOIR8be9lx7uSVqaSGKFYHDkplRQt27+zU6RhBDqJQ4rLmD3clKW5GdtIcgd4C6mta8f2MDGo5ED6Io9vp8hB1Ro4R6pKefG6P6MwgZf7Bkr4QF7c3LgdMK1htutV07gzVmy4aO+7fePU/6M61uBFbsu+8bKmE1HFOoBtQ2gwi9vUS6g+x0rUryqvV6akw1n2FFISXhZB9zh6gMLHcvPsVfef1s1Z9BmfVTj62XtDra5uyevDNRNYptK1gl7avgrLQod7z1zkE0bIRtlMS33jGIMtJK6acfjwlvtVbrLEpuUnoZ7SAoW5DYcGtqeGO71Q5sTYA6yNJGsD/15jvnWWWnAiwFxTSmf7SGz8WGp0LH91PGJtdujUro/UtKLKThI0Lo9rsGNel3n3h2tDikK386LjctpZIOPmAQvZ5HDuW1+H1AOIQ5RiDHbz39brjWW4mBa5r9+cqUawWWwOl++73zhdtETb76LFaSOr2jAiQU3Br3bDJSmZYVvNieJZCoMYEReGTuCNUPRfMD6HqtyTMvjJUajqOHc3kH1urJc9AX6qhBzAkOw5YIhgUgTiwtWq10rViXhhXcVDNtrTlrj/dGrQ3Knt9ZOtmqcoNs6Z1FeyRi5qL9J2zdCvdbzBbcVGiv3YO6cBw5194Qo5rMQbnmS/M2C1E8Rn1biz48/fxYaZ/69ed4eVhCeOmgFtxSpPTlp7Gqky5sxd6ff3JQyOilf7QVQ4QN9cbi9NQ0wwvAusMKxx3Np3Fnd6VXXz/XaqnC/r1Z9PTcDdLkjGrBVuOjUTZzIcKE+fay3qgxwLzEO2arQ5N/z9siBfedunjR3Xf8YbV0E/L8v8fLTBek7aVpmTQOacFxbah/R3XgN18catZaPP/0JsmGBljqn1vx1VBJMpw+KeFtwvsBkmJCBDjTZ14ZRQvfPs+qcifzPc59dJ2UD2OMiaEVG1Swmfle87UmoynHTgFPmSKAAio3tRLI1Um04n/HKSxcmdkOhqqH7l3TYGLjyXljaNa1fRmuKNWHGo1jKjnuHZnbRQt30Q/fHW2Scr8xf4dANlBrGFq5I8lkZpq1Bk+g4Bqt1uYgM8KAubkVwllz1z2D6fGnR1u9TzSR3337H7IZQOvXFveqddHkoOk4q6V8dFLgz5YZizz9svqMU7Daby7YKQ2kyJYh1tuzt5/wlzxy/xpa8uEFVt97zpOjxJFDJw8wG1rUHK0W3GQe1AqOwzfmb5fe0quu6dsgQRGOasCStX8lsaPlXxPEaN2QplIToiZYk8qKaqXx2MZICRQbHUBPPTeWLp7ey7oDnVVGs2/7XapI0TvbFn2zZn8jS1dZYci0BwMsUtYPPDxc9XhC1zvChv0HBCses0lp5Yrs4097d2XSI/etodcXTbT63qgbR4UZwkpYBGBVS82EowgWGqnmMFbq/35zmDasS5Zx2Qh59oz0lxQ0OsgRPsPcSoxsRO14n+gAsZ5tUi3JD8yaMcPnY00kbmXDg0V5cM+efvR/T4xskB8SjvM9tzEcZf3o3suvTRoqLPejc9Fm6srLDWnePi17M9A8AD9Ondaz3vdgzVb8eFwK3GvvXJN5JDQSAWvXJNLjjM1efu1sq5+BBgFk+p57cqOQfeK0cCRqCNM/uE8cbESTVvx0TBQfJxAcMTjOmMuJyj2cZqgJb8vTCHtIp9dacTBt32SWobnPsZ/UkHJjMz9072pJ+KF/VsbatJHgRPL20adp2YqktPTNsnmXjj+nm9C41RV0raD/UA2XW5w0PKQ/fztJcx/+u8HPAcH90k8vlGKsY0dzlZnqDhhZkdnyfL/d2OFGswauFyGzTnzy4IjGRIW2alOrG+d2taLg2Hjwc2yhjLBEYg7uy2ow7Hnnzb9LbQ38i7am88D9BAa6p2j5g5OaV4qo/AkqgszMMho1pqvKDi6gVStOCIVaY2WYCPj/9WciPXTPaqUew4rgyF/6yQU0fGSIsMVWmee7O2o5bU0okX0PjVbTzteCzn4XKxbPIM/dlmcJwYZFr6zaWiG8+/B9q+Vnu4X7ys+09b2i97RLqFcSn5yaBD5aC2z9TYSFcNSgA0W6UPjfKNZHJVxd+d8PcVTIuNMdxUgNvKdJwoCK8mKUyH13/SnWxJqAR2/x0sk088o+dDwuX/AgukUcvni8HV8mwd8aVQ5AC0SpSZfb8H6oHUlOLhZHs7a8/+5eevrx9ULgBDYzdDu1x/1WVFQXRET4Juh0Ok0u//s4a9iwxiIlWnMaHjhuytSeNPysLvwKEQdQ7ZiGgwESTERYkIJu6JiSJARfW99+geJ43nL9Knrr3fMbHNb6+DOjhdD9rQU7wQctxz8WqYONUB02oVowIFD9eQJGIkwoXIA2RVEw2KpcGHxvutVPfnce+0e/r4qXBB4mD7cby5gSKjzOflquFliRnbW4xpQbGyPuSB57/YH0ymvnSEodNb5qym05lp99cSzNe2m8HFFIZFhzcGpfFyrzEEJEpOH2m34VJ7UhuXRmJL299Hy5DowkMbQh9ZgzCdYPERRr40AA9bBOtj46vJ8f+xZ7dmUoTGPsTEK5wQKM8uH2nJhhUsKYcZgBqkUWjnfv0Qbbk00agQIXTe9F7386hUZa6cqoK9g8SPwsfh8K6EmJ8YXKNN0G265JWtWAydHudusNq2jHtvQGP6dfTBB9+vXFdDlDljjeGHBsXFy01EHZ9s8LsBLRHF8r9SGFBZVKqr4JybQgPl3TU0uFkAksCn3NvJSmNqJ/s5pdNoDz0OVocCdP0oJrpLio6rA15QHmjo8voPMu6C5hIU0zqEcjWVkXvz9ZIikYK621YWoWFgS8dfD8H2THExWGDQnqGpD5fOHlCYLfEaKSKIumw5pbwmbAxQhNqsarM0oUssumnH4mhSgIRgvKJA3NDoAP4WAyPDmMjjItOAVZIWKJVDPQlJ1dJhm5l+ZPaNGH4nNeee1sSdUCr9myGXFsAnoge/nM3A3CbtWYYADsux9eIASeR4/m8udVKfN4znAjjk2PPllrU++QqLM0btjMcYK4Pz9bdMEbTY7TZgiiV1buWHd3F9KCbs1gMB3grx9S39mldPd9Q04ZT1L3+x+/v19i2OjOWLXSev8lptdOmdqDUmUEoG0bAxYCDiocl6Xv7KX/e2Ct6sCi2oIKxKUfT5F5Prg+ifZoiM5kY46saXBnD6vPACertTV2unutqD7UuYvnAfEFBw/pDBbPaj7C9tbdCtjViJJMUiFIlDDg8mN07RUr6a0Fu4QAH7yET7GlvfHqX4Rl1lpG0tVVp2S1bMZUJmE/RRMEeFNuvfFX6eVrTG6fPVigUb+YYPEhSoqqBHKdiSYc8AHDpqwJ1lqSQE5+n8pkZNobFuYtDEdakFkiMlJQULG79k/iP7A1gWNPDcf+Yc48Ql/69gsQyjbg+d69/ejg/iwproH1rCsgpQS2Vmh8bb9yqY/gz0IDM1q7bmPnc2UD3foWQcvcB59NkfY5FPso2BxVdXRGaTgghLV5k4CMyEYr2Wbnvk/cS3Cwx+5hIxVSfa0lO8i4ZVddDjkUD6lVxKHOAgF9BPIxy9CSpbTgMGwYhBS/+DRWNXwIxlXExpvOr2cSOgpkRrFYzz6+np57apPg+sZkNsOsJQxbRo4OlSpGJIfOJGyO/IC1JA82PsqWhQ/Qye8Tg6v6DwzeFW7WW1HwrmE+wLo72VLH1RxpDCGQrVIb/XzsaL7U92ISrdpUBcAPhB/37c5UzUiiwKopEEXtuEWqGCfGD98dodsYsqAxojGJ6R9Ei947nx59fKSEEfE7WHit5vSGLUrpqKbeNGqLwCkD+aeSDXZueFJcVBXHerGzxqDi/0aPCUWlXl5FefVWyzcQqEcZratK+SugC5SsoRCcp4eecnLK2VJXqob08N4t6Zq3zJJBCW5CfAHdcdOv9NlHB2363ev/FUMffj6VZl0bTclJxdJmZ5kTdLpmMaWUt5t6bzmaT0pKqtt0Tn1rCS/h1l69/fNOUXB0QIOgnnfylpr4N98sQmylKpQIPr565XhvQEHBRYcSWsRe1WKyShq35QqF9+kW4cunjSstmL9dkg4YP9eYoKIPqf43Fk+igYM7ST9hbm65kgU9zfQckx0QibLWgJGSUizr7OwZYMCs8AifLRiXc4qCQ8CLV1hQuZm3QBnUVmueVgCsWlcQzUBtNiw5aerjWMuEYsZCqg0QqDIkc5zdLjRxrOSIlSOhhCGwiOJYY7atK3gYSz66QKiPPdnKIRNaWqIkPE4XlALr3DXMWzqO1OTEsfwakky7d/OZ0UBZuYGKiqpkSgcaP+A3WWrh7fVZjBbKuvfw24zZPvUUHJzNelftLqPBuN4yOa2MHwywdl0BNr/hphhh40cxlSX0JrwY/HvxJ/KpM2+A6/6lPnpbZlrCstu5+Vdi4GYSmeef3kyPPfy3hL9skctn9aFPv72IbrptAOO4SornRcfMIe1pEFZEIVVD7XMneB1l2K4dPxM6UVFmkPHgGaxD0A2c6NALVIPiuSo5iiIqZ0Pa0vCtViY5V66PGRC0q/a91bjVYP2EBeTjfR0fZ9IkiWMNBTRqoyZQqgrs9t47eyXmjcIW4HLUh4d3VzKfag8VFjLucC4FWkkZt1Sg3Ghpw7XDmoNM51+39qerrolu9HfhUN//8HAJjX712SGJ62ekl1AYWz89uLOddGoyOp8CAtVrUBCuxWnr6WkffkVJ9fNxgFMalaAXTO0hg6YQWPD3d5dRKVgjzCs6yRvrj18TaNvWNDGWaA5xaeawAySyePOsu6hOb+gpd9WnXyDFxuas9Qtwq+Jr1ENRNq5Pkf5B1HzXlZvvGEijxnWlH7+PE64T3NzQYZ3pmhv6WaXr+g4dPnw8dUFHSyvpi6WiEOFPlBq8+OwWuY97HhjWKBGoRHl6+9NTz42hmVf1oQ/e3StkRfAbwrv7tksnTosUjpTWQCiXmoC6AycWSmlbelcKhUSVVI6ee16EEN1HWXnemMsJA4hOMFSMLn5zN/3+S7z0tDaVpxD3mJdbXjVgcPDaukb1FC3ETlux/NhGo8G0mi3+FOBrf7ZqSxbtVlVwS+gtpgFyzdqC8XAgOQceVGjCWk9RFGxuEquMxd3Mm3Tvriy68pq+AkOslY3WvbcFb0+S3wUdxPq/k+Q92ZExM7G27j3YJYJiIolYdbdCsgTKOIQJYcxa0g0MgwInLy1FmZ52+92Dbf5dXNv8N86R/MiCV7cLjIGS22pIQHXB2H71iJEhG+ttunnz5tX8A47jb7+chFMSys7hZHwNUZBDsblSgoqBrs32cPkovP1fvwqMUQhu2lYxAs2F/miz2rQ+VXwA1C7bIlBoHLVwrmHJDx/MkRCoj49eLLojc4Ti6AZcQyZXrdAKtBXr1ibVPJ/mhyJJmmEeeGSEfFZzBNEslPP+suKEDIG1NWwLh5U3xNInnx2zqe49nhL4BKyAs8m7+g9+80xLDBUhxK8/P0QvPLOpWReeklRMN1+3SqIusN7twWuCz0S3CqwycPUT/7eO7r3jT9q1w3ZOwXMmhdN/3jyX3lxyHl18SS/p7sdQJctMdUcURMJQkSkWWkWOHMrhTdoy2hDgZpRATLs0Uk7Hlgj6B66+PlowvIuLLQ3Q0vSeOWBg8B9q93iKBYfgeGCYku7hoR/EizZYOkH4CIAVwKjug/tzxIm0FnKqK2hAfWrOekpOLpLMY3U7jyaBpUHREe4H5Dur/0yQuDmuzRpZZF0BPd1ExphDhnYRowAlT2VHG8e04ntoHMaqMzaVhpDzp3RX/f43Xx6Wqcy83i04naslkYScAoyIeuQsi5b99yitW5MsRgXPyZoOgePxt59PiuHQ6xvefHjOfI/Lbp89+F21E7megqNnb9vWdHi17nyMX25BmVg8FLUfPJBDv686Kel64CQMFKqbAYPCAGu/8Z+d9B0/QFg31I9UO8jcHYvyBQV7yn1t5I37F0MXJHpiBgTZPLEBmcEJ53YTZQfPybG4fCnNxcJgwdsbvsC6IRQHvho1nnZwm4A0FJTHen3zsph4fphYjUgbmmLU5OXnt9DLL2ylrZvSpK0Qf6KsGiFonIp1BT4DakowEDY42LPBzy8urgSseXXOk6MOqN2D6kqCdmzr5tRVvDgb+J/jLUoB3Ay4gukNv62Klw54sFNhCjHiqKg7gcOCC09JKpLqtK5s7XDUtCXpS1PCZ0hEodUKLVuoa1/7VyJdclmkxMVh5W3F6Jh1OePKPvL7wJAY1434MzpofMzZ3LZWdsAyONNDhnWxmo9AiDAiovkzhrDmuD9ANjX5z7+30UdLD7D/4i/zlywlFqh9+fyjg/L3p1TGm8Dfw+aDUbQGVWA4szLLNtx8+4BVHlZODo2as4dpuLNm/AROwcd4d7yiFijQmOkjEGLCKD0pWuKv4UiBsuOlaYdFbUk8DdcPhtzsrFKBLNfe2I+msbKDDbWpgmMY4dO9e7Ioia06FhczIvF82irMWMTWDQVWn359EXoU633/tZe30ZefHRLWseauU76Z2Ofjr6bW+97O7Rl087W/CNsBjJ2p1n3jdIHDDnj35ffTJIJSV269/lfB9moFf6Kn/Pu5uWVzv19x2asovVA9YdS+iGA8ogZsiVdoNZo4ayOZkc73ZSuH6AvmG3ZmTIXyWaEeMCkhKqdJ+Jmp5OC9IxsK5Xj5+a10/ZUrJekjZQlNEECC518ZT5/wwj/4f8Ml/o7IC0p1EZs3mRe5Ne8JJQeATmrKDTkZXyhlxy1ZJ9S5IKatJmAUxnOFchvrTE/DZwJSIIEGP001fMhoAdE3K4S+lJ5eEjd2fNgKa8ptVcEhyOYFBLrFlpZV/UhnkJjMaX9YDbC+QrFffWkr/euaX6RlzlqnkjWBT3PjLQPEwi18Z5Ikx0C4mXCyQDA7arFrshV2FpRRWAuFwvKiirI5p9MpTrs5iqIaoqyols1l7cTClwEtkpKKrEZnGjpYSkqqfpxxZVRsQ9dn1ZtCRujSmVH02ccHl7P1uZ4vMvRMU3SJn/OJhBfyAG++toOWM+y47PIocSyhqE2RESND5AWBU7ttS7rwiqA5BM0iwmHIJ6LWDhMtoFTwL0aNVl+2rZvTJIMIn6pFn2ayPvcHmU30z+J+1CbRAUMjTh8Y4GZ1DUwmU73rw++lp5WkjT87bPmYcQ2PT28wXHDVtdG07LujmyvKDd/zcXIfnYFi8VFQaxMQECTVcG+9vpO+/fIwjZ0QJtlf5A6aKog44AUfZsumNDp8KIc2b0gRsn9hRvVWOExwjDdnAjH8KMAt1ICoCYiV4EO11E/SCS10ldUNjRp9QD+Nto6eapRNCAWfPLWn6u8jGqc6dU4j00S+v/7GmM2N5R/qhQlrC8ZMYJdv3ZRWHNzZYypfjzedwWJJe8PngOzYliYFXQf35Uh9TUSEj2qDSEOCn4cSopUOiRJk89Dyh97CnOxyeSGch4VEOA+OsKaRaddY85yscoruF0SzrlMvMoNfkZ1ZRp4tgChQLTjNcBQRqanbUIGankMHc+SkQjTJ4nNozIOuDsfm0KTzutPs+4fWOwUA3wAJkZuozaODqkHG3umDhnR67r6Hhyc2VsPeaMD3xpv7owhmfVmZ4VtXV+0DdIaL9Dei24kVUxmBZ6LNm1Il3Y2wFlhvL78yiqJjgpr83oAUKD7CCxnBBHYCwbm4fUuasHshA5teUCkRKziHwLdITfO6nGKF8Xc4ydbYEMBCtY3fMyi4eel5bDaE79ArgPAqLDG6qkaODqn3s68uOIcemP2XJHi8ffWCuZFah/M4muEFMsNqRhgOKqJZ2Bi1MTz+lpNV9u0zz49Zb1Om05aaEATqv/gkdnR0v8CveEF7UofUs5hScM84HfXnSBnDCl9wYQ+GMV2FrL+lgtp0JJEQNtu3O0tOViRD4PTiMwFlkKCCsiOECzrkz7+9WBWifLR0v4QIYeFtCVlqzHACsWuk/tEwjiRfJL/36PFd6ZIZkRIKbEhWLD8mSo6Nh9g8Ejz4PWv5iasvWyGjT/xr5SIkqZRQGD9keOdrP/jswi02rY0tCp6eWkIzLlqOgP4LbDme6qBvtS5YBOBKhAKBgzt39lCwOuPtAQw//G1MHtmk9AxjwPeyb0+W1NnD4iHRhuM9mDfZt/+7pF6GEifOLdetok3rU1THOKKJHO+LBI4logRrDcsbGuYtpRxI7p0zKUJ6CFqjBOeDJftowSvbKbp/kNLUXstx5g3+4oefT3161FjbYh4aW6v6QO6zZNGeaLbin/MRPaJDlRu3emQmYkdJKhQNCoIM3eChnQRz+we42f1zoQSoza+uMkkcua7A2s99ZJ1AC4Vv5tQBsfAxpGGEnWrAICTs/P0UZxWcNhb/o7Vkw9/JdO+df0nPLCCbyfRPyJAd8B0XX9rrBoY9h21eB1sVHJ79xef/QKXFVffxTb7lrN0tNc4HKxxwoFqDMhYbBVU47u1R+Yj3A27nZyeWHf9GpvTsid2kTGDAoE5W67VbYwPglKmGpeaTxiQDsEiZj6nRmKFOy6oLUZsS0Yz72bIxVQaSuQiZ5z/zi/C8gNvZ2b7/h5WXLkKTvN0VHIICqjkP/u0X1SfgY/7nDGdW8KLCCsHJ4EsElKh5IFolxIaCMpnUZWe+PgvXOhpvc4XwkiTbiON+2Fkhwgw2aGhnm0pFHU0QMVn23VHJFVx/U3+64+5BVtm06hpPOOhvM0pAVAdErbUL8/AsDsXmLL/1zoE3P/r4yIImPe+mNh7MvuUP2rwxZXrP3v4fGQ3GYGdVcFhuePFvvnue+n3e+gdt25QqbWqt15yhUFRUlCmYHdgX8W9sPOBcEDINHtKJ2KlyaGJMhEoxRAytfajlQf05irgQ8px4frg42z1VRruDX/Lv1Yn8SqbdOzMkuQgHtPb0PDjMDPGyfX3dbvnptxkr9E0cedlkBUci4opLfqTQUO+X3T1c5pqcFKnAeUHYDVTLsOJ15aflx+mpOeuoKcdhC1VdBNABg3ORAKqsNEqdB+pY0NuIrhtsOMxDAgSwx3zT5gjgAhRy+5Z0me6wfWuaJI3QzAJn1Ggep4j4PTA/4B4oRKD4gH3wS7ABUHEJ/wQdXsGM7U2mU2efWpJQhw/lvvL20vMfR31Uk59rc6zT++/uo/kvbo3sPyh4KSvKRGeNdvCDo5tvH0CPPTVKBcJU0qVTlklyxV4d583C7qzwCMvBXwB0AoRChATKhH5ZOKroRodDiVAd6u7VyJaaK4AKUMJDB3PpwL4sSepg8gYIUIuLqiTDC7wM3Kzml2nNs+wRM8eGlVlMGjSGuMj1u7qZGc5U1BDvGXc0d83kC3vc8cbiScea9Qybe/zOuuwnhKhmhUf4vMeL4OeMSo6YrDcfiZ9/N001ovHiM5vpu6+PUM9evg5V9osQHqxgpTmcB8WBZczKLKPXFp0rlHR1BRYTPlRIiJdERlDxKSFN80ACVAWWlRmkFAEdPnl5FVTASok0fE52qYSK8TmWUmh0RSkNHaZW2tways8vL2An+M7lq2Z+29ykVLNN0zPPj6WrLv3p25KSqiF8LDklVEEaeP+eLJnEfMPN9UmKrv1XjLRZoZPekZw+4YysA0+QhEFWc6SV4qql7+yT5A7gDlLfWvN4F8sYcUR5LGMEca+wniibtiSQQhlmaOvUk7Rm4ziKaxPiC99laNJs5W6RgjM8of97ciSs3LsDBgUP4Jud5ow4HC13cJDQ3FBXiXv19qOx48NoKzuboaizcNBNrIx3LKJrbojm06b+YQpyn3VrEmn02K6MkV1OGehqiX8r84wa1bq2CeHyyXBwf/bKWddFvzvtst4tezYt+WXUS4w7Oywx7mjeYr6oY+SE0okVHD2CO7erT3K7ZGakQsrpwMyzCLMBNky3kvpeyScUcLOnl04p2tJqzFZa+bsUcDnI7eGaUpKLj/Xo6bf46RfGJrZ487f0DV5761x497+mpZYs0mo1TjcEGFYJC/9fxtpqcvbEcDqLj/0M87QKR7t+KCxa4lCyq9ZYDOX/4uODCu+Jo68F+AX5tCkurly08N1Jv7a0GcMuCo7U7asLz6GcnLK32PFZ6Gwc23iwiEjAyh3Ym13v+/D2b7i5PztZxQ5JL2wwGgU/X35VH9Xvgw4NkQ90Fjm8n8QXeOxo3sKH54x4q1//ILu8pV2yB8Cpjzx2Fp04lreQsfgyZ+ORh0MFp+3zj9UJ9MEpAucNx7wjbWBsOPCxII7PUFH1Z8B7ovRMahx8DTRQ7mUzruyz8Na7BtnvGdnrje68dzBdOK1XQtyRvAX84Dc7lbNpVPgGMTVuz67Met9HbQa49jAsVaNxHDOIGDVChRiXqCa/sfXeuS1DEiwmBzbfcCpPxhdu7tnbf8H8heck2NUI2PPN3nh7Ig0aErwx/kTBa3zRx53KivNDRhYOpZrWrDgqAVFIpHWAkCGsN5qGz+PrGm2lLxH34uWjd+jJDbDc6eklxxlvv7bkows22rskwa7vhjoB8PZ5euqWpSYXzeeLzXMWBYcVR8vVX78l0LbNaao/c+9Dw6i8XEmKtKcAJaESsLrKQHffP1T1Z35adox278yUslNHrfyEchcUVOTlZJXOX7B44jJQAtrdENj7DdG98sHnF+L4XJqVWfoK34TBWZQcDxxd7a+8uFX1+2eNDqGrrouWhl2drv2sIizyST5JbrhlgJTb1hVUKi55ew916eLp0LH7kpIqQ3Ji0SuvLZq41FqCyuEUHILCGr5oYNb5vEP/7Syln6iLBiHk/t1Z9MXH6nQbDzwyXBoCMjPK2uXol9Ef7OzitHlojnrfyZJFe2REIpJYjgi9cQKhxCD+eMG/n5g3er611jWHVXAI4rJQcsaJLxUVVs53FiWHM4aCpbcX7pIio7oCjpQX50+Q9jBAFU07KEZOThm9+OoE1cYEjGxB3BvVhygxcDjLrVHGzMQezJ5/74NDXwKnY6t+Xmu+OXbmS/MnVKQkF71QVFixwMUJxmdDwQFTUK4678mNqveF/kqk9tEHqVjxtrk2fNYRqYAcSGOsTNx44elNEspUyCgd69kKHyErd9zR/AWz7xv6woNzRlS0+oZq7Q8AedDTL4wtTkwoeq64uGqBM8xiRMF9z95+tGpFvNVxhE8+N0bI9BMTC9tkgCqiC0jYoPNn7jOj1KMm7+6jHVvTpYa9dtOAo8ASWG7eoAtuuKX/c3OfHlXcJp/bVvHRrz6NpSfnbPDu2cv3aV9f1zntMeWhSQ+GNyJ4CVFK+sPPl6pOjEtKKKKZFy8XBUes2dBK/OdQ7uTkYoFDK/6cqUocD2hy9WU/SVZWyDYd6PHCqAFaHTyQM/+Ouwe/8NTzY4rb7LPb6oNQevrv1yYUp6WWPJObW/6Co0dX0IwbxHi7rLSKHrp7tdR01BWEtTBEFlg8K6O0VSw54vMgsa+sqKZ3PpysqtxohHjikXVS4+3pqXMs5VYGChsYlrxw171DnmlL5Zbn1xB1m70FPXrhEb6Gn5bFrWELXu7r6zbCYDR5OKqSI36MiMm+PZlS8D/5wh71fgYWs090EH33zWH5efAJGuwUd4blRsQkO7uUlnw8xSrufuTe1UKmCWqHagc6GRFYKCyszEs4Wfjc/Y8Of/HRx89qc6PW5p2sl14eSR9+MRUhufnx8QVzdXrHznhWM5YFAxSwOMJv6hGjcPqI7wlWHsOTdHqtXZQbWdOy8mp6/7MLhWJCTd59a4/0j0b1CZBrdRTB9Wdnlh1PTS6eyyf3/PsfHtY+J0h7fCiYnj779iLEaZceic2dw8fwZoct0EJJKlsi0AzP//c2oURQExQ7IcGF2PPB/dkSf26OQ20ZHY73QAXgJ19PVZ1jAwFFw8L/7JAO/Br+OEdQbt7gCfEFmysqDXPefv/8pVddG91u16JpzyIcUAw8zMfrujXJ46JjAh/mXT/TUdPKUDxkCIG1//PWRBnspCZoVn728Q3SBodwI5xPhO0ae86Wn0HFYl5umXCQPzFvjMTd1eSHb4/S44/8LR3rMkbdAaCJpSvo6OHcZT17+S1Y8M6kjf1igtr3mhyhymzuw39jwbp3C/d5kBfrQUeNsMCJxFg+VBW+vmgSXXxpL6s/++vKE8KNjUFPoBgO6uRBrmzZ0KVvOa0U7j+jNPOCYgHOKliurr8pRjqJrAksN54ZqODAdegIzwvOJPhdGKItHH9Ot4VvLJ6U0BrUdE6p4BCEEf/9/BYow/3hET738XVFOmKaGY4TwofgVHns6VHUWCZu9R+JDGuOynxRTF1DczCYX03CNa6V4VQgu0F5AzbM5Ck9GqxWfPuNXfTmazvFcvv5O4blBt7m53GMN+mi22cPfmvOUyMdZr00jlQnvGdnJr307Gbavy/rQj7i7tG7ukxzRMhijg7IqMRrb4yhZ18a22gjBGgbkPpHgwLCfrgvhPxQU4K+UERjGhLQOzz31Cax3qhdB31xeyu3xswwylZ7ZadOHovnPjP61wsvdix2bY2jFcIj/vz0Yxvou68OR/DCz+7UyXN2tcHocLwrwOSAFBiIi46aZ14cS/Zqs6orYJF64enNQryDoVI6kOy087oBrrFPUpB4suBddoLfffm1cxI7h3g6nDHSOGqnB5yoBa9uB5v/LF7UO1mhJjqaNddoakjZ5Zi+894hdN2/YqTD3R4CKPTZhwdkQC3eH1ZexvGZ2v+e2WqvcdFp3rvljoHf3v/IcHJU0ThyKxMU5/WXt7PDFh8ZGOR+Kx/pt1VXOx7hp1izwgpKTS2mgewkXnZllMwZbS6XNqY2/PZzvMARENyHhftI57+xnSEJNllBfkV2wsnCD8ZM6PrhQ3NGHLNMjetQ8BbIN18cog+X7KP4E4XTe0f63+zm7jLDaHA8aw5MaiGc7BXpJ5EQOI8Y0IRQXkOCTOnBA9nCtAWKNYwoAc0aYuFGK9x9bXZvWoUB60Rc/vKAQLePr7+5/4q7HxhKziBOoeAQKM17i/fS15/F+rEi3ciO1o1aF80Ik9HRnqgyCQyEmdnsVIJcEtTBqM9GEghlrBiNh8Ks0tIqIaZMY+U+ejhXLDcUCZbfx8e13VvNxIfkV0ZayY7c3PLPLpkR9dnsB4YURPUJIGcRp1Fwi2zZlEofvbef1q9Njvb1db2OleY6/nJPR70NWF/UliMBhAaE2hTB4PqD1QdlBSw8QoYaB9mkuK683PL4jPSSL4cN7/zlTbcPPDx1ei9yNnE6BbcI5psvWbQbtL6j/fzdrmZFn8VfDjF1DMhqMczKyy1LZ6j1bVg3n2/Yidxy9fX9yEWncc57MjmxRkit9jdH6Ad2xg4dzJng7e16ZecQzyv4W6Edit4cxS5Py84q/b57D9//XjIzav01N/SzWirQoeBtKEh4fPHJQVr+3zg6cihnjJubbkZYuPdlWq0mymjsUOAGMTZLZkZpXH5e+Y89evotn3Jxr8233jXQruMOOxTcjor+w7dH6I9fT9LGdSkg/J4e1s17moeHfryhQ9NrRJJUVUZkVTdUVFSvHH5WyIqJ50fEXnlNNDlC/UiHgtuI0Vf/nkAb1qX4Z6aXTGXoMjUg0H0KG63OcsdnEoRRZl0JDCksrMhMSyn5zctbv2rshLBV50wKz7+KFZs0p+mtm05zsIpexV9+Ok47tmUg1Q0Sv8nskJ7n7a2fxH/Xn9a3b8bWFeXVVRlpJavZZ/krsk/AHyPHhO45f0oPq4SdHQrujA5puYHWrUmi7VvTxbInJxeN07lozw0Kdj/bw1M/QafTeJwOj8IyuIrvtywnp2x9eVn1uqBgj7WTJnffCGaucWd3k6FRZ8zhZToDww1IrGD03d5dmbR5Qyqq/IaVFFeN8fV1He3j6zpKr9dGoWTVGR4NFBruBXgKS0qq43Jzy7a6u+u2sFJvHjqiyy7QTAwe2lkSTWekI206w+NpaGAA38jmDSmi7ClJRQEFBZXDKysMwzy9dEPdPXSDPT31/fR6rcMoNGiTS0uqqby8+hBvzL3sNO72C3DbxdBr5+ixXfPGjA8ThUY30ZkuZ7yC15UTx/Pp5IkCIdBBoRNvAF1KctGA3JzyGBcXbbS7h0sfV1eXKH71dnN38XOp1aFj/6iQUaBVZaWxoLLScJwVOq6q0njU18/tcFi4d2xgkPuBiO5+1SNGdqFIVmjMu0cZQId0KLjNgkaDE2zhD+zPlsm86OQpklmSFYFZWWXdS4orw6uqjGFsRUP51ZmVvRM7dkGM6f11Oq2v1kXrrdWSh1ajcWOnT2eek1NtNJoqGCuXVRuMxYZqY6HJSPlGkymH1yOLv57p4qJJ8/J2TQkKck/yD3RP8PN1zUXbW9/oQIoZGCx/+thx4OvpKv8vwACDD58CCMT+eAAAAABJRU5ErkJggg==" data-filename="logo-big.png"></p>', '533616ea-ec27-48b7-bba8-e110785937a7');


--
-- Data for Name: DRKod; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."DRKod" VALUES ('2681d116-5302-4269-a879-06f8070a6dde', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:38:53.000285', NULL, NULL, 1, 'D1', 'Toprağın altında veya üstünde düzenli depolama (örneğin, düzenli depolama ve benzeri)', '', 1, 1, 'IF(E2=1,"Bertaraf Yöntemleri","Geri Kazanım İşlemleri")Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('b7cc1333-4266-408f-be0a-8f809ab39b3a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:01.399533', NULL, NULL, 1, 'D2', 'Arazi ıslahı (örneğin, sıvı veya çamur atıkların toprakta biyolojik bozulmaya uğraması ve benzeri)', '', 2, 1, 'IF(E3=1,"Bertaraf Yöntemleri","Geri Kazanım İşlemleri")Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('fd9e626f-4420-4551-a091-dd376cd83f94', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:04.631292', NULL, NULL, 1, 'D3', 'Derine enjeksiyon (örneğin, pompalanabilir atıkların kuyulara, tuz kayalarına veya doğal olarak bulunan boşluklara enjeksiyonu ve benzeri),
', '', 3, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('e3ddf85b-bf6d-422c-b7e3-989e8e728b53', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:06.244785', NULL, NULL, 1, 'D4', 'Yüzey doldurma (örneğin, sıvı ya da çamur atıkların kovuklara, havuzlara ve lagünlere doldurulması ve benzeri),_x000D_
', '', 5, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('315628d4-11b0-4c1d-885f-8451798676ee', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:07.961975', NULL, NULL, 1, 'D5', 'Özel mühendislik gerektiren düzenli depolama (çevreden ve herbiri ayrı olarak izole edilmiş ve örtülmüş hücresel depolama ve benzeri),_x000D_
', '', 6, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('60083ecf-5628-4f88-8e8a-fdc22f71b522', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:09.694332', NULL, NULL, 1, 'D6', 'Deniz/okyanus hariç bir su kütlesine boşaltım_x000D_
', '', 7, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('3a0539a4-c2c9-46b0-9d86-850d63977df6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:11.376239', NULL, NULL, 1, 'D7', 'Deniz yatakları dahil deniz/okyanuslara boşaltım_x000D_
', '', 8, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('4591fdde-36a4-48dd-8160-4b602a50bf2f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:13.478273', NULL, NULL, 1, 'D8', 'D1 ile D7 ve D9 ile D12 arasında verilen işlemlerden herhangi biri yoluyla atılan nihai bileşiklerin veya karışımların oluşmasına neden olan ve bu ekin başka bir yerinde ifade edilmeyen biyolojik işlemler,_x000D_
', '', 9, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('59f29c84-0161-46e5-9976-c02f1245d7b7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:15.434887', NULL, NULL, 1, 'D9', 'D1 ile D8 ve D10 ile D12 arasında verilen işlemlerden herhangi biri yoluyla atılan nihai bileşiklerin veya karışımların oluşmasına neden olan fiziksel-kimyasal işlemler (örneğin, buharlaştırma, kurutma, kalsinasyon ve benzeri),_x000D_
', '', 10, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('4953145c-fa11-4e3c-a870-c96c2a0ebf8f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:17.316017', NULL, NULL, 1, 'D10', 'Yakma (Karada)_x000D_
', '', 11, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('c5fbd464-22f0-4fb6-832a-7746c01a7214', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:18.967423', NULL, NULL, 1, 'D11', 'Yakma (Deniz üstünde)_x000D_
', '', 12, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('619d56f0-4a96-4b05-b742-ae8720877111', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:20.643592', NULL, NULL, 1, 'D12', 'Sürekli depolama (bir madende konteynerların yerleştirilmesi ve benzeri),_x000D_
', '', 13, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('170fda3b-c275-4ba8-8d0f-76774d438057', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:22.23322', NULL, NULL, 1, 'D13', 'D1 ila D12 arasında belirtilen işlemlerden herhangi birine tabi tutulmadan önce harmanlama veya karıştırma,_x000D_
', '', 14, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('77223536-3ce6-4e04-8878-74a2de4a3dcd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:23.857679', NULL, NULL, 1, 'D14', 'D1 ila D13 arasında belirtilen işlemlerden herhangi birine tabi tutulmadan önce yeniden ambalajlama', '', 15, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('06795ea1-fb9d-48d1-9a25-f548fcdcb7f8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:25.474587', NULL, NULL, 1, 'D15', 'D1 ila D14 arasında belirtilen işlemlerden herhangi birine tabi tutuluncaya kadar depolama (atığın üretildiği alan içinde geçici depolama, toplama hariç)_x000D_
', '', 16, 1, 'Bertaraf Yöntemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('e329323b-522e-461a-addd-06345a798f86', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:27.072701', NULL, NULL, 1, 'R1', 'Enerji üretimi amacıyla başlıca yakıt olarak veya başka şekillerde kullanma_x000D_
', 'Beraber yakma (Çimento, kireç vb.)_x000D_
', 17, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('55e669cc-2bd0-4984-9e66-212aa6daf968', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:31.753961', NULL, NULL, 1, 'R2', 'Solvent (çözücü) ıslahı/yeniden üretimi,_x000D_
', 'Atık solventten solvent geri kazanım_x000D_
', 18, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('3832c863-7004-4c77-b7fa-e9a91cfc6487', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:33.349072', NULL, NULL, 1, 'R3', 'Solvent olarak kullanılmayan organik maddelerin ıslahı/geri dönüşümü (kompost ve diğer biyolojik dönüşüm prosesleri dahil)_x000D_
', 'Solvent harici organik maddelerin geri kazanımı_x000D_
', 19, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('84ffeb01-a5b3-4406-b5a8-8bb9ac32dc56', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:35.020647', NULL, NULL, 1, 'R4', 'Metallerin ve metal bileşiklerinin ıslahı/geri dönüşümü,_x000D_
', 'Metal geri kazanım tesisi (demir,çelik, bakır, vb), akü geri kazanım_x000D_
', 20, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('4e03ab9a-bbd2-4987-8f99-9d3408a045da', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:36.753933', NULL, NULL, 1, 'R5', 'Diğer anorganik malzemelerin ıslahı/geri dönüşümü,_x000D_
', 'Anorganik madde geri kazanımı_x000D_
', 21, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('78893120-755b-40c2-81a4-0d1ec9116b57', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:38.353474', NULL, NULL, 1, 'R6', 'Asitlerin veya bazların yeniden üretimi,_x000D_
', 'Asitlerin veya bazların yeniden üretimi _x000D_
', 22, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('4a1eb389-35ba-4d93-9141-3464971e757f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:40.085369', NULL, NULL, 1, 'R7', 'Kirliliğin azaltılması için kullanılan parçaların (bileşenlerin) geri kazanımı,_x000D_
', 'Ön işlem ve Ömrünü tamamlamış lastik_x000D_
', 23, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('7061e63b-d212-4f27-bf18-b2ccc879bc33', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:41.760214', NULL, NULL, 1, 'R8', 'Katalizör parçalarının (bileşenlerinin) geri kazanımı,_x000D_
', '', 24, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('7fec88c9-17ca-44e6-9d40-62a6dff4de8f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:43.40997', NULL, NULL, 1, 'R9', 'Yağların yeniden rafine edilmesi veya diğer tekrar kullanımları,_x000D_
', 'Atık yağ ve bitkisel atık yağ geri kazanım tesisi_x000D_
', 25, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('ea239ecb-e12b-498a-bc21-0b471062c98f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:45.273603', NULL, NULL, 1, 'R10', 'Ekolojik iyileştirme veya tarımcılık yararına sonuç verecek arazi ıslahı,_x000D_
', '', 26, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('0297edbb-d6a0-4cb4-92b4-bbe96d037678', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:47.175615', NULL, NULL, 1, 'R11', 'R1 ila R10 arasındaki işlemlerden elde edilecek atıkların kullanımı,_x000D_
', '', 27, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('5ee4b004-c88e-4d4b-a60c-febacf11cc8a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:48.774224', NULL, NULL, 1, 'R12', 'Atıkların R1 ila R11 arasındaki işlemlerden herhangi birine tabi tutulmak üzere değişimi,_x000D_
', 'Ön İşlem, Tanker temizleme, kontamine ambalaj malzmesi geri kazanım (sac, plastik varil, bidon, IBC vb)_x000D_
', 28, 2, 'Geri Kazanım İşlemleri', true);
INSERT INTO "e-izin"."DRKod" VALUES ('512c7ff0-abc2-4872-a894-e485d4a9932c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-07 14:40:50.498977', NULL, NULL, 1, 'R13', 'R1 ila R12 arasında belirtilen işlemlerden herhangi birine tabi tutuluncaya kadar atıkların depolanması (atığın üretildiği alan içinde geçici depolama, toplama hariç)_x000D_
', 'Ara depolama_x000D_
', 29, 2, 'Geri Kazanım İşlemleri', true);


--
-- Data for Name: EK3A; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."EK3A" VALUES ('7f95e0ee-5a8e-4457-bb28-200512bc23a2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-20 21:40:57.644363', '2023-08-08 10:24:52.372076', 'd349697c-9816-417f-a80f-c82475decc4a', 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'Ada', 'Parsel', 'paf', 'sag', 'yuk', 'dşk', 'paf', 'asd', '213', '123', 5.3, 34, 2, 4, 1, 2, 2, 2, 1, 1, 2, 3);
INSERT INTO "e-izin"."EK3A" VALUES ('7391569a-cca2-4885-9fc1-4ed2ea99f4fd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:39:49.928181', NULL, NULL, 1, 'be7242d4-f8f1-441d-80bd-5835df40177a', 'asda', 'sada', 'asdsa', 'sada', 'sads', 'a', '1231', '1', '1', '1', 1, 1, 1, 3, 4, 1, 2, 2, 2, 2, 1, 2);
INSERT INTO "e-izin"."EK3A" VALUES ('952684d4-0973-4d4c-99b0-3b127f9d303a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:22.373554', '2023-08-11 16:31:48.698964', 'd349697c-9816-417f-a80f-c82475decc4a', 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'test', 'test', 'test12', '1', '2', '3', '4', '1', '2', '3', 1, 2, 3, 5, 6, 1, 2, 2, 1, 1, 2, 4);
INSERT INTO "e-izin"."EK3A" VALUES ('1496d147-9c71-4898-8710-6af0997fa607', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:00.231455', NULL, NULL, 1, '671ed4b3-4cab-443a-b2a3-4ea2ac0d563b', '1', '1', '1', '1', '22', '1', '1', '1', '1', '3', 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1);


--
-- Data for Name: EK3ANaceBilgi; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."EK3ANaceBilgi" VALUES ('f52984ec-c373-4503-bf01-31b59352fe59', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:39:51.513247', NULL, NULL, 1, '7391569a-cca2-4885-9fc1-4ed2ea99f4fd', 'ff3124f4-ce91-4289-9658-511367978580');


--
-- Data for Name: EK3ATesisFaaliyetBolge; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('06b837aa-f391-4088-ad10-6b16c71c62d1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 10:24:52.38753', NULL, NULL, 1, '7f95e0ee-5a8e-4457-bb28-200512bc23a2', 3);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('0e82bc16-1401-4604-9a92-a1988de9a118', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 10:24:52.387634', NULL, NULL, 1, '7f95e0ee-5a8e-4457-bb28-200512bc23a2', 8);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('65df2888-c73a-4408-971d-6765ce60ead8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:39:51.484816', NULL, NULL, 1, '7391569a-cca2-4885-9fc1-4ed2ea99f4fd', 10);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('af7c9d7f-6283-41e3-87e8-6a9113bfd9fa', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:39:51.475072', NULL, NULL, 1, '7391569a-cca2-4885-9fc1-4ed2ea99f4fd', 2);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('104cd37a-383c-4cad-b77a-38c1d9ab1bc9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:48.723408', NULL, NULL, 1, '952684d4-0973-4d4c-99b0-3b127f9d303a', 8);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('15d7f9df-d6ff-4a15-b313-68c04ae74ec8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:48.723041', NULL, NULL, 1, '952684d4-0973-4d4c-99b0-3b127f9d303a', 7);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('4882e6cc-a564-4481-964a-f2506c3aea70', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:48.722431', NULL, NULL, 1, '952684d4-0973-4d4c-99b0-3b127f9d303a', 1);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('520c7c61-95df-4738-9840-4bb14d67d113', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:48.722784', NULL, NULL, 1, '952684d4-0973-4d4c-99b0-3b127f9d303a', 4);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('513ceb8f-4dab-474e-83a8-6292d0af00d4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:01.878634', NULL, NULL, 1, '1496d147-9c71-4898-8710-6af0997fa607', 3);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('a3cf16ec-1652-4767-a452-7452dc85794c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:01.887134', NULL, NULL, 1, '1496d147-9c71-4898-8710-6af0997fa607', 4);
INSERT INTO "e-izin"."EK3ATesisFaaliyetBolge" VALUES ('bff64e33-0347-4dfa-bf49-2928aebc1850', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:01.887454', NULL, NULL, 1, '1496d147-9c71-4898-8710-6af0997fa607', 8);


--
-- Data for Name: EK3AYillikTuketimKapasite; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."EK3AYillikTuketimKapasite" VALUES ('6f56d06c-3267-4743-bd08-d93ffb3ac15e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-20 21:54:38.575635', NULL, NULL, 1, 'fasdsa', 'sadsaf', 4, '7f95e0ee-5a8e-4457-bb28-200512bc23a2');
INSERT INTO "e-izin"."EK3AYillikTuketimKapasite" VALUES ('72e37f76-e475-4447-a970-499429a87caf', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-20 22:03:44.478632', NULL, NULL, 1, 'yyy', 'yyy', 1, '7f95e0ee-5a8e-4457-bb28-200512bc23a2');
INSERT INTO "e-izin"."EK3AYillikTuketimKapasite" VALUES ('78885193-4043-47b4-bd64-c48d34cbe05c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:39:51.607296', NULL, NULL, 1, 'asd', 'sad', 3, '7391569a-cca2-4885-9fc1-4ed2ea99f4fd');
INSERT INTO "e-izin"."EK3AYillikTuketimKapasite" VALUES ('34bed5a6-0d59-47a2-958e-1acf46c6ed9d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:24.543972', NULL, NULL, 1, 'gg', 'a', 2, '952684d4-0973-4d4c-99b0-3b127f9d303a');
INSERT INTO "e-izin"."EK3AYillikTuketimKapasite" VALUES ('3b8eaebc-6c35-425e-ae67-3a7bbd7cd57e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:24.555609', NULL, NULL, 1, 't', '1', 4, '952684d4-0973-4d4c-99b0-3b127f9d303a');
INSERT INTO "e-izin"."EK3AYillikTuketimKapasite" VALUES ('ccf11278-c5aa-4e19-8773-5d88f2cdd775', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:24.556192', NULL, NULL, 1, 'ttttt', '1', 3, '952684d4-0973-4d4c-99b0-3b127f9d303a');


--
-- Data for Name: EK3AYillikUretimKapasite; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('631f5648-d678-454e-af58-2fba0d49d62c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-20 21:41:02.148861', NULL, NULL, 1, 'as', 'sad', 2, '7f95e0ee-5a8e-4457-bb28-200512bc23a2');
INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('d3219836-a0df-4526-ba44-a085fa369182', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-20 21:41:02.177117', NULL, NULL, 1, 'test', 'test', 3, '7f95e0ee-5a8e-4457-bb28-200512bc23a2');
INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('9579082f-0553-4af0-bb17-fa2fff0d08ef', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-21 13:38:18.28977', NULL, NULL, 1, 'sadasd', 'asdsada', 5, '7f95e0ee-5a8e-4457-bb28-200512bc23a2');
INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('2c5814c3-af01-45f9-9710-18ac00ebd2e5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-08 13:39:51.557123', NULL, NULL, 1, 'asd', 'asd', 2, '7391569a-cca2-4885-9fc1-4ed2ea99f4fd');
INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('0102098e-c6b7-40a9-b016-4621e4683635', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:24.517245', NULL, NULL, 1, '1', '132', 2, '952684d4-0973-4d4c-99b0-3b127f9d303a');
INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('0418a842-247d-4b99-b090-b23480f7ca4a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:24.516845', NULL, NULL, 1, '5123', '1321', 1, '952684d4-0973-4d4c-99b0-3b127f9d303a');
INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('2b7e7a48-ade2-4e5d-8f1f-4be2c97d65c7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:24.50249', NULL, NULL, 1, '51', '12', 1, '952684d4-0973-4d4c-99b0-3b127f9d303a');
INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('e4153559-13a1-47b7-a9bf-f342d0d5fb2d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:31:24.517646', NULL, NULL, 1, '5', '1', 4, '952684d4-0973-4d4c-99b0-3b127f9d303a');
INSERT INTO "e-izin"."EK3AYillikUretimKapasite" VALUES ('f538a33f-1107-4fa4-b2c9-b88aa246b410', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 18:09:01.93827', NULL, NULL, 1, '3', '4', 4, '1496d147-9c71-4898-8710-6af0997fa607');


--
-- Data for Name: EkTuru; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."EkTuru" VALUES ('84e08dca-f5be-4f2c-8074-42da230c1927', '2023-07-03 10:15:30', '84e08dca-f5be-4f2c-8074-42da230c1927', NULL, NULL, 1, 1, 1, 'Ek1');
INSERT INTO "e-izin"."EkTuru" VALUES ('84e08dda-f5be-4f2c-8074-42da230c1927', '2023-07-03 10:15:30', '84e08dca-f5be-4f2c-8074-42da230c1927', NULL, NULL, 1, 2, 2, 'Ek-2');


--
-- Data for Name: ILMudurluguUygunlukUzmanKonu; Type: TABLE DATA; Schema: e-izin; Owner: -
--



--
-- Data for Name: IlMudurluguUygunluk; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."IlMudurluguUygunluk" VALUES ('a2aeeb18-2ae6-494c-a6a5-74cad6d841ee', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-31 16:12:37.125399', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-10 14:43:42.097623', 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, false, 2, NULL, 1);
INSERT INTO "e-izin"."IlMudurluguUygunluk" VALUES ('951dc85e-653f-473b-a71e-4234f72872b1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-10 14:43:40.697393', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-17 13:44:43.601208', 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'd349697c-9816-417f-a80f-c82475decc4a', 'd349697c-9816-417f-a80f-c82475decc4a', true, 1, 'a2aeeb18-2ae6-494c-a6a5-74cad6d841ee', 3);
INSERT INTO "e-izin"."IlMudurluguUygunluk" VALUES ('a550e4a1-a0cd-431f-9f36-eaa6069eda87', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-17 13:44:45.027768', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-17 17:56:09.662414', 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'd349697c-9816-417f-a80f-c82475decc4a', 'd349697c-9816-417f-a80f-c82475decc4a', false, 2, 'a2aeeb18-2ae6-494c-a6a5-74cad6d841ee', 3);
INSERT INTO "e-izin"."IlMudurluguUygunluk" VALUES ('75099fe6-490f-4577-bbd0-9e9b52cd7bf0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-17 17:56:10.240178', NULL, NULL, 1, '84bfab1b-cfe6-49bf-b917-102405792afc', 'd349697c-9816-417f-a80f-c82475decc4a', 'd349697c-9816-417f-a80f-c82475decc4a', false, 3, 'a2aeeb18-2ae6-494c-a6a5-74cad6d841ee', 2);
INSERT INTO "e-izin"."IlMudurluguUygunluk" VALUES ('ce7828ce-91f0-4f00-93f0-677a4590aeaa', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-18 12:00:41.966502', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'd349697c-9816-417f-a80f-c82475decc4a', 'd349697c-9816-417f-a80f-c82475decc4a', false, 3, NULL, 2);
INSERT INTO "e-izin"."IlMudurluguUygunluk" VALUES ('21c6a791-2b69-4e5d-b6e5-0acf83341c2b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-11 16:44:51.518467', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-18 12:00:42.935249', 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'd349697c-9816-417f-a80f-c82475decc4a', NULL, false, 2, NULL, 3);
INSERT INTO "e-izin"."IlMudurluguUygunluk" VALUES ('cd523d54-8264-4841-b68d-7667ac8900d4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-08-18 12:00:45.333713', NULL, NULL, 1, 'a34e05c8-5a9f-4e1b-8c7d-79b74846c3f6', 'd349697c-9816-417f-a80f-c82475decc4a', 'd349697c-9816-417f-a80f-c82475decc4a', false, 3, NULL, 2);


--
-- Data for Name: IsAkisi; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."IsAkisi" VALUES ('84e08dca-f5be-4f2c-8074-42da230c1926', '2023-07-03 10:15:30', '84e08dca-f5be-4f2c-8074-42da230c1926', NULL, 1, 4, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', 4, false, '44e08dda-f5be-4f2c-8074-42da230c1927', NULL);
INSERT INTO "e-izin"."IsAkisi" VALUES ('84e08dca-f5be-4f2c-8074-42da230c1923', '2023-07-03 10:15:30', '84e08dca-f5be-4f2c-8074-42da230c1926', NULL, 1, 3, '84e08dca-f5be-4f2c-8074-42da230c1926', '84e08dda-f5be-4f2c-8074-42da230c1927', 3, false, '44e08dda-f5be-4f2c-8074-42da230c1927', NULL);
INSERT INTO "e-izin"."IsAkisi" VALUES ('84e08dca-f5be-4f2c-8074-42da230c1924', '2023-07-03 10:15:30', '84e08dca-f5be-4f2c-8074-42da230c1926', NULL, 1, 2, '84e08dca-f5be-4f2c-8074-42da230c1923', '84e08dda-f5be-4f2c-8074-42da230c1927', 2, true, '44e08dda-f5be-4f2c-8074-42da230c1927', NULL);
INSERT INTO "e-izin"."IsAkisi" VALUES ('84e08dca-f5be-4f2c-8074-42da230c1925', '2023-07-03 10:15:30', '84e08dca-f5be-4f2c-8074-42da230c1926', NULL, 1, 1, '84e08dca-f5be-4f2c-8074-42da230c1924', '84e08dda-f5be-4f2c-8074-42da230c1927', 1, false, '44e08dda-f5be-4f2c-8074-42da230c1927', NULL);


--
-- Data for Name: Kapsam; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."Kapsam" VALUES ('30e6b8ad-681c-44b4-a68c-3abd480850c6', '30e6b8ad-681c-44b4-a68c-3abd480850c6', '2023-07-03 10:15:30', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1. Enerji Endüstrisi', false, NULL, 1, 1000, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('f6c6145a-fa67-4077-9853-c1969fbb4c97', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:21:51.602601', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '2.Madencilik ve Yapi Malzemeleri Endüstrisi', false, NULL, 2, 1019, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d798db8c-485f-4207-9d71-c0f569423a9f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:06.771021', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3. Metal Endüstrisi', false, NULL, 3, 1025, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('976bfd1b-9f80-42ac-b30c-cfdd80077ea3', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:12.94266', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4. Kimya ve Petrokimya Endüstrisi', false, NULL, 4, 1035, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('29cd0fd3-ec03-4793-bd52-3d3bc50071da', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.066418', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '1. Enerji Endüstrisi', false, NULL, 1, 1041, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('40c89d8c-a681-456c-90fd-37dc5b390d44', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.40614', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8. Atik Yönetimi', false, NULL, 8, 1063, 0, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('766da44b-c55f-49a7-9135-474c4d33f090', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.144037', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5. Yüzey Kaplama Endüstrisi', false, NULL, 5, 1048, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('4d72d8ba-30d1-4c24-aab8-825bd0bbe618', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.239219', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '6. Orman Ürünleri ve Selüloz Tesisleri', false, NULL, 6, 1057, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('02de98b7-7f00-4323-87ae-f62c6ddc1c68', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:16.336418', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5.1 Maddelerin, profil ve tabaka biçimindeki malzemelerin cilalandigi, kurutuldugu tesisler(cilalarin organik çözücü madde ihtiva ettigi ve cila kullanim kapasitesinin 250 kg/saat ve üzerinde oldugu tesisler)(1)', true, '766da44b-c55f-49a7-9135-474c4d33f090', 1, 1049, 1048, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('011dbf2a-d2fb-4e5f-bf8a-e4664e132a5c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:18.01294', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5.2 Profil ve tabaka biçimindeki malzemelerin döner baski makinalari ile basildigi ve kurutuldugu tesisler.', true, '766da44b-c55f-49a7-9135-474c4d33f090', 2, 1050, 1048, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6dfadd5d-8a79-4531-9edb-12ba189c9c1f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:32.267025', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5.3  10.000 adet/yil ve üzeri motorlu tasitlarin üretimi,kara tasitlari (otomobil,kamyon vb.),tarim makinalari (traktör,biçerdöver vb.),is makinalari (dozer,ekskavatör vb.),savunma sanayi tasitlari(tank,zirhli araç vb.) boyandigi ve verniklendigi tesisler.(1)', true, '766da44b-c55f-49a7-9135-474c4d33f090', 3, 1053, 1048, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a4716ee9-95eb-46a8-b155-5aa415d1c884', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:33.844502', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5.4  Demiryolu tasitlarinin üretiminin yapildigi tesisler (Tüm parçalarin sadece montajinin yapildigi tesisler hariç)(1.000 adet/yil ve üzeri).', true, '766da44b-c55f-49a7-9135-474c4d33f090', 4, 1054, 1048, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2c49a87b-d127-4821-b609-e750ca1104df', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:35.422551', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5.6 Ahsap veya metal yüzeylerin 250 kg/saat ve  üzerinde organik çözücü kullanilarak boyandigi tesisler*', true, '766da44b-c55f-49a7-9135-474c4d33f090', 6, 1056, 1048, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e113112e-692d-48a0-89cd-e2e8ca4fef9c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:37.10092', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5.5 Motorlu hava tasitlarinin üretimi.', true, '766da44b-c55f-49a7-9135-474c4d33f090', 5, 1339, 1048, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('f2e75220-1719-48ff-94c8-9a8504168ce8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:50.831648', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.2  Asagidaki yakitlari yakan tesisler ', true, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 2, 1004, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6d5f4139-c4ab-4f82-bc17-9477a9bed62e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:14.244951', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '8. Atik Yönetimi', false, NULL, 8, 1279, 0, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('89755716-d7ea-44b5-87e7-48248e7ce332', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:39.443535', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.7.2 Biyokurutma', true, 'ae0e9ba7-65b4-45e5-bcd4-31ea238c69b8', 2, 311, 306, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('b285660d-27cb-40d3-85eb-034d41a6b780', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:41.122234', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.7.3 Biyometanizasyon', true, 'ae0e9ba7-65b4-45e5-bcd4-31ea238c69b8', 3, 312, 306, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('2f60e394-f825-45ef-813b-419722df0e3d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:44.330327', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.8.1 Depolama', true, '2dc37c42-eaf7-4f9a-a534-d222e49e4933', 1, 315, 314, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('a9008b4c-2966-4374-8af4-6f12a13666d8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:45.967082', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.8.2 Derine Enjeksiyon', true, '2dc37c42-eaf7-4f9a-a534-d222e49e4933', 2, 316, 314, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('483024ea-573b-4b71-a9d4-69fb310d7e14', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:47.614671', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.8.3 Alıcı Ortamda Bertaraf', true, '2dc37c42-eaf7-4f9a-a534-d222e49e4933', 3, 318, 314, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('ae0e9ba7-65b4-45e5-bcd4-31ea238c69b8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:02.302418', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.7 Biyobozunur Atık İşleme Tesisleri*', true, '40c89d8c-a681-456c-90fd-37dc5b390d44', 7, 306, 1063, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('2dc37c42-eaf7-4f9a-a534-d222e49e4933', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:03.910825', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.8 Maden Atığı Bertaraf Tesisleri*', true, '40c89d8c-a681-456c-90fd-37dc5b390d44', 8, 314, 1063, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('aad3783d-713f-4533-9121-055caefe0144', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:05.513624', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.1 Atik ara depolama, geri kazanim ve bertaraf tesisleri*(Bu maddeye Çevre izninde gürültü konusunda getirilen muafiyet Atik Pil ve Akümülatör ve Ömrünü Tamamlamis Lastik Geri Kazanim tesisleri için geçerli degildir.)', true, '40c89d8c-a681-456c-90fd-37dc5b390d44', 1, 1064, 1063, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('2b6ea208-caa0-41ba-a092-ba16f9c80586', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:07.161319', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.3 Gemi geri dönüsüm tesisleri*', true, '40c89d8c-a681-456c-90fd-37dc5b390d44', 3, 1065, 1063, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('54bcfe43-1fdb-4f6b-ade4-a31d56cce699', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:08.910631', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.2 Hurda parçalama tesisleri dahil hurdalarin veya ömrünü tamamlamis araçlarin depolama alanlari ve/veya isleme tesisleri,atik elektrikli ve elektronik esya isleme tesisleri,tanker temizleme tesisleri ile PCB arındırma tesisleri .*', true, '40c89d8c-a681-456c-90fd-37dc5b390d44', 2, 1329, 1063, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('704a031d-c163-4b8f-b0a4-331ed8a2c629', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:10.576042', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.4 Ileri Termal Islem Tesisleri(Piroliz,Gazlastirma)', true, '40c89d8c-a681-456c-90fd-37dc5b390d44', 4, 1365, 1063, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('631a719f-e22d-42c9-90f0-640f36164fe8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:12.158081', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.5 Atiktan Türetilmis Yakit(ATY) Hazirlama Tesisleri', true, '40c89d8c-a681-456c-90fd-37dc5b390d44', 5, 1366, 1063, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('09043e9b-ad63-4ad2-b141-18efa8707e83', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:13.825599', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.6 Tibbi atik strelizasyon tesisleri', true, '40c89d8c-a681-456c-90fd-37dc5b390d44', 6, 1367, 1063, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('7ae6e562-8f3a-4b5a-b469-05dea384f495', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:14.49765', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.7.1 Mekanik Ayırma ', true, 'ae0e9ba7-65b4-45e5-bcd4-31ea238c69b8', 1, 308, 306, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('763afc4f-5bc3-4088-8617-d0e1cd6a6463', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:42.74423', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '8.7.4 Kompost ', true, 'ae0e9ba7-65b4-45e5-bcd4-31ea238c69b8', 4, 313, 306, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.313542', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7. Gida Endüstrisi, Tarim ve Hayvancilik', false, NULL, 7, 1060, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('827f699b-60a6-4ba1-8947-547aa45494b1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.484038', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9. Maddelerin Depolanmasi, Doldurma ve Bosaltilmasi      ', false, NULL, 9, 1066, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('1fed800f-eb0f-42f3-9561-32356e718dab', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.558436', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '10. Diger Tesisler', false, NULL, 10, 1078, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.651785', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2. Madencilik ve Yapi Malzemeleri Endüstrisi', false, NULL, 2, 1097, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.724162', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3. Metal Endüstrisi', false, NULL, 3, 1124, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('58f43af8-77f7-48f0-bad5-305cd9bb845c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.859427', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4. Kimya ve Petrokimya Endüstrisi', false, NULL, 4, 1166, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d535b814-0d81-43d7-8d9a-d647d74f3e2e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:13.93024', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5. Yüzey Kaplama Endüstrisi', false, NULL, 5, 1210, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0641e8f7-78f5-46f6-90d2-d3efc814bbe7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:14.006524', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '6. Orman Ürünleri ve Selülöz Tesisleri', false, NULL, 6, 1231, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('bc09458b-8ad2-490f-8cb0-3773e80ded4d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:14.165866', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7. Gida Endüstrisi, Tarim ve Hayvancilik', false, NULL, 7, 1236, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('159c68a9-1d18-49dd-829f-066f0cc8142b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:14.326109', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9. Maddelerin Depolanmasi, Doldurma ve Bosaltilmasi      ', false, NULL, 9, 1282, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('09141047-8ad1-4369-bcf4-12ab46584f17', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:22:14.413689', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10. Diger Tesisler', false, NULL, 10, 1301, 0, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c37692df-9f19-4893-8897-be173d4784e0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:49.178076', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.1 Termik ve Isi Santralleri ', false, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 1, 1001, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5c6f69a7-4e36-4b93-93c5-45b61f27d44b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:20.619406', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.7  Turizm konaklama tesisleri,tatil köyleri ve/veya turizm kompleksleri.', true, '09141047-8ad1-4369-bcf4-12ab46584f17', 7, 1310, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ef486d4b-830e-49fd-91a1-289e97f9a478', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:52.49252', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.3  Yakma isil gücü 100 MW veya üzeri kombine çevrim, birlesik isi güç santralleri, içten yanmali motorlar ve gaz türbinleri. (Mobil santrallerde kullanilan içten yanmali motorlar ve gaz türbinleri dahil).', false, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 3, 1010, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('092f1e3e-a150-40d6-aeb9-6b28a49f69cd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:54.329498', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.4 Yakma isil gücü 100 MW veya üzerinde olan jeneratör ve is makinalari tahrikinde kullanilan gaz türbinleri. (Kapali çevrim gaz türbinleri, sondaj tesisleri ve acil durumlarda kullanilan jeneratörler hariç).', false, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 4, 1011, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('4de99843-8e30-48df-b502-e43425d7b6ef', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:56.080527', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.6 Katran, katran ürünleri, katran suyu veya gazi damitma ve islenmesiyle ilgili tesisler.', true, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 6, 1012, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('704d489f-67bf-4c45-bc43-43ee88dfb454', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:57.639015', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.7 Parçalama yoluyla hidrokarbonlardan gaz yakit elde edilen tesisler.', true, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 7, 1013, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('f1c5c491-0625-42d0-b818-0410dc06a031', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:23:59.250308', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.5 Nükleer güç santralleri', true, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 5, 1014, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('88c26e06-d38b-45b4-aa2a-adbc4c116a78', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:00.873702', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.8 Rafineriler:', false, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 8, 1015, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c5ef9791-e590-4e1c-99e4-b989eb01474d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:02.481158', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.9 Kok firinlari', false, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 9, 1016, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('96d97d5f-e9d1-411b-9347-9f285607da08', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:04.241825', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.10 500.000 ton/gün ve üzeri ham petrol veya 500.000m3/gün ve üzeri dogalgazin çikarilmasi.', false, '30e6b8ad-681c-44b4-a68c-3abd480850c6', 10, 1018, 1000, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2b9405d7-abf8-4231-9a8e-1b8cd3912e67', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:06.005734', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.1.1 Kati  ve  sivi yakitli tesislerden toplam yakma sistemi isil gücü 100 MW veya daha fazla olan tesisler', false, 'c37692df-9f19-4893-8897-be173d4784e0', 1, 1002, 1001, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5525d202-4548-4c9e-94c6-0e31693ef1df', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:07.714671', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.1.2 Gaz yakitli tesislerden toplam yakma sistemi isil gücü 100 MW veya daha fazla olan tesisler', false, 'c37692df-9f19-4893-8897-be173d4784e0', 2, 1003, 1001, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('87a39f17-f85f-4a21-8dd0-2e2c6062a325', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:09.337988', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.2.1 Kati (Kömür, kok, kömür briketi, turba, odun, plastik veya kimyasal maddelerle kaplanmamis ve muameleye tabi tutulmamis odun artiklari, petrol koku) ve sivi (fuel-oil, nafta, motorin, biyodizel vb.) yakitli tesislerden toplam yakma sistemi isil gücü 100 MW veya daha fazla olan tesisler', false, 'f2e75220-1719-48ff-94c8-9a8504168ce8', 1, 1005, 1004, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c922360c-8993-494f-a074-76f398971705', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:10.965406', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.2.2  Gaz yakit (dogalgaz, sivilastirilmis petrol gazi, kokgazi, yüksek firin gazi, fuel gaz) yakan ve toplam yakma sistemi isil gücü 100 MW veya daha fazla olan tesisler.', false, 'f2e75220-1719-48ff-94c8-9a8504168ce8', 2, 1006, 1004, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('8b3a8185-ada8-434f-8657-b71cbb296491', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:12.630621', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.2.3  Biyokütlenin (Pirina, ayçiçegi, pamuk çigiti vb) yakit olarak kullanildigi toplam yakma isil gücü 100 MW veya daha fazla olan tesisler.', false, 'f2e75220-1719-48ff-94c8-9a8504168ce8', 3, 1008, 1004, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('556e29f7-5323-4e7e-823f-3cd83b5a5ac9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:14.277675', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '1.2.4  Yukarida belirtilen yakitlar disindaki, yakit tanimina girmeyen kati ve sivi yanici maddelerle çalisan, toplam yakma isil gücü 50 MW veya üzerinde olan yakma tesisleri.', false, 'f2e75220-1719-48ff-94c8-9a8504168ce8', 4, 1009, 1004, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('1c767e07-eed2-4ba3-a171-ca759737010f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:15.915631', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '2.1 Çimento klinkeri ve entegre çimento üretim tesisleri', false, 'f6c6145a-fa67-4077-9853-c1969fbb4c97', 1, 1020, 1019, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2c6929aa-757c-42e8-be5c-93e8c2aa8709', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:52.566703', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.21 Akarsudan ve denizden mineral çikarilmasi,*', true, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 21, 1121, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0a586c20-ad0b-442d-bba5-3c47cab4b20b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:17.678346', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '2.2 Yakit olarak petrol koku kullanan ve  günlük sonmemis kirec üretim kapasitesi 250 ton ve üzeri olan dolomit,  kireçtasi veya magnezit  pisirme tesisleri', false, 'f6c6145a-fa67-4077-9853-c1969fbb4c97', 2, 1021, 1019, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2f656222-981f-4fdd-8910-8a29fd6e2c95', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:19.447882', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '2.3 Asbest ve asbest içeren ürünleri çikarma, üretme, isleme, dönüsüm tesisleri.', true, 'f6c6145a-fa67-4077-9853-c1969fbb4c97', 3, 1022, 1019, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a6cdd5f3-acc0-4ebb-ab13-ce4c521aa425', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:21.153782', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '2.4 300 ton/gün ve üzerinde eritme kapasitesine sahip, cam elyaf dahil cam üretim tesisleri.(Haberlesme ve medikal alanda kullanilan ürünleri hazir cam çubuk, bilye ve kütükten üreten tesisler, hazir cam çubuk, bilye ve kütükten elyaf çekme yoluyla cam elyaf üreten tesisler hariçtir)', false, 'f6c6145a-fa67-4077-9853-c1969fbb4c97', 4, 1023, 1019, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d33d597d-5fb1-4580-a9a2-3f14efd1da6d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:22.762794', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '2.5 300 ton/gün ve üzeri seramik veya porselen üretiminin yapildigi tesisler.', false, 'f6c6145a-fa67-4077-9853-c1969fbb4c97', 5, 1024, 1019, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6e91049e-a834-48fc-8889-e74cd4b20360', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:24.417317', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.1 Sülfür cevheri dahil metal cevherleri kavuran (oksit haline getirmek için hava altinda isitilmasi), ergiten ve sinterleyen  (ince taneli maddelerin isitma yoluyla bir araya baglanmasi) tesisler.', false, 'd798db8c-485f-4207-9d71-c0f569423a9f', 1, 1026, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d3549383-4953-4a48-8cb5-ad4719e54816', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:25.988659', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.2 Cevherden demir ve çelik üreten tesisler', false, 'd798db8c-485f-4207-9d71-c0f569423a9f', 2, 1028, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e60ebb49-d205-4e1d-9de4-661c903361bb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:27.627847', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.3 Kapasitesi 100 ton/ gün ve üzerindeki, cevherden, konsantreden ya da ikincil hammaddelerden metalürjik, kimyasal veya elektrolitik prosesler ile demir içermeyen ham metal üretim tesisleri,', false, 'd798db8c-485f-4207-9d71-c0f569423a9f', 3, 1029, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7042760c-28c1-411e-8ca1-0f1a0b6f8c8d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:29.277305', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.4 Kapasitesi 500 ton/ gün ve üzerindeki ham demir üretim tesisi (Kupol Ocaklari dahil)', false, 'd798db8c-485f-4207-9d71-c0f569423a9f', 4, 1031, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('15451725-8cd6-4ca3-9135-230cade88bf6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:30.909119', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.5 Kapasitesi 2000 ton/ gün ve üzerindeki hurda demir çelikten çelik üreten tesisler', false, 'd798db8c-485f-4207-9d71-c0f569423a9f', 5, 1032, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('8489b248-5ae2-46eb-91fa-91a796dda8fe', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:32.568609', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.6 Kapasitesi 50 ton/gün ve üzerindeki demir disi metal ergitme tesisleri  (Vakumlu ergitme tesisleri ve Basinçli döküm veya kokilli döküm makinalarinin bir parçasi olan ergitme tesisleri haric)', false, 'd798db8c-485f-4207-9d71-c0f569423a9f', 6, 1033, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('dd8f4254-bf26-4cf0-88d1-b8389db7ab98', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:34.213563', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.7 Sicak Haddeleme Tesisleri ', false, 'd798db8c-485f-4207-9d71-c0f569423a9f', 7, 1322, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('26d5d528-c03d-4b81-b763-3b37aeaeee8d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:35.773149', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.8  Üretim kapasitesi 700 ton/gün ve daha büyük olan demir, temper veya çelik dökümhaneleri', false, 'd798db8c-485f-4207-9d71-c0f569423a9f', 8, 1325, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('30fd4f08-edf8-4aa5-abad-37dd8b1f5c3d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:37.43831', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.9 5.000 adet/gün ve üzerindeki kursunlu akümülatör ile endüstriyel akümülatör hücreleri üreten tesisler  (1)', true, 'd798db8c-485f-4207-9d71-c0f569423a9f', 9, 1327, 1025, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('49058404-32a3-424c-a800-45cb199fbc90', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:39.123908', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.1 Entegre kimya tesisleri.', false, '976bfd1b-9f80-42ac-b30c-cfdd80077ea3', 1, 1036, 1035, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('4ae280b9-c5ae-4ef7-822c-35c255229a9d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:40.740453', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.2  Toplam 100 ton/gün veya daha fazla organik kimyasal çözücü maddelerin (alkoller, aldehitler, aromatikler, ketonlar, asitler, esterler, asetatlar eterler vb.) hammadde olarak kullanildigi tesisler', false, '976bfd1b-9f80-42ac-b30c-cfdd80077ea3', 2, 1046, 1035, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('fb36930a-8d31-42ba-89ed-2e69819fc505', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:42.372782', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.3  Petrol ve petrol ürünlerinin destilasyon ve rafinasyon islemlerinin gerçeklestirildigi tesisler', false, '976bfd1b-9f80-42ac-b30c-cfdd80077ea3', 3, 1047, 1035, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('098c3c23-e95b-4f14-b391-21846026ac0b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:43.967256', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.4 Terbiye islemlerinden kasar(hasil,sökme,agartma,merserizasyon,kostikleme ve benzeri) ve boyama birimlerini birlikte içeren,üretim kapasitesi 3.000 ton/yil ve üzeri olan iplik,kumas veya hali fabrikalari.(1)', true, '976bfd1b-9f80-42ac-b30c-cfdd80077ea3', 4, 1337, 1035, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('fb17b080-bef0-4547-92d7-94a72988338b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:45.58557', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.1.1 Üretim kapasitesi toplam 200 ton/gün ve daha fazla olan asitler, bazlar veya tuzlar gibi inorganik kimyasal maddelerin üretildigi tesisler.', true, '49058404-32a3-424c-a800-45cb199fbc90', 1, 1038, 1036, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('92b9a888-c444-445a-8781-0aa9812a28e9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:47.205258', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.1.2 Amonyak, klor ya da hidrojen klorür, flor ya da hidrojen florür, karbon oksitler, kükürt ve bilesikleri, azot oksitler, hidrojen, kükürt di oksit, karbonil klorür gibi inorganik gazlarin üretildigi tesisler.', true, '49058404-32a3-424c-a800-45cb199fbc90', 2, 1039, 1036, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('142e2d28-f2c6-4466-a5f4-5ba356330d1f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:48.89376', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.1.3 Hammadde asamasindan baslamak suretiyle 50 ton/gün ve daha fazla fosfor, azot ya da potasyum bazli gübre üretimi (basit bilesik gübreler)', false, '49058404-32a3-424c-a800-45cb199fbc90', 3, 1040, 1036, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('1e0ac0cb-7297-475a-9fef-ed6509168952', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:50.530978', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.1.4 Kapasitesi 100 ton/gün  ve daha büyük olan basit hidrokarbon (lineer veya döngüsel, doymus veya doymamis, alifatik veya aromatik) üreten tesisler', false, '49058404-32a3-424c-a800-45cb199fbc90', 4, 1043, 1036, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('9606028f-735b-42e2-84f1-147ac050f7e7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:52.178317', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '4.1.5 Üretim kapasitesi 100 ton/gün ve daha fazla olan organik kimyasal çözücü maddelerin (alkoller, aldehitler, aromatikler, ketonlar, asitler, esterler, asetatlar eterler vb.) üretildigi tesisler', true, '49058404-32a3-424c-a800-45cb199fbc90', 5, 1045, 1036, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2754ef6d-dfee-4102-8725-eb199b9a0919', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:53.835555', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '1.1 Termik ve Isi Santralleri', false, '29cd0fd3-ec03-4793-bd52-3d3bc50071da', 1, 1042, 1041, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('dd9ae8d2-f4fc-44e8-a9d7-01a2a8fbf548', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:24:55.525759', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '1.2  Asagidaki Yakitlari Yakan Tesisler*', true, '29cd0fd3-ec03-4793-bd52-3d3bc50071da', 2, 1084, 1041, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('876ffd05-5473-4e3f-8cee-6b19d8847704', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:06.371419', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '1.3  Yakma isil gücü 1 MW ve daha büyük 100 MW?tan küçük  kombine çevrim, birlesik isi güç santralleri, içten yanmali motorlar ve gaz türbinleri. (Mobil santrallerde kullanilan içten yanmali motorlar ve gaz türbinleri dahil).', false, '29cd0fd3-ec03-4793-bd52-3d3bc50071da', 3, 1089, 1041, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('24e517a5-df83-457e-a225-c6f96a26027b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:08.269223', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '1.4 Yakma isil gücü 1 MW ve daha büyük 100 MW?tan küçük  olan jeneratör ve is makinalari tahrikinde kullanilan gaz türbinleri. Kapali çevrim gaz türbinleri, sondaj tesisleri ve acil durumlarda kullanilan Jeneratörler hariç.', false, '29cd0fd3-ec03-4793-bd52-3d3bc50071da', 4, 1090, 1041, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7982f0ba-da80-4403-a185-64368aa6d924', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:09.642979', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '1.5 50 ton/gün ve üzeri,500 ton/günden küçük taskömürü ve bitümlü maddelerin gazlastirilmasi ve sivilastirilma tesisleri.', false, '29cd0fd3-ec03-4793-bd52-3d3bc50071da', 5, 1091, 1041, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a7a68047-470c-4ae3-99ed-fb7188754dc8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:11.247766', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '1.6 500 ton/gün ve ham petrol veya 500.000m3/gün altinda dogalgazin çikarilmasi.', false, '29cd0fd3-ec03-4793-bd52-3d3bc50071da', 6, 1092, 1041, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('aea7153d-ff5d-4dea-a007-a1f7330d9de9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:12.973873', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '      1.1.1 Kati  ve  sivi yakitli tesislerden toplam yakma sistemi isil gücü 1 MW ve daha büyük 100 MW?tan küçük  olan tesisler', false, '2754ef6d-dfee-4102-8725-eb199b9a0919', 1, 1082, 1042, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a88a471d-5ba2-4127-932c-1243e842ffd7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:14.712112', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '        1.1.2 Gaz yakitli tesislerden toplam yakma sistemi isil gücü 2 MW ve daha büyük 100 MW?tan küçük  olan tesisler', false, '2754ef6d-dfee-4102-8725-eb199b9a0919', 2, 1083, 1042, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5fb0d213-67c4-4506-a430-f93f0343ca91', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:38.729125', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5.2.1 Boya ve Cila maddeleri: Organik çözücü olarak yalniz etanol ihtiva eden ve bundan 500 kg/saat ve üzerinde kullanan tesisler', false, '011dbf2a-d2fb-4e5f-bf8a-e4664e132a5c', 1, 1051, 1050, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('628497d4-07c9-4b7a-9db3-2b20911ffeb0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:40.572187', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '5.2.2 Boya ve Cila maddeleri: Diger organik çözücüleri 250 kg/saat ve üzerinde kullanan tesisler', false, '011dbf2a-d2fb-4e5f-bf8a-e4664e132a5c', 2, 1052, 1050, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('cfca00d4-7a8b-4c88-ab18-2edf42e5be1d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:42.229119', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '6.1 Selülöz üretimi tesisleri', false, '4d72d8ba-30d1-4c24-aab8-825bd0bbe618', 1, 1058, 1057, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('3aa918a6-b93b-416b-a9a4-7a710fbdb36c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:44.031561', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '6.2 Kereste veya benzeri lifli maddelerden kagit hamuru üretim tesisleri', false, '4d72d8ba-30d1-4c24-aab8-825bd0bbe618', 2, 1059, 1057, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('bfa2a325-650a-4beb-93be-940af2367e74', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:45.72046', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '6.3 Hazir selülozdan ve / veya atik kagittan her çesit karton,kagit veya mukavva üretimi yapan tesisler (300 ton/gün ve üzeri kapasiteli)', false, '4d72d8ba-30d1-4c24-aab8-825bd0bbe618', 3, 1340, 1057, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('40811975-c92e-4cb2-91e5-bd080024356f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:47.327516', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.1 Seker Fabrikalari*', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 1, 1061, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('308e624b-5c91-4f30-bab4-c149b9c34de2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:48.969969', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.2 Üretim kapasitesi 30 ton / gün ve üzeri olan zeytin isleme tesisleri.', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 2, 1062, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('b5be9aac-a1e0-40c3-849c-00b2bdcebb2d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:50.594803', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.3 Bitkisel ürünlerden ham yag üretimi veya rafinasyon isleminin yapildigi tesisler. (200 ton /gün yag ve üzeri (kekik,papatya vb. Esansiyel yaglar hariç))', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 3, 1341, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a11962ba-7e94-4770-b9b9-1b30e0c044e0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:52.205237', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.4 Kapasitesi 25.000 ton/yil ve üzeri olan maya üretim tesisleri.', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 4, 1342, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('42145926-3415-4d18-9d80-28f0d4a78380', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:53.816759', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.5 Suma ve malttan 50.000 m3/yil ve daha fazla alkollü içeçek üreten yerler.', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 5, 1344, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0e9da139-882e-461f-91b6-ebadf8a41a18', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:55.541576', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.6 Kapasitesi 2.000 ton/yil ve üzeri olan ham deri isleme tesisleri(konfeksiyon ürünleri hariç)', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 6, 1346, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5e95d999-5702-4803-8396-c6885139e672', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:57.365515', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.7 Hayvan Yetistirme Tesisleri*', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 7, 1348, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a8783903-167e-4cbd-b75e-a09c8ce3cbac', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:25:58.989631', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.8 Hayvan Kesim Tesisleri*', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 8, 1355, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('821c069f-0347-4690-8237-0d3b47d355e2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:00.699356', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.9 Süt isletme tesisleri.(çig süt isetme kapasitesi 100.000litre/gün ve üzeri)*', true, '33cc7db8-0b5b-4ab2-abd5-14bacd97e49a', 9, 1364, 1060, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('83fe04b6-1f6b-4bc0-9067-78dc706e71f0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:15.486081', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.1 Yanici, parlayici veya patlayici gazlar için depolama ve dolum tesisleri*', true, '827f699b-60a6-4ba1-8947-547aa45494b1', 1, 1068, 1066, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('39ebe174-f89b-4ff8-aa8b-827585e00dde', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:17.219756', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.2 Ham petrol, petrol ürünleri ve petrokimyasal ve kimyasal ürünler için depolama tesisleri  *', true, '827f699b-60a6-4ba1-8947-547aa45494b1', 2, 1072, 1066, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('81149a07-816f-4ae8-b5e5-0119fc5659c6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:18.79761', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.3 Metanol için toplam depolama tank kapasitesi 30.000 ton ve daha fazla olan tesisler*', true, '827f699b-60a6-4ba1-8947-547aa45494b1', 3, 1076, 1066, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('df57fc3a-663c-4041-a064-899c0ceb4b0b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:20.545558', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.4 Akrilonitril için toplam depolama tank kapasitesi 2000 ton ve daha fazla olan tesisler*', true, '827f699b-60a6-4ba1-8947-547aa45494b1', 4, 1077, 1066, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('afeda6d6-66ff-4cb7-bc6f-c3c4432fc51d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:22.176477', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.1.1 Sivilastirilmis petrol gazlari için toplam depolama tank kapasitesi 10.000 m3 veya daha fazla olan tesisler( Isinma amaçli kullanilan depolama tanklari hariçtir)', false, '83fe04b6-1f6b-4bc0-9067-78dc706e71f0', 1, 1069, 1068, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5a333c94-5ba0-4ffc-95f7-586ab03c3e02', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:23.745734', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.1.2 Dogal gaz/LNG (sivilastirilmis dogalgaz) vb. gazlar  için toplam depolama tank kapasitesi 20.000 m3 ve daha fazla olan tesisler, ( Isinma amaçli kullanilan depolama tanklari hariçtir)', false, '83fe04b6-1f6b-4bc0-9067-78dc706e71f0', 2, 1070, 1068, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('04883a43-f9b9-42c2-9238-d9005bb1c628', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:25.462361', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.1.3 Dolum kapasitesi 200 ton/gün ve daha büyük olan Sivilastirilmis petrol gazlarindan tüp dolum islemlerinin gerceklestirildigi tesisler', false, '83fe04b6-1f6b-4bc0-9067-78dc706e71f0', 3, 1071, 1068, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('082e3b65-1c2a-45d4-b425-07d1c4b3b9ec', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:27.132349', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.2.1 Ham petrol için toplam depolama tank kapasitesi 100.000 ton ve daha fazla olan tesisler', false, '39ebe174-f89b-4ff8-aa8b-827585e00dde', 1, 1073, 1072, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c5b76912-3497-49a3-a371-badb723c6840', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:28.768312', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.2.2 Benzin, nafta, motorin, fuel-oil vb. akaryakitlar,  için toplam depolama tank kapasitesi 50.000 ton ve daha fazla olan tesisleri( Isinma amaçli kullanilan depolama tanklari hariçtir)', false, '39ebe174-f89b-4ff8-aa8b-827585e00dde', 2, 1074, 1072, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('eeee257d-3b78-4661-a20c-48852a1f74f3', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:30.339909', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '9.2.3 Organik kimyasal çözücü maddeler için (alkoller, aldehitler, aromatikler, aminler, ketonlar, asitler, esterler, asetatlar, eterler vb.) toplam depolama tank kapasitesi 50.000 ton ve daha fazla olan tesisler', false, '39ebe174-f89b-4ff8-aa8b-827585e00dde', 3, 1075, 1072, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e5b8b31b-556b-440f-82c7-ee06370f9fdf', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:31.944293', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '10.1 Sanayilerin toplu olarak yer aldigi bölgelere ait atik su aritma tesisleri.', true, '1fed800f-eb0f-42f3-9561-32356e718dab', 1, 1079, 1078, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('8dd5b85c-3544-40ad-b619-4d28d1f0440c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:33.544492', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '10.2 Nüfusu 100.000 kisi ve üzeri olan kentsel ve/veya evsel nitelikli atik su aritma tesisleri.*', true, '1fed800f-eb0f-42f3-9561-32356e718dab', 2, 1330, 1078, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('8697b1aa-aa31-4657-ac07-41ba0b5d4b3c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:35.174562', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '      1.2.1 Kati (Kömür, kok, kömür briketi, turba, odun, plastik veya kimyasal maddelerle kaplanmamis ve muameleye tabi tutulmamis odun artiklari, petrol koku) ve sivi (fuel-oil, nafta, motorin, biyodizel vb.) yakitli tesislerden toplam yakma sistemi isil gücü 1 MW ve daha büyük 100 MW?tan küçük  olan tesisler', false, 'dd9ae8d2-f4fc-44e8-a9d7-01a2a8fbf548', 1, 1085, 1084, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('bb1156e5-6d89-428c-abf1-b0fe55a1558a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:36.850916', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '      1.2.2  Gaz yakit (dogalgaz, sivilastirilmis petrol gazi, kokgazi, yüksek firin gazi, fuel gaz) yakan ve toplam  yakma sistemi isil gücü 2 MW ve daha büyük 100 MW?tan küçük  olan tesisler', false, 'dd9ae8d2-f4fc-44e8-a9d7-01a2a8fbf548', 2, 1086, 1084, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('01be59fa-afe7-4e9e-933a-eb918f8594c2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:38.518183', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '      1.2.3  Biyokütlenin (Pirina, ayçiçegi, pamuk çigiti vb) yakit olarak kullanildigi toplam yakma isil gücü 500 kW ve daha büyük 100 MW?tan küçük  olan tesisler', false, 'dd9ae8d2-f4fc-44e8-a9d7-01a2a8fbf548', 3, 1087, 1084, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d1276562-1428-40d7-9f37-8391ba70e36c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:40.183853', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '      1.2.4  Yukarida belirtilen yakitlar disindaki, yakit tanimina girmeyen kati ve sivi yanici maddelerle çalisan, toplam yakma isil gücü 1 MW ve daha büyük 50 MW?tan küçük  olan tesisler', false, 'dd9ae8d2-f4fc-44e8-a9d7-01a2a8fbf548', 4, 1088, 1084, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('b572e381-ad10-4924-bb14-038c84140b47', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:41.80989', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.1 Klinkerden çimento üreten ve /veya paketleyen tesisler', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 1, 1098, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ec61cdd8-1f6c-41f3-a693-f94d103c0d9c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:43.465578', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.2 Yakit olarak petrol koku kullanan  ve günlük sönmemis kireç üretim kapasitesi 250 ton?dan az olan  dolomit, kireçtasi veya magnezit pisirme tesisleri', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 2, 1099, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('105d0d8b-1f25-437c-89c5-03dc57a7e383', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:45.085219', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.3 Petrol koku disindaki yakitlar ve/veya atiklarin ek yakit olarak kullanildigi boksit, dolomit, alçi, kireçtasi, kiselgur, magnezit, kuvars veya samot pisirme tesisleri', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 3, 1100, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2290d839-7abb-4f28-ab05-1ecdd9b00696', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:46.712012', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.4 Kireç ögütme, söndürme veya paketleme tesisleri,', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 4, 1101, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d6f7e415-7fea-4b5f-8f03-e97d015e22f2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:48.324978', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.5 Alçi,  kiselgur, magnezit, mineral boya, midye kabugu, talk, kil, tras veya kromit ögütme tesisleri', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 5, 1102, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('681b2735-c893-4974-b91a-ad47807bcb00', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:50.015152', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.6 Perlit, sist veya kil patlatma tesisleri', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 6, 1103, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('8cebe551-b644-4701-8578-84a4f4bb3239', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:50.224626', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.7 300 ton/gün?ün altinda eritme kapasitesine sahip, cam elyaf dahil cam üretim tesisleri. (Haberlesme ve medikal alanda kullanilan ürünleri hazir cam çubuk, bilye ve kütükten üreten tesisler, hazir cam çubuk, bilye ve kütükten elyaf çekme yoluyla cam elyaf üreten tesisler hariçtir.)', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 7, 1104, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('cf37bd4e-2489-4e30-bee4-82c9fcc8c596', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:50.364263', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.8 Cam ve cam ürünlerini asitlerle parlatan veya matlastiran tesisler.*', true, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 8, 1105, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d049238b-8b0f-47db-9013-7f181d35a0a7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:50.507858', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.9 300 ton/gün altinda seramik veya porselen üretiminin yapildigi tesisler.', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 9, 1106, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('757f70f2-5101-4f9d-86d6-b77cd651a232', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:50.629695', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.10 Üretim kapasitesi 75 ton/gün ve üzerinde olan özellikle ates tuglasi, çati kiremitleri, tugla, yassi kiremit ürünlerin imalatinin yapildigi tesisler.', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 10, 1107, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6a5a748e-4fe8-445b-b2b7-0f742b0f207d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:50.818553', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.11 Ergitme kapasitesi 20 ton/gün ve üzeri olan mineral elyaf dahil mineral madde ergitme tesisleri', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 11, 1108, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e05a5cd6-1d86-424f-bf50-9e67a9ccf1b5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:50.965742', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.12 Gazli beton bloklari ve buhar basinci altinda kum-kireç briketi veya elyafli çimento levhalarin üretildigi tesisler.', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 12, 1110, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('fec830a5-9dde-47a7-be4a-79e00958811f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:51.174179', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.13 Üretim kapasitesi 10 m3/saat veya üzerinde olan, çimento kullanarak beton, harç veya yol malzemesi üreten tesisler; malzemelerin sadece kuru olduklari zaman karistirildiklari yerler dahil. (Kurulduklari yerde bir yildan az kalacak tesisler hariçtir.)', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 13, 1111, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('81501049-80b9-4b2a-b278-34e7162adb01', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:51.307636', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.14 Üretim kapasitesi 5 ton/saat ve üzerinde olan, çimento veya diger baglayici maddeler kullanarak, sikistirma darbe, sarsma ve titresim yoluyla sekillendirilmis malzeme üreten tesisler.', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 14, 1112, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c5f54939-3f8a-4526-97e1-c11e152f7d24', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:51.438058', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.15 Yol malzemesi hazirlayan asfalt plent tesisleriyle(katran eritme ve püskürtme tesisleri dahil) mineral malzemeli bitüm veya katran karisimlarini eriten ve üreten tesisler.', true, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 15, 1113, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('67f3626d-57b8-4969-ad02-8bfe6d88f6ce', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:51.569158', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.16 Patlayici kullanilan maden ocaklari.', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 16, 1114, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('44aaec86-6573-453a-8a0e-1275e17b53d6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:51.716417', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.17 Üretim kapasitesi 200 ton/gün ve üzeri olan ve 4/6/1985 tarihli ve 3213 sayili Maden Kanununun I.Grup b, II.Grup (kireçtasi dahil), IV.Grup, V.Grup?larinda yer alan madenlerin çikartildigi ocaklar', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 17, 1115, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c1f499d7-8087-46cb-8e22-b0dda63e02ef', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:51.862755', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.18 Üretim kapasitesi 200 ton/gün ve üzeri olan ve 3213 sayili Maden Kanununun I.Grup b, II.Grup (kireçtasi dahil), IV.Grup, V.Grup?larinda yer alan madenlerin ve cüruf ve molozlarin kirilmasi, ögütülmesi, elenmesi için kurulan tesisler.', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 18, 1116, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('040e9aa9-6b2a-4d37-aca9-1baddd34cd80', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:52.189826', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.19 Kapasitesi 20.000 m3/yil ve üzerinde olan mermer üretim veya isleme tesisleri', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 19, 1117, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('03364f69-e078-4063-b420-7d85a4b4da0e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:52.394905', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.20 Kömür ve/veya cevher hazirlama ve/veya zenginlestirme tesisleri,', false, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 20, 1118, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('07770567-4b02-4c56-9a8b-df8a0b999322', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:52.838393', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '2.22 Tuz isletmeleri,*', true, '8605bfed-5ce1-47fd-a4b3-8c8165ad3242', 22, 1123, 1097, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('178b6694-6202-4543-b85c-765092f2c515', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:53.017453', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.1 Kapasitesi 15 ton/ gün ve daha büyük, 100 ton/ gün?den küçük cevherden, konsantreden ya da ikincil hammaddelerden metalürjik, kimyasal veya elektrolitik prosesler ile demir içermeyen ham metal üretim tesisleri,', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 1, 1125, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7afc4ff0-33ea-4d39-96e4-ae3c1bd3f851', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:53.15536', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.2 Kapasitesi 50 ton/gün ve daha büyük, 500 ton/ gün?den küçük ham demir üretim tesisi (Kupol Ocaklari dahil)', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 2, 1126, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('4af8465a-eb61-4c8a-938b-b5d42c04587f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:53.335283', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.3  Kapasitesi 2000 ton/ günden az olan hurda demir çelikten çelik üreten tesisler', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 3, 1127, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('18cd0c8e-314e-4122-8448-08a3e2f231ca', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:53.461206', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.4 Kapasitesi 100 kg/gün ve daha büyük, 50 ton/gün?den küçük demir disi metal ergitme tesisleri (Vakumlu ergitme tesisleri ve Basinçli döküm veya kokilli döküm makinalarinin bir parçasi olan ergitme tesisleri haric)', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 4, 1129, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('b04eaf2d-9511-4c48-854a-38d451e4d106', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:53.604364', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.5 Sicak Haddeleme Tesisleri', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 5, 1132, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('18e72ca3-8f12-4622-bc2a-1e94e205d4fd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:53.802887', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.6 Soguk Haddeleme Tesisleri', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 6, 1136, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('cb268c96-c869-4c27-ae10-36f22769be41', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:53.927294', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.7 Üretim kapasitesi 700 ton/gün?ün altinda olan demir, temper veya çelik dökümhaneleri.', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 7, 1139, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0d41b449-90a9-48c0-af5a-d364a3a785ec', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:54.060806', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.8  5000 adet/gün den  az kursunlu akümülatör ile endüstriyel akümülatör hücreleri üreten tesisler.*', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 8, 1140, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6538452e-1b90-4bff-8e92-66c77eda1085', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:54.178173', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.9 Isleme tanklarinin hacminin 30 m³ den ve üzeri elektrolitik veya kimyasal bir proses kullanilarak metal ve plastik maddelerin yüzey islemesinin yapildigi tesisler,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 9, 1143, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('1885dadc-2561-4a5a-aacd-a88ed5f50df2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:54.344974', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.10  Batarya ve pil vb üreten tesisler,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 10, 1145, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('73ae64f5-1e2b-42e0-adf7-9f115e431e0a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:54.503711', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.11 Kaplama kapasitesi 1 ton/saat ve üzerinde olan ergitme banyolu veya alev püskürtme ile metal yüzeylerinin kursun, kalay veya çinko gibi koruyucu tabakalari ile kaplandigi tesisler. (Sendzimir metodu ile çalisan sürekli çinko kaplama tesisleri hariçtir).*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 11, 1146, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('096042c2-9ee3-43c0-97be-836bb7b3ded7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:54.64359', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.12  Her tokmagi 50 kJ veya  üzerinde enerji ile çalisan ve  isil gücü 2 MW ve daha fazla olan tokmakli (sahmerdanli)  tesislerde sicak metallerin sekillendirildigi tesisler. (Metal levhalarin soguk olarak preslendigi tesisler hariç.)', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 12, 1148, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('31936158-0690-4db9-830c-5696c278b936', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:54.795325', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.13  10 ton ve daha fazla bulon, çivi, perçin, somun vb. Makine parçalariyla, bilye, igne ve benzeri standart metal parçalarin birlikte otomatlarda basinçla biçimlendirildigi tesisler', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 13, 1149, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('34b5dd82-d1f7-4af8-8419-7e4b37012347', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:54.950354', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.14  Her seferinde 10 kg veya üzerinde patlayici madde kullanilarak detonasyonla biçimlendirme veya metal kaplama islemlerinin yapildigi tesisler', false, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 14, 1150, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('21fc3a38-51f9-4b4d-999a-bae1b77eaae2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:55.1737', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.15    Asagidaki makinelerin üretildigi veya tamirinin yapildigi tesisler.*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 15, 1152, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a307cd1c-9fc0-499e-a654-3f0802a75327', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:55.310742', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.16 Soguk ve/veya Sicak biçimlendirme metoduyla üretilen çelik dikissiz veya kaynakli boru üreten tesisler*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 16, 1155, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('4d8564bb-026f-40dd-9cbc-432a7ba967ab', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:55.461515', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.17 Püskürtmeli maddelerle demir-çelik yapi konstrüksiyonlari, çelik konstrüksiyonlar ve sac parçalari yüzeylerinin muamele edildigi ve taslama veya zimparalama tesisleri. (Kapali devre çalisan püskürtme maddesinin devrede kaldigi tesisler hariçtir),*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 17, 1156, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('bc0c5327-9d1a-46c4-a3a4-e536ae32c3e6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:55.630222', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.18 Metal tozlari veya pastalari üreten tesisler,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 18, 1157, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7759bb0b-4d64-4e11-a94f-0e302228a42b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:55.968075', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.19 Motorlu tasitlarin motorlarinin üretimi,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 19, 1158, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('07b84306-b9c9-4a2d-8540-ef004a760101', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:56.124685', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.20 Gemi, yat insa ve bakim onarim tersaneleri,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 20, 1159, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c9906eb8-73fb-4140-915b-56474795f213', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:56.276173', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.21 Uçak yapim ve bakim tesisleri,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 21, 1160, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('77a96a12-10f1-4efd-9de8-93b427f97fff', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:56.466144', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.22 Demiryolu ekipmani üretimi,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 22, 1161, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2fa03c01-1322-4e23-b0f1-35040167955c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:56.609276', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.23 Patlayicilar ile baski yapilmasi,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 23, 1162, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d102ff4c-f4f7-4446-853a-4f5707c6779a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:56.765675', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.24 Metallerin sirlama, emaye ve/veya mineleme isleminin yapildigi tesisler,*', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 24, 1163, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a2b61f7c-65e0-4ca2-9cae-bf7067f53900', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:56.885875', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.25 Demir disi metal oksit (alüminyum oksit ve çinko oksit gibi) üretim tesisleri *', true, '31549fa8-b62e-40a2-93ae-e05bcfb5da6d', 25, 1164, 1124, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2b89094a-46c0-4e93-960f-41e52c61af8f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:56.998696', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '      3.5.1 Kapasitesi, 5 ton/gün ve daha büyük, 5000 ton/gün?den küçük olan  demir veya çeligin haddelendigi tesisler.', false, 'b04eaf2d-9511-4c48-854a-38d451e4d106', 1, 1133, 1132, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('89774f3b-c2e8-4e4c-ba48-001761cb30e2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:57.13368', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '      3.5.2 Kapasitesi, 5 ton/gün ve daha büyük, 250 ton/gün?den küçük olan  demir disi metallerin haddelendigi tesisler.', false, 'b04eaf2d-9511-4c48-854a-38d451e4d106', 2, 1134, 1132, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('3e5578dc-3f73-44da-b0f4-efcc04841554', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:57.289668', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '      3.5.3  Haddeleme islemi yapilmayan ve anma isil gücü 1 MW ve daha büyük olan metallerin isil isleme tabi tutuldugu firinlar (tav firinlari vb)', false, 'b04eaf2d-9511-4c48-854a-38d451e4d106', 3, 1135, 1132, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7cedb083-8e91-4d42-a8fd-a50d3aa11609', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:57.436363', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '       3.6.1 Kapasitesi 10 ton/gün ve daha büyük olan demir veya çeligin haddelendigi tesisler.', false, '18e72ca3-8f12-4622-bc2a-1e94e205d4fd', 1, 1137, 1136, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('56cd651f-fdaf-426d-9dba-9ee8a3152bfa', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:57.562964', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '       3.6.2 Kapasitesi 5 ton/gün ve daha büyük olan demir disi metallerin haddelendigi tesisler.', false, '18e72ca3-8f12-4622-bc2a-1e94e205d4fd', 2, 1138, 1136, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e68c8ec7-6436-4f12-b908-74ec1f0622b9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:57.728701', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.15.1    Günde en az bir adet ve toplam hacmi 30 m3 ve üzerinde olan metal saçtan yapilmis  depo, tank vb. üreten tesisler', false, '21fc3a38-51f9-4b4d-999a-bae1b77eaae2', 1, 1331, 1152, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('4a1aff3f-cc7d-4938-ad90-7b0814eaa22a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:57.950576', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '3.15.2    Günde en az bir adet ve taban alani 7 m2 veya üzerinde olan konteyner üreten tesisler', false, '21fc3a38-51f9-4b4d-999a-bae1b77eaae2', 2, 1332, 1152, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e5ed627c-b660-4271-abbd-d76fca5d9b55', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:58.100444', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.1 Entegre kimya tesisleri', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 1, 1167, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a94db4cc-4a56-484c-8e48-d348b20ed20d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:58.258802', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.2 Toplam 2 ton/gün ve daha fazla ,100 ton/gün?den az organik kimyasal çözücü maddelerin (alkoller, aldehitler, aromatikler, ketonlar, asitler, esterler, asetatlar eterler vb.)  hammadde olarak kullanildigi tesisler*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 2, 1188, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e6c63176-8269-4455-900b-00d1841142c8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:58.409042', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.3 Bitki Koruma Ürünlerinin ve biyositlerin üretimi ve Bitki Koruma Ürünleri ile bunlarda kullanilan etkin maddelerin ögütüldügü, mekanik olarak, karistirildigi, paketlendigi ve bosaltildigi ve yeniden paketlendigi tesisler.*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 3, 1189, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2c12aa92-ee0c-4e6a-8948-7df54a8c0e7c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:58.595386', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.4 Farmasötik ürünlerin üretimi (alkaloid tesisler dahildir.)', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 4, 1190, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('f878d5f2-3210-402f-9af8-023651456b00', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:58.783374', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.5 Yaglayici maddeler, gres metal yaglari benzeri yaglama sivilarinin üretildigi tesisler*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 5, 1191, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('65180163-ba8f-4ef3-bfd3-d05d970ff8ce', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:58.90751', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.6 Kurum  ve karbon siyahi üreten tesisler.*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 6, 1192, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e248e575-96b6-4a3b-a453-5bf5fd7ac4ba', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:59.058704', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.7 Karbon üreten tesisler veya yakma yolu ile elektrotlar, elektrik kullanicilari veya aygit parçalari v.b. için elektro grafit üreten tesisler*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 7, 1193, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('cd8b062a-7dbe-4654-9229-ed25a4449241', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:59.271764', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.8 Kapasitesi 25 kg/saat veya üzerindeki dogal ve/veya  sentetik reçinelerin ergitildigi tesisler*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 8, 1194, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0c364e8e-0309-4345-a459-4569b4d1e060', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:59.448147', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.9 Üretim kapasitesi 1 ton/gün ve üzerinde olan boya, pigmen, vernik, cila, elastomer ve peroksit üretim tesisleri (Ek-1?de bulunmayan faaliyetler)*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 9, 1195, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('69e8d24c-3974-4efc-9a0a-da1dc2bd6d3c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:59.566767', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.10 Elastomer bazli ürünlerin üretimi ve muamelesi,*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 10, 1196, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('eadb257b-b47a-4d56-ade6-d32b1eb81717', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:59.726567', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.11 Selüloit üretim tesisleri  *', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 11, 1197, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d3f687e0-53ee-451e-91c8-406039a50e4b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:26:59.927136', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.12 Azot içerigi %12,6?ya kadar olan Nitroselüloz kullanilarak vernik ve baski boyasi için katki maddesi üreten tesisler.*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 12, 1198, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('3d61f05e-ba8a-4bae-8432-75692b5b4ed9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:00.113278', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.13 Sülfat terebentin yagi veya tall-yaginin temizlenmesi ve islenmesi için kullanilan tesisler.*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 13, 1200, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a889db2f-57fb-4f8d-8ac5-98ee0bd91e1a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:00.224288', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.14 Yapilari koruma, temizleme, ahsap koruma veya yapistirma maddelerinin üretildigi üretim kapasitesi 1 ton/gün veya daha fazla olan tesisler. (Sadece suyun çözüm maddesi olarak kullandigi ve 4.1.de verilen tesisler hariçtir.)*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 14, 1201, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('85ceb117-603d-45c2-b183-b7b16928e3e5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:00.655129', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.15 Halojenli aromatik hidrokarbonlar kullanilarak ahsap koruma maddeleri üreten tesisler (4.1.?de verilen tesisler hariçtir.)*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 15, 1202, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5e7440ad-fda2-476d-a07c-6e1617af11b3', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:00.833561', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.16 Terbiye islemlerinden kasar (hasil, sökme, agartma, merserizasyon, kostikleme vb.) ve boyama birimlerini birlikte içeren,üretim kapasitesi 3.000 ton/yil altinda olan iplik,kumas veya hali fabrikalari.', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 16, 1203, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('16c504f7-133b-4b3f-8963-654ac6be2f03', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:01.011203', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.17 Alkalik maddeler, klor ve klor bilesiklerinin kullanildigi iplik veya kumas agartma tesisleri.*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 17, 1204, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('639d6ef2-c1be-4570-a6e3-2b98e1b67dfb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:01.142075', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.18 Biyodizel üretim tesisleri(1 ton/gün ve üzeri kapasiteli metanol vb organik kimyasal maddelerin hammadde olarak kullanildigi tesisler)*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 18, 1205, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('19236325-622f-4070-a47b-5d9c4c6b1083', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:01.290904', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.19 Kimyasallarin ve ara ürünlerin islenmesi (Ek-1 ve Ek-2?de tanimlanmayan  faaliyetler için),*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 19, 1206, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('da600186-6f37-4b07-9cf1-ac9d30066883', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:01.448868', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.20 Zifir Üretim Tesisleri*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 20, 1207, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('8231c079-c489-45d2-bf5a-ebb2b3030696', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:01.570945', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.21 Dogal asfaltin ergitildigi veya damitildigi tesisler*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 21, 1208, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c7440775-74c0-4961-a0ff-440c4059ae9c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:01.690874', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '4.22 Zift buharlastirma tesisleri*', true, '58f43af8-77f7-48f0-bad5-305cd9bb845c', 22, 1209, 1166, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('fa5b92af-29ba-42ae-b20e-80b4ea4bb8cb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:02.050356', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.1 Üretim kapasitesi 200 ton/gün''den az olan asitler, bazlar veya tuzlar gibi inorganik kimyasal maddelerin üretildigi tesisler.', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 1, 1170, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('73b406cd-0b8f-4c35-81d6-75214a8db3bc', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:02.257043', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.2 Islak metot veya elektrik enerjisi kullanilarak metaller veya metal disi maddelerin üretildigi tesisler.', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 2, 1171, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('90cff11a-937f-4507-a1f2-8812f7851502', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:02.375976', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.3 Korindon, ametaller, metal oksitler ya da kalsiyum karpit, bor ve bilesikleri, zirnik, dispeng oksit, silisyum, silisyum karpit gibi diger inorganik maddelerin  üretildigi tesisler.', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 3, 1172, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('abd5d97e-4693-4b2d-bd07-13ac0ddf9177', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:02.520615', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.4 Halojenler veya halojen ürünleri üreten tesisler (organik halojenli bilesikleri üreten tesisler hariç).', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 4, 1173, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('45b3dfb0-b033-4f9c-8666-d880cae165dc', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:02.760265', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.5 Basinç altinda çözülen asetilenin üretildigi tesisler.', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 5, 1174, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('9c128a5c-e17b-4a49-96dc-74d2aa270d01', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:02.982161', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.6 Üretim kapasitesi toplam 2 ton/gün ve daha fazla ,100 ton/gün?den az olan organik kimyasal çözücü maddelerin (alkoller, aldehitler, aromatikler, ketonlar, asitler, esterler, asetatlar eterler vb.) üretildigi tesisler', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 6, 1175, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ae6aca53-aa68-428d-ac18-10a4c8ade456', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:03.114986', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.7 2 ton/gün ve daha fazla ,100 ton/gün?den az basit hidrokarbon (lineer veya döngüsel, doymus veya doymamis, alifatik veya aromatik) üreten tesisler', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 7, 1176, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('fed45641-ddac-4e94-b6bb-452232bbcd44', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:03.257174', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.8 Organometalik bilesiklerin üretildigi tesisler', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 8, 1177, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2b720b56-d729-4bf3-bfb0-f720359a2ad9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:03.399787', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.9 Temel plastik maddelerin (polimerler, sentetik elyaflar ve seluloz bazli elyaflar) üretildigi tesisler', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 9, 1178, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('53adae95-4697-4490-88c4-5e3e599990e2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:03.531743', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.10 Sentetik kauçuk üreten tesisler', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 10, 1179, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('849c9b32-bc74-47ed-b790-3086f8e0242d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:03.67395', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.11 Yüzey aktif maddelerin üretildigi tesisler', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 11, 1180, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0ec38976-8926-48b0-a7a9-828e468b6edc', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:03.833461', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.12 Selüloz nitrat üretim tesisleri', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 12, 1181, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('fe7dd7a7-e651-4920-b4e2-8aacd11559af', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:04.014555', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.13 Sentetik reçine üreten tesisler', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 13, 1182, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('fcd6aa98-c629-4083-9af9-114792d1841a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:04.13274', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.14 Kauçuk, kükürt veya karbon kullanilarak  vulkanize lastik üreten tesisler.( Saatte 50 kg?dan az kauçuk islenen tesisler veya yalniz vulkanize kauçuk kullanilan tesisler   tesisler hariçtir)', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 14, 1183, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('94dda437-3552-4721-bda0-7675022303b4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:04.240748', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.15 Hammadde olarak 3 ton/gün ve üzeri lastik kullanan veya lastik  rejenere eden tesisler.', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 15, 1184, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('bc0c1182-fbc2-4e2b-910c-7b9cea52a312', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:04.366555', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.16 Katran boyalari veya katran boyasi ara ürünlerinin üretildigi tesisler.', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 16, 1185, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2184ef82-8a62-4d5e-ab3b-14f9149d5beb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:04.653554', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.17 Hammadde üretim ünitesini içeren sabun ve/veya deterjan üretimi yapan tesisler', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 17, 1186, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ccfa7723-f886-4589-80e2-8b37f737b112', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:04.845072', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.18 Kapasitesi 2 ton/gün  ve daha büyük olan sabun üreten tesisler.', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 18, 1187, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('259af330-5193-494f-9d07-d268045918f7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:04.999249', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    4.1.19 Hammadde asamasindan baslayarak suretiyle 50 ton/gün alti fosfor,azot ya da potasyum bazli gübre üretimi (basit bilesik gübreleri)', false, 'e5ed627c-b660-4271-abbd-d76fca5d9b55', 19, 1368, 1167, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('66ad277c-9c95-4901-b03a-0c35e3d67bfb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:05.158055', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.1 Maddelerin, profil ve tabaka biçimindeki malzemelerin cilalandigi, kurutuldugu tesisler(Cilalarin organik çözücü madde içerdigi ve cila kullanim kapasitesinin 25 kg/saat ve daha büyük, 250 kg/saat?den küçük oldugu  tesisler.)*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 1, 1211, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a476f62d-e37d-42ca-a591-0efccad4cfd4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:05.339805', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.2 Profil ve tabaka biçimindeki malzemelerin döner baski makinalari ile basildigi ve kurutuldugu tesisler.*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 2, 1212, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('f3784ea2-5bcb-43b3-a64c-0f0c21b086f2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:05.464865', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.3 Cam elyaf, mineral elyaflar veya profil ve tabaka biçimindeki malzemelerin kimyasal tabaka, plastik maddeler veya lastik ile kaplandigi, emprenye edildigi, doyuruldugu ve arkasindan kurutuldugu tesisler.*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 3, 1215, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('de9d91c1-f92e-4cd0-986e-0fcbe41f6132', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:05.631401', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.4  500-10.000 adet/yil arasinda motorlu tasitlarin üretimi,(kara tasitlari (otomobil,kamyon vb),tarim makinalari (traktör,biçerdöver vb.),is makinalari(dozer,ekskavatör vb.),savunma sanayi tasitlari (tank,zirhli araç vb.) boyandigi ve verniklendigi tesisler.', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 4, 1220, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('18e1827d-14d5-4cf9-9b8a-50d3be97dd52', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:05.756384', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.5  Demiryolu tasitlarinin üretiminin yapildigi tesisler (Tüm parçalarin sadece montajinin yapildigi tesisler hariç)(1.000 adet/yil ve alti)', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 5, 1221, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('22732d6b-d919-4f22-8eba-44a5592830da', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:05.915361', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.7  Ahsap veya metal yüzeylerin 10 kg/saat ve daha fazla, 250 kg/saatten az organik çözücü kullanilarak boyandigi tesisler.*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 7, 1222, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c133aa5c-d0f1-4f30-9999-3805d29d3189', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:06.091193', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.8  Madde ve araç gereçlerin katran, katran yagi veya sicak bitümle kaplandiginda doyuruldugu tesisler (kablolarin sicak bitümle doyuruldugu ve kaplandigi tesisler hariçtir.)*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 8, 1223, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('bcaf7b86-67b3-47e9-8e22-d9c8700f5bd4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:06.236529', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.9  Tellerin fenol veya kresol reçinesi veya diger organik madde kullanilarak izole edildigi tesisler.*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 9, 1224, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ef474ac4-3bce-4c18-8d14-49c9d2c03d17', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:06.348027', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.10  Bant biçimindeki malzemeleri plastik maddelerle kaplayan; tesislerle plastik maddeler, yumusaticilar okside ve beziryagi ve diger maddelerden meydana gelen karisimlari kurutan tesisler.*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 10, 1225, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('4701f135-23c4-46e6-879a-51906e9731b5', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:06.479738', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.11 Üretim kapasitesi 500 kg/saat ve üzerinde olan stiren katkili veya aminli epoksi reçineli sivi veya doymamis poliester reçinelerinin islendigi tesisler.*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 11, 1226, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('b80b17d5-604a-406f-b0d4-5f85f3779a3d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:06.590416', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.12 Isil islem yoluyla furan, üre fenolü resorsin maddeleri veya ksilen reçinesi gibi aminoplast veya fenol formaldehit plastlarin kullanimi ile madde üretilen tesisler. (Ana girdi maddeleri 10 kg/saat veya üzerinde olan tesisler dahildir).*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 12, 1227, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('644567bc-a9df-4a0e-a079-04ada8d34163', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:06.705497', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', ' 5.13 Asbest kullanilmamasi kosulu ile fenol veya diger plastik reçineli baglayici maddelerin kullanilmasi suretiyle balata üretilen tesisler.*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 13, 1228, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ea5269ac-b5bc-49df-b393-0122fa9ce007', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:06.84226', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', ' 5.14 Organik baglayici maddeler veya çözücüler kullanilarak yapay zimpara plakalari, parçalari, zimpara kagitlari veya dokularinin üretildigi tesisler.*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 14, 1229, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('9de6aba3-0adc-480d-a07b-78b38ed5f049', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:07.00683', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', ' 5.15  Poliüretan biçimlendirme maddeleri veya poliüretan köpügü ile maddeler içerisinde bosluk olusturma çalismalari yapan tesisler.( Ana girdi maddelerinin  1000 kg/saat ve üzerindeki tesisler dahil olup, termoplastik poliüretan kullanan tesisler hariçtir.)*', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 15, 1230, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7f47ec53-3f93-4d86-9951-9c9c3836fda0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:07.206111', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '5.6  Beyaz esyalarin boyanarak üretiminin yapildigi tesisler.', true, 'd535b814-0d81-43d7-8d9a-d647d74f3e2e', 6, 1370, 1210, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0b88fad5-3788-4f06-9bd9-b78131652cfe', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:07.350163', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     5.2.1 Boya ve Cila maddeleri: Organik çözücü olarak yalniz etanol ihtiva eden ve bundan 50 kg/saat ve üzerinde, 500 kg/saat altinda  kullanan tesisler', false, 'a476f62d-e37d-42ca-a591-0efccad4cfd4', 1, 1213, 1212, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6c5de783-66ef-4505-918c-f4a6947306fb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:07.486392', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     5.2.2 Boya ve Cila maddeleri: Diger organik çözücüleri 25 kg/saat ve daha fazla, 250 kg/saat?den az kullanilan tesisler.', false, 'a476f62d-e37d-42ca-a591-0efccad4cfd4', 2, 1214, 1212, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ca604694-4135-4dcc-93d7-30023bec8c19', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:07.631511', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     5.3.1 Sentetik reçine kullanimi 25 kg/saat ve daha fazla olan tesisler.', false, 'f3784ea2-5bcb-43b3-a64c-0f0c21b086f2', 1, 1216, 1215, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('493bab20-28d7-4828-85af-48bdb86ba11b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:07.806001', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     5.3.2 Plastik madde kulanim kapasitesi 25 kg/saat ve daha fazla olan tesisler', false, 'f3784ea2-5bcb-43b3-a64c-0f0c21b086f2', 2, 1217, 1215, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a59fe557-543e-4d9c-908b-28d3c4b63417', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:07.97559', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     5.3.3 Organik çözücü kullanim kapasitesi 25 kg/saat ve daha fazla olan tesisler.', false, 'f3784ea2-5bcb-43b3-a64c-0f0c21b086f2', 3, 1218, 1215, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('bc472792-1395-4f9e-87df-1258815307fe', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:08.099775', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '6.4 Hazir selülozdan ve /veya atik kagittan her çesit karton, kagit veya mukavva üretimi yapan tesisler(300 ton/gün alti kapasiteli)', false, '0641e8f7-78f5-46f6-90d2-d3efc814bbe7', 4, 1232, 1231, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ce7ca25d-e9a8-4e9c-9e39-4f0db05f7ad0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:08.254536', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '6.1 Hammadde olarak agaç ve agaç ürünleri kullanilarak 50 m3/ay ve daha fazla kapasitede sunta ve benzeri malzemeleri üreten tesisler', false, '0641e8f7-78f5-46f6-90d2-d3efc814bbe7', 1, 1233, 1231, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ccd388d2-e3d9-41b0-baf6-26af2cb0ff4a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:08.515161', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '6.2 Agaç isleme tesisleri ve/ veya  tahrik gücü 100 kW veya üzerinde olan kereste üretim (hizar fabrikalari) tesisleri', false, '0641e8f7-78f5-46f6-90d2-d3efc814bbe7', 2, 1234, 1231, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('939dfa3d-c049-4039-b907-7451477a5621', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:08.655697', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '6.3 Üretim kapasitesi 300 m3/ay ve üzerinde olan, hammadde olarak agaç ve agaç ürünleri kullanilarak mobilya ve parke vb yer dösemesi üreten fabrikalar*', true, '0641e8f7-78f5-46f6-90d2-d3efc814bbe7', 3, 1235, 1231, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a1a41421-496c-4747-afd0-45faab4e4dc7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:08.822278', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.1 Süt isleme tesisleri.(çig süt isleme kapasitesi 10.000 litre/gün-100.000 litr/gün arasi)*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 1, 1238, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('cf1b0536-07d3-45d3-82bb-ae37f108ac3c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:08.962056', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.2 Fermantasyon ile içki imalinde kullanilan 1000 m3/yil ve üzerindeki suma üretim veya 1000m3/yil ve üzerindeki malt tesisleri.', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 2, 1239, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6e8a0b3e-1409-4584-a319-4e39c429b903', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:09.128629', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.3 Suma ve malttan 50.000 m3/yıl altında alkollü içecek üreten yerler*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 3, 1240, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c5bdab95-0899-41e8-946d-afc641065fb4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:09.282294', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.4 Alkolsüz içecek üreten yerler.', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 4, 1241, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0141ae4d-0aae-4227-a466-d1b255d210a7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:09.482637', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.5 Kapasitesi 5 ton/gün ve üzeri sekerleme/çikolata ve surup üretim tesisleri,*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 5, 1244, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('07bd616a-85fb-409b-bbf3-0e2435d71d96', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:09.854385', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.6 Hayvansal yaglarin ergitildigi tesisler.(Özel kesim tesislerinde kazanilarak islenilen, haftalik isleme kapasitesi 200 kg ve üzerinde olan tesisler.)*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 6, 1246, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('f5557269-e5a2-4bb4-acdd-296c5b1fd473', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:09.966421', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.7 Hayvan organlari veya hayvansal ürünlerin, hayvansal atiklarin toplandigi, ortadan kaldirildigi tesislere gönderilmek üzere depolandigi tesisler ve hayvan cesetlerinin yakilarak ortadan kaldirildigi tesisler*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 7, 1247, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6f2a9840-272b-46ea-b297-54fd7e0e89dc', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:10.302298', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.8 Kemik, kil, yün, boynuz, tirnak ve kan gibi kesim artiklarindan yem, gübre veya teknik yaglarin üretildigi tesisler. (Rendering tesisleri vb.)*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 8, 1248, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7b92a9ac-3a82-4978-8fd1-8076b080489b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:10.496824', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.9 Hayvan kesim artiklarindan jelatin veya tutkal üretim tesisleri.*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 9, 1249, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('95fa9ff9-1e4a-4f20-a491-47f093295f52', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:10.772116', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.10 Yünün disinda, islenmis hayvan derisi veya kili depolama ve isleme tesisleri. (Et ve Et Ürünleri Üretim Tesislerinin Kurulus, Açilis, Çalisma ve Denetleme Usul ve Esaslarina   Dair meri mevzuat da belirtilmeyen ve isletmenin kendi ihtiyaci için kazandigi hayvansal killar hariç.)*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 10, 1250, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('89e6078b-becf-4cd1-90e0-3d5c7be0701b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:10.921988', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.11 Kapasitesi 2.000 ton/yil altinda olan ham deri isleme tesisleri (konfeksiyon ürünleri hariç)', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 11, 1251, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('eed62e0f-ec6f-477b-90d4-410ffe085f56', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:11.080922', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.14 Üretim kapasitesi 30 ton/gün altinda olan zeytin isleme tesisleri.', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 14, 1252, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5570ba8a-b2bc-40f2-8aa2-4422f763a11b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:11.308082', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.15 Bitkisel ürünlerden ham yag üretimi veya rafinasyon isleminin yapildigi tesisler.(200 ton/gün yag alti (kekik,papatya vb. Esansiyel yaglar hariç))', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 15, 1253, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('421d5d9b-1066-46da-83a8-237a313886f8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:11.437151', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.12 Balik veya kemik unu üretim ve/veya depolama tesisleri,*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 12, 1255, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('bb909c08-29ff-40ae-8d2e-aca7bc1bd9c7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:11.603736', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.13 Balik yagi fabrikalari,*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 13, 1256, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('8b0aef34-3ed5-4ec9-aca2-a4fd212f14c1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:11.746543', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.17 Kapasitesi 25.000 ton/yil altinda olan maya üretim tesisleri.', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 17, 1257, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d8b2b751-b1a6-4223-8bf3-a130c522981c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:11.866671', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.16 Çay fabrikalari.*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 16, 1258, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0a938246-1e77-41d2-8342-91c52e859b07', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:12.080183', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.18 Hayvansal ve/veya bitkisel maddelerden asitler kullanarak baharat üreten tesisler*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 18, 1260, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0dceaf41-8ae4-4198-bd0c-d2e23d508ded', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:12.221335', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.19 Süt tozu üretim tesisleri*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 19, 1261, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c9301e4e-78ec-4ec4-b6a5-8e562060b858', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:12.354713', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.20 Nisasta üretimi veya nisasta türevlerinin üretildigi tesisler*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 20, 1262, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('64dc55e9-ce00-4d1c-a92e-01ee774c7f2c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:12.538721', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.21 Hayvan yemi kurutma tesisleri*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 21, 1263, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('4d2c9989-8f86-404d-a791-19eab7ba26da', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:12.869932', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.22 Hayvan diskisi  kurutma tesisleri*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 22, 1264, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2fa62eb5-dfc0-4588-add2-8ed70ae4c98f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:12.995046', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.24 Bitkisel yag üreten tesisler (Eleme ve tozdan arindirma, kirma, ezme, isitma, pres veya santifüj vb. islemlerin tümünü veya birkaçini yaparak ham yag üreten bitkisel yag üretim tesisleri hariçtir).*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 24, 1266, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d74c5da8-5330-4e3b-899b-b3b1265c5428', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:13.118339', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.25 Hayvansal yag üreten tesisler*', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 25, 1267, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e865d2a1-68ab-4573-a4b8-356696bc5cf6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:13.25421', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.26 Hayvan Yetistirme Tesisleri', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 26, 1268, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c253e6f8-346e-4a33-90cf-776021371843', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:13.431045', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.27 Su ürünleri isleme tesisleri.', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 27, 1272, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a8dfd95a-675a-4429-969a-962e6b1958d2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:13.83918', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '7.28 Hayvan Kesim Tesisleri', true, 'bc09458b-8ad2-490f-8cb0-3773e80ded4d', 28, 1276, 1236, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('958b1fa4-fc2a-4dce-a6ee-493ce6d661c4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:14.128901', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     7.26.1  500 - 5000 arasi büyükbas yetistirme tesisler', false, 'e865d2a1-68ab-4573-a4b8-356696bc5cf6', 1, 1269, 1268, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('b6428feb-4430-4505-b2fa-a495e540bc77', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:14.325364', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     7.26.2  2500-25.000 arasi küçükbas yetistirme tesisleri', false, 'e865d2a1-68ab-4573-a4b8-356696bc5cf6', 2, 1270, 1268, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('39902fa0-1057-444b-a7e5-f475462e690a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:14.5284', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     7.26.3 Büyükbas ve küçükbas hayvanlarin birlikte yetistirilmesi.(500-5000 arasi,1 büyükbas=5 küçükbas esdegeri esas alinmalidir.)', false, 'e865d2a1-68ab-4573-a4b8-356696bc5cf6', 3, 1372, 1268, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('3c8f960a-c17d-4e3e-8482-1bd6d7f1c848', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:14.735269', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     7.26.4 1000 bas altinda domuz besi tesisleri.', false, 'e865d2a1-68ab-4573-a4b8-356696bc5cf6', 4, 1373, 1268, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6b4ae0ca-9335-47fc-97a1-283919fe0762', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:15.35893', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     7.26.5 Kanatli yetistirme tesisleri.[bir üretim periyodunda 20.000-60.000 arasitavuk (civciv,damizlik,piliç vb) veya esdeger diger kanatlilar](1 adet hindi =7 adet tavuk esdegeri esas alinmalidir.)', false, 'e865d2a1-68ab-4573-a4b8-356696bc5cf6', 5, 1375, 1268, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('6843e928-4152-4b8f-993f-c10c0ab7caf7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:15.584567', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     7.26.6 Limit yumurta üretim tesisleri 10 ton/gün ve üzeri.', false, 'e865d2a1-68ab-4573-a4b8-356696bc5cf6', 6, 1377, 1268, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e71b2c51-3619-40e1-ac72-062a0a8dcbdb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:20.510739', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.6  Limanlar,yat limanlari(Karasularimizda tarifeli seferler yapan gemilerin yolcu almak için yanastigi limanlar,balikçi barinaklari hariç )', true, '09141047-8ad1-4369-bcf4-12ab46584f17', 6, 1309, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5205fd59-d903-40e2-800e-4e67232f3894', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:15.76935', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     7.28.1  Büyükbas ve/veya küçükbas hayvan kesiminin yapildigi tesisler.(100 kesim ünitesi/gün alti),(her bir kesim ünitesi esdegerleri;1 bas sigir,2 bas devekusu,4 bas domuz,8 bas koyun ,10 bas keçi,130 bas tavsan)', false, 'a8dfd95a-675a-4429-969a-962e6b1958d2', 1, 1277, 1276, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('95532953-b767-46e5-8dc8-3775c9348f28', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:15.903177', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '     7.28.2  Kanatli hayvanlari kesiminin yapildigi tesisler.(1.000-50.000 adet/gün arasi tavuk ve esdegeri diger kanatlilar.)(1 adet hindi=7 adet tavuk esdegeri esas alinmalidir.)', false, 'a8dfd95a-675a-4429-969a-962e6b1958d2', 2, 1278, 1276, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('ccbae1a0-313f-4610-9695-231c17082ee3', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:16.861179', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.1 Yanici, parlayici veya patlayici gazlar için depolama ve dolum tesisleri*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 1, 1283, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('3c1cc08e-35f6-42d4-8214-186d968ead61', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:17.002891', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.2 Ham petrol, petrol ürünleri ve petrokimyasal ve kimyasal ürünler için depolama tesisleri*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 2, 1288, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7f75c0fb-4940-4a00-8eb3-6d29bb8ab007', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:17.252855', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.3 Metanol için toplam depolama tank kapasitesi 5.000 ton ve daha fazla, 30.000 ton?dan az olan tesisler*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 3, 1292, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('b29c42ef-b5fb-48d2-bde2-7bf4d82725bc', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:17.398926', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.4 Akrilonitril  için toplam depolama tank kapasitesi 200 ton ve daha fazla, 2000 ton?dan az olan tesisler*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 4, 1293, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('1ba60636-c5a8-4129-9f16-dc6712ae6f8b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:17.574965', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.5 Klor için toplam depolama tank kapasitesi 10 ton ve daha fazla olan tesisler.*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 5, 1294, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e837e9ac-5b10-4bb7-8a0d-baa9ef39ce8b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:17.714433', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.6 Kükürtdioksit için toplam depolama tank kapasitesi 20 ve daha fazla olan tesisler.*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 6, 1295, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('a7f0fe38-5e2c-407c-a6cd-7b1874f6ac2e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:17.898244', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.7 Sivi oksijen için toplam depolama tank kapasitesi 200 ton ve daha fazla olan tesisler.*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 7, 1296, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0fb3bb86-1c42-47f4-a68b-854885f23115', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:18.019996', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.8 Amonyumnitrat için toplam depolama tank kapasitesi  500 ton ve daha fazla olan tesisler.*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 8, 1297, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('9ad5c623-4ca1-4747-85c3-b1d62cdc6a08', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:18.156084', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.9 Sodyumklorat için toplam depolama tank kapasitesi  25 ton ve daha fazla olan tesisler.*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 9, 1298, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('f7f78ae8-3644-4f84-8366-cf4206b2bd4a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:18.290756', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.10 Bitki koruma maddeleri veya hasereye karsi korunma maddeleri için toplam depolama tank kapasitesi  5 ton ve daha fazla  olan  tesisler.*', true, '159c68a9-1d18-49dd-829f-066f0cc8142b', 10, 1299, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('113c8a6b-94e7-4495-9ffd-d091f8137015', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:18.435779', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '9.11 200 ton/gün ve üzerinde kuru durumda iken tozuma yapabilen yigma maddelerin, damperli araçlar veya devirmeli depolar, kepçeler veya teknik araç ve gereçlerle doldurulup bosaltildigi açik veya tam kapali olmayan depolama, eleme ve paketleme tesisleri. (200 ton/gün veya üzerinde madde aktarilan tesisler dahil olup, hafriyat çalismalari hariçtir.)', false, '159c68a9-1d18-49dd-829f-066f0cc8142b', 11, 1300, 1282, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('32799334-7c15-4889-ab30-a6f30d84f442', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:18.608891', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '  9.1.1 Sivilastirilmis petrol gazlari için toplam depolama tank kapasitesi 200 m3 ve daha fazla, 10.000 m3?ten az olan  tesisler( Isinma amaçli kullanilan depolama tanklari hariçtir)', false, 'ccbae1a0-313f-4610-9695-231c17082ee3', 1, 1284, 1283, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('d1ffead0-90d6-476c-a49e-7deb30c740bb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:18.727512', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '  9.1.2 Dogal gaz/LNG (sivilastirilmis dogalgaz) vb. gazlar için toplam depolama tank kapasitesi 1000 m3 ve daha fazla, 20.000 m3 ten az olan tesisler, ( Isinma amaçli kullanilan depolama tanklari hariçtir)', false, 'ccbae1a0-313f-4610-9695-231c17082ee3', 2, 1285, 1283, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e5b01e58-a641-4913-9eeb-f8a82eb09a25', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:18.876724', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    9.1.3 Dolum kapasitesi 30 ton/gün ve daha büyük, 200 ton/gün''den az  olan sivilastirilmis petrol gazlarindan tüp dolum islemlerinin gerceklestirildigi tesisler', false, 'ccbae1a0-313f-4610-9695-231c17082ee3', 3, 1286, 1283, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('103179e8-1cf5-42fe-9111-8500389acdc7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:19.068543', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '  9.2.1 Ham petrol için toplam depolama tank kapasitesi 5.000 ton ve daha fazla, 100.000 ton?dan az olan tesisler', false, '3c1cc08e-35f6-42d4-8214-186d968ead61', 1, 1289, 1288, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('e6669ac5-e205-4cd1-b738-ea7ff60b79e2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:19.216735', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    9.2.2 Benzin, nafta, Motorin,fuel-oil vb. akaryakitlar için toplam depolama tank kapasitesi 1.000 ton ve daha fazla, 50.000 ton?dan az olan tesisler ( Isinma amaçli kullanilan depolama tanklari hariçtir)', false, '3c1cc08e-35f6-42d4-8214-186d968ead61', 2, 1290, 1288, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('5bbac089-5f63-4a75-8e89-3008c51b1695', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:19.341981', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    9.2.3 Organik kimyasal çözücü maddeler için (alkoller, aldehitler, aromatikler, ketonlar,aminler, asitler, esterler, asetatlar eterler vb.) toplam depolama tank kapasitesi 200 ton ve daha fazla, 50.000 ton?dan az olan  tesisler', false, '3c1cc08e-35f6-42d4-8214-186d968ead61', 3, 1291, 1288, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2ee1c753-6469-45fb-97f4-e4fc9cecdfc9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:19.589843', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.1 Patlama tehlikesi olan maddelerin üretildigi, geri kazanildigi veya bertaraf edildigi tesisler. Mühimmat veya diger patlayicilari yükleme, bosaltma veya parçalama tesisleri dahil olup, kibrit üretimi dahil degildir. *', true, '09141047-8ad1-4369-bcf4-12ab46584f17', 1, 1302, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('af86fd1e-cb7c-49c3-81c7-a340680b2b02', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:19.733606', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.2  Üretim kapasitesi 25 ton/saat ve üzerinde olan hava sivilastirma tesisleri,*', true, '09141047-8ad1-4369-bcf4-12ab46584f17', 2, 1303, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('59fcc759-90eb-4699-af79-8371c5d95ae0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:19.927757', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.3  Nüfusu 100.000 kisinin altinda olan kentsel ve/veya evsel nitelikli atik su aritma tesisleri,*', true, '09141047-8ad1-4369-bcf4-12ab46584f17', 3, 1305, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('858bc9e4-3ea2-4206-a84f-76c45c6ec8a6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:20.100042', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.4  3.000 KW veya üzerindeki anma güçlü jet motorlar ve gaz türbinleri için test merkezleri veya bu güçlerde motor ve gaz türbinlerinin bulundugu test standartlari,', false, '09141047-8ad1-4369-bcf4-12ab46584f17', 4, 1307, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('7f441a5a-715e-4c44-8c72-099cd320c72a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:20.267847', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.5  Sigara fabrikalari,*', true, '09141047-8ad1-4369-bcf4-12ab46584f17', 5, 1308, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('daccb763-94bf-46b0-a8b9-6ad983ad47da', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:20.842645', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.8  Ek-1 ve Ek-2 listelerinde yer alamayan,alici ortama atiksudesarji olan isletmeler.', true, '09141047-8ad1-4369-bcf4-12ab46584f17', 8, 1311, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('887da7ac-8df7-466f-b16d-df30ab4057c3', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:20.975531', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '10.9  Hastane ve saglik kuruluslari(yatak kapasitesi 20 ve üzeri olanlar) ile hastane ve tip merkezleri bünyesi disinda yer alan diyaliz merkzleri(15 cihaz ve üzeri)', true, '09141047-8ad1-4369-bcf4-12ab46584f17', 9, 1312, 1301, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('3b98ed90-242e-4295-8462-49ee4e009799', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:21.251391', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.7.1 Kapasitesi 5.000 ton/gün ve üzerindeki demir veya çeligin haddelendigi tesisler', false, 'dd8f4254-bf26-4cf0-88d1-b8389db7ab98', 1, 1323, 1322, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('c5a92e1e-66ca-4351-98ff-49af6d8c7c17', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:21.360679', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '3.7.2 Kapasitesi 250 ton/gün ve üzerindeki demir disi metallerin haddelendigi tesisler', false, 'dd8f4254-bf26-4cf0-88d1-b8389db7ab98', 2, 1324, 1322, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('0debbf12-c3a2-42b2-b5f8-c745a2fa8f7b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:21.509015', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.7.1 5000 bas ve üzeri büyükbas yetistirme tesisleri*', true, '5e95d999-5702-4803-8396-c6885139e672', 1, 1349, 1348, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('abf27371-17fc-4db9-b959-155d9d6f3eb0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:21.645428', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.7.2 25000 bas ve üzeri küçükbas yetistirme tesisleri*', true, '5e95d999-5702-4803-8396-c6885139e672', 2, 1350, 1348, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('2609e64f-318f-40e6-9da2-18030aab135a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:21.803498', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.7.3 Büyükbas ve küçükbas hayvanlarin birlikte yetistirilmesi.(5.000 büyükbas ve üzeri ,1 büyükbas = 5 küçükbas esdegeri esas alinmalidir.)', true, '5e95d999-5702-4803-8396-c6885139e672', 3, 1351, 1348, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('de8b5f59-b689-4cb7-b810-96b5db6c303b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:21.928081', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.7.4 1000 bas ve üzeri domuz besi tesisleri.*', true, '5e95d999-5702-4803-8396-c6885139e672', 4, 1352, 1348, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('44699e79-c13b-450c-967d-564671237669', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:22.092243', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.7.5 Kanatli yetistirme tesisleri.[bir üretim periyodunda 60.000 adet ve üzeri tavuk(civciv,damizlik,piliç vb.)veya esdeger diger kanatlilar])(1 adet hindi=7 adet tavuk esdegeri esas alinmalidir.)*', true, '5e95d999-5702-4803-8396-c6885139e672', 5, 1354, 1348, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('22e18859-0971-471f-a523-5da9fce30dfe', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:22.367099', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.8.1 Büyükbas ve/ veya küçükbas hayvan kesiminin yapildigi tesisler.(100 kesim ünitesi/gün ve üzeri),(her bir kesim ünitesi esdegerleri;1 bas sigir,2bas devekusu,4 bas domuz,8 bas koyun,10 bas keçi,130 bas tavsan)*', true, 'a8783903-167e-4cbd-b75e-a09c8ce3cbac', 1, 1362, 1355, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('b89ba293-3bd8-41ce-88ad-94fa422eb7e6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:22.591316', 1, NULL, NULL, '84e08dca-f5be-4f2c-8074-42da230c1927', '7.8.2 Kanatli hayvanlarin kesiminin yapildigi tesisler.(50.000 adet/gün ve üzeri tavuk ve esdegeri diger kanatlilar.)(1 adet hindi=7 adet tavuk esdegeri esas alinmalidir.)*', true, 'a8783903-167e-4cbd-b75e-a09c8ce3cbac', 2, 1363, 1355, false);
INSERT INTO "e-izin"."Kapsam" VALUES ('41ea061e-1251-429b-8d69-bdc48fb9aed7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:16.037626', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    8.4 Bitkisel Atık Yağ Ara Depolama Tesisleri*', true, '6d5f4139-c4ab-4f82-bc17-9477a9bed62e', 4, 319, 1279, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('9d09c821-cec0-40f3-9ff7-d77f99a71dbf', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:16.175821', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    8.5 Atık Akümülatör Ara Depolama Tesisleri*', true, '6d5f4139-c4ab-4f82-bc17-9477a9bed62e', 5, 320, 1279, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('70a8ebea-a498-43fb-8f39-025091200324', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:16.301845', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    8.6 Ömrünü Tamamlamış Lastik Ara Depolama Tesisleri*', true, '6d5f4139-c4ab-4f82-bc17-9477a9bed62e', 6, 321, 1279, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('1068b843-cea8-471b-af7f-7f78f44699f1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:16.417719', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    8.1 Ambalaj atigi toplama-ayirma ve/veya geri kazanim tesisleri.(Hava emisyonu konulu çevre iznine getirilen muafiyet geri kazanim tesisleri için geçerli degildir.)', true, '6d5f4139-c4ab-4f82-bc17-9477a9bed62e', 1, 1280, 1279, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('2c09c80c-6808-48ac-af9e-1eb1a9e4faea', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:16.56724', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    8.2 Ambalaj atiklari disindaki,tehlikesiz atik niteliginde olan plastik türevli ve/veya tekstil türevli atiklarin geri kazanildigi tesisleri.', true, '6d5f4139-c4ab-4f82-bc17-9477a9bed62e', 2, 1380, 1279, true);
INSERT INTO "e-izin"."Kapsam" VALUES ('a73f3fe2-6108-4417-b5eb-b46c8110341a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-06 15:27:16.694305', 1, NULL, NULL, '84e08dda-f5be-4f2c-8074-42da230c1927', '    8.3 Gemilerin ürettigi atiklar ile yük artiklarinin toplandigi atik kabul tesisleri.', true, '6d5f4139-c4ab-4f82-bc17-9477a9bed62e', 3, 1381, 1279, true);


--
-- Data for Name: LisansKonu; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."LisansKonu" VALUES ('1a6ee288-dc92-43f8-a055-b48d381d58b0', '1a6ee288-dc92-43f8-a055-b48d381d58b0', '2023-07-03 10:15:30', NULL, NULL, 'GERİ KAZANIM', 1, NULL);
INSERT INTO "e-izin"."LisansKonu" VALUES ('1a6ee288-dc92-43f8-a055-b48d381d58b1', '1a6ee288-dc92-43f8-a055-b48d381d58b0', '2023-07-03 10:15:30', NULL, NULL, 'BERTARAF', 1, NULL);
INSERT INTO "e-izin"."LisansKonu" VALUES ('1a6ee288-dc92-43f8-a055-b48d381d58b5', '1a6ee288-dc92-43f8-a055-b48d381d58b0', '2023-07-03 10:15:30', NULL, NULL, 'DİĞER ATIK YÖNETİM FAALİYETLERİ', 1, NULL);
INSERT INTO "e-izin"."LisansKonu" VALUES ('1a6ee288-dc92-43f8-a055-b48d381d58b4', '1a6ee288-dc92-43f8-a055-b48d381d58b0', '2023-07-03 10:15:30', NULL, NULL, 'ARA DEPOLAMA', 1, NULL);
INSERT INTO "e-izin"."LisansKonu" VALUES ('1a6ee288-dc92-43f8-a055-b48d381d58b3', '1a6ee288-dc92-43f8-a055-b48d381d58b0', '2023-07-03 10:15:30', NULL, NULL, 'ARINDIRMA', 1, NULL);
INSERT INTO "e-izin"."LisansKonu" VALUES ('1a6ee288-dc92-43f8-a055-b48d381d58b2', '1a6ee288-dc92-43f8-a055-b48d381d58b0', '2023-07-03 10:15:30', NULL, NULL, 'ÖN İŞLEME', 1, NULL);
INSERT INTO "e-izin"."LisansKonu" VALUES ('046f5e92-c26f-4e07-a9c5-365b5cbe04bd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:05:02.255271', NULL, NULL, 'Yeniden Kullanıma Hazırlama', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('09ad63cd-9816-44ba-b7ff-3688d79ae325', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:50:05.656901', NULL, NULL, 'Gemi Geri Dönüsüm Tesisi', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('0f92b10c-3e3c-4293-869a-d988f66649f0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:26:35.79782', NULL, NULL, 'Tehlikeli Atık Geri Kazanım', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('10bb9967-8328-48ac-a36d-13c61c8a9dc7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:52:34.702627', NULL, NULL, 'Ömrünü Tamamlamıs Lastik Ara Depolama Tesisi', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b4');
INSERT INTO "e-izin"."LisansKonu" VALUES ('135cf186-30ed-49ab-a823-05e033861d4a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:27:19.607552', NULL, NULL, 'Ambalaj Atığı Geri Kazanım', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('143638c2-92a3-4d3c-b224-574b0f792afe', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:26:18.870427', NULL, NULL, 'Biyobozunur Atık İşleme - Mekanik Ayırma', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('15de59c9-9207-4953-b4e6-066e7bcfee6f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:26:56.570187', NULL, NULL, 'Biyobozunur Atık İşleme - Kompost', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('17deda97-24ae-4e28-bdc3-06a1a3ea591a', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:49:26.209209', NULL, NULL, 'Ömrünü Tamamlamış Araç Geçici Depolama', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('1a63ceff-ae4f-4436-ab1b-209429336752', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:38:37.403838', NULL, NULL, 'Maden Atığı Bertaraf- Derine Enjeksiyon Kategori B', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('1f2b0fee-3cc2-4020-ae88-aebb34ac2a11', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:49:33.896058', NULL, NULL, 'Ambalaj Atığı Toplama ve Ayırma Tip 1', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('20ef9e5c-84a3-4cf4-8261-f31c1e307aa2', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:04:46.006803', NULL, NULL, 'Atık Akümülatör Ara Depolama Tesisi', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('216a1c9a-9668-4676-928a-1804b776f167', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:51:04.317883', NULL, NULL, 'Toplama Ayırma Tesisi', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('23083445-829c-40a4-9ece-425163a1939c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:25:31.272369', NULL, NULL, 'Bitkisel Atık Yağ Geri Kazanım', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('2a6bd194-0b68-4255-9e7a-0ea0f30904b0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:38:44.083224', NULL, NULL, 'Maden Atığı Bertaraf- Alıcı Ortamda Bertaraf Kategori A', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('2c6a0221-4ed6-4cda-9cd2-e8c87dc31298', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:48:27.628663', NULL, NULL, 'Ambalaj Atığı Toplama ve Ayırma Tip 3', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('3c5ee896-535e-4960-af51-090135981aad', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:37:16.386075', NULL, NULL, 'Depolama', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('3e770ebe-0d00-4056-ae6e-40924accab6f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:38:50.139', NULL, NULL, 'Maden Atığı Bertaraf- Alıcı Ortamda Bertaraf Kategori B', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('4272084b-92bf-4345-93ed-708e05ba3608', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:48:04.874866', NULL, NULL, 'Ambalaj Atığı Toplama ve Ayırma Tip 2', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('42dec797-3fd4-4497-a9f4-baad1efca17e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:38:22.65486', NULL, NULL, 'İleri Termal İşlem Tesisleri(Piroliz,Gazlaştırma)', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('4a59cecf-76f9-439c-84fa-26561720b88b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:04:33.128807', NULL, NULL, 'Atık Ara Depolama', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('4ad37ec7-52d1-4fde-ba02-63d5cb064ff4', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:38:29.473841', NULL, NULL, 'Maden Atığı Bertaraf- Derine Enjeksiyon Kategori A', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('613a9519-16dd-435e-90e5-1f0cf6deae7f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:26:03.444377', NULL, NULL, 'Tehlikesiz Atık Geri Kazanım', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('6f3d6999-9be8-4a02-9975-118303f76ae7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:51:25.663373', NULL, NULL, 'Atık Elektrikli ve Elektronik Eşya İşleme', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('6f64e929-f6bd-4c0f-ae4f-be15e27d010e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:37:26.961554', NULL, NULL, 'Alıcı Ortamda Bertaraf', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('72d597e4-afbf-420d-9a4d-aec34559e264', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:26:49.119355', NULL, NULL, 'Biyobozunur Atık İşleme -Biyometanizasyon', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('738ea8cf-20a7-4faf-9dc5-cc9f255a7ea8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:27:12.26055', NULL, NULL, 'Atık Yağ Rafinasyonu', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('7551849f-dc3e-4a16-9757-f9c89d057acb', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 09:58:26.282442', NULL, NULL, 'Atık Yağ Geri Kazanım', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('7ad89a29-5f8d-4061-b3da-8029b16990ee', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:51:11.529184', NULL, NULL, 'Toplama Ayırma Tesisi Tip 1', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('7e1f847e-9d7f-48cf-b6ed-2a7ddc2f3566', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:05:14.643463', NULL, NULL, 'Atık elektrikli ve elektronik eşya yeniden kullanıma hazırlama tesisi', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('7e3f1e62-2825-41bb-bac9-c3bcdef2584e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:25:55.256692', NULL, NULL, 'Ömrünü Tamamlamış Lastik Geri Kazanım', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('831c4ab0-c28d-479e-b6ef-782aac85535c', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:37:33.10574', NULL, NULL, 'Düzenli Depolama - 1. Sınıf (Tehlikeli Atık Düzenli Depolama)', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('843ec341-b203-417a-9eaf-70cafe7548b1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:37:21.011961', NULL, NULL, 'Derine Enjeksiyon', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('8d050df4-ec43-4999-8128-317eaa64b4d9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:50:33.50109', NULL, NULL, 'Toplama Ayırma Tesisi Tip 3', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('8d89d4eb-ba28-403d-bbb1-6d097b9e0f7b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:38:15.635993', NULL, NULL, 'Düzenli Depolama - 3. Sınıf (İnert Atık Düzenli Depolama)', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('8f1b99db-e421-4437-87e4-e36184a03e94', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:49:56.384819', NULL, NULL, 'Ömrünü Tamamlamış Araç İşleme', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('9d70a22c-c871-48dc-8f9c-8986b12a6c3e', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:50:55.471347', NULL, NULL, 'Tehlikesiz Atık Ön İşlem Tesisleri', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('9e7117b6-19f6-4f8c-bd3e-7f5d5fb894f7', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:27:03.63988', NULL, NULL, 'Biyobozunur Atık İşleme', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('9f360506-5480-4cdc-9d7b-619ef02e204b', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:49:46.668438', NULL, NULL, 'PCB Arındırma', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('a0a5a05b-0b41-457c-acef-6ab313ec49ba', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:05:20.204284', NULL, NULL, 'Atık Elektrikli ve Elektronik Eşya Transfer Noktası', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('a6f05817-bed1-4c0b-aa4c-4b4bf6a803b6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:04:39.48814', NULL, NULL, 'Bitkisel Atik Yağ Ara Depolama Tesisi', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('ab5fa01e-c28d-40da-a225-0d0098ccb4fd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:50:40.495834', NULL, NULL, 'Hurda Metal /ÖTA İşleme', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('abd504e7-dfd9-4ea7-9115-b4b53654b4d1', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:04:54.442224', NULL, NULL, 'Atık Elektrikli ve Elektronik Eşya Yeniden Kullanıma Hazırlama', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('b7353a96-39b6-48a2-ab6b-88ba2990da28', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:50:25.181133', NULL, NULL, 'Tespit edilen', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('bf7779cd-d667-40ae-89a7-db99021ac2bd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:36:45.092685', NULL, NULL, 'Maden Atığı Bertaraf- Depolama Kategori B', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('c3d9654a-b7fa-4e7f-8181-fc29edde85d9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:05:08.277947', NULL, NULL, 'Atık Yağ Transfer Noktası', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('cb9904c4-793f-4510-8ecf-ea757bb613f9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:51:17.879022', NULL, NULL, 'Toplama Ayırma Tesisi Tip 2', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('cecc5917-1f69-457e-a4c6-8c0e2539b75f', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:04:25.748224', NULL, NULL, 'Tanker Temizleme', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('cf35b138-addc-4cbb-a0ae-d34ca914eb47', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 11:04:19.151954', NULL, NULL, 'Atık Yakma ve Beraber Yakma', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b5');
INSERT INTO "e-izin"."LisansKonu" VALUES ('cfe1cba5-5729-4573-a8d6-a516ab7275dc', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:50:16.577432', NULL, NULL, 'Atıktan Türetilmiş Yakıt (ATY) Hazırlama Tesisi', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('d4c784ee-ae44-4f14-a752-6c736aa0c5dd', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:36:33.20973', NULL, NULL, 'Maden Atığı Bertaraf- Depolama Kategori A', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('d61744e1-4f4d-43ec-9446-580a3ae2dcc8', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:50:46.393954', NULL, NULL, 'Tehlikeli Atık Ön İşlem Tesisleri', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('da1126a7-ef78-483f-9e19-927aacbb1b4d', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:26:42.060073', NULL, NULL, 'Atık Pil ve Akümülatör Geri Kazanım', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('dfa4fb72-73f0-4869-a4c1-8b6c14ad1fde', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:25:42.589439', NULL, NULL, 'Atık Pil ve Akümülatör Geri Kazanım', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('e033a368-0378-48a8-b9f4-fdce4898f2c9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:26:28.057889', NULL, NULL, 'Biyobozunur Atık İşleme -Biyokurutma', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b0');
INSERT INTO "e-izin"."LisansKonu" VALUES ('edb0ed03-e58e-43cc-9edd-6e4e3ac75bb9', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:38:06.133632', NULL, NULL, 'Düzenli Depolama - 2. Sınıf (Belediye Atıkları ve Tehlikesiz Atık Düzenli Depolama)', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b1');
INSERT INTO "e-izin"."LisansKonu" VALUES ('f649ab14-bf7b-4f4f-b69a-4e4c1dd379d6', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:48:33.706436', NULL, NULL, 'Tıbbi Atık Sterilizasyon', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');
INSERT INTO "e-izin"."LisansKonu" VALUES ('f8abcc07-7979-4e91-a271-f1ad854858b0', 'd349697c-9816-417f-a80f-c82475decc4a', '2023-07-05 10:49:40.42351', NULL, NULL, 'Atık Kabul Tesisi', 1, '1a6ee288-dc92-43f8-a055-b48d381d58b2');


--
-- Data for Name: atikKodGecici; Type: TABLE DATA; Schema: e-izin; Owner: -
--

INSERT INTO "e-izin"."atikKodGecici" VALUES (40102, 'Kireçleme atıkları', NULL, NULL, 0, '040102', 401, 0, 'Kireçleme atiklari', '0401', 'Kireçleme atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40103, 'Sıvı halde olmayan çözücüler içeren yağ giderme atıkları', NULL, 1, 1, '040103', 401, 1, 'Sivi halde olmayan çözücüler içeren yag giderme atiklari', '0401', 'Sıvı halde olmayan çözücüler içeren yağ giderme atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40104, 'Krom içeren sepi şerbeti', NULL, NULL, 0, '040104', 401, 0, 'Krom içeren sepi serbeti', '0401', 'Krom içeren sepi şerbeti');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40107, 'Saha içi atıksu arıtımından kaynaklanan krom içermeyen çamurlar', NULL, NULL, 0, '040107', 401, 0, 'Saha içi atiksu aritimindan kaynaklanan krom içermeyen çamurlar', '0401', 'Saha içi atıksu arıtımından kaynaklanan krom içermeyen çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40109, 'Perdah ve boyama atıkları', NULL, NULL, 0, '040109', 401, 0, 'Perdah ve boyama atiklari', '0401', 'Perdah ve boyama atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '040199', 401, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0401', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (402, 'Tekstil Endüstrisinden Kaynaklanan Atıklar', NULL, NULL, 1, '0402', 4, 0, 'Tekstil Endüstrisinden Kaynaklanan Atiklar', '04', 'Tekstil Endüstrisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40210, 'Doğal ürünlerden oluşan organik maddeler (örneğin yağ, mum)', NULL, NULL, 0, '040210', 402, 0, 'Dogal ürünlerden olusan organik maddeler (örnegin yag, mum)', '0402', 'Doğal ürünlerden oluşan organik maddeler (örneğin yağ, mum)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40215, '04 02 14 dışındaki perdah atıkları', NULL, NULL, 0, '040215', 402, 0, '04 02 14 disindaki perdah atiklari', '0402', '04 02 14 dışındaki perdah atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40217, '04 02 16 dışındaki boya maddeleri ve pigmentler', NULL, NULL, 0, '040217', 402, 0, '04 02 16 disindaki boya maddeleri ve pigmentler', '0402', '04 02 16 dışındaki boya maddeleri ve pigmentler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40222, 'İşlenmiş tekstil elyafı atıkları', NULL, NULL, 0, '040222', 402, 0, 'Islenmis tekstil elyafi atiklari', '0402', 'İşlenmiş tekstil elyafı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (5, 'PETROL RAFİNASYONU, DOĞAL GAZ SAFLAŞTIRMA VE KÖMÜRÜN PİROLİTİK İŞLENMESİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '05', 0, 0, 'PETROL RAFINASYONU, DOGAL GAZ SAFLASTIRMA VE KÖMÜRÜN PIROLITIK ISLENMESINDEN KAYNAKLANAN ATIKLAR', NULL, 'PETROL RAFİNASYONU, DOĞAL GAZ SAFLAŞTIRMA VE KÖMÜRÜN PİROLİTİK İŞLENMESİNDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50103, 'Tank dibi çamurları', NULL, 1, 1, '050103', 501, 1, 'Tank dibi çamurlari', '0501', 'Tank dibi çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50105, 'Petrol döküntüleri', NULL, 1, 1, '050105', 501, 1, 'Petrol döküntüleri', '0501', 'Petrol döküntüleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50107, 'Asit ziftleri', NULL, 1, 1, '050107', 501, 1, 'Asit ziftleri', '0501', 'Asit ziftleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50108, 'Diğer ziftler', NULL, 1, 1, '050108', 501, 1, 'Diger ziftler', '0501', 'Diğer ziftler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50111, 'Yakıtların bazlar ile temizlemesi sonucu oluşan atıklar', NULL, 1, 1, '050111', 501, 1, 'Yakitlarin bazlar ile temizlemesi sonucu olusan atiklar', '0501', 'Yakıtların bazlar ile temizlemesi sonucu oluşan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50112, 'Yağ içeren asitler', NULL, 1, 1, '050112', 501, 1, 'Yag içeren asitler', '0501', 'Yağ içeren asitler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50113, 'Kazan besleme suyu çamurları', NULL, NULL, 0, '050113', 501, 0, 'Kazan besleme suyu çamurlari', '0501', 'Kazan besleme suyu çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50115, 'Kullanılmış filtre killeri', NULL, 1, 1, '050115', 501, 1, 'Kullanilmis filtre killeri', '0501', 'Kullanılmış filtre killeri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50117, 'Bitüm', NULL, NULL, 0, '050117', 501, 0, 'Bitüm', '0501', 'Bitüm');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200113, 'Çözücüler', NULL, 1, 1, '200113', 2001, 1, 'Çözücüler', '2001', 'Çözücüler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '050199', 501, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0501', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (506, 'Kömürün Pirolitik İşlenmesinden Kaynaklanan Atıklar', NULL, NULL, 1, '0506', 5, 0, 'Kömürün Pirolitik Islenmesinden Kaynaklanan Atiklar', '05', 'Kömürün Pirolitik İşlenmesinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50603, 'Diğer ziftler', NULL, 1, 1, '050603', 506, 1, 'Diger ziftler', '0506', 'Diğer ziftler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50701, 'Cıva içeren atıklar', NULL, 1, 1, '050701', 507, 1, 'Civa içeren atiklar', '0507', 'Cıva içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50702, 'Kükürt içeren atıklar', NULL, NULL, 0, '050702', 507, 0, 'Kükürt içeren atiklar', '0507', 'Kükürt içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50799, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '050799', 507, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0507', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60101, 'Sülfürik asit ve sülfüröz asit', NULL, 1, 1, '060101', 601, 1, 'Sülfürik asit ve sülfüröz asit', '0601', 'Sülfürik asit ve sülfüröz asit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60102, 'Hidroklorik asit', NULL, 1, 1, '060102', 601, 1, 'Hidroklorik asit', '0601', 'Hidroklorik asit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60103, 'Hidroflorik asit', NULL, 1, 1, '060103', 601, 1, 'Hidroflorik asit', '0601', 'Hidroflorik asit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60105, 'Nitrik asit ve nitröz asit', NULL, 1, 1, '060105', 601, 1, 'Nitrik asit ve nitröz asit', '0601', 'Nitrik asit ve nitröz asit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60106, 'Diğer asitler', NULL, 1, 1, '060106', 601, 1, 'Diger asitler', '0601', 'Diğer asitler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60203, 'Amonyum hidroksit', NULL, 1, 1, '060203', 602, 1, 'Amonyum hidroksit', '0602', 'Amonyum hidroksit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60204, 'Sodyum ve potasyum hidroksit', NULL, 1, 1, '060204', 602, 1, 'Sodyum ve potasyum hidroksit', '0602', 'Sodyum ve potasyum hidroksit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60205, 'Diğer bazlar', NULL, 1, 1, '060205', 602, 1, 'Diger bazlar', '0602', 'Diğer bazlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60311, 'Siyanür içeren katı tuzlar ve solüsyonlar', NULL, 1, 1, '060311', 603, 1, 'Siyanür içeren kati tuzlar ve solüsyonlar', '0603', 'Siyanür içeren katı tuzlar ve solüsyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60313, 'Ağır metal içeren katı tuzlar ve solüsyonlar', NULL, 1, 1, '060313', 603, 1, 'Agir metal içeren kati tuzlar ve solüsyonlar', '0603', 'Ağır metal içeren katı tuzlar ve solüsyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60314, '06 03 11 ve 06 03 13 dışındaki katı tuzlar ve solüsyonlar', NULL, NULL, 0, '060314', 603, 0, '06 03 11 ve 06 03 13 disindaki kati tuzlar ve solüsyonlar', '0603', '06 03 11 ve 06 03 13 dışındaki katı tuzlar ve solüsyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60315, 'Ağır metal içeren metal oksitler', NULL, 1, 1, '060315', 603, 1, 'Agir metal içeren metal oksitler', '0603', 'Ağır metal içeren metal oksitler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '060399', 603, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0603', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60404, 'Cıva içeren atıklar', NULL, 1, 1, '060404', 604, 1, 'Civa içeren atiklar', '0604', 'Cıva içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60502, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '060502', 605, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0605', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (606, 'Kükürtlü Kimyasallardan, Kükürtleyici Kimyasal İşlemlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0606', 6, 0, 'Kükürtlü Kimyasallardan, Kükürtleyici Kimyasal Islemlerinin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '06', 'Kükürtlü Kimyasallardan, Kükürtleyici Kimyasal İşlemlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60699, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '060699', 606, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0606', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60701, 'Elektrolizden kaynaklanan asbest içeren atıklar', NULL, 1, 1, '060701', 607, 1, 'Elektrolizden kaynaklanan asbest içeren atiklar', '0607', 'Elektrolizden kaynaklanan asbest içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60703, 'Cıva içeren baryum sülfat çamuru', NULL, 1, 1, '060703', 607, 1, 'Civa içeren baryum sülfat çamuru', '0607', 'Cıva içeren baryum sülfat çamuru');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60704, 'Çözeltiler ve asitler, örneğin kontakt asiti', NULL, 1, 1, '060704', 607, 1, 'Çözeltiler ve asitler, örnegin kontakt asiti', '0607', 'Çözeltiler ve asitler, örneğin kontakt asiti');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60799, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '060799', 607, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0607', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60802, 'Zararlı klorosilan içeren atıklar', NULL, 1, 1, '060802', 608, 1, 'Zararli klorosilan içeren atiklar', '0608', 'Zararlı klorosilan içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60899, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '060899', 608, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0608', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60902, 'Fosforlu cüruf', NULL, NULL, 0, '060902', 609, 0, 'Fosforlu cüruf', '0609', 'Fosforlu cüruf');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60903, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerle kontamine olmuş kalsiyum bazlı reaksiyon atıkları', NULL, 1, 1, '060903', 609, 1, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerle kontamine olmus kalsiyum bazli reaksiyon atiklari', '0609', 'Tehlikeli maddeler içeren ya da tehlikeli maddelerle kontamine olmuş kalsiyum bazlı reaksiyon atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61099, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '061099', 610, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0610', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (611, 'İnorganik Pigmentlerin ve Opaklaştırıcıların İmalatından Kaynaklanan Atıklar', NULL, NULL, 1, '0611', 6, 0, 'İnorganik Pigmentlerin ve Opaklastiricilarin Imalatindan Kaynaklanan Atiklar', '06', 'İnorganik Pigmentlerin ve Opaklaştırıcıların İmalatından Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61101, 'Titanyum dioksit üretiminden kaynaklanan kalsiyum bazlı reaksiyon atıkları', NULL, NULL, 0, '061101', 611, 0, 'Titanyum dioksit üretiminden kaynaklanan kalsiyum bazli reaksiyon atiklari', '0611', 'Titanyum dioksit üretiminden kaynaklanan kalsiyum bazlı reaksiyon atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '061199', 611, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0611', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61302, 'Kullanılmış aktif karbon (06 07 02 hariç)', NULL, 1, 1, '061302', 613, 1, 'Kullanilmis aktif karbon (06 07 02 hariç)', '0613', 'Kullanılmış aktif karbon (06 07 02 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61303, 'Karbon siyahı', NULL, NULL, 0, '061303', 613, 0, 'Karbon siyahi', '0613', 'Karbon siyahı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (7, 'ORGANİK KİMYASAL İŞLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '07', 0, 0, 'ORGANIK KIMYASAL ISLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, 'ORGANİK KİMYASAL İŞLEMLERDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70103, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070103', 701, 1, 'Halojenli organik çözücüler, yikama sivilari ve ana çözeltiler', '0701', 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200301, 'Karışık belediye atıkları', NULL, NULL, 0, '200301', 2003, 0, 'Karisik belediye atiklari', '2003', 'Karışık belediye atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70108, 'Diğer dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070108', 701, 1, 'Diger dip tortusu ve reaksiyon kalintilari', '0701', 'Diğer dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70109, 'Halojenli filtre keki ve kullanılmış absorbanlar', NULL, 1, 1, '070109', 701, 1, 'Halojenli filtre keki ve kullanilmis absorbanlar', '0701', 'Halojenli filtre keki ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70112, '07 01 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '070112', 701, 0, '07 01 11 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0701', '07 01 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70201, 'Su bazlı yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070201', 702, 1, 'Su bazli yikama sivilari ve ana çözeltiler', '0702', 'Su bazlı yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70203, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070203', 702, 1, 'Halojenli organik çözücüler, yikama sivilari ve ana çözeltiler', '0702', 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70204, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070204', 702, 1, 'Diger organik çözücüler, yikama sivilari ve ana çözeltiler', '0702', 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70208, 'Diğer dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070208', 702, 1, 'Diger dip tortusu ve reaksiyon kalintilari', '0702', 'Diğer dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70210, 'Diğer filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070210', 702, 1, 'Diger filtre kekleri ve kullanilmis absorbanlar', '0702', 'Diğer filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70211, 'Saha içi atıksu arıtmından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '070211', 702, 1, 'Saha içi atiksu aritmindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0702', 'Saha içi atıksu arıtmından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70213, 'Atık plastik', NULL, NULL, 0, '070213', 702, 0, 'Atik plastik', '0702', 'Atık plastik');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70214, 'Tehlikeli maddeler içeren katkı maddelerinin atıkları', NULL, 1, 1, '070214', 702, 1, 'Tehlikeli maddeler içeren katki maddelerinin atiklari', '0702', 'Tehlikeli maddeler içeren katkı maddelerinin atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70216, 'Zararlı silikonlar içeren atıklar', NULL, 1, 1, '070216', 702, 1, 'Zararli silikonlar içeren atiklar', '0702', 'Zararlı silikonlar içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '070299', 702, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0702', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70301, 'Su bazlı yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070301', 703, 1, 'Su bazli yikama sivilari ve ana çözeltiler', '0703', 'Su bazlı yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70304, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070304', 703, 1, 'Diger organik çözücüler, yikama sivilari ve ana çözeltiler', '0703', 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70308, 'Diğer dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070308', 703, 1, 'Diger dip tortusu ve reaksiyon kalintilari', '0703', 'Diğer dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70310, 'Diğer filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070310', 703, 1, 'Diger filtre kekleri ve kullanilmis absorbanlar', '0703', 'Diğer filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70312, '07 03 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '070312', 703, 0, '07 03 11 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0703', '07 03 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '070399', 703, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0703', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70401, 'Su bazlı yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070401', 704, 1, 'Su bazli yikama sivilari ve ana çözeltiler', '0704', 'Su bazlı yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70403, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070403', 704, 1, 'Halojenli organik çözücüler, yikama sivilari ve ana çözeltiler', '0704', 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70404, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070404', 704, 1, 'Diger organik çözücüler, yikama sivilari ve ana çözeltiler', '0704', 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70407, 'Halojenli dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070407', 704, 1, 'Halojenli dip tortusu ve reaksiyon kalintilari', '0704', 'Halojenli dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70408, 'Diğer dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070408', 704, 1, 'Diger dip tortusu ve reaksiyon kalintilari', '0704', 'Diğer dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70412, '07 04 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '070412', 704, 0, '07 04 11 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0704', '07 04 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70499, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '070499', 704, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0704', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70501, 'Su bazlı yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070501', 705, 1, 'Su bazli yikama sivilari ve ana çözeltiler', '0705', 'Su bazlı yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70504, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070504', 705, 1, 'Diger organik çözücüler, yikama sivilari ve ana çözeltiler', '0705', 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70510, 'Diğer filtre tabakaları kekleri, kullanılmış absorbanlar', NULL, 1, 1, '070510', 705, 1, 'Diger filtre tabakalari kekleri, kullanilmis absorbanlar', '0705', 'Diğer filtre tabakaları kekleri, kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70513, 'Tehlikeli madde içeren katı atıklar', NULL, 1, 1, '070513', 705, 1, 'Tehlikeli madde içeren kati atiklar', '0705', 'Tehlikeli madde içeren katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70514, '07 05 13 dışındaki katı atıklar', NULL, NULL, 0, '070514', 705, 0, '07 05 13 disindaki kati atiklar', '0705', '07 05 13 dışındaki katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70599, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '070599', 705, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0705', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70601, 'Su bazlı yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070601', 706, 1, 'Su bazli yikama sivilari ve ana çözeltiler', '0706', 'Su bazlı yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70603, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070603', 706, 1, 'Halojenli organik çözücüler, yikama sivilari ve ana çözeltiler', '0706', 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200303, 'Sokak temizleme kalıntıları', NULL, NULL, 0, '200303', 2003, 0, 'Sokak temizleme kalintilari', '2003', 'Sokak temizleme kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70604, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070604', 706, 1, 'Diger organik çözücüler, yikama sivilari ve ana çözeltiler', '0706', 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70609, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070609', 706, 1, 'Halojenli filtre kekleri ve kullanilmis absorbanlar', '0706', 'Halojenli filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70610, 'Diğer filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070610', 706, 1, 'Diger filtre kekleri ve kullanilmis absorbanlar', '0706', 'Diğer filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70701, 'Su bazlı yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070701', 707, 1, 'Su bazli yikama sivilari ve ana çözeltiler', '0707', 'Su bazlı yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70703, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070703', 707, 1, 'Halojenli organik çözücüler, yikama sivilari ve ana çözeltiler', '0707', 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70704, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070704', 707, 1, 'Diger organik çözücüler, yikama sivilari ve ana çözeltiler', '0707', 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70707, 'Halojenli dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070707', 707, 1, 'Halojenli dip tortusu ve reaksiyon kalintilari', '0707', 'Halojenli dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70708, 'Diğer dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070708', 707, 1, 'Diger dip tortusu ve reaksiyon kalintilari', '0707', 'Diğer dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70710, 'Diğer filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070710', 707, 1, 'Diger filtre kekleri ve kullanilmis absorbanlar', '0707', 'Diğer filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (801, 'Boya ve Verniğin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Sökülmesinden Kaynaklanan Atıklar', NULL, NULL, 1, '0801', 8, 0, 'Boya ve Vernigin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) ve Sökülmesinden Kaynaklanan Atiklar', '08', 'Boya ve Verniğin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Sökülmesinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80111, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren atık boya ve vernikler', NULL, 1, 1, '080111', 801, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren atik boya ve vernikler', '0801', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren atık boya ve vernikler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80112, '08 01 11 dışındaki atık boya ve vernikler', NULL, NULL, 0, '080112', 801, 0, '08 01 11 disindaki atik boya ve vernikler', '0801', '08 01 11 dışındaki atık boya ve vernikler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80113, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernik çamurları', NULL, 1, 1, '080113', 801, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren boya ve vernik çamurlari', '0801', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernik çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80115, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernikli sulu çamurlar', NULL, 1, 1, '080115', 801, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren boya ve vernikli sulu çamurlar', '0801', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernikli sulu çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80119, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernik sökülmesinden kaynaklanan sulu süspansiyonlar', NULL, 1, 1, '080119', 801, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren boya ve vernik sökülmesinden kaynaklanan sulu süspansiyonlar', '0801', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve vernik sökülmesinden kaynaklanan sulu süspansiyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80120, '08 01 19 dışındaki sulu boya ya da vernik içeren sulu süspansiyonlar', NULL, NULL, 0, '080120', 801, 0, '08 01 19 disindaki sulu boya ya da vernik içeren sulu süspansiyonlar', '0801', '08 01 19 dışındaki sulu boya ya da vernik içeren sulu süspansiyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100330, '10 03 29 dışındaki tuz cürufları ve kara cürufların arıtımından çıkan atıklar', NULL, NULL, 0, '100330', 1003, 0, '10 03 29 disindaki tuz cüruflari ve kara cüruflarin aritimindan çikan atiklar', '1003', '10 03 29 dışındaki tuz cürufları ve kara cürufların arıtımından çıkan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100399', 1003, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1003', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100401, 'Birincil ve ikincil üretim cürufları', NULL, 1, 1, '100401', 1004, 1, 'Birincil ve ikincil üretim cüruflari', '1004', 'Birincil ve ikincil üretim cürufları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100403, 'Kalsiyum arsenat', NULL, 1, 1, '100403', 1004, 1, 'Kalsiyum arsenat', '1004', 'Kalsiyum arsenat');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100404, 'Baca gazı tozu', NULL, 1, 1, '100404', 1004, 1, 'Baca gazi tozu', '1004', 'Baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190115, 'Tehlikeli maddeler içeren kazan tozu', NULL, 1, 1, '190115', 1901, 1, 'Tehlikeli maddeler içeren kazan tozu', '1901', 'Tehlikeli maddeler içeren kazan tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200123, 'Kloroflorokarbonlar içeren ıskartaya çıkartılmış ekipmanlar', NULL, 1, 1, '200123', 2001, 1, 'Kloroflorokarbonlar içeren iskartaya çikartilmis ekipmanlar', '2001', 'Kloroflorokarbonlar içeren ıskartaya çıkartılmış ekipmanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200125, 'Yenilebilir sıvı ve katı yağlar', NULL, NULL, 0, '200125', 2001, 0, 'Yenilebilir sivi ve kati yaglar', '2001', 'Yenilebilir sıvı ve katı yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200130, '20 01 29 dışındaki deterjanlar', NULL, NULL, 0, '200130', 2001, 0, '20 01 29 disindaki deterjanlar', '2001', '20 01 29 dışındaki deterjanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200134, '20 01 33 dışındaki pil ve akümülatörler', NULL, 2, 0, '200134', 2001, 0, '20 01 33 disindaki pil ve akümülatörler', '2001', '20 01 33 dışındaki pil ve akümülatörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200135, '20 01 21 ve 20 01 23 dışındaki tehlikeli parçalar6 içeren ve ıskartaya çıkmış elektrikli ve elektronik ekipmanlar', NULL, 1, 1, '200135', 2001, 1, '20 01 21 ve 20 01 23 disindaki tehlikeli parçalar6 içeren ve iskartaya çikmis elektrikli ve elektronik ekipmanlar', '2001', '20 01 21 ve 20 01 23 dışındaki tehlikeli parçalar6 içeren ve ıskartaya çıkmış elektrikli ve elektronik ekipmanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200136, '20 01 21, 20 01 23 ve 20 01 35 dışındaki ıskarta elektrikli ve elektronik ekipmanlar', NULL, NULL, 0, '200136', 2001, 0, '20 01 21, 20 01 23 ve 20 01 35 disindaki iskarta elektrikli ve elektronik ekipmanlar', '2001', '20 01 21, 20 01 23 ve 20 01 35 dışındaki ıskarta elektrikli ve elektronik ekipmanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200138, '20 01 37 dışındaki ahşap', NULL, NULL, 0, '200138', 2001, 0, '20 01 37 disindaki ahsap', '2001', '20 01 37 dışındaki ahşap');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200139, 'Plastikler', NULL, NULL, 0, '200139', 2001, 0, 'Plastikler', '2001', 'Plastikler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200140, 'Metaller', NULL, NULL, 0, '200140', 2001, 0, 'Metaller', '2001', 'Metaller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (2002, 'Bahçe ve Park Atıkları (Mezarlık Atıkları Dahil)', NULL, NULL, 1, '2002', 20, 0, 'Bahçe ve Park Atiklari (Mezarlik Atiklari Dahil)', '20', 'Bahçe ve Park Atıkları (Mezarlık Atıkları Dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200203, 'Biyolojik olarak bozunamayan diğer atıklar', NULL, NULL, 0, '200203', 2002, 0, 'Biyolojik olarak bozunamayan diger atiklar', '2002', 'Biyolojik olarak bozunamayan diğer atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200306, 'Kanalizasyon temizliğinden kaynaklanan atıklar', NULL, NULL, 0, '200306', 2003, 0, 'Kanalizasyon temizliginden kaynaklanan atiklar', '2003', 'Kanalizasyon temizliğinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50106, 'İşletme ya da ekipman bakım çalışmalarından kaynaklanan yağlı çamurlar', NULL, 1, 1, '050106', 501, 1, 'Isletme ya da ekipman bakim çalismalarindan kaynaklanan yagli çamurlar', '0501', 'İşletme ya da ekipman bakım çalışmalarından kaynaklanan yağlı çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50699, 'Başka bir şekilde tanımlanmayan atıklar', NULL, NULL, 0, '050699', 506, 0, 'Baska bir sekilde tanimlanmayan atiklar', '0506', 'Başka bir şekilde tanımlanmayan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '060199', 601, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0601', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60316, '06 03 15 dışındaki diğer metal oksitler', NULL, NULL, 0, '060316', 603, 0, '06 03 15 disindaki diger metal oksitler', '0603', '06 03 15 dışındaki diğer metal oksitler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60603, '06 06 02 dışındaki kükürt bileşenlerini içeren atıklar', NULL, NULL, 0, '060603', 606, 0, '06 06 02 disindaki kükürt bilesenlerini içeren atiklar', '0606', '06 06 02 dışındaki kükürt bileşenlerini içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60904, '06 09 03 dışındaki kalsiyum bazlı reaksiyon atıkları', NULL, NULL, 0, '060904', 609, 0, '06 09 03 disindaki kalsiyum bazli reaksiyon atiklari', '0609', '06 09 03 dışındaki kalsiyum bazlı reaksiyon atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61305, 'Kurum', NULL, 1, 1, '061305', 613, 1, 'Kurum', '0613', 'Kurum');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70507, 'Halojenli dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070507', 705, 1, 'Halojenli dip tortusu ve reaksiyon kalintilari', '0705', 'Halojenli dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70608, 'Diğer dip tortuları ve reaksiyon kalıntıları', NULL, 1, 1, '070608', 706, 1, 'Diger dip tortulari ve reaksiyon kalintilari', '0706', 'Diğer dip tortuları ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70711, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '070711', 707, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0707', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100799, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100799', 1007, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1007', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100815, 'Tehlikeli maddeler içeren baca gazı tozu', NULL, 1, 1, '100815', 1008, 1, 'Tehlikeli maddeler içeren baca gazi tozu', '1008', 'Tehlikeli maddeler içeren baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101006, '10 10 05 dışındaki henüz döküm yapılamamış maça ve kum döküm kalıpları', NULL, NULL, 0, '101006', 1010, 0, '10 10 05 disindaki henüz döküm yapilamamis maça ve kum döküm kaliplari', '1010', '10 10 05 dışındaki henüz döküm yapılamamış maça ve kum döküm kalıpları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101110, '10 11 09 dışında ısıl işlemden önce hazırlanan harman atığı', NULL, NULL, 0, '101110', 1011, 0, '10 11 09 disinda isil islemden önce hazirlanan harman atigi', '1011', '10 11 09 dışında ısıl işlemden önce hazırlanan harman atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100113, 'Yakıt olarak kullanılan emülsifiye hidrokarbonların uçucu külleri', NULL, 1, 1, '100113', 1001, 1, 'Yakit olarak kullanilan emülsifiye hidrokarbonlarin uçucu külleri', '1001', 'Yakıt olarak kullanılan emülsifiye hidrokarbonların uçucu külleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130104, 'Klor içeren emülsiyonlar', 1, 2, 1, '130104', 1301, 1, 'Klor içeren emülsiyonlar', '1301', 'Klor içeren emülsiyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100214, '10 02 13 dışındaki gaz arıtımı sonucu oluşan çamurlar ve filtre kekleri', NULL, NULL, 0, '100214', 1002, 0, '10 02 13 disindaki gaz aritimi sonucu olusan çamurlar ve filtre kekleri', '1002', '10 02 13 dışındaki gaz arıtımı sonucu oluşan çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '020399', 203, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0203', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20599, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '020599', 205, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0205', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20703, 'Kimyasal işlem atıkları', NULL, NULL, 0, '020703', 207, 0, 'Kimyasal islem atiklari', '0207', 'Kimyasal işlem atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30310, 'Mekanik ayırma sonucu oluşan elyaf ıskartaları, elyaf, dolgu ve yüzey kaplama maddesi çamuru', NULL, NULL, 0, '030310', 303, 0, 'Mekanik ayirma sonucu olusan elyaf iskartalari, elyaf, dolgu ve yüzey kaplama maddesi çamuru', '0303', 'Mekanik ayırma sonucu oluşan elyaf ıskartaları, elyaf, dolgu ve yüzey kaplama maddesi çamuru');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '101299', 1012, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1012', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110111, 'Tehlikeli maddeler içeren sulu durulama sıvıları', NULL, 1, 1, '110111', 1101, 1, 'Tehlikeli maddeler içeren sulu durulama sivilari', '1101', 'Tehlikeli maddeler içeren sulu durulama sıvıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110207, 'Tehlikeli maddeler içeren diğer atıklar', NULL, 1, 1, '110207', 1102, 1, 'Tehlikeli maddeler içeren diger atiklar', '1102', 'Tehlikeli maddeler içeren diğer atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120110, 'Sentetik işleme yağları', 1, 2, 1, '120110', 1201, 1, 'Sentetik isleme yaglari', '1201', 'Sentetik işleme yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120119, 'Biyolojik olarak kolay bozunur işleme yağı', NULL, 2, 1, '120119', 1201, 1, 'Biyolojik olarak kolay bozunur isleme yagi', '1201', 'Biyolojik olarak kolay bozunur işleme yağı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130403, 'Diğer denizcilik seyrüseferinden kaynaklanan sintine yağları', NULL, 1, 1, '130403', 1304, 1, 'Diger denizcilik seyrüseferinden kaynaklanan sintine yaglari', '1304', 'Diğer denizcilik seyrüseferinden kaynaklanan sintine yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150109, 'Tekstil ambalaj', NULL, NULL, 0, '150109', 1501, 0, 'Tekstil ambalaj', '1501', 'Tekstil ambalaj');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160103, 'Ömrünü tamamlamış lastikler', NULL, 2, 0, '160103', 1601, 0, 'Ömrünü tamamlamis lastikler', '1601', 'Ömrünü tamamlamış lastikler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160120, 'Cam', NULL, NULL, 0, '160120', 1601, 0, 'Cam', '1601', 'Cam');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '160199', 1601, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1601', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160806, 'Katalizör olarak bitik sıvılar', NULL, 1, 1, '160806', 1608, 1, 'Katalizör olarak bitik sivilar', '1608', 'Katalizör olarak bitik sıvılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161004, '16 10 03 dışındaki sulu derişik maddeler', NULL, NULL, 0, '161004', 1610, 0, '16 10 03 disindaki sulu derisik maddeler', '1610', '16 10 03 dışındaki sulu derişik maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1802, 'Hayvanlarla İlgili Araştırma, Teşhis, Tedavi ya da Hastalık Önleme Çalışmalarından Kaynaklanan Atıklar', NULL, NULL, 1, '1802', 18, 0, 'Hayvanlarla Ilgili Arastirma, Teshis, Tedavi ya da Hastalik Önleme Çalismalarindan Kaynaklanan Atiklar', '18', 'Hayvanlarla İlgili Araştırma, Teşhis, Tedavi ya da Hastalık Önleme Çalışmalarından Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190119, 'Akışkan yatak kumları', NULL, NULL, 0, '190119', 1901, 0, 'Akiskan yatak kumlari', '1901', 'Akışkan yatak kumları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190207, 'Ayrışmadan oluşan yağ ve konsantrasyonlar', NULL, 1, 1, '190207', 1902, 1, 'Ayrismadan olusan yag ve konsantrasyonlar', '1902', 'Ayrışmadan oluşan yağ ve konsantrasyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190503, 'Standart dışı kompost', NULL, NULL, 0, '190503', 1905, 0, 'Standart disi kompost', '1905', 'Standart dışı kompost');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191304, '19 13 03 dışındaki toprak ıslahından kaynaklanan çamurlar', NULL, NULL, 0, '191304', 1913, 0, '19 13 03 disindaki toprak islahindan kaynaklanan çamurlar', '1913', '19 13 03 dışındaki toprak ıslahından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200199, 'Başka bir şekilde tanımlanmamış fraksiyonlar', NULL, NULL, 0, '200199', 2001, 0, 'Baska bir sekilde tanimlanmamis fraksiyonlar', '2001', 'Başka bir şekilde tanımlanmamış fraksiyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200304, 'Fosseptik çamurları', NULL, NULL, 0, '200304', 2003, 0, 'Fosseptik çamurlari', '2003', 'Fosseptik çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40106, 'Saha içi atıksu arıtımından kaynaklanan krom içeren çamurlar', NULL, NULL, 0, '040106', 401, 0, 'Saha içi atiksu aritimindan kaynaklanan krom içeren çamurlar', '0401', 'Saha içi atıksu arıtımından kaynaklanan krom içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101003, 'Ocak cürufları', NULL, NULL, 0, '101003', 1010, 0, 'Ocak cüruflari', '1010', 'Ocak cürufları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160505, '16 05 04 dışında basınçlı tanklar içindeki gazlar', NULL, NULL, 0, '160505', 1605, 0, '16 05 04 disinda basinçli tanklar içindeki gazlar', '1605', '16 05 04 dışında basınçlı tanklar içindeki gazlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170508, '17 05 07 dışındaki demiryolu çakılı', NULL, NULL, 0, '170508', 1705, 0, '17 05 07 disindaki demiryolu çakili', '1705', '17 05 07 dışındaki demiryolu çakılı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50104, 'Asit alkil çamurları', NULL, 1, 1, '050104', 501, 1, 'Asit alkil çamurlari', '0501', 'Asit alkil çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50601, 'Asit ziftleri', NULL, 1, 1, '050601', 506, 1, 'Asit ziftleri', '0506', 'Asit ziftleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60201, 'Kalsiyum hidroksit', NULL, 1, 1, '060201', 602, 1, 'Kalsiyum hidroksit', '0602', 'Kalsiyum hidroksit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60499, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '060499', 604, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0604', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40220, '04 02 19 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '040220', 402, 0, '04 02 19 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0402', '04 02 19 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60403, 'Arsenik içeren atıklar', NULL, 1, 1, '060403', 604, 1, 'Arsenik içeren atiklar', '0604', 'Arsenik içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (613, 'Başka Bir Şekilde Tanımlanmamış İnorganik Kimyasal İşlemlerden Kaynaklanan Atıklar', NULL, NULL, 1, '0613', 6, 0, 'Baska Bir Sekilde Tanimlanmamis İnorganik Kimyasal Islemlerden Kaynaklanan Atiklar', '06', 'Başka Bir Şekilde Tanımlanmamış İnorganik Kimyasal İşlemlerden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70411, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '070411', 704, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0704', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1007, 'Gümüş, Altın ve Platin Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, NULL, 1, '1007', 10, 0, 'Gümüs, Altin ve Platin Isil Metalurjisinden Kaynaklanan Atiklar', '10', 'Gümüş, Altın ve Platin Isıl Metalurjisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101014, '10 10 13 dışındaki bağlayıcı atıkları', NULL, NULL, 0, '101014', 1010, 0, '10 10 13 disindaki baglayici atiklari', '1010', '10 10 13 dışındaki bağlayıcı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80412, '08 04 11 dışındaki yapışkan ve dolgu macunu çamurları', NULL, NULL, 0, '080412', 804, 0, '08 04 11 disindaki yapiskan ve dolgu macunu çamurlari', '0804', '08 04 11 dışındaki yapışkan ve dolgu macunu çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100125, 'Termik santrallerin yakıt depolama ve hazırlama işlemlerinden çıkan atıklar', NULL, NULL, 0, '100125', 1001, 0, 'Termik santrallerin yakit depolama ve hazirlama islemlerinden çikan atiklar', '1001', 'Termik santrallerin yakıt depolama ve hazırlama işlemlerinden çıkan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10308, '01 03 07 dışındaki diğer tozumsu ve pudramsı atıklar', NULL, NULL, 0, '010308', 103, 0, '01 03 07 disindaki diger tozumsu ve pudramsi atiklar', '0103', '01 03 07 dışındaki diğer tozumsu ve pudramsı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20305, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan atıklar', NULL, NULL, 0, '020305', 203, 0, 'Isletme sahasi içerisindeki atik su aritimindan kaynaklanan atiklar', '0203', 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110113, 'Tehlikeli maddeler içeren yağ alma atıkları', NULL, 1, 1, '110113', 1101, 1, 'Tehlikeli maddeler içeren yag alma atiklari', '1101', 'Tehlikeli maddeler içeren yağ alma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120120, 'Tehlikeli maddeler içeren öğütme parçaları ve öğütme maddeleri', NULL, 1, 1, '120120', 1201, 1, 'Tehlikeli maddeler içeren ögütme parçalari ve ögütme maddeleri', '1201', 'Tehlikeli maddeler içeren öğütme parçaları ve öğütme maddeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130703, 'Diğer yakıtlar (karışımlar dahil)', NULL, 1, 1, '130703', 1307, 1, 'Diger yakitlar (karisimlar dahil)', '1307', 'Diğer yakıtlar (karışımlar dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160111, 'Asbest içeren fren balataları', NULL, 1, 1, '160111', 1601, 1, 'Asbest içeren fren balatalari', '1601', 'Asbest içeren fren balataları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160601, 'Kurşunlu piller', NULL, 2, 1, '160601', 1606, 1, 'Kursunlu piller', '1606', 'Kurşunlu piller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161001, 'Tehlikeli maddeler içeren sulu sıvı atıklar', NULL, 1, 1, '161001', 1610, 1, 'Tehlikeli maddeler içeren sulu sivi atiklar', '1610', 'Tehlikeli maddeler içeren sulu sıvı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170507, 'Tehlikeli maddeler içeren demiryolu çakılı', NULL, 1, 1, '170507', 1705, 1, 'Tehlikeli maddeler içeren demiryolu çakili', '1705', 'Tehlikeli maddeler içeren demiryolu çakılı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190112, '19 01 11 dışındaki taban külü ve cüruf', NULL, NULL, 0, '190112', 1901, 0, '19 01 11 disindaki taban külü ve cüruf', '1901', '19 01 11 dışındaki taban külü ve cüruf');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200129, 'Tehlikeli maddeler içeren deterjanlar', NULL, 1, 1, '200129', 2001, 1, 'Tehlikeli maddeler içeren deterjanlar', '2001', 'Tehlikeli maddeler içeren deterjanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61002, 'Tehlikeli maddeler içeren atıklar', NULL, 1, 1, '061002', 610, 1, 'Tehlikeli maddeler içeren atiklar', '0610', 'Tehlikeli maddeler içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70199, 'Başka şekilde tanımlanmayan atıklar', NULL, NULL, 0, '070199', 701, 0, 'Baska sekilde tanimlanmayan atiklar', '0701', 'Başka şekilde tanımlanmayan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70612, '07 06 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '070612', 706, 0, '07 06 11 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0706', '07 06 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100402, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', NULL, 1, 1, '100402', 1004, 1, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', '1004', 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100607, 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri', NULL, 1, 1, '100607', 1006, 1, 'Gaz aritimindan kaynaklanan çamurlar ve filtre kekleri', '1006', 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100899, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100899', 1008, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1008', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (604, '06 03 Dışındaki Metal İçeren Atıklar', NULL, NULL, 1, '0604', 6, 0, '06 03 Disindaki Metal Içeren Atiklar', '06', '06 03 Dışındaki Metal İçeren Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101120, '10 11 19 dışındaki saha içi atık su arıtımından kaynaklanan katı atıklar', NULL, NULL, 0, '101120', 1011, 0, '10 11 19 disindaki saha içi atik su aritimindan kaynaklanan kati atiklar', '1011', '10 11 19 dışındaki saha içi atık su arıtımından kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90103, 'Çözücü bazlı banyo solüsyonları', NULL, 1, 1, '090103', 901, 1, 'Çözücü bazli banyo solüsyonlari', '0901', 'Çözücü bazlı banyo solüsyonları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100321, 'Tehlikeli maddeler içeren diğer partiküller ve tozlar (öğütücü değirmen tozu dahil)', NULL, 1, 1, '100321', 1003, 1, 'Tehlikeli maddeler içeren diger partiküller ve tozlar (ögütücü degirmen tozu dahil)', '1003', 'Tehlikeli maddeler içeren diğer partiküller ve tozlar (öğütücü değirmen tozu dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10304, 'Sülfürlü cevherlerin işlenmesinden kaynaklanan asit üretici maden atıkları', NULL, 1, 1, '010304', 103, 1, 'Sülfürlü cevherlerin islenmesinden kaynaklanan asit üretici maden atiklari', '0103', 'Sülfürlü cevherlerin işlenmesinden kaynaklanan asit üretici maden atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20110, 'Atık metal', NULL, NULL, 0, '020110', 201, 0, 'Atik metal', '0201', 'Atık metal');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20303, 'Çözücü ekstraksiyonundan kaynaklanan atıklar', NULL, NULL, 0, '020303', 203, 0, 'Çözücü ekstraksiyonundan kaynaklanan atiklar', '0203', 'Çözücü ekstraksiyonundan kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101301, 'Isıl işlem öncesi karışım hazırlama atıkları', NULL, NULL, 0, '101301', 1013, 0, 'Isil islem öncesi karisim hazirlama atiklari', '1013', 'Isıl işlem öncesi karışım hazırlama atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110116, 'Doymuş ya da bitik iyon değişim reçineleri', NULL, 1, 1, '110116', 1101, 1, 'Doymus ya da bitik iyon degisim reçineleri', '1101', 'Doymuş ya da bitik iyon değişim reçineleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1301, 'Atık Hidrolik Yağlar', NULL, NULL, 1, '1301', 13, 0, 'Atik Hidrolik Yaglar', '13', 'Atık Hidrolik Yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130208, 'Diğer motor, şanzıman ve yağlama yağları', 1, 2, 1, '130208', 1302, 1, 'Diger motor, sanziman ve yaglama yaglari', '1302', 'Diğer motor, şanzıman ve yağlama yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150105, 'Kompozit ambalaj', NULL, NULL, 0, '150105', 1501, 0, 'Kompozit ambalaj', '1501', 'Kompozit ambalaj');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160212, 'Serbest asbest içeren ıskarta ekipman', NULL, 1, 1, '160212', 1602, 1, 'Serbest asbest içeren iskarta ekipman', '1602', 'Serbest asbest içeren ıskarta ekipman');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160603, 'Cıva içeren piller', NULL, 2, 1, '160603', 1606, 1, 'Civa içeren piller', '1606', 'Cıva içeren piller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170102, 'Tuğlalar', NULL, NULL, 0, '170102', 1701, 0, 'Tuglalar', '1701', 'Tuğlalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170303, 'Kömür katranı ve katranlı ürünler', NULL, 1, 1, '170303', 1703, 1, 'Kömür katrani ve katranli ürünler', '1703', 'Kömür katranı ve katranlı ürünler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170604, '17 06 01 ve 17 06 03 dışındaki yalıtım malzemeleri', NULL, NULL, 0, '170604', 1706, 0, '17 06 01 ve 17 06 03 disindaki yalitim malzemeleri', '1706', '17 06 01 ve 17 06 03 dışındaki yalıtım malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190203, 'Tehlikeli olmayan atıkların önceden karıştırılması ile oluşmuş atıklar', NULL, NULL, 0, '190203', 1902, 0, 'Tehlikeli olmayan atiklarin önceden karistirilmasi ile olusmus atiklar', '1902', 'Tehlikeli olmayan atıkların önceden karıştırılması ile oluşmuş atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191005, 'Tehlikeli maddeler içeren diğer kalıntılar', NULL, 1, 1, '191005', 1910, 1, 'Tehlikeli maddeler içeren diger kalintilar', '1910', 'Tehlikeli maddeler içeren diğer kalıntılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200202, 'Toprak ve taşlar', NULL, NULL, 0, '200202', 2002, 0, 'Toprak ve taslar', '2002', 'Toprak ve taşlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130110, 'Mineral esaslı klor içermeyen hidrolik yağlar', 1, 2, 1, '130110', 1301, 1, 'Mineral esasli klor içermeyen hidrolik yaglar', '1301', 'Mineral esaslı klor içermeyen hidrolik yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40101, 'Sıyırma ve kireçleme ile deriden et sıyırma işleminden kaynaklanan atıklar', NULL, NULL, 0, '040101', 401, 0, 'Siyirma ve kireçleme ile deriden et siyirma isleminden kaynaklanan atiklar', '0401', 'Sıyırma ve kireçleme ile deriden et sıyırma işleminden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40105, 'Krom içermeyen sepi şerbeti', NULL, NULL, 0, '040105', 401, 0, 'Krom içermeyen sepi serbeti', '0401', 'Krom içermeyen sepi şerbeti');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60104, 'Fosforik ve fosforöz asit', NULL, 1, 1, '060104', 601, 1, 'Fosforik ve fosforöz asit', '0601', 'Fosforik ve fosforöz asit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61301, 'İnorganik bitki koruma ürünleri, ahşap koruma ürünleri ve diğer biositler', NULL, 1, 1, '061301', 613, 1, 'İnorganik bitki koruma ürünleri, ahsap koruma ürünleri ve diger biositler', '0613', 'İnorganik bitki koruma ürünleri, ahşap koruma ürünleri ve diğer biositler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70107, 'Halojenli dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070107', 701, 1, 'Halojenli dip tortusu ve reaksiyon kalintilari', '0701', 'Halojenli dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70503, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070503', 705, 1, 'Halojenli organik çözücüler, yikama sivilari ve ana çözeltiler', '0705', 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100406, 'Gaz arıtımından kaynaklanan katı atıklar', NULL, 1, 1, '100406', 1004, 1, 'Gaz aritimindan kaynaklanan kati atiklar', '1004', 'Gaz arıtımından kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101109, 'Isıl işlemden önce hazırlanan tehlikeli maddeler içeren harman atığı', NULL, 1, 1, '101109', 1011, 1, 'Isil islemden önce hazirlanan tehlikeli maddeler içeren harman atigi', '1011', 'Isıl işlemden önce hazırlanan tehlikeli maddeler içeren harman atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100308, 'İkincil üretimden kaynaklanan tuz cürufları', NULL, 1, 1, '100308', 1003, 1, 'Ikincil üretimden kaynaklanan tuz cüruflari', '1003', 'İkincil üretimden kaynaklanan tuz cürufları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110105, 'Sıyırma asitleri (parlatma asitleri)', NULL, 1, 1, '110105', 1101, 1, 'Siyirma asitleri (parlatma asitleri)', '1101', 'Sıyırma asitleri (parlatma asitleri)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130105, 'Klor içermeyen emülsiyonlar', 1, 2, 1, '130105', 1301, 1, 'Klor içermeyen emülsiyonlar', '1301', 'Klor içermeyen emülsiyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160303, 'Tehlikeli maddeler içeren inorganik atıklar', NULL, 1, 1, '160303', 1603, 1, 'Tehlikeli maddeler içeren inorganik atiklar', '1603', 'Tehlikeli maddeler içeren inorganik atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170605, 'Asbest içeren inşaat malzemeleri', NULL, 1, 1, '170605', 1706, 1, 'Asbest içeren insaat malzemeleri', '1706', 'Asbest içeren inşaat malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110115, 'Membran ya da iyon değişim sistemlerinden kaynaklanan tehlikeli maddeler içeren sıvı ve çamurlar', NULL, 1, 1, '110115', 1101, 1, 'Membran ya da iyon degisim sistemlerinden kaynaklanan tehlikeli maddeler içeren sivi ve çamurlar', '1101', 'Membran ya da iyon değişim sistemlerinden kaynaklanan tehlikeli maddeler içeren sıvı ve çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110198, 'Tehlikeli maddeler içeren diğer atıklar', NULL, 1, 1, '110198', 1101, 1, 'Tehlikeli maddeler içeren diger atiklar', '1101', 'Tehlikeli maddeler içeren diğer atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1102, 'Demir Dışındaki Madenlerin Hidrometalürjik İşlenmesinin Atıkları', NULL, NULL, 1, '1102', 11, 0, 'Demir Disindaki Madenlerin Hidrometalürjik Islenmesinin Atiklari', '11', 'Demir Dışındaki Madenlerin Hidrometalürjik İşlenmesinin Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1308, 'Başka bir şekilde tanımlanmamış yağ atıkları', NULL, NULL, 1, '1308', 13, 0, 'Baska bir sekilde tanimlanmamis yag atiklari', '13', 'Başka bir şekilde tanımlanmamış yağ atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110205, 'Bakır hidrometalürjisi işlemlerinden kaynaklanan tehlikeli maddeler içeren atıklar', NULL, 1, 1, '110205', 1102, 1, 'Bakir hidrometalürjisi islemlerinden kaynaklanan tehlikeli maddeler içeren atiklar', '1102', 'Bakır hidrometalürjisi işlemlerinden kaynaklanan tehlikeli maddeler içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '110299', 1102, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1102', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1103, 'Tavlama İşlemleri Çamurları ve Katı Maddeleri', NULL, NULL, 1, '1103', 11, 0, 'Tavlama Islemleri Çamurlari ve Kati Maddeleri', '11', 'Tavlama İşlemleri Çamurları ve Katı Maddeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110301, 'Siyanür içeren atıklar', NULL, 1, 1, '110301', 1103, 1, 'Siyanür içeren atiklar', '1103', 'Siyanür içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110501, 'Katı çinko', NULL, NULL, 0, '110501', 1105, 0, 'Kati çinko', '1105', 'Katı çinko');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110502, 'Çinko külü', NULL, NULL, 0, '110502', 1105, 0, 'Çinko külü', '1105', 'Çinko külü');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110503, 'Gaz arıtımından kaynaklanan katı atıklar', NULL, 1, 1, '110503', 1105, 1, 'Gaz aritimindan kaynaklanan kati atiklar', '1105', 'Gaz arıtımından kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110599, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '110599', 1105, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1105', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120102, 'Demir metal toz ve parçacıklar', NULL, NULL, 0, '120102', 1201, 0, 'Demir metal toz ve parçaciklar', '1201', 'Demir metal toz ve parçacıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120103, 'Demir dışı metal çapakları ve talaşları', NULL, NULL, 0, '120103', 1201, 0, 'Demir disi metal çapaklari ve talaslari', '1201', 'Demir dışı metal çapakları ve talaşları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120105, 'Plastik yongalar ve çapaklar', NULL, NULL, 0, '120105', 1201, 0, 'Plastik yongalar ve çapaklar', '1201', 'Plastik yongalar ve çapaklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120107, 'Halojen içermeyen madeni bazlı işleme yağları (emülsiyon ve solüsyonlar hariç)', 1, 2, 1, '120107', 1201, 1, 'Halojen içermeyen madeni bazli isleme yaglari (emülsiyon ve solüsyonlar hariç)', '1201', 'Halojen içermeyen madeni bazlı işleme yağları (emülsiyon ve solüsyonlar hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120108, 'Halojen içeren işleme emülsiyon ve solüsyonları', NULL, 1, 1, '120108', 1201, 1, 'Halojen içeren isleme emülsiyon ve solüsyonlari', '1201', 'Halojen içeren işleme emülsiyon ve solüsyonları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120112, 'Kullanılmış (mum) parafin ve yağlar (Atık Ara Depolama tesisleri sadece kullanılmış parafin atıklarını kabul edebilir.)', 1, 1, 1, '120112', 1201, 1, 'Kullanilmis (mum) parafin ve yaglar', '1201', 'Kullanılmış (mum) parafin ve yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120113, 'Kaynak atıkları', NULL, NULL, 0, '120113', 1201, 0, 'Kaynak atiklari', '1201', 'Kaynak atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120114, 'Tehlikeli maddeler içeren işleme çamurları', NULL, 1, 1, '120114', 1201, 1, 'Tehlikeli maddeler içeren isleme çamurlari', '1201', 'Tehlikeli maddeler içeren işleme çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120118, 'Yağ içeren metalik çamurlar (öğütme, bileme ve freze tortuları)', NULL, 1, 1, '120118', 1201, 1, 'Yag içeren metalik çamurlar (ögütme, bileme ve freze tortulari)', '1201', 'Yağ içeren metalik çamurlar (öğütme, bileme ve freze tortuları)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1203, 'Su ve Buhar Yağ Alma İşlemlerinden Kaynaklanan Atıklar (11 Hariç)', NULL, NULL, 1, '1203', 12, 0, 'Su ve Buhar Yag Alma Islemlerinden Kaynaklanan Atiklar (11 Hariç)', '12', 'Su ve Buhar Yağ Alma İşlemlerinden Kaynaklanan Atıklar (11 Hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120301, 'Sulu yıkama sıvıları', NULL, 1, 1, '120301', 1203, 1, 'Sulu yikama sivilari', '1203', 'Sulu yıkama sıvıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120302, 'Buhar yağ alma atıkları', NULL, 1, 1, '120302', 1203, 1, 'Buhar yag alma atiklari', '1203', 'Buhar yağ alma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130101, 'PCB (1) içeren hidrolik yağlar', 1, 2, 1, '130101', 1301, 1, 'PCB (1) içeren hidrolik yaglar', '1301', 'PCB (1) içeren hidrolik yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130113, 'Diğer hidrolik yağlar', 1, 2, 1, '130113', 1301, 1, 'Diger hidrolik yaglar', '1301', 'Diğer hidrolik yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1302, 'Atık Motor, Şanzıman ve Yağlama Yağları', NULL, NULL, 1, '1302', 13, 0, 'Atik Motor, Sanziman ve Yaglama Yaglari', '13', 'Atık Motor, Şanzıman ve Yağlama Yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130205, 'Mineral esaslı klor içermeyen motor, şanzıman ve yağlama yağları', 1, 2, 1, '130205', 1302, 1, 'Mineral esasli klor içermeyen motor, sanziman ve yaglama yaglari', '1302', 'Mineral esaslı klor içermeyen motor, şanzıman ve yağlama yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130207, 'Kolayca biyolojik olarak bozunabilir motor, şanzıman ve yağlama yağları', 1, 2, 1, '130207', 1302, 1, 'Kolayca biyolojik olarak bozunabilir motor, sanziman ve yaglama yaglari', '1302', 'Kolayca biyolojik olarak bozunabilir motor, şanzıman ve yağlama yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130306, '13 03 01 dışındaki mineral esaslı klor içeren yalıtım ve ısı iletim yağları', 1, 2, 1, '130306', 1303, 1, '13 03 01 disindaki mineral esasli klor içeren yalitim ve isi iletim yaglari', '1303', '13 03 01 dışındaki mineral esaslı klor içeren yalıtım ve ısı iletim yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130308, 'Sentetik yalıtım ve ısı iletim yağları', 1, 2, 1, '130308', 1303, 1, 'Sentetik yalitim ve isi iletim yaglari', '1303', 'Sentetik yalıtım ve ısı iletim yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130309, 'Kolayca biyolojik olarak bozunabilir yalıtım ve ısı iletim yağları', 1, 2, 1, '130309', 1303, 1, 'Kolayca biyolojik olarak bozunabilir yalitim ve isi iletim yaglari', '1303', 'Kolayca biyolojik olarak bozunabilir yalıtım ve ısı iletim yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1304, 'Sintine Yağları', NULL, NULL, 1, '1304', 13, 0, 'Sintine Yaglari', '13', 'Sintine Yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130402, 'İskele kanalizasyonlarından(mendirekten) kaynaklanan sintine yağları', NULL, 1, 1, '130402', 1304, 1, 'Iskele kanalizasyonlarindan(mendirekten) kaynaklanan sintine yaglari', '1304', 'İskele kanalizasyonlarından(mendirekten) kaynaklanan sintine yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130501, 'Kum odacığından ve yağ/su ayırıcısından çıkan katılar', NULL, 1, 1, '130501', 1305, 1, 'Kum odacigindan ve yag/su ayiricisindan çikan katilar', '1305', 'Kum odacığından ve yağ/su ayırıcısından çıkan katılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130503, 'Yakalayıcı (interseptör) çamurları', NULL, 1, 1, '130503', 1305, 1, 'Yakalayici (interseptör) çamurlari', '1305', 'Yakalayıcı (interseptör) çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130506, 'Yağ/su ayırıcılarından çıkan yağ', 1, 1, 1, '130506', 1305, 1, 'Yag/su ayiricilarindan çikan yag', '1305', 'Yağ/su ayırıcılarından çıkan yağ');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1307, 'Sıvı Yakıtların Atıkları', NULL, NULL, 1, '1307', 13, 0, 'Sivi Yakitlarin Atiklari', '13', 'Sıvı Yakıtların Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130701, 'Fuel-oil ve mazot', NULL, 1, 1, '130701', 1307, 1, 'Fuel-oil ve mazot', '1307', 'Fuel-oil ve mazot');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130702, 'Benzin', NULL, 1, 1, '130702', 1307, 1, 'Benzin', '1307', 'Benzin');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130111, 'Sentetik hidrolik yağlar', 1, 2, 1, '130111', 1301, 1, 'Sentetik hidrolik yaglar', '1301', 'Sentetik hidrolik yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1303, 'Atık Yalıtım ve Isı İletim Yağları', NULL, NULL, 1, '1303', 13, 0, 'Atik Yalitim ve Isi Iletim Yaglari', '13', 'Atık Yalıtım ve Isı İletim Yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130401, 'Nehir ve göl seyrüseferinden (iç su yolu denizciliğinden) kaynaklanan sintine yağları', NULL, 1, 1, '130401', 1304, 1, 'Nehir ve göl seyrüseferinden (iç su yolu denizciliginden) kaynaklanan sintine yaglari', '1304', 'Nehir ve göl seyrüseferinden (iç su yolu denizciliğinden) kaynaklanan sintine yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (140604, 'Halojenli çözücüler içeren çamurlar veya katı atıklar', NULL, 1, 1, '140604', 1406, 1, 'Halojenli çözücüler içeren çamurlar veya kati atiklar', '1406', 'Halojenli çözücüler içeren çamurlar veya katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1502, 'Emiciler, Filtre Malzemeleri, Temizleme Bezleri ve Koruyucu Giysiler', NULL, NULL, 1, '1502', 15, 0, 'Emiciler, Filtre Malzemeleri, Temizleme Bezleri ve Koruyucu Giysiler', '15', 'Emiciler, Filtre Malzemeleri, Temizleme Bezleri ve Koruyucu Giysiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160114, 'Tehlikeli maddeler içeren antifriz sıvıları', NULL, 1, 1, '160114', 1601, 1, 'Tehlikeli maddeler içeren antifriz sivilari', '1601', 'Tehlikeli maddeler içeren antifriz sıvıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160210, '16 02 09 dışındaki PCB içeren ya da PCB ile kontamine olmuş ıskarta ekipmanlar', NULL, 2, 1, '160210', 1602, 1, '16 02 09 disindaki PCB içeren ya da PCB ile kontamine olmus iskarta ekipmanlar', '1602', '16 02 09 dışındaki PCB içeren ya da PCB ile kontamine olmuş ıskarta ekipmanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160506, 'Laboratuvar kimyasalları karışımları dahil tehlikeli maddelerden oluşan ya da tehlikeli maddeler içeren laboratuvar kimyasalları', NULL, 1, 1, '160506', 1605, 1, 'Laboratuvar kimyasallari karisimlari dahil tehlikeli maddelerden olusan ya da tehlikeli maddeler içeren laboratuvar kimyasallari', '1605', 'Laboratuvar kimyasalları karışımları dahil tehlikeli maddelerden oluşan ya da tehlikeli maddeler içeren laboratuvar kimyasalları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160902, 'Kromatlar (örneğin potasyum kromat, potasyum veya sodyum dikromat)', NULL, 1, 1, '160902', 1609, 1, 'Kromatlar (örnegin potasyum kromat, potasyum veya sodyum dikromat)', '1609', 'Kromatlar (örneğin potasyum kromat, potasyum veya sodyum dikromat)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170201, 'Ahşap', NULL, NULL, 0, '170201', 1702, 0, 'Ahsap', '1702', 'Ahşap');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170301, 'Kömür katranı içeren bitümlü karışımlar', NULL, 1, 1, '170301', 1703, 1, 'Kömür katrani içeren bitümlü karisimlar', '1703', 'Kömür katranı içeren bitümlü karışımlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170406, 'Kalay', NULL, NULL, 0, '170406', 1704, 0, 'Kalay', '1704', 'Kalay');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170411, '17 04 10 dışındaki kablolar', NULL, NULL, 0, '170411', 1704, 0, '17 04 10 disindaki kablolar', '1704', '17 04 10 dışındaki kablolar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170601, 'Asbest içeren yalıtım malzemeleri', NULL, 1, 1, '170601', 1706, 1, 'Asbest içeren yalitim malzemeleri', '1706', 'Asbest içeren yalıtım malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170904, '17 09 01, 17 09 02 ve 17 09 03 dışındaki karışık inşaat ve yıkıntı atıkları', NULL, NULL, 0, '170904', 1709, 0, '17 09 01, 17 09 02 ve 17 09 03 disindaki karisik insaat ve yikinti atiklari', '1709', '17 09 01, 17 09 02 ve 17 09 03 dışındaki karışık inşaat ve yıkıntı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190206, '19 02 05 dışındaki fiziksel ve kimyasal işlemlerden kaynaklanan çamurlar', NULL, NULL, 0, '190206', 1902, 0, '19 02 05 disindaki fiziksel ve kimyasal islemlerden kaynaklanan çamurlar', '1902', '19 02 05 dışındaki fiziksel ve kimyasal işlemlerden kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190699, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '190699', 1906, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1906', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190808, 'Ağır metaller içeren membran sistemi atıkları', NULL, 1, 1, '190808', 1908, 1, 'Agir metaller içeren membran sistemi atiklari', '1908', 'Ağır metaller içeren membran sistemi atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191006, '19 10 05 dışındaki diğer kalıntılar', NULL, NULL, 0, '191006', 1910, 0, '19 10 05 disindaki diger kalintilar', '1910', '19 10 05 dışındaki diğer kalıntılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200119, 'Pestisitler', NULL, 1, 1, '200119', 2001, 1, 'Pestisitler', '2001', 'Pestisitler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20102, 'Hayvan dokusu atıkları', NULL, NULL, 0, '020102', 201, 0, 'Hayvan dokusu atiklari', '0201', 'Hayvan dokusu atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200127, 'Tehlikeli maddeler içeren boya, mürekkepler, yapıştırıcılar ve reçineler', NULL, 1, 1, '200127', 2001, 1, 'Tehlikeli maddeler içeren boya, mürekkepler, yapistiricilar ve reçineler', '2001', 'Tehlikeli maddeler içeren boya, mürekkepler, yapıştırıcılar ve reçineler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200201, 'Biyolojik olarak bozunabilir atıklar', NULL, NULL, 0, '200201', 2002, 0, 'Biyolojik olarak bozunabilir atiklar', '2002', 'Biyolojik olarak bozunabilir atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200307, 'Hacimli atıklar', NULL, NULL, 0, '200307', 2003, 0, 'Hacimli atiklar', '2003', 'Hacimli atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40108, 'Krom içeren tabaklanmış atık deri (çivitli parçalar, tıraşlamalar, kesmeler, parlatma tozu)', NULL, NULL, 0, '040108', 401, 0, 'Krom içeren tabaklanmis atik deri (çivitli parçalar, tiraslamalar, kesmeler, parlatma tozu)', '0401', 'Krom içeren tabaklanmış atık deri (çivitli parçalar, tıraşlamalar, kesmeler, parlatma tozu)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40209, 'Kompozit malzeme atıkları (emprenye edilmiş tekstil, elastomer, plastomer)', NULL, NULL, 0, '040209', 402, 0, 'Kompozit malzeme atiklari (emprenye edilmis tekstil, elastomer, plastomer)', '0402', 'Kompozit malzeme atıkları (emprenye edilmiş tekstil, elastomer, plastomer)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40216, 'Tehlikeli maddeler içeren boya maddeleri ve pigmentler', NULL, 1, 1, '040216', 402, 1, 'Tehlikeli maddeler içeren boya maddeleri ve pigmentler', '0402', 'Tehlikeli maddeler içeren boya maddeleri ve pigmentler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40221, 'İşlenmemiş tekstil elyafı atıkları', NULL, NULL, 0, '040221', 402, 0, 'Islenmemis tekstil elyafi atiklari', '0402', 'İşlenmemiş tekstil elyafı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '040299', 402, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0402', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50102, 'Tuz arındırma(tuz giderici) çamurları', NULL, 1, 1, '050102', 501, 1, 'Tuz arindirma(tuz giderici) çamurlari', '0501', 'Tuz arındırma(tuz giderici) çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50110, '05 01 09 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '050110', 501, 0, '05 01 09 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0501', '05 01 09 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50114, 'Soğutma kolonlarından kaynaklanan atıklar', NULL, NULL, 0, '050114', 501, 0, 'Sogutma kolonlarindan kaynaklanan atiklar', '0501', 'Soğutma kolonlarından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50116, 'Petrol desülfürizasyonu sonucu oluşan kükürt içeren atıklar', NULL, NULL, 0, '050116', 501, 0, 'Petrol desülfürizasyonu sonucu olusan kükürt içeren atiklar', '0501', 'Petrol desülfürizasyonu sonucu oluşan kükürt içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50604, 'Soğutma kolonlarından kaynaklanan atıklar', NULL, NULL, 0, '050604', 506, 0, 'Sogutma kolonlarindan kaynaklanan atiklar', '0506', 'Soğutma kolonlarından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (6, 'İNORGANİK KİMYASAL İŞLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '06', 0, 0, 'İNORGANIK KIMYASAL ISLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, 'İNORGANİK KİMYASAL İŞLEMLERDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '060299', 602, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0602', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (603, 'Tuzların ve Çözeltilerinin ve Metalik Oksitlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0603', 6, 0, 'Tuzlarin ve Çözeltilerinin ve Metalik Oksitlerin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '06', 'Tuzların ve Çözeltilerinin ve Metalik Oksitlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (605, 'İşletme Sahası İçerisindeki Atıksu Arıtımından Kaynaklanan Çamurlar', NULL, NULL, 1, '0605', 6, 0, 'Isletme Sahasi Içerisindeki Atiksu Aritimindan Kaynaklanan Çamurlar', '06', 'İşletme Sahası İçerisindeki Atıksu Arıtımından Kaynaklanan Çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60503, '06 05 02 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '060503', 605, 0, '06 05 02 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0605', '06 05 02 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60602, 'Tehlikeli kükürt bileşenleri içeren atıklar', NULL, 1, 1, '060602', 606, 1, 'Tehlikeli kükürt bilesenleri içeren atiklar', '0606', 'Tehlikeli kükürt bileşenleri içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130802, 'Diğer emülsiyonlar', NULL, 1, 1, '130802', 1308, 1, 'Diger emülsiyonlar', '1308', 'Diğer emülsiyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130899, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 1, '130899', 1308, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1308', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1406, 'Atık Organik Çözücüler, Soğutucular ve Köpük/Aerosol İtici Gazlar', NULL, NULL, 1, '1406', 14, 0, 'Atik Organik Çözücüler, Sogutucular ve Köpük/Aerosol Itici Gazlar', '14', 'Atık Organik Çözücüler, Soğutucular ve Köpük/Aerosol İtici Gazlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (140601, 'Kloroflorokarbonlar, HCFC, HFC', NULL, 1, 1, '140601', 1406, 1, 'Kloroflorokarbonlar, HCFC, HFC', '1406', 'Kloroflorokarbonlar, HCFC, HFC');
INSERT INTO "e-izin"."atikKodGecici" VALUES (140603, 'Diğer çözücüler ve çözücü karışımları', NULL, 1, 1, '140603', 1406, 1, 'Diger çözücüler ve çözücü karisimlari', '1406', 'Diğer çözücüler ve çözücü karışımları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (140605, 'Diğer çözücüleri içeren çamurlar veya katı atıklar', NULL, 1, 1, '140605', 1406, 1, 'Diger çözücüleri içeren çamurlar veya kati atiklar', '1406', 'Diğer çözücüleri içeren çamurlar veya katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1501, 'Ambalaj (Belediyenin Ayrı Toplanmış Ambalaj Atıkları Dahil)', NULL, NULL, 1, '1501', 15, 0, 'Ambalaj (Belediyenin Ayri Toplanmis Ambalaj Atiklari Dahil)', '15', 'Ambalaj (Belediyenin Ayrı Toplanmış Ambalaj Atıkları Dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150101, 'Kağıt ve karton ambalaj', NULL, NULL, 0, '150101', 1501, 0, 'Kagit ve karton ambalaj', '1501', 'Kağıt ve karton ambalaj');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150102, 'Plastik ambalaj', NULL, NULL, 0, '150102', 1501, 0, 'Plastik ambalaj', '1501', 'Plastik ambalaj');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150103, 'Ahşap ambalaj', NULL, NULL, 0, '150103', 1501, 0, 'Ahsap ambalaj', '1501', 'Ahşap ambalaj');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150104, 'Metalik ambalaj', NULL, NULL, 0, '150104', 1501, 0, 'Metalik ambalaj', '1501', 'Metalik ambalaj');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150107, 'Cam ambalaj', NULL, NULL, 0, '150107', 1501, 0, 'Cam ambalaj', '1501', 'Cam ambalaj');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150111, 'Boş basınçlı konteynırlar dahil olmak üzere tehlikeli gözenekli katı yapılı (örneğin asbest) metalik ambalajlar', NULL, 1, 1, '150111', 1501, 1, 'Bos basinçli konteynirlar dahil olmak üzere tehlikeli gözenekli kati yapili (örnegin asbest) metalik ambalajlar', '1501', 'Boş basınçlı konteynırlar dahil olmak üzere tehlikeli gözenekli katı yapılı (örneğin asbest) metalik ambalajlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (16, 'LİSTEDE BAŞKA BİR ŞEKİLDE BELİRTİLMEMİŞ ATIKLAR', NULL, NULL, 1, '16', 0, 0, 'LISTEDE BASKA BIR SEKILDE BELIRTILMEMIS ATIKLAR', NULL, 'LİSTEDE BAŞKA BİR ŞEKİLDE BELİRTİLMEMİŞ ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160104, 'Ömrünü tamamlamış araçlar', NULL, 2, 1, '160104', 1601, 1, 'Ömrünü tamamlamis araçlar', '1601', 'Ömrünü tamamlamış araçlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101112, '10 11 11 dışındaki atık camlar', NULL, NULL, 0, '101112', 1011, 0, '10 11 11 disindaki atik camlar', '1011', '10 11 11 dışındaki atık camlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160106, 'Sıvı ya da tehlikeli maddeler içermeyen ömrünü tamamlamış araçlar', NULL, 2, 0, '160106', 1601, 0, 'Sivi ya da tehlikeli maddeler içermeyen ömrünü tamamlamis araçlar', '1601', 'Sıvı ya da tehlikeli maddeler içermeyen ömrünü tamamlamış araçlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160107, 'Yağ filtreleri', NULL, 1, 1, '160107', 1601, 1, 'Yag filtreleri', '1601', 'Yağ filtreleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160109, 'PCB içeren parçalar', NULL, 2, 1, '160109', 1601, 1, 'PCB içeren parçalar', '1601', 'PCB içeren parçalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160110, 'Patlayıcı parçalar (örneğin hava yastıkları)', NULL, 1, 1, '160110', 1601, 1, 'Patlayici parçalar (örnegin hava yastiklari)', '1601', 'Patlayıcı parçalar (örneğin hava yastıkları)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160113, 'Fren sıvıları', NULL, 1, 1, '160113', 1601, 1, 'Fren sivilari', '1601', 'Fren sıvıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160115, '16 01 14 dışındaki antifriz sıvıları', NULL, NULL, 0, '160115', 1601, 0, '16 01 14 disindaki antifriz sivilari', '1601', '16 01 14 dışındaki antifriz sıvıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160116, 'Sıvılaştırılmış gaz tankları', NULL, NULL, 0, '160116', 1601, 0, 'Sivilastirilmis gaz tanklari', '1601', 'Sıvılaştırılmış gaz tankları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160117, 'Demir metaller', NULL, NULL, 0, '160117', 1601, 0, 'Demir metaller', '1601', 'Demir metaller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160118, 'Demir olmayan metaller', NULL, NULL, 0, '160118', 1601, 0, 'Demir olmayan metaller', '1601', 'Demir olmayan metaller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160119, 'Plastik', NULL, NULL, 0, '160119', 1601, 0, 'Plastik', '1601', 'Plastik');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160122, 'Başka bir şekilde tanımlanmamış parçalar', NULL, NULL, 0, '160122', 1601, 0, 'Baska bir sekilde tanimlanmamis parçalar', '1601', 'Başka bir şekilde tanımlanmamış parçalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1602, 'Elektrikli ve Elektronik Ekipman Atıkları', NULL, NULL, 1, '1602', 16, 0, 'Elektrikli ve Elektronik Ekipman Atiklari', '16', 'Elektrikli ve Elektronik Ekipman Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160211, 'Kloroflorokarbon, HCFC, HFC içeren ıskarta ekipmanlar', NULL, 1, 1, '160211', 1602, 1, 'Kloroflorokarbon, HCFC, HFC içeren iskarta ekipmanlar', '1602', 'Kloroflorokarbon, HCFC, HFC içeren ıskarta ekipmanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160214, '16 02 09''dan 16 02 13''e kadar olanların dışındaki ıskarta ekipmanlar', NULL, NULL, 0, '160214', 1602, 0, '16 02 09?dan 16 02 13?e kadar olanlarin disindaki iskarta ekipmanlar', '1602', '16 02 09?dan 16 02 13?e kadar olanların dışındaki ıskarta ekipmanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160215, 'Iskarta ekipmanlardan çıkartılmış tehlikeli parçalar', NULL, 1, 1, '160215', 1602, 1, 'Iskarta ekipmanlardan çikartilmis tehlikeli parçalar', '1602', 'Iskarta ekipmanlardan çıkartılmış tehlikeli parçalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160216, '16 02 15 dışındaki ıskarta ekipmanlardan çıkartılmış parçalar', NULL, NULL, 0, '160216', 1602, 0, '16 02 15 disindaki iskarta ekipmanlardan çikartilmis parçalar', '1602', '16 02 15 dışındaki ıskarta ekipmanlardan çıkartılmış parçalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160305, 'Tehlikeli maddeler içeren organik atıklar', NULL, 1, 1, '160305', 1603, 1, 'Tehlikeli maddeler içeren organik atiklar', '1603', 'Tehlikeli maddeler içeren organik atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160306, '16 03 05 dışındaki organik atıklar', NULL, NULL, 0, '160306', 1603, 0, '16 03 05 disindaki organik atiklar', '1603', '16 03 05 dışındaki organik atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160401, 'Mühimmat Atığı', NULL, 1, 1, '160401', 1604, 1, 'Mühimmat Atigi', '1604', 'Mühimmat Atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160402, 'Havai fişek atıkları', NULL, 1, 1, '160402', 1604, 1, 'Havai fisek atiklari', '1604', 'Havai fişek atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1605, 'Basınçlı Tank İçindeki Gazlar ve Iskartaya Çıkmış Kimyasallar', NULL, NULL, 1, '1605', 16, 0, 'Basinçli Tank Içindeki Gazlar ve Iskartaya Çikmis Kimyasallar', '16', 'Basınçlı Tank İçindeki Gazlar ve Iskartaya Çıkmış Kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190211, 'Tehlikeli maddeler içeren diğer atıklar', NULL, 1, 1, '190211', 1902, 1, 'Tehlikeli maddeler içeren diger atiklar', '1902', 'Tehlikeli maddeler içeren diğer atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40214, 'Organik çözücüler içeren perdah atıkları', NULL, 1, 1, '040214', 402, 1, 'Organik çözücüler içeren perdah atiklari', '0402', 'Organik çözücüler içeren perdah atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (501, 'Petrol Rafinasyon Atıkları', NULL, NULL, 1, '0501', 5, 0, 'Petrol Rafinasyon Atiklari', '05', 'Petrol Rafinasyon Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (50109, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli madde içeren çamurlar', NULL, 1, 1, '050109', 501, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli madde içeren çamurlar', '0501', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli madde içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (602, 'Bazların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0602', 6, 0, 'Bazlarin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '06', 'Bazların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60702, 'Klor üretiminden kaynaklanan aktif karbon', NULL, 1, 1, '060702', 607, 1, 'Klor üretiminden kaynaklanan aktif karbon', '0607', 'Klor üretiminden kaynaklanan aktif karbon');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60999, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '060999', 609, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0609', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70111, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '070111', 701, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0701', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70309, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070309', 703, 1, 'Halojenli filtre kekleri ve kullanilmis absorbanlar', '0703', 'Halojenli filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70409, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070409', 704, 1, 'Halojenli filtre kekleri ve kullanilmis absorbanlar', '0704', 'Halojenli filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70699, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '070699', 706, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0706', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70799, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '070799', 707, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0707', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100409, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar', NULL, 1, 1, '100409', 1004, 1, 'Sogutma suyunun aritilmasindan kaynaklanan yag içerikli atiklar', '1004', 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100599, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100599', 1005, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1005', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100610, '10 06 09 dışındaki soğutma suyu arıtma atıkları', NULL, NULL, 0, '100610', 1006, 0, '10 06 09 disindaki sogutma suyu aritma atiklari', '1006', '10 06 09 dışındaki soğutma suyu arıtma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100910, '10 09 09 dışındaki baca gazı tozu', NULL, NULL, 0, '100910', 1009, 0, '10 09 09 disindaki baca gazi tozu', '1009', '10 09 09 dışındaki baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1010, 'Demir Dışı Döküm Atıkları', NULL, NULL, 1, '1010', 10, 0, 'Demir Disi Döküm Atiklari', '10', 'Demir Dışı Döküm Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101011, 'Tehlikeli maddeler içeren diğer partiküller', NULL, 1, 1, '101011', 1010, 1, 'Tehlikeli maddeler içeren diger partiküller', '1010', 'Tehlikeli maddeler içeren diğer partiküller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '080299', 802, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0802', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80318, '08 03 18 dışındaki atık baskı tonerleri', NULL, NULL, 0, '080318', 803, 0, '08 03 18 disindaki atik baski tonerleri', '0803', '08 03 18 dışındaki atık baskı tonerleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80414, '08 04 13 dışındaki sulu organik yapışkan veya dolgu macunu çamurları', NULL, NULL, 0, '080414', 804, 0, '08 04 13 disindaki sulu organik yapiskan veya dolgu macunu çamurlari', '0804', '08 04 13 dışındaki sulu organik yapışkan veya dolgu macunu çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100114, 'Atıkların birlikte yakılmasından (co-incineration) kaynaklanan ve tehlikeli maddeler içeren dip külü, cüruf ve kazan tozu', NULL, 1, 1, '100114', 1001, 1, 'Atiklarin birlikte yakilmasindan (co-incineration) kaynaklanan ve tehlikeli maddeler içeren dip külü, cüruf ve kazan tozu', '1001', 'Atıkların birlikte yakılmasından (co-incineration) kaynaklanan ve tehlikeli maddeler içeren dip külü, cüruf ve kazan tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100324, '10 03 23 dışındaki gaz arıtımı katı atıkları', NULL, NULL, 0, '100324', 1003, 0, '10 03 23 disindaki gaz aritimi kati atiklari', '1003', '10 03 23 dışındaki gaz arıtımı katı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10599, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '010599', 105, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0105', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20109, '02 01 08 dışındaki zirai kimyasal atıkları', NULL, NULL, 0, '020109', 201, 0, '02 01 08 disindaki zirai kimyasal atiklari', '0201', '02 01 08 dışındaki zirai kimyasal atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20301, 'Yıkama, temizleme, soyma, santrifüj ve ayırma işlemlerinden kaynaklanan çamurlar', NULL, NULL, 0, '020301', 203, 0, 'Yikama, temizleme, soyma, santrifüj ve ayirma islemlerinden kaynaklanan çamurlar', '0203', 'Yıkama, temizleme, soyma, santrifüj ve ayırma işlemlerinden kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20603, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '020603', 206, 0, 'Isletme sahasi içerisindeki atik su aritimindan kaynaklanan çamurlar', '0206', 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30309, 'Kireç çamuru atığı', NULL, NULL, 0, '030309', 303, 0, 'Kireç çamuru atigi', '0303', 'Kireç çamuru atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101213, 'Saha içi atık su arıtımından kaynaklanan çamur', NULL, NULL, 0, '101213', 1012, 0, 'Saha içi atik su aritimindan kaynaklanan çamur', '1012', 'Saha içi atık su arıtımından kaynaklanan çamur');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101314, 'Atık beton ve beton çamurları', NULL, NULL, 0, '101314', 1013, 0, 'Atik beton ve beton çamurlari', '1013', 'Atık beton ve beton çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110203, 'Sulu elektrolitik işlemleri için üretilen anot üretim atıkları', NULL, NULL, 0, '110203', 1102, 0, 'Sulu elektrolitik islemleri için üretilen anot üretim atiklari', '1102', 'Sulu elektrolitik işlemleri için üretilen anot üretim atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (202, 'Et, balık ve diğer hayvansal kökenli gıda maddelerinin hazırlanmasından ve işlenmesinden kaynaklanan atıklar', NULL, NULL, 1, '0202', 2, 0, 'Et, balik ve diger hayvansal kökenli gida maddelerinin hazirlanmasindan ve islenmesinden kaynaklanan atiklar', '02', 'Et, balık ve diğer hayvansal kökenli gıda maddelerinin hazırlanmasından ve işlenmesinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '020299', 202, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0202', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160121, '16 01 07''den 16 01 11''e ve 16 01 13 ile 16 01 14 dışındaki tehlikeli parçalar', NULL, 1, 1, '160121', 1601, 1, '16 01 07?den 16 01 11?e ve 16 01 13 ile 16 01 14 disindaki tehlikeli parçalar', '1601', '16 01 07?den 16 01 11?e ve 16 01 13 ile 16 01 14 dışındaki tehlikeli parçalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (203, 'Meyve, sebze, tahıl, yenilebilir yağlar, kakao, kahve, çay ve tütünün hazırlanmasından ve işlenmesinden; konserve üretiminden, maya ve maya özütü üretiminden, molas hazırlanması ve fermantasyonundan kaynaklanan atıklar', NULL, NULL, 1, '0203', 2, 0, 'Meyve, sebze, tahil, yenilebilir yaglar, kakao, kahve, çay ve tütünün hazirlanmasindan ve islenmesinden; konserve üretiminden, maya ve maya özütü üretiminden, molas hazirlanmasi ve fermantasyonundan kaynaklanan atiklar', '02', 'Meyve, sebze, tahıl, yenilebilir yağlar, kakao, kahve, çay ve tütünün hazırlanmasından ve işlenmesinden; konserve üretiminden, maya ve maya özütü üretiminden, molas hazırlanması ve fermantasyonundan kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20499, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '020499', 204, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0204', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20501, 'Tüketime ya da işlenmeye uygun olmayan maddeler', NULL, NULL, 0, '020501', 205, 0, 'Tüketime ya da islenmeye uygun olmayan maddeler', '0205', 'Tüketime ya da işlenmeye uygun olmayan maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (206, 'Unlu mamuller ve şekerleme endüstrisinden kaynaklanan atıklar', NULL, NULL, 1, '0206', 2, 0, 'Unlu mamuller ve sekerleme endüstrisinden kaynaklanan atiklar', '02', 'Unlu mamuller ve şekerleme endüstrisinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (207, 'Alkollü ve alkolsüz içeceklerin (kahve, çay ve kakao hariç) üretiminden kaynaklanan atıklar', NULL, NULL, 1, '0207', 2, 0, 'Alkollü ve alkolsüz içeceklerin (kahve, çay ve kakao hariç) üretiminden kaynaklanan atiklar', '02', 'Alkollü ve alkolsüz içeceklerin (kahve, çay ve kakao hariç) üretiminden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20702, 'Alkol damıtılmasından kaynaklanan atıklar', NULL, NULL, 0, '020702', 207, 0, 'Alkol damitilmasindan kaynaklanan atiklar', '0207', 'Alkol damıtılmasından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20705, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '020705', 207, 0, 'Isletme sahasi içerisindeki atik su aritimindan kaynaklanan çamurlar', '0207', 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (3, 'AHŞAP İŞLEME VE KAĞIT, KARTON, KAĞIT HAMURU, PANEL(SUNTA) VE MOBİLYA ÜRETİMİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '03', 0, 0, 'AHSAP ISLEME VE KAGIT, KARTON, KAGIT HAMURU, PANEL(SUNTA) VE MOBILYA ÜRETIMINDEN KAYNAKLANAN ATIKLAR', NULL, 'AHŞAP İŞLEME VE KAĞIT, KARTON, KAĞIT HAMURU, PANEL(SUNTA) VE MOBİLYA ÜRETİMİNDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30202, 'Organoklorlu ahşap koruyucu maddeler', NULL, 1, 1, '030202', 302, 1, 'Organoklorlu ahsap koruyucu maddeler', '0302', 'Organoklorlu ahşap koruyucu maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30299, 'Başka bir şekilde tanımlanmamış ahşap koruyucuları', NULL, NULL, 0, '030299', 302, 0, 'Baska bir sekilde tanimlanmamis ahsap koruyuculari', '0302', 'Başka bir şekilde tanımlanmamış ahşap koruyucuları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30301, 'Ağaç kabuğu ve odun atıkları', NULL, NULL, 0, '030301', 303, 0, 'Agaç kabugu ve odun atiklari', '0303', 'Ağaç kabuğu ve odun atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30305, 'Kağıt geri kazanım işleminden kaynaklanan mürekkep giderme çamurları', NULL, NULL, 0, '030305', 303, 0, 'Kagit geri kazanim isleminden kaynaklanan mürekkep giderme çamurlari', '0303', 'Kağıt geri kazanım işleminden kaynaklanan mürekkep giderme çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30308, 'Geri dönüşüm amaçlı kağıt ve kartonun ayrıştırılmasından kaynaklanan atıklar', NULL, NULL, 0, '030308', 303, 0, 'Geri dönüsüm amaçli kagit ve kartonun ayristirilmasindan kaynaklanan atiklar', '0303', 'Geri dönüşüm amaçlı kağıt ve kartonun ayrıştırılmasından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (4, 'DERİ, KÜRK VE TEKSTİL ENDÜSTRİLERİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '04', 0, 0, 'DERI, KÜRK VE TEKSTIL ENDÜSTRILERINDEN KAYNAKLANAN ATIKLAR', NULL, 'DERİ, KÜRK VE TEKSTİL ENDÜSTRİLERİNDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101208, 'Atık seramikler, tuğlalar, fayanslar ve inşaat malzemeleri (ısıl işlem sonrası)', NULL, NULL, 0, '101208', 1012, 0, 'Atik seramikler, tuglalar, fayanslar ve insaat malzemeleri (isil islem sonrasi)', '1012', 'Atık seramikler, tuğlalar, fayanslar ve inşaat malzemeleri (ısıl işlem sonrası)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101211, 'Ağır metaller içeren sırlama atıkları', NULL, 1, 1, '101211', 1012, 1, 'Agir metaller içeren sirlama atiklari', '1012', 'Ağır metaller içeren sırlama atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1013, 'Çimento, Kireç ve Alçı ve Bunlardan Yapılan Ürünlerin Üretim Atıkları', NULL, NULL, 1, '1013', 10, 0, 'Çimento, Kireç ve Alçi ve Bunlardan Yapilan Ürünlerin Üretim Atiklari', '10', 'Çimento, Kireç ve Alçı ve Bunlardan Yapılan Ürünlerin Üretim Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101307, 'Gaz arıtma çamuru ve filtre kekleri', NULL, NULL, 0, '101307', 1013, 0, 'Gaz aritma çamuru ve filtre kekleri', '1013', 'Gaz arıtma çamuru ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101310, '10 13 09 dışındaki asbestli çimento üretimi atıkları', NULL, NULL, 0, '101310', 1013, 0, '10 13 09 disindaki asbestli çimento üretimi atiklari', '1013', '10 13 09 dışındaki asbestli çimento üretimi atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101312, 'Gaz arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar', NULL, 1, 1, '101312', 1013, 1, 'Gaz aritimindan kaynaklanan tehlikeli maddeler içeren kati atiklar', '1013', 'Gaz arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (11, 'METAL VE DİĞER MALZEMELERİN KİMYASAL YÜZEY İŞLEMİ VE KAPLANMASI İŞLEMLERİNDEN KAYNAKLANAN ATIKLAR; DEMİR DIŞI HİDROMETALURJİ', NULL, NULL, 1, '11', 0, 0, 'METAL VE DIGER MALZEMELERIN KIMYASAL YÜZEY ISLEMI VE KAPLANMASI ISLEMLERINDEN KAYNAKLANAN ATIKLAR; DEMIR DISI HIDROMETALURJI', NULL, 'METAL VE DİĞER MALZEMELERİN KİMYASAL YÜZEY İŞLEMİ VE KAPLANMASI İŞLEMLERİNDEN KAYNAKLANAN ATIKLAR; DEMİR DIŞI HİDROMETALURJİ');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1101, 'Metal ve Diğer Malzemelerin Kimyasal Yüzey İşlemi ve Kaplanmasından Kaynaklanan Atıklar (Örn: Galvanizleme, Çinko Kaplama, Dekapaj, Asitle Sıyırma, Fosfatlama, Alkalin Degradasyonu, Anotlama)', NULL, NULL, 1, '1101', 11, 0, 'Metal ve Diger Malzemelerin Kimyasal Yüzey Islemi ve Kaplanmasindan Kaynaklanan Atiklar (Örn: Galvanizleme, Çinko Kaplama, Dekapaj, Asitle Siyirma, Fosfatlama, Alkalin Degradasyonu, Anotlama)', '11', 'Metal ve Diğer Malzemelerin Kimyasal Yüzey İşlemi ve Kaplanmasından Kaynaklanan Atıklar (Örn: Galvanizleme, Çinko Kaplama, Dekapaj, Asitle Sıyırma, Fosfatlama, Alkalin Degradasyonu, Anotlama)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '110199', 1101, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1101', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110202, 'Çinko hidrometalürjisi (jarosid ve goetid dahil) çamurları', NULL, 1, 1, '110202', 1102, 1, 'Çinko hidrometalürjisi (jarosid ve goetid dahil) çamurlari', '1102', 'Çinko hidrometalürjisi (jarosid ve goetid dahil) çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110206, '11 02 05 dışındaki bakır hidrometalürjisi atıkları', NULL, NULL, 0, '110206', 1102, 0, '11 02 05 disindaki bakir hidrometalürjisi atiklari', '1102', '11 02 05 dışındaki bakır hidrometalürjisi atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1105, 'Sıcak Galvanizleme İşlemleri Atıkları', NULL, NULL, 1, '1105', 11, 0, 'Sicak Galvanizleme Islemleri Atiklari', '11', 'Sıcak Galvanizleme İşlemleri Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110504, 'Iskarta flaks malzemeler', NULL, 1, 1, '110504', 1105, 1, 'Iskarta flaks malzemeler', '1105', 'Iskarta flaks malzemeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160209, 'PCB''ler içeren transformatörler ve kapasitörler', NULL, 2, 1, '160209', 1602, 1, 'PCB?ler içeren transformatörler ve kapasitörler', '1602', 'PCB?ler içeren transformatörler ve kapasitörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (12, 'METALLERİN VE PLASTİKLERİN FİZİKİ VE MEKANİK YÜZEY İŞLEMLERİNDEN VE ŞEKİLLENDİRİLMESİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '12', 0, 0, 'METALLERIN VE PLASTIKLERIN FIZIKI VE MEKANIK YÜZEY ISLEMLERINDEN VE SEKILLENDIRILMESINDEN KAYNAKLANAN ATIKLAR', NULL, 'METALLERİN VE PLASTİKLERİN FİZİKİ VE MEKANİK YÜZEY İŞLEMLERİNDEN VE ŞEKİLLENDİRİLMESİNDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120106, 'Halojen içeren madeni bazlı işleme yağları (emülsiyon ve solüsyonlar hariç)', 1, 2, 1, '120106', 1201, 1, 'Halojen içeren madeni bazli isleme yaglari (emülsiyon ve solüsyonlar hariç)', '1201', 'Halojen içeren madeni bazlı işleme yağları (emülsiyon ve solüsyonlar hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120109, 'Halojen içermeyen işleme emülsiyon ve solüsyonları', NULL, 1, 1, '120109', 1201, 1, 'Halojen içermeyen isleme emülsiyon ve solüsyonlari', '1201', 'Halojen içermeyen işleme emülsiyon ve solüsyonları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120115, '12 01 14 dışındaki işleme çamurları', NULL, NULL, 0, '120115', 1201, 0, '12 01 14 disindaki isleme çamurlari', '1201', '12 01 14 dışındaki işleme çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120117, '12 01 16 dışındaki kumlama maddeleri atıkları', NULL, NULL, 0, '120117', 1201, 0, '12 01 16 disindaki kumlama maddeleri atiklari', '1201', '12 01 16 dışındaki kumlama maddeleri atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120121, '12 01 20 dışındaki öğütme parçaları ve öğütme maddeleri', NULL, NULL, 0, '120121', 1201, 0, '12 01 20 disindaki ögütme parçalari ve ögütme maddeleri', '1201', '12 01 20 dışındaki öğütme parçaları ve öğütme maddeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (13, 'YAĞ ATIKLARI VE SIVI YAKIT ATIKLARI (YENİLEBİLİR YAĞLAR, 05 VE 12 HARİÇ)', NULL, NULL, 1, '13', 0, 0, 'YAG ATIKLARI VE SIVI YAKIT ATIKLARI (YENILEBILIR YAGLAR, 05 VE 12 HARIÇ)', NULL, 'YAĞ ATIKLARI VE SIVI YAKIT ATIKLARI (YENİLEBİLİR YAĞLAR, 05 VE 12 HARİÇ)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130109, 'Mineral esaslı klor içeren hidrolik yağlar', 1, 2, 1, '130109', 1301, 1, 'Mineral esasli klor içeren hidrolik yaglar', '1301', 'Mineral esaslı klor içeren hidrolik yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130204, 'Mineral esaslı klor içeren motor, şanzıman ve yağlama yağları', 1, 2, 1, '130204', 1302, 1, 'Mineral esasli klor içeren motor, sanziman ve yaglama yaglari', '1302', 'Mineral esaslı klor içeren motor, şanzıman ve yağlama yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130206, 'Sentetik motor, şanzıman ve yağlama yağları', 1, 2, 1, '130206', 1302, 1, 'Sentetik motor, sanziman ve yaglama yaglari', '1302', 'Sentetik motor, şanzıman ve yağlama yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130301, 'PCB''ler içeren yalıtım ya da ısı iletim yağları', 1, 2, 1, '130301', 1303, 1, 'PCB?ler içeren yalitim ya da isi iletim yaglari', '1303', 'PCB?ler içeren yalıtım ya da ısı iletim yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130307, 'Mineral esaslı klor içermeyen yalıtım ve ısı iletim yağları', 1, 2, 1, '130307', 1303, 1, 'Mineral esasli klor içermeyen yalitim ve isi iletim yaglari', '1303', 'Mineral esaslı klor içermeyen yalıtım ve ısı iletim yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130310, 'Diğer yalıtım ve ısı iletim yağları', 1, 2, 1, '130310', 1303, 1, 'Diger yalitim ve isi iletim yaglari', '1303', 'Diğer yalıtım ve ısı iletim yağları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1305, 'Yağ/Su Ayırıcısı İçerikleri', NULL, NULL, 1, '1305', 13, 0, 'Yag/Su Ayiricisi Içerikleri', '13', 'Yağ/Su Ayırıcısı İçerikleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130502, 'Yağ/su ayırıcısından çıkan çamurlar', NULL, 1, 1, '130502', 1305, 1, 'Yag/su ayiricisindan çikan çamurlar', '1305', 'Yağ/su ayırıcısından çıkan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130507, 'Yağ/su ayırıcılarından çıkan yağlı su', NULL, 1, 1, '130507', 1305, 1, 'Yag/su ayiricilarindan çikan yagli su', '1305', 'Yağ/su ayırıcılarından çıkan yağlı su');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190501, 'Belediye ve benzeri atıklarının kompostlanmamış fraksiyonları', NULL, NULL, 0, '190501', 1905, 0, 'Belediye ve benzeri atiklarinin kompostlanmamis fraksiyonlari', '1905', 'Belediye ve benzeri atıklarının kompostlanmamış fraksiyonları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190903, 'Karbonat gidermeden kaynaklanan çamurlar', NULL, NULL, 0, '190903', 1909, 0, 'Karbonat gidermeden kaynaklanan çamurlar', '1909', 'Karbonat gidermeden kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1912, 'Başka Bir Şekilde Tanımlanmamış Atıkların Mekanik Arıtımından (Örneğin Ayrıştırılması, Ezilmesi, Sıkıştırılması, Topak Haline Getirilmesi) Kaynaklanan Atıklar', NULL, NULL, 1, '1912', 19, 0, 'Baska Bir Sekilde Tanimlanmamis Atiklarin Mekanik Aritimindan (Örnegin Ayristirilmasi, Ezilmesi, Sikistirilmasi, Topak Haline Getirilmesi) Kaynaklanan Atiklar', '19', 'Başka Bir Şekilde Tanımlanmamış Atıkların Mekanik Arıtımından (Örneğin Ayrıştırılması, Ezilmesi, Sıkıştırılması, Topak Haline Getirilmesi) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130801, 'Tuz giderim çamurları ya da emülsiyonları', NULL, 1, 1, '130801', 1308, 1, 'Tuz giderim çamurlari ya da emülsiyonlari', '1308', 'Tuz giderim çamurları ya da emülsiyonları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (14, 'ATIK ORGANİK ÇÖZÜCÜLER, SOĞUTUCULAR VE İTİCİ GAZLAR (07 VE 08 HARİÇ)', NULL, NULL, 1, '14', 0, 0, 'ATIK ORGANIK ÇÖZÜCÜLER, SOGUTUCULAR VE ITICI GAZLAR (07 VE 08 HARIÇ)', NULL, 'ATIK ORGANİK ÇÖZÜCÜLER, SOĞUTUCULAR VE İTİCİ GAZLAR (07 VE 08 HARİÇ)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (140602, 'Diğer halojenli çözücüler ve çözücü karışımları', NULL, 1, 1, '140602', 1406, 1, 'Diger halojenli çözücüler ve çözücü karisimlari', '1406', 'Diğer halojenli çözücüler ve çözücü karışımları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (15, 'ATIK AMBALAJLAR; BAŞKA BİR ŞEKİLDE BELİRTİLMEMİŞ EMİCİLER, SİLME BEZLERİ, FİLTRE MALZEMELERİ VE KORUYUCU GİYSİLER', NULL, NULL, 1, '15', 0, 0, 'ATIK AMBALAJLAR; BASKA BIR SEKILDE BELIRTILMEMIS EMICILER, SILME BEZLERI, FILTRE MALZEMELERI VE KORUYUCU GIYSILER', NULL, 'ATIK AMBALAJLAR; BAŞKA BİR ŞEKİLDE BELİRTİLMEMİŞ EMİCİLER, SİLME BEZLERİ, FİLTRE MALZEMELERİ VE KORUYUCU GİYSİLER');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150106, 'Karışık ambalaj', NULL, NULL, 0, '150106', 1501, 0, 'Karisik ambalaj', '1501', 'Karışık ambalaj');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150110, 'Tehlikeli maddelerin kalıntılarını içeren ya da tehlikeli maddelerle kontamine olmuş ambalajlar', NULL, 1, 1, '150110', 1501, 1, 'Tehlikeli maddelerin kalintilarini içeren ya da tehlikeli maddelerle kontamine olmus ambalajlar', '1501', 'Tehlikeli maddelerin kalıntılarını içeren ya da tehlikeli maddelerle kontamine olmuş ambalajlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150202, 'Tehlikeli maddelerle kirlenmiş emiciler, filtre malzemeleri (başka şekilde tanımlanmamış ise yağ filtreleri), temizleme bezleri, koruyucu giysiler', NULL, 1, 1, '150202', 1502, 1, 'Tehlikeli maddelerle kirlenmis emiciler, filtre malzemeleri (baska sekilde tanimlanmamis ise yag filtreleri), temizleme bezleri, koruyucu giysiler', '1502', 'Tehlikeli maddelerle kirlenmiş emiciler, filtre malzemeleri (başka şekilde tanımlanmamış ise yağ filtreleri), temizleme bezleri, koruyucu giysiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1601, 'Çeşitli Taşıma Türlerindeki (İş Makineleri Dahil) Ömrünü Tamamlamış Araçlar ve Ömrünü Tamamlamış Araçların Sökülmesi ile Araç Bakımından (13, 14, 16 06 ve 16 08 hariç) Kaynaklanan Atıklar', NULL, NULL, 1, '1601', 16, 0, 'Çesitli Tasima Türlerindeki (Is Makineleri Dahil) Ömrünü Tamamlamis Araçlar ve Ömrünü Tamamlamis Araçlarin Sökülmesi ile Araç Bakimindan (13, 14, 16 06 ve 16 08 hariç) Kaynaklanan Atiklar', '16', 'Çeşitli Taşıma Türlerindeki (İş Makineleri Dahil) Ömrünü Tamamlamış Araçlar ve Ömrünü Tamamlamış Araçların Sökülmesi ile Araç Bakımından (13, 14, 16 06 ve 16 08 hariç) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170505, 'Tehlikeli maddeler içeren dip tarama çamuru', NULL, 1, 1, '170505', 1705, 1, 'Tehlikeli maddeler içeren dip tarama çamuru', '1705', 'Tehlikeli maddeler içeren dip tarama çamuru');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160213, '16 02 09''dan 16 02 12''ye kadar olanların dışındaki tehlikeli parçalar2 içeren ıskarta ekipmanlar', NULL, 1, 1, '160213', 1602, 1, '16 02 09?dan 16 02 12?ye kadar olanlarin disindaki tehlikeli parçalar2 içeren iskarta ekipmanlar', '1602', '16 02 09?dan 16 02 12?ye kadar olanların dışındaki tehlikeli parçalar2 içeren ıskarta ekipmanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160507, 'Tehlikeli maddeler içeren ya da bunlardan oluşan ıskarta inorganik kimyasallar', NULL, 1, 1, '160507', 1605, 1, 'Tehlikeli maddeler içeren ya da bunlardan olusan iskarta inorganik kimyasallar', '1605', 'Tehlikeli maddeler içeren ya da bunlardan oluşan ıskarta inorganik kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1606, 'Piller ve Aküler', NULL, NULL, 1, '1606', 16, 0, 'Piller ve Aküler', '16', 'Piller ve Aküler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160602, 'Nikel kadmiyum piller', NULL, 2, 1, '160602', 1606, 1, 'Nikel kadmiyum piller', '1606', 'Nikel kadmiyum piller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160604, 'Alkali piller (16 06 03 hariç)', NULL, 2, 0, '160604', 1606, 0, 'Alkali piller (16 06 03 hariç)', '1606', 'Alkali piller (16 06 03 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160605, 'Diğer piller ve akümülatörler', NULL, 2, 0, '160605', 1606, 0, 'Diger piller ve akümülatörler', '1606', 'Diğer piller ve akümülatörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160606, 'Piller ve akümülatörlerden ayrı toplanmış elektrolitler', NULL, 2, 1, '160606', 1606, 1, 'Piller ve akümülatörlerden ayri toplanmis elektrolitler', '1606', 'Piller ve akümülatörlerden ayrı toplanmış elektrolitler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160708, 'Yağ içeren atıklar', NULL, 1, 1, '160708', 1607, 1, 'Yag içeren atiklar', '1607', 'Yağ içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160709, 'Diğer tehlikeli maddeler içeren atıklar', NULL, 1, 1, '160709', 1607, 1, 'Diger tehlikeli maddeler içeren atiklar', '1607', 'Diğer tehlikeli maddeler içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160799, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '160799', 1607, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1607', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1608, 'Bitik Katalizörler', NULL, NULL, 1, '1608', 16, 0, 'Bitik Katalizörler', '16', 'Bitik Katalizörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160802, 'Tehlikeli geçiş metalleri3 ya da tehlikeli geçiş metal bileşenlerini içeren bitik katalizörler', NULL, 1, 1, '160802', 1608, 1, 'Tehlikeli geçis metalleri3 ya da tehlikeli geçis metal bilesenlerini içeren bitik katalizörler', '1608', 'Tehlikeli geçiş metalleri3 ya da tehlikeli geçiş metal bileşenlerini içeren bitik katalizörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160804, 'Bitik katalitik ?cracking? katalizör sıvısı (16 08 07 hariç)', NULL, NULL, 0, '160804', 1608, 0, 'Bitik katalitik ?cracking? katalizör sivisi (16 08 07 hariç)', '1608', 'Bitik katalitik ?cracking? katalizör sıvısı (16 08 07 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160805, 'Fosforik asit içeren bitik katalizörler', NULL, 1, 1, '160805', 1608, 1, 'Fosforik asit içeren bitik katalizörler', '1608', 'Fosforik asit içeren bitik katalizörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1609, 'Oksitleyici Maddeler', NULL, NULL, 1, '1609', 16, 0, 'Oksitleyici Maddeler', '16', 'Oksitleyici Maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160901, 'Permanganatlar (örneğin potasyum permanganat)', NULL, 1, 1, '160901', 1609, 1, 'Permanganatlar (örnegin potasyum permanganat)', '1609', 'Permanganatlar (örneğin potasyum permanganat)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160904, 'Başka bir şekilde tanımlanmamış oksitleyici malzemeler', NULL, 1, 1, '160904', 1609, 1, 'Baska bir sekilde tanimlanmamis oksitleyici malzemeler', '1609', 'Başka bir şekilde tanımlanmamış oksitleyici malzemeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161002, '16 10 01 dışındaki sulu sıvı atıklar', NULL, NULL, 0, '161002', 1610, 0, '16 10 01 disindaki sulu sivi atiklar', '1610', '16 10 01 dışındaki sulu sıvı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180208, '18 02 07 dışındaki ilaçlar', NULL, NULL, 0, '180208', 1802, 0, '18 02 07 disindaki ilaçlar', '1802', '18 02 07 dışındaki ilaçlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161003, 'Tehlikeli madde içeren sulu derişik maddeler', NULL, 1, 1, '161003', 1610, 1, 'Tehlikeli madde içeren sulu derisik maddeler', '1610', 'Tehlikeli madde içeren sulu derişik maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161102, '16 11 01 dışındaki metalürjik proseslerden kaynaklanan karbon bazlı astar ve refraktörler', NULL, NULL, 0, '161102', 1611, 0, '16 11 01 disindaki metalürjik proseslerden kaynaklanan karbon bazli astar ve refraktörler', '1611', '16 11 01 dışındaki metalürjik proseslerden kaynaklanan karbon bazlı astar ve refraktörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161103, 'Metalürjik proseslerden kaynaklanan, tehlikeli maddeler içeren diğer astarlar ve refraktörler', NULL, 1, 1, '161103', 1611, 1, 'Metalürjik proseslerden kaynaklanan, tehlikeli maddeler içeren diger astarlar ve refraktörler', '1611', 'Metalürjik proseslerden kaynaklanan, tehlikeli maddeler içeren diğer astarlar ve refraktörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (17, 'İNŞAAT VE YIKINTI ATIKLARI (KİRLENMİŞ ALANLARDAN ÇIKARTILAN HAFRİYAT DAHİL)', NULL, NULL, 1, '17', 0, 0, 'INSAAT VE YIKINTI ATIKLARI (KIRLENMIS ALANLARDAN ÇIKARTILAN HAFRIYAT DAHIL)', NULL, 'İNŞAAT VE YIKINTI ATIKLARI (KİRLENMİŞ ALANLARDAN ÇIKARTILAN HAFRİYAT DAHİL)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170101, 'Beton', NULL, NULL, 0, '170101', 1701, 0, 'Beton', '1701', 'Beton');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170103, 'Kiremitler ve seramikler', NULL, NULL, 0, '170103', 1701, 0, 'Kiremitler ve seramikler', '1701', 'Kiremitler ve seramikler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170107, '17 01 06 dışındaki beton, tuğla kiremit ve seramik karışımları ya da ayrılmış grupları', NULL, NULL, 0, '170107', 1701, 0, '17 01 06 disindaki beton, tugla kiremit ve seramik karisimlari ya da ayrilmis gruplari', '1701', '17 01 06 dışındaki beton, tuğla kiremit ve seramik karışımları ya da ayrılmış grupları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1702, 'Ahşap, Cam ve Plastik', NULL, NULL, 1, '1702', 17, 0, 'Ahsap, Cam ve Plastik', '17', 'Ahşap, Cam ve Plastik');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170202, 'Cam', NULL, NULL, 0, '170202', 1702, 0, 'Cam', '1702', 'Cam');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170203, 'Plastik', NULL, NULL, 0, '170203', 1702, 0, 'Plastik', '1702', 'Plastik');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1703, 'Bitümlü Karışımlar, Kömür Katranı ve Katranlı Ürünler', NULL, NULL, 1, '1703', 17, 0, 'Bitümlü Karisimlar, Kömür Katrani ve Katranli Ürünler', '17', 'Bitümlü Karışımlar, Kömür Katranı ve Katranlı Ürünler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170302, '17 03 01 dışındaki bitümlü karışımlar', NULL, NULL, 0, '170302', 1703, 0, '17 03 01 disindaki bitümlü karisimlar', '1703', '17 03 01 dışındaki bitümlü karışımlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1704, 'Metaller (Alaşımları Dahil)', NULL, NULL, 1, '1704', 17, 0, 'Metaller (Alasimlari Dahil)', '17', 'Metaller (Alaşımları Dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170401, 'Bakır, bronz, pirinç', NULL, NULL, 0, '170401', 1704, 0, 'Bakir, bronz, pirinç', '1704', 'Bakır, bronz, pirinç');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170402, 'Alüminyum', NULL, NULL, 0, '170402', 1704, 0, 'Alüminyum', '1704', 'Alüminyum');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170403, 'Kurşun', NULL, NULL, 0, '170403', 1704, 0, 'Kursun', '1704', 'Kurşun');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170404, 'Çinko', NULL, NULL, 0, '170404', 1704, 0, 'Çinko', '1704', 'Çinko');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170407, 'Karışık metaller', NULL, NULL, 0, '170407', 1704, 0, 'Karisik metaller', '1704', 'Karışık metaller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170410, 'Yağ, katran ve diğer tehlikeli maddeler içeren kablolar', NULL, 1, 1, '170410', 1704, 1, 'Yag, katran ve diger tehlikeli maddeler içeren kablolar', '1704', 'Yağ, katran ve diğer tehlikeli maddeler içeren kablolar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170503, 'Tehlikeli maddeler içeren toprak ve kayalar', NULL, 1, 1, '170503', 1705, 1, 'Tehlikeli maddeler içeren toprak ve kayalar', '1705', 'Tehlikeli maddeler içeren toprak ve kayalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170504, '17 05 03 dışındaki toprak ve kayalar', NULL, NULL, 0, '170504', 1705, 0, '17 05 03 disindaki toprak ve kayalar', '1705', '17 05 03 dışındaki toprak ve kayalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170506, '17 05 05 dışındaki dip tarama çamuru', NULL, NULL, 0, '170506', 1705, 0, '17 05 05 disindaki dip tarama çamuru', '1705', '17 05 05 dışındaki dip tarama çamuru');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170603, 'Tehlikeli maddelerden oluşan ya da tehlikeli maddeler içeren diğer yalıtım malzemeleri', NULL, 1, 1, '170603', 1706, 1, 'Tehlikeli maddelerden olusan ya da tehlikeli maddeler içeren diger yalitim malzemeleri', '1706', 'Tehlikeli maddelerden oluşan ya da tehlikeli maddeler içeren diğer yalıtım malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170802, '17 08 01 dışındaki alçı bazlı inşaat malzemeleri', NULL, NULL, 0, '170802', 1708, 0, '17 08 01 disindaki alçi bazli insaat malzemeleri', '1708', '17 08 01 dışındaki alçı bazlı inşaat malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170901, 'Cıva içeren inşaat ve yıkım atıkları', NULL, 1, 1, '170901', 1709, 1, 'Civa içeren insaat ve yikinti atiklari', '1709', 'Cıva içeren inşaat ve yıkıntı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170903, 'Tehlikeli maddeler içeren diğer inşaat ve yıkıntı atıkları (karışık atıklar dahil)', NULL, 1, 1, '170903', 1709, 1, 'Tehlikeli maddeler içeren diger insaat ve yikinti atiklari (karisik atiklar dahil)', '1709', 'Tehlikeli maddeler içeren diğer inşaat ve yıkıntı atıkları (karışık atıklar dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (18, 'İNSAN VE HAYVAN SAĞLIĞI VE/VEYA BU KONULARDAKİ ARAŞTIRMALARDAN KAYNAKLANAN ATIKLAR (DOĞRUDAN SAĞLIĞA İLİŞKİN OLMAYAN MUTFAK VE RESTORAN ATIKLARI HARİÇ)', NULL, NULL, 1, '18', 0, 0, 'INSAN VE HAYVAN SAGLIGI VE/VEYA BU KONULARDAKI ARASTIRMALARDAN KAYNAKLANAN ATIKLAR (DOGRUDAN SAGLIGA ILISKIN OLMAYAN MUTFAK VE RESTORAN ATIKLARI HARIÇ)', NULL, 'İNSAN VE HAYVAN SAĞLIĞI VE/VEYA BU KONULARDAKİ ARAŞTIRMALARDAN KAYNAKLANAN ATIKLAR (DOĞRUDAN SAĞLIĞA İLİŞKİN OLMAYAN MUTFAK VE RESTORAN ATIKLARI HARİÇ)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180101, 'Kesiciler (18 01 03 hariç)', NULL, 2, 0, '180101', 1801, 0, 'Kesiciler (18 01 03 hariç)', '1801', 'Kesiciler (18 01 03 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180102, 'Kan torbaları ve kan yedekleri dahil vücut parçaları ve organları (18 01 03 hariç)', NULL, 2, 0, '180102', 1801, 0, 'Kan torbalari ve kan yedekleri dahil vücut parçalari ve organlari (18 01 03 hariç)', '1801', 'Kan torbaları ve kan yedekleri dahil vücut parçaları ve organları (18 01 03 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180106, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerden oluşan kimyasallar', NULL, 1, 1, '180106', 1801, 1, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerden olusan kimyasallar', '1801', 'Tehlikeli maddeler içeren ya da tehlikeli maddelerden oluşan kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180107, '18 01 06 dışındaki kimyasallar', NULL, NULL, 0, '180107', 1801, 0, '18 01 06 disindaki kimyasallar', '1801', '18 01 06 dışındaki kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180108, 'Sitotoksik ve sitostatik ilaçlar', NULL, 1, 1, '180108', 1801, 1, 'Sitotoksik ve sitostatik ilaçlar', '1801', 'Sitotoksik ve sitostatik ilaçlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180109, '18 01 08 dışındaki ilaçlar', NULL, NULL, 0, '180109', 1801, 0, '18 01 08 disindaki ilaçlar', '1801', '18 01 08 dışındaki ilaçlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180110, 'Diş tedavisinden kaynaklanan amalgam atıkları', NULL, 1, 1, '180110', 1801, 1, 'Dis tedavisinden kaynaklanan amalgam atiklari', '1801', 'Diş tedavisinden kaynaklanan amalgam atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180203, 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olmayan atıklar', NULL, NULL, 0, '180203', 1802, 0, 'Enfeksiyonu önlemek amaci ile toplanmalari ve bertarafi özel isleme tabi olmayan atiklar', '1802', 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olmayan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180206, '18 02 05 dışındaki kimyasallar', NULL, NULL, 0, '180206', 1802, 0, '18 02 05 disindaki kimyasallar', '1802', '18 02 05 dışındaki kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1901, 'Atık Yakma veya Piroliz?den Kaynaklanan Atıklar', NULL, NULL, 1, '1901', 19, 0, 'Atik Yakma veya Piroliz?den Kaynaklanan Atiklar', '19', 'Atık Yakma veya Piroliz?den Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190102, 'Taban külünden ayrılan demir içerikli maddeler', NULL, NULL, 0, '190102', 1901, 0, 'Taban külünden ayrilan demir içerikli maddeler', '1901', 'Taban külünden ayrılan demir içerikli maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190105, 'Gaz arıtımından kaynaklanan filtre kekleri', NULL, 1, 1, '190105', 1901, 1, 'Gaz aritimindan kaynaklanan filtre kekleri', '1901', 'Gaz arıtımından kaynaklanan filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190106, 'Gaz arıtımından kaynaklanan sulu sıvı atıklar ile diğer sulu sıvı atıkları', NULL, 1, 1, '190106', 1901, 1, 'Gaz aritimindan kaynaklanan sulu sivi atiklar ile diger sulu sivi atiklari', '1901', 'Gaz arıtımından kaynaklanan sulu sıvı atıklar ile diğer sulu sıvı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190110, 'Baca gazı arıtımından kaynaklanan kullanılmış aktif karbon', NULL, 1, 1, '190110', 1901, 1, 'Baca gazi aritimindan kaynaklanan kullanilmis aktif karbon', '1901', 'Baca gazı arıtımından kaynaklanan kullanılmış aktif karbon');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190113, 'Tehlikeli maddeler içeren uçucu kül', NULL, 1, 1, '190113', 1901, 1, 'Tehlikeli maddeler içeren uçucu kül', '1901', 'Tehlikeli maddeler içeren uçucu kül');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190114, '19 01 13 dışındaki uçucu kül', NULL, NULL, 0, '190114', 1901, 0, '19 01 13 disindaki uçucu kül', '1901', '19 01 13 dışındaki uçucu kül');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190116, '19 01 15 dışındaki kazan tozu', NULL, NULL, 0, '190116', 1901, 0, '19 01 15 disindaki kazan tozu', '1901', '19 01 15 dışındaki kazan tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190118, '19 01 17 dışındaki piroliz atıkları', NULL, NULL, 0, '190118', 1901, 0, '19 01 17 disindaki piroliz atiklari', '1901', '19 01 17 dışındaki piroliz atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '190199', 1901, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1901', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190204, 'En az bir tehlikeli atık ile önceden karıştırılması ile oluşmuş atıklar', NULL, 1, 1, '190204', 1902, 1, 'En az bir tehlikeli atik ile önceden karistirilmasi ile olusmus atiklar', '1902', 'En az bir tehlikeli atık ile önceden karıştırılması ile oluşmuş atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190208, 'Tehlikeli maddeler içeren sıvı yanabilir atıklar', NULL, 1, 1, '190208', 1902, 1, 'Tehlikeli maddeler içeren sivi yanabilir atiklar', '1902', 'Tehlikeli maddeler içeren sıvı yanabilir atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190209, 'Tehlikeli maddeler içeren katı yanabilir atıklar', NULL, 1, 1, '190209', 1902, 1, 'Tehlikeli maddeler içeren kati yanabilir atiklar', '1902', 'Tehlikeli maddeler içeren katı yanabilir atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190210, '19 02 08 ve 19 02 09 dışında yanabilir atıklar', NULL, NULL, 0, '190210', 1902, 0, '19 02 08 ve 19 02 09 disinda yanabilir atiklar', '1902', '19 02 08 ve 19 02 09 dışında yanabilir atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '190299', 1902, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1902', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190306, 'Tehlikeli olarak sınıflandırılmış, katılaştırılmış atıklar', NULL, 1, 1, '190306', 1903, 1, 'Tehlikeli olarak siniflandirilmis, katilastirilmis atiklar', '1903', 'Tehlikeli olarak sınıflandırılmış, katılaştırılmış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1904, 'Vitrifiye Edilmiş Atık ve Vitrifikasyon İşleminden Kaynaklanan Atıklar', NULL, NULL, 1, '1904', 19, 0, 'Vitrifiye Edilmis Atik ve Vitrifikasyon Isleminden Kaynaklanan Atiklar', '19', 'Vitrifiye Edilmiş Atık ve Vitrifikasyon İşleminden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190403, 'Vitrifiye olmamış katılar', NULL, 1, 1, '190403', 1904, 1, 'Vitrifiye olmamis katilar', '1904', 'Vitrifiye olmamış katılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190404, 'Vitrifiye atık tavlanmasından çıkan sulu sıvı', NULL, NULL, 0, '190404', 1904, 0, 'Vitrifiye atik tavlanmasindan çikan sulu sivi', '1904', 'Vitrifiye atık tavlanmasından çıkan sulu sıvı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190502, 'Hayvansal ve bitkisel atıklarının kompostlanmamış fraksiyonları', NULL, NULL, 0, '190502', 1905, 0, 'Hayvansal ve bitkisel atiklarinin kompostlanmamis fraksiyonlari', '1905', 'Hayvansal ve bitkisel atıklarının kompostlanmamış fraksiyonları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1906, 'Atığın Anaerobik Arıtımından Kaynaklanan Atıklar', NULL, NULL, 1, '1906', 19, 0, 'Atigin Anaerobik Aritimindan Kaynaklanan Atiklar', '19', 'Atığın Anaerobik Arıtımından Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190605, 'Hayvansal ve bitkisel atıkların anaerobik arıtımından kaynaklanan sıvılar', NULL, NULL, 0, '190605', 1906, 0, 'Hayvansal ve bitkisel atiklarin anaerobik aritimindan kaynaklanan sivilar', '1906', 'Hayvansal ve bitkisel atıkların anaerobik arıtımından kaynaklanan sıvılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1907, 'Düzenli Depolama Sahası Süzüntü Suları', NULL, NULL, 1, '1907', 19, 0, 'Düzenli Depolama Sahasi Süzüntü Sulari', '19', 'Düzenli Depolama Sahası Süzüntü Suları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190702, 'Tehlikeli maddeler içeren düzenli depolama sahası sızıntı suları', NULL, 1, 1, '190702', 1907, 1, 'Tehlikeli maddeler içeren düzenli depolama sahasi sizinti sulari', '1907', 'Tehlikeli maddeler içeren düzenli depolama sahası sızıntı suları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190801, 'Elek üstü maddeler', NULL, NULL, 0, '190801', 1908, 0, 'Elek üstü maddeler', '1908', 'Elek üstü maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190802, 'Kum ayırma işleminden kaynaklanan atıkları', NULL, NULL, 0, '190802', 1908, 0, 'Kum ayirma isleminden kaynaklanan atiklari', '1908', 'Kum ayırma işleminden kaynaklanan atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190805, 'Kentsel atık suyun arıtılmasından kaynaklanan çamurlar', NULL, NULL, 0, '190805', 1908, 0, 'Kentsel atik suyun aritilmasindan kaynaklanan çamurlar', '1908', 'Kentsel atık suyun arıtılmasından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190807, 'İyon değiştiricilerinin rejenerasyonundan kaynaklanan solüsyonlar ve çamurlar', NULL, 1, 1, '190807', 1908, 1, 'Iyon degistiricilerinin rejenerasyonundan kaynaklanan solüsyonlar ve çamurlar', '1908', 'İyon değiştiricilerinin rejenerasyonundan kaynaklanan solüsyonlar ve çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190813, 'Endüstriyel atık suyun diğer yöntemlerle arıtılmasından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '190813', 1908, 1, 'Endüstriyel atik suyun diger yöntemlerle aritilmasindan kaynaklanan tehlikeli maddeler içeren çamurlar', '1908', 'Endüstriyel atık suyun diğer yöntemlerle arıtılmasından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190899, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '190899', 1908, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1908', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1909, 'İnsan Tüketimi ve Endüstriyel Kullanım İçin Gereken Suyun Hazırlanmasından Kaynaklanan Atıklar', NULL, NULL, 1, '1909', 19, 0, 'Insan Tüketimi ve Endüstriyel Kullanim Için Gereken Suyun Hazirlanmasindan Kaynaklanan Atiklar', '19', 'İnsan Tüketimi ve Endüstriyel Kullanım İçin Gereken Suyun Hazırlanmasından Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190901, 'İlk filtreleme ve süzme işlemlerinden kaynaklanan katı atıklar', NULL, NULL, 0, '190901', 1909, 0, 'Ilk filtreleme ve süzme islemlerinden kaynaklanan kati atiklar', '1909', 'İlk filtreleme ve süzme işlemlerinden kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190905, 'Doymuş ya da kullanılmış iyon değtirme reçinesi', NULL, NULL, 0, '190905', 1909, 0, 'Doymus ya da kullanilmis iyon degtirme reçinesi', '1909', 'Doymuş ya da kullanılmış iyon değtirme reçinesi');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190999, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '190999', 1909, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1909', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1910, 'Metal İçeren Atıkların Parçalanmasından Kaynaklanan Atıklar', NULL, NULL, 1, '1910', 19, 0, 'Metal Içeren Atiklarin Parçalanmasindan Kaynaklanan Atiklar', '19', 'Metal İçeren Atıkların Parçalanmasından Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191002, 'Demir olmayan atıklar', NULL, NULL, 0, '191002', 1910, 0, 'Demir olmayan atiklar', '1910', 'Demir olmayan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1911, 'Yağın Yeniden Üretiminden Kaynaklanan Atıklar', NULL, NULL, 1, '1911', 19, 0, 'Yagin Yeniden Üretiminden Kaynaklanan Atiklar', '19', 'Yağın Yeniden Üretiminden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191101, 'Kullanılmış filtre killeri', NULL, 1, 1, '191101', 1911, 1, 'Kullanilmis filtre killeri', '1911', 'Kullanılmış filtre killeri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191102, 'Asit katranları', NULL, 1, 1, '191102', 1911, 1, 'Asit katranlari', '1911', 'Asit katranları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191103, 'Sulu sıvı atıklar', NULL, 1, 1, '191103', 1911, 1, 'Sulu sivi atiklar', '1911', 'Sulu sıvı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191105, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '191105', 1911, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '1911', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191107, 'Baca gazı temizleme atıkları', NULL, 1, 1, '191107', 1911, 1, 'Baca gazi temizleme atiklari', '1911', 'Baca gazı temizleme atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '191199', 1911, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1911', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191201, 'Kağıt ve karton', NULL, NULL, 0, '191201', 1912, 0, 'Kagit ve karton', '1912', 'Kağıt ve karton');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191202, 'Demir metali', NULL, NULL, 0, '191202', 1912, 0, 'Demir metali', '1912', 'Demir metali');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191203, 'Demir dışı metal', NULL, NULL, 0, '191203', 1912, 0, 'Demir disi metal', '1912', 'Demir dışı metal');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191204, 'Plastik ve lastik', NULL, NULL, 0, '191204', 1912, 0, 'Plastik ve lastik', '1912', 'Plastik ve lastik');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191205, 'Cam', NULL, NULL, 0, '191205', 1912, 0, 'Cam', '1912', 'Cam');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191207, '19 12 06 dışındaki ahşap', NULL, NULL, 0, '191207', 1912, 0, '19 12 06 disindaki ahsap', '1912', '19 12 06 dışındaki ahşap');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191208, 'Tekstil malzemeleri', NULL, NULL, 0, '191208', 1912, 0, 'Tekstil malzemeleri', '1912', 'Tekstil malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191210, 'Yanabilir atıklar (atıktan türetilmiş yakıt)', NULL, NULL, 0, '191210', 1912, 0, 'Yanabilir atiklar (atiktan türetilmis yakit)', '1912', 'Yanabilir atıklar (atıktan türetilmiş yakıt)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1913, 'Toprak ve Yeraltı Suyu Islahından Kaynaklanan Atıklar', NULL, NULL, 1, '1913', 19, 0, 'Toprak ve Yeralti Suyu Islahindan Kaynaklanan Atiklar', '19', 'Toprak ve Yeraltı Suyu Islahından Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191301, 'Toprak ıslahından kaynaklanan tehlikeli maddeler içeren atıklar', NULL, 1, 1, '191301', 1913, 1, 'Toprak islahindan kaynaklanan tehlikeli maddeler içeren atiklar', '1913', 'Toprak ıslahından kaynaklanan tehlikeli maddeler içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191302, '19 13 01 dışında toprak ıslahından kaynaklanan atıklar', NULL, NULL, 0, '191302', 1913, 0, '19 13 01 disinda toprak islahindan kaynaklanan atiklar', '1913', '19 13 01 dışında toprak ıslahından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191305, 'Yeraltı suyunun ıslahından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '191305', 1913, 1, 'Yeralti suyunun islahindan kaynaklanan tehlikeli maddeler içeren çamurlar', '1913', 'Yeraltı suyunun ıslahından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100912, '10 09 11 dışındaki diğer partiküller', NULL, NULL, 0, '100912', 1009, 0, '10 09 11 disindaki diger partiküller', '1009', '10 09 11 dışındaki diğer partiküller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191307, 'Yeraltı suyunun ıslahından kaynaklanan tehlikeli maddeler içeren sulu sıvı atıklar ve sulu konsantrasyonlar', NULL, 1, 1, '191307', 1913, 1, 'Yeralti suyunun islahindan kaynaklanan tehlikeli maddeler içeren sulu sivi atiklar ve sulu konsantrasyonlar', '1913', 'Yeraltı suyunun ıslahından kaynaklanan tehlikeli maddeler içeren sulu sıvı atıklar ve sulu konsantrasyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20, 'AYRI TOPLANMIŞ FRAKSİYONLAR DAHİL BELEDİYE ATIKLARI (EVSEL ATIKLAR VE BENZER TİCARİ, ENDÜSTRİYEL VE KURUMSAL ATIKLAR)', NULL, NULL, 1, '20', 0, 0, 'AYRI TOPLANMIS FRAKSIYONLAR DAHIL BELEDIYE ATIKLARI (EVSEL ATIKLAR VE BENZER TICARI, ENDÜSTRIYEL VE KURUMSAL ATIKLAR)', NULL, 'AYRI TOPLANMIŞ FRAKSİYONLAR DAHİL BELEDİYE ATIKLARI (EVSEL ATIKLAR VE BENZER TİCARİ, ENDÜSTRİYEL VE KURUMSAL ATIKLAR)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200101, 'Kâğıt ve karton', NULL, NULL, 0, '200101', 2001, 0, 'Kâgit ve karton', '2001', 'Kâğıt ve karton');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200102, 'Cam', NULL, NULL, 0, '200102', 2001, 0, 'Cam', '2001', 'Cam');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200108, 'Biyolojik olarak bozunabilir mutfak ve kantin atıkları', NULL, NULL, 0, '200108', 2001, 0, 'Biyolojik olarak bozunabilir mutfak ve kantin atiklari', '2001', 'Biyolojik olarak bozunabilir mutfak ve kantin atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200110, 'Giysiler', NULL, NULL, 0, '200110', 2001, 0, 'Giysiler', '2001', 'Giysiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200111, 'Tekstil ürünleri', NULL, NULL, 0, '200111', 2001, 0, 'Tekstil ürünleri', '2001', 'Tekstil ürünleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200114, 'Asitler', NULL, 1, 1, '200114', 2001, 1, 'Asitler', '2001', 'Asitler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200115, 'Alkalinler', NULL, 1, 1, '200115', 2001, 1, 'Alkalinler', '2001', 'Alkalinler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100407, 'Gaz arıtım çamurları ve filtre kekleri', NULL, 1, 1, '100407', 1004, 1, 'Gaz aritim çamurlari ve filtre kekleri', '1004', 'Gaz arıtım çamurları ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100499, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100499', 1004, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1004', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1005, 'Çinko Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, NULL, 1, '1005', 10, 0, 'Çinko Isil Metalurjisinden Kaynaklanan Atiklar', '10', 'Çinko Isıl Metalurjisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100503, 'Baca gazı tozu', NULL, 1, 1, '100503', 1005, 1, 'Baca gazi tozu', '1005', 'Baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100504, 'Diğer partiküller ve toz', NULL, NULL, 0, '100504', 1005, 0, 'Diger partiküller ve toz', '1005', 'Diğer partiküller ve toz');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100505, 'Gaz arıtımından kaynaklanan katı atıklar', NULL, 1, 1, '100505', 1005, 1, 'Gaz aritimindan kaynaklanan kati atiklar', '1005', 'Gaz arıtımından kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100508, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar', NULL, 1, 1, '100508', 1005, 1, 'Sogutma suyunun aritilmasindan kaynaklanan yag içerikli atiklar', '1005', 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100511, '10 05 10 dışındaki cüruf ve köpükler', NULL, NULL, 0, '100511', 1005, 0, '10 05 10 disindaki cüruf ve köpükler', '1005', '10 05 10 dışındaki cüruf ve köpükler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1006, 'Bakır Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, NULL, 1, '1006', 10, 0, 'Bakir Isil Metalurjisinden Kaynaklanan Atiklar', '10', 'Bakır Isıl Metalurjisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100601, 'Birincil ve ikincil üretim cürufları', NULL, NULL, 0, '100601', 1006, 0, 'Birincil ve ikincil üretim cüruflari', '1006', 'Birincil ve ikincil üretim cürufları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100602, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', NULL, NULL, 0, '100602', 1006, 0, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', '1006', 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100603, 'Baca gazı tozu', NULL, 1, 1, '100603', 1006, 1, 'Baca gazi tozu', '1006', 'Baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100604, 'Diğer partiküller ve toz', NULL, NULL, 0, '100604', 1006, 0, 'Diger partiküller ve toz', '1006', 'Diğer partiküller ve toz');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100609, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar', NULL, 1, 1, '100609', 1006, 1, 'Sogutma suyunun aritilmasindan kaynaklanan yag içeren atiklar', '1006', 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100701, 'Birincil ve ikincil üretim cürufları', NULL, NULL, 0, '100701', 1007, 0, 'Birincil ve ikincil üretim cüruflari', '1007', 'Birincil ve ikincil üretim cürufları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100704, 'Diğer partiküller ve toz', NULL, NULL, 0, '100704', 1007, 0, 'Diger partiküller ve toz', '1007', 'Diğer partiküller ve toz');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100705, 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri', NULL, NULL, 0, '100705', 1007, 0, 'Gaz aritimindan kaynaklanan çamurlar ve filtre kekleri', '1007', 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100708, '10 07 07 dışındaki soğutma suyu arıtma atıkları', NULL, NULL, 0, '100708', 1007, 0, '10 07 07 disindaki sogutma suyu aritma atiklari', '1007', '10 07 07 dışındaki soğutma suyu arıtma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1008, 'Demir Dışı Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, NULL, 1, '1008', 10, 0, 'Demir Disi Isil Metalurjisinden Kaynaklanan Atiklar', '10', 'Demir Dışı Isıl Metalurjisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100809, 'Diğer cüruflar', NULL, NULL, 0, '100809', 1008, 0, 'Diger cüruflar', '1008', 'Diğer cüruflar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100811, '10 08 10 dışındaki cüruf, toz ve kırpıntılar', NULL, NULL, 0, '100811', 1008, 0, '10 08 10 disindaki cüruf, toz ve kirpintilar', '1008', '10 08 10 dışındaki cüruf, toz ve kırpıntılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100812, 'Anot üretiminden kaynaklanan katran içeren atıklar', NULL, 1, 1, '100812', 1008, 1, 'Anot üretiminden kaynaklanan katran içeren atiklar', '1008', 'Anot üretiminden kaynaklanan katran içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100814, 'Anot hurdası', NULL, NULL, 0, '100814', 1008, 0, 'Anot hurdasi', '1008', 'Anot hurdası');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100816, '10 08 15 dışındaki baca gazı tozu', NULL, NULL, 0, '100816', 1008, 0, '10 08 15 disindaki baca gazi tozu', '1008', '10 08 15 dışındaki baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100817, 'Baca gazı arıtımından kaynaklanan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', NULL, 1, 1, '100817', 1008, 1, 'Baca gazi aritimindan kaynaklanan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', '1008', 'Baca gazı arıtımından kaynaklanan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100819, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar', NULL, 1, 1, '100819', 1008, 1, 'Sogutma suyunun aritilmasindan kaynaklanan yag içeren atiklar', '1008', 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1009, 'Demir Döküm İşleminden Kaynaklanan Atıklar', NULL, NULL, 1, '1009', 10, 0, 'Demir Döküm Isleminden Kaynaklanan Atiklar', '10', 'Demir Döküm İşleminden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100903, 'Ocak cürufları', NULL, NULL, 0, '100903', 1009, 0, 'Ocak cüruflari', '1009', 'Ocak cürufları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100907, 'Döküm yapılmış tehlikeli madde içeren maça ve kum döküm kalıpları', NULL, 1, 1, '100907', 1009, 1, 'Döküm yapilmis tehlikeli madde içeren maça ve kum döküm kaliplari', '1009', 'Döküm yapılmış tehlikeli madde içeren maça ve kum döküm kalıpları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100908, '10 09 07 dışında döküm yapılmış maça ve kum döküm kalıpları', NULL, NULL, 0, '100908', 1009, 0, '10 09 07 disinda döküm yapilmis maça ve kum döküm kaliplari', '1009', '10 09 07 dışında döküm yapılmış maça ve kum döküm kalıpları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100911, 'Tehlikeli maddeler içeren diğer partiküller', NULL, 1, 1, '100911', 1009, 1, 'Tehlikeli maddeler içeren diger partiküller', '1009', 'Tehlikeli maddeler içeren diğer partiküller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100914, '10 09 13 dışındaki atık bağlayıcılar', NULL, NULL, 0, '100914', 1009, 0, '10 09 13 disindaki atik baglayicilar', '1009', '10 09 13 dışındaki atık bağlayıcılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100915, 'Tehlikeli madde içeren çatlak belirleme kimyasalları atığı', NULL, 1, 1, '100915', 1009, 1, 'Tehlikeli madde içeren çatlak belirleme kimyasallari atigi', '1009', 'Tehlikeli madde içeren çatlak belirleme kimyasalları atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100999, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100999', 1009, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1009', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101007, 'Döküm yapılmış tehlikeli madde içeren maça ve kum döküm kalıpları', NULL, 1, 1, '101007', 1010, 1, 'Döküm yapilmis tehlikeli madde içeren maça ve kum döküm kaliplari', '1010', 'Döküm yapılmış tehlikeli madde içeren maça ve kum döküm kalıpları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101008, '10 10 07 dışındaki döküm yapılmış maça ve kum döküm kalıpları', NULL, NULL, 0, '101008', 1010, 0, '10 10 07 disindaki döküm yapilmis maça ve kum döküm kaliplari', '1010', '10 10 07 dışındaki döküm yapılmış maça ve kum döküm kalıpları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101012, '10 10 11 dışındaki diğer partiküller', NULL, NULL, 0, '101012', 1010, 0, '10 10 11 disindaki diger partiküller', '1010', '10 10 11 dışındaki diğer partiküller');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101016, '10 10 15 dışındaki çatlak belirleme kimyasalları atığı', NULL, NULL, 0, '101016', 1010, 0, '10 10 15 disindaki çatlak belirleme kimyasallari atigi', '1010', '10 10 15 dışındaki çatlak belirleme kimyasalları atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101099, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '101099', 1010, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1010', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101103, 'Cam elyaf atıkları', NULL, NULL, 0, '101103', 1011, 0, 'Cam elyaf atiklari', '1011', 'Cam elyaf atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101105, 'Partiküller ve toz', NULL, NULL, 0, '101105', 1011, 0, 'Partiküller ve toz', '1011', 'Partiküller ve toz');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101113, 'Tehlikeli maddeler içeren cam parlatma ve öğütme çamuru', NULL, 1, 1, '101113', 1011, 1, 'Tehlikeli maddeler içeren cam parlatma ve ögütme çamuru', '1011', 'Tehlikeli maddeler içeren cam parlatma ve öğütme çamuru');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101114, '10 11 13 dışındaki cam parlatma ve öğütme çamuru', NULL, NULL, 0, '101114', 1011, 0, '10 11 13 disindaki cam parlatma ve ögütme çamuru', '1011', '10 11 13 dışındaki cam parlatma ve öğütme çamuru');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101116, '10 11 15 dışında baca gazı arıtımından kaynaklanan katı atıklar', NULL, NULL, 0, '101116', 1011, 0, '10 11 15 disinda baca gazi aritimindan kaynaklanan kati atiklar', '1011', '10 11 15 dışında baca gazı arıtımından kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101117, 'Baca gazı arıtımından kaynaklanan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', NULL, 1, 1, '101117', 1011, 1, 'Baca gazi aritimindan kaynaklanan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', '1011', 'Baca gazı arıtımından kaynaklanan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '101199', 1011, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1011', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101203, 'Partiküller ve toz', NULL, NULL, 0, '101203', 1012, 0, 'Partiküller ve toz', '1012', 'Partiküller ve toz');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101205, 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri', NULL, NULL, 0, '101205', 1012, 0, 'Gaz aritimindan kaynaklanan çamurlar ve filtre kekleri', '1012', 'Gaz arıtımından kaynaklanan çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101206, 'Iskarta kalıplar', NULL, NULL, 0, '101206', 1012, 0, 'Iskarta kaliplar', '1012', 'Iskarta kalıplar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80121, 'Boya ya da vernik sökücü atıkları', NULL, 1, 1, '080121', 801, 1, 'Boya ya da vernik sökücü atiklari', '0801', 'Boya ya da vernik sökücü atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '080199', 801, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0801', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80201, 'Atık kaplama tozları', NULL, NULL, 0, '080201', 802, 0, 'Atik kaplama tozlari', '0802', 'Atık kaplama tozları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80202, 'Seramik malzemeler içeren sulu  çamurlar', NULL, NULL, 0, '080202', 802, 0, 'Seramik malzemeler içeren sulu  çamurlar', '0802', 'Seramik malzemeler içeren sulu  çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80203, 'Seramik malzemeler içeren sulu süspansiyonlar', NULL, NULL, 0, '080203', 802, 0, 'Seramik malzemeler içeren sulu süspansiyonlar', '0802', 'Seramik malzemeler içeren sulu süspansiyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80307, 'Mürekkep içeren sulu çamurlar', NULL, NULL, 0, '080307', 803, 0, 'Mürekkep içeren sulu çamurlar', '0803', 'Mürekkep içeren sulu çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80308, 'Mürekkep içeren sulu sıvı atıklar', NULL, NULL, 0, '080308', 803, 0, 'Mürekkep içeren sulu sivi atiklar', '0803', 'Mürekkep içeren sulu sıvı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80312, 'Tehlikeli maddeler içeren mürekkep atıkları', NULL, 1, 1, '080312', 803, 1, 'Tehlikeli maddeler içeren mürekkep atiklari', '0803', 'Tehlikeli maddeler içeren mürekkep atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80313, '08 03 12 dışındaki mürekkep atıkları', NULL, NULL, 0, '080313', 803, 0, '08 03 12 disindaki mürekkep atiklari', '0803', '08 03 12 dışındaki mürekkep atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80316, 'Atık aşındırma solüsyonları', NULL, 1, 1, '080316', 803, 1, 'Atik asindirma solüsyonlari', '0803', 'Atık aşındırma solüsyonları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80317, 'Tehlikeli maddeler içeren atık baskı tonerleri', NULL, 1, 1, '080317', 803, 1, 'Tehlikeli maddeler içeren atik baski tonerleri', '0803', 'Tehlikeli maddeler içeren atık baskı tonerleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80319, 'Dağıtıcı yağ', NULL, 1, 1, '080319', 803, 1, 'Dagitici yag', '0803', 'Dağıtıcı yağ');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80409, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren atık yapışkanlar ve dolgu macunları', NULL, 1, 1, '080409', 804, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren atik yapiskanlar ve dolgu macunlari', '0804', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren atık yapışkanlar ve dolgu macunları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80410, '08 04 09 dışındaki atık yapışkanlar ve dolgu macunları', NULL, NULL, 0, '080410', 804, 0, '08 04 09 disindaki atik yapiskanlar ve dolgu macunlari', '0804', '08 04 09 dışındaki atık yapışkanlar ve dolgu macunları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80413, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren sulu yapışkan veya dolgu macunu çamurları', NULL, 1, 1, '080413', 804, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren sulu yapiskan veya dolgu macunu çamurlari', '0804', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren sulu yapışkan veya dolgu macunu çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80415, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren sulu yapışkan veya dolgu macunlarının sıvı atıkları', NULL, 1, 1, '080415', 804, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren sulu yapiskan veya dolgu macunlarinin sivi atiklari', '0804', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren sulu yapışkan veya dolgu macunlarının sıvı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80417, 'Reçine yağı', NULL, 1, 1, '080417', 804, 1, 'Reçine yagi', '0804', 'Reçine yağı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80499, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '080499', 804, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0804', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (805, '08''de Başka Şekilde Tanımlanmamış Atıklar', NULL, NULL, 1, '0805', 8, 0, '08?de Baska Sekilde Tanimlanmamis Atiklar', '08', '08?de Başka Şekilde Tanımlanmamış Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (9, 'FOTOĞRAF ENDÜSTRİSİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '09', 0, 0, 'FOTOGRAF ENDÜSTRISINDEN KAYNAKLANAN ATIKLAR', NULL, 'FOTOĞRAF ENDÜSTRİSİNDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90101, 'Su bazlı banyo ve aktifleştirici solüsyonları', NULL, 1, 1, '090101', 901, 1, 'Su bazli banyo ve aktiflestirici solüsyonlari', '0901', 'Su bazlı banyo ve aktifleştirici solüsyonları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90104, 'Sabitleyici solüsyonlar', NULL, 1, 1, '090104', 901, 1, 'Sabitleyici solüsyonlar', '0901', 'Sabitleyici solüsyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90105, 'Ağartıcı solüsyonları ve ağartıcı sabitleyici solüsyonlar', NULL, 1, 1, '090105', 901, 1, 'Agartici solüsyonlari ve agartici sabitleyici solüsyonlar', '0901', 'Ağartıcı solüsyonları ve ağartıcı sabitleyici solüsyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90108, 'Gümüş veya gümüş bileşenleri içermeyen fotoğraf filmi ve kağıdı', NULL, NULL, 0, '090108', 901, 0, 'Gümüs veya gümüs bilesenleri içermeyen fotograf filmi ve kagidi', '0901', 'Gümüş veya gümüş bileşenleri içermeyen fotoğraf filmi ve kağıdı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90111, '16 06 01, 16 06 02 ya da 16 06 03?ün altında geçen pillerle çalışan tek kullanımlık fotoğraf makineleri', NULL, 1, 1, '090111', 901, 1, '16 06 01, 16 06 02 ya da 16 06 03?ün altinda geçen pillerle çalisan tek kullanimlik fotograf makineleri', '0901', '16 06 01, 16 06 02 ya da 16 06 03?ün altında geçen pillerle çalışan tek kullanımlık fotoğraf makineleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90113, '09 01 06 dışındaki gümüş geri kazanımı için yapılan arıtmadan kalan sulu sıvı atıklar', NULL, 1, 1, '090113', 901, 1, '09 01 06 disindaki gümüs geri kazanimi için yapilan aritmadan kalan sulu sivi atiklar', '0901', '09 01 06 dışındaki gümüş geri kazanımı için yapılan arıtmadan kalan sulu sıvı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10, 'ISIL İŞLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '10', 0, 0, 'ISIL ISLEMLERDEN KAYNAKLANAN ATIKLAR', NULL, 'ISIL İŞLEMLERDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100103, 'Turba ve işlenmenmiş odundan kaynaklanan uçucu kül', NULL, NULL, 0, '100103', 1001, 0, 'Turba ve islenmenmis odundan kaynaklanan uçucu kül', '1001', 'Turba ve işlenmenmiş odundan kaynaklanan uçucu kül');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100104, 'Uçucu yağ külü ve kazan tozu', NULL, 1, 1, '100104', 1001, 1, 'Uçucu yag külü ve kazan tozu', '1001', 'Uçucu yağ külü ve kazan tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100107, 'Baca gazı kükürt giderme işleminden (desülfrizasyon) çıkan kalsiyum bazlı çamurlar', NULL, NULL, 0, '100107', 1001, 0, 'Baca gazi kükürt giderme isleminden (desülfrizasyon) çikan kalsiyum bazli çamurlar', '1001', 'Baca gazı kükürt giderme işleminden (desülfrizasyon) çıkan kalsiyum bazlı çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100109, 'Sülfürik asit', NULL, 1, 1, '100109', 1001, 1, 'Sülfürik asit', '1001', 'Sülfürik asit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100117, '10 01 16 dışındaki birlikte yakılmadan (co-incineration) kaynaklanan uçucu kül', NULL, NULL, 0, '100117', 1001, 0, '10 01 16 disindaki birlikte yakilmadan (co-incineration) kaynaklanan uçucu kül', '1001', '10 01 16 dışındaki birlikte yakılmadan (co-incineration) kaynaklanan uçucu kül');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100118, 'Tehlikeli maddeler içeren gaz temizleme atıkları', NULL, 1, 1, '100118', 1001, 1, 'Tehlikeli maddeler içeren gaz temizleme atiklari', '1001', 'Tehlikeli maddeler içeren gaz temizleme atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100120, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '100120', 1001, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '1001', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100122, 'Kazan temizlemesi sonucu çıkan tehlikeli maddeler içeren sulu çamurlar', NULL, 1, 1, '100122', 1001, 1, 'Kazan temizlemesi sonucu çikan tehlikeli maddeler içeren sulu çamurlar', '1001', 'Kazan temizlemesi sonucu çıkan tehlikeli maddeler içeren sulu çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100123, '10 01 22 dışındaki kazan temizlemesi sonucu çıkan sulu çamurlar', NULL, NULL, 0, '100123', 1001, 0, '10 01 22 disindaki kazan temizlemesi sonucu çikan sulu çamurlar', '1001', '10 01 22 dışındaki kazan temizlemesi sonucu çıkan sulu çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100126, 'Soğutma suyu işlemlerinden çıkan atıklar', NULL, NULL, 0, '100126', 1001, 0, 'Sogutma suyu islemlerinden çikan atiklar', '1001', 'Soğutma suyu işlemlerinden çıkan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100201, 'Cüruf işleme atıkları', NULL, NULL, 0, '100201', 1002, 0, 'Cüruf isleme atiklari', '1002', 'Cüruf işleme atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100202, 'İşlenmemiş cüruf', NULL, NULL, 0, '100202', 1002, 0, 'Islenmemis cüruf', '1002', 'İşlenmemiş cüruf');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100208, '10 02 07 dışında gaz arıtımı sonucu ortaya çıkan katı atıklar', NULL, NULL, 0, '100208', 1002, 0, '10 02 07 disinda gaz aritimi sonucu ortaya çikan kati atiklar', '1002', '10 02 07 dışında gaz arıtımı sonucu ortaya çıkan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100210, 'Haddehane tufalı', NULL, NULL, 0, '100210', 1002, 0, 'Haddehane tufali', '1002', 'Haddehane tufalı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100211, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar', NULL, 1, 1, '100211', 1002, 1, 'Sogutma suyunun aritilmasindan kaynaklanan yag içerikli atiklar', '1002', 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100215, 'Diğer çamurlar ve filtre kekleri', NULL, NULL, 0, '100215', 1002, 0, 'Diger çamurlar ve filtre kekleri', '1002', 'Diğer çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100299, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100299', 1002, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1002', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100302, 'Anot hurdaları', NULL, NULL, 0, '100302', 1003, 0, 'Anot hurdalari', '1003', 'Anot hurdaları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100304, 'Birincil üretim cürufları', NULL, 1, 1, '100304', 1003, 1, 'Birincil üretim cüruflari', '1003', 'Birincil üretim cürufları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100305, 'Atık alüminyum oksit', NULL, NULL, 0, '100305', 1003, 0, 'Atik alüminyum oksit', '1003', 'Atık alüminyum oksit');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100315, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir köpükler', NULL, 1, 1, '100315', 1003, 1, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çikaran yanici veya yayilabilir köpükler', '1003', 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir köpükler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100317, 'Anot üretiminden kaynaklanan katranlı atıklar', NULL, 1, 1, '100317', 1003, 1, 'Anot üretiminden kaynaklanan katranli atiklar', '1003', 'Anot üretiminden kaynaklanan katranlı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100319, 'Tehlikeli maddeler içeren baca gazı tozu', NULL, 1, 1, '100319', 1003, 1, 'Tehlikeli maddeler içeren baca gazi tozu', '1003', 'Tehlikeli maddeler içeren baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100320, '10 03 19 dışındaki baca gazı tozu', NULL, NULL, 0, '100320', 1003, 0, '10 03 19 disindaki baca gazi tozu', '1003', '10 03 19 dışındaki baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100325, 'Tehlikeli maddeler içeren gaz arıtımı çamurları ve filtre kekleri', NULL, 1, 1, '100325', 1003, 1, 'Tehlikeli maddeler içeren gaz aritimi çamurlari ve filtre kekleri', '1003', 'Tehlikeli maddeler içeren gaz arıtımı çamurları ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100326, '10 03 25 dışındaki gaz arıtımı çamurları ve filtre kekleri', NULL, NULL, 0, '100326', 1003, 0, '10 03 25 disindaki gaz aritimi çamurlari ve filtre kekleri', '1003', '10 03 25 dışındaki gaz arıtımı çamurları ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101, 'Maden kazılarından kaynaklanan atıklar', NULL, NULL, 1, '0101', 1, 0, 'Maden kazilarindan kaynaklanan atiklar', '01', 'Maden kazılarından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10101, 'Metalik maden kazılarından kaynaklanan atıklar', NULL, NULL, 0, '010101', 101, 0, 'Metalik maden kazilarindan kaynaklanan atiklar', '0101', 'Metalik maden kazılarından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10102, 'Metalik olmayan maden kazılarından kaynaklanan atıklar', NULL, NULL, 0, '010102', 101, 0, 'Metalik olmayan maden kazilarindan kaynaklanan atiklar', '0101', 'Metalik olmayan maden kazılarından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10305, 'Tehlikeli madde içeren diğer maden atıkları', NULL, 1, 1, '010305', 103, 1, 'Tehlikeli madde içeren diger maden atiklari', '0103', 'Tehlikeli madde içeren diğer maden atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10306, '01 03 04 ve 01 03 05 dışındaki diğer maden atıkları', NULL, NULL, 0, '010306', 103, 0, '01 03 04 ve 01 03 05 disindaki diger maden atiklari', '0103', '01 03 04 ve 01 03 05 dışındaki diğer maden atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '010399', 103, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0103', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10407, 'Metalik olmayan minerallerin fiziki ve kimyasal işlenmesinden kaynaklanan tehlikeli maddeler içeren atıklar', NULL, 1, 1, '010407', 104, 1, 'Metalik olmayan minerallerin fiziki ve kimyasal islenmesinden kaynaklanan tehlikeli maddeler içeren atiklar', '0104', 'Metalik olmayan minerallerin fiziki ve kimyasal işlenmesinden kaynaklanan tehlikeli maddeler içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10408, '01 04 07 dışındaki atık kaya ve çakıl taşı atıkları', NULL, NULL, 0, '010408', 104, 0, '01 04 07 disindaki atik kaya ve çakil tasi atiklari', '0104', '01 04 07 dışındaki atık kaya ve çakıl taşı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10409, 'Atık kum ve killer', NULL, NULL, 0, '010409', 104, 0, 'Atik kum ve killer', '0104', 'Atık kum ve killer');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10413, '01 04 07 dışındaki taş yontma ve kesme işlemlerinden kaynaklanan atıklar', NULL, NULL, 0, '010413', 104, 0, '01 04 07 disindaki tas yontma ve kesme islemlerinden kaynaklanan atiklar', '0104', '01 04 07 dışındaki taş yontma ve kesme işlemlerinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10499, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '010499', 104, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0104', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (105, 'Sondaj Çamurları ve Diğer Sondaj Atıkları', NULL, NULL, 1, '0105', 1, 0, 'Sondaj Çamurlari ve Diger Sondaj Atiklari', '01', 'Sondaj Çamurları ve Diğer Sondaj Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10505, 'Yağ içeren sondaj çamurları ve atıkları', NULL, 1, 1, '010505', 105, 1, 'Yag içeren sondaj çamurlari ve atiklari', '0105', 'Yağ içeren sondaj çamurları ve atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10507, '01 05 05 ve 01 05 06 dışındaki barit içeren sondaj çamurları ve atıkları', NULL, NULL, 0, '010507', 105, 0, '01 05 05 ve 01 05 06 disindaki barit içeren sondaj çamurlari ve atiklari', '0105', '01 05 05 ve 01 05 06 dışındaki barit içeren sondaj çamurları ve atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (2, 'TARIM, BAHÇIVANLIK, SU KÜLTÜRÜ, ORMANCILIK, AVCILIK VE BALIKÇILIK, GIDA HAZIRLAMA VE İŞLEMEDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '02', 0, 0, 'TARIM, BAHÇIVANLIK, SU KÜLTÜRÜ, ORMANCILIK, AVCILIK VE BALIKÇILIK, GIDA HAZIRLAMA VE ISLEMEDEN KAYNAKLANAN ATIKLAR', NULL, 'TARIM, BAHÇIVANLIK, SU KÜLTÜRÜ, ORMANCILIK, AVCILIK VE BALIKÇILIK, GIDA HAZIRLAMA VE İŞLEMEDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20101, 'Yıkama ve temizleme işlemlerinden kaynaklanan çamurlar', NULL, NULL, 0, '020101', 201, 0, 'Yikama ve temizleme islemlerinden kaynaklanan çamurlar', '0201', 'Yıkama ve temizleme işlemlerinden kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20103, 'Bitki dokusu atıkları', NULL, NULL, 0, '020103', 201, 0, 'Bitki dokusu atiklari', '0201', 'Bitki dokusu atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20104, 'Atık plastikler (ambalajlar hariç)', NULL, NULL, 0, '020104', 201, 0, 'Atik plastikler (ambalajlar hariç)', '0201', 'Atık plastikler (ambalajlar hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20107, 'Ormancılık atıkları', NULL, NULL, 0, '020107', 201, 0, 'Ormancilik atiklari', '0201', 'Ormancılık atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20108, 'Tehlikeli maddeler içeren zirai kimyasal atıklar', NULL, 1, 1, '020108', 201, 1, 'Tehlikeli maddeler içeren zirai kimyasal atiklar', '0201', 'Tehlikeli maddeler içeren zirai kimyasal atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '020199', 201, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0201', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20201, 'Yıkama ve temizlemeden kaynaklanan çamurlar', NULL, NULL, 0, '020201', 202, 0, 'Yikama ve temizlemeden kaynaklanan çamurlar', '0202', 'Yıkama ve temizlemeden kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20202, 'Hayvan dokusu atığı', NULL, NULL, 0, '020202', 202, 0, 'Hayvan dokusu atigi', '0202', 'Hayvan dokusu atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20203, 'Tüketime ya da işlenmeye uygun olmayan maddeler', NULL, NULL, 0, '020203', 202, 0, 'Tüketime ya da islenmeye uygun olmayan maddeler', '0202', 'Tüketime ya da işlenmeye uygun olmayan maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20204, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '020204', 202, 0, 'Isletme sahasi içerisindeki atik su aritimindan kaynaklanan çamurlar', '0202', 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20302, 'Koruyucu katkı maddelerinden kaynaklanan atıklar', NULL, NULL, 0, '020302', 203, 0, 'Koruyucu katki maddelerinden kaynaklanan atiklar', '0203', 'Koruyucu katkı maddelerinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20304, 'Tüketime ya da işlenmeye uygun olmayan maddeler', NULL, NULL, 0, '020304', 203, 0, 'Tüketime ya da islenmeye uygun olmayan maddeler', '0203', 'Tüketime ya da işlenmeye uygun olmayan maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (204, 'Şeker üretiminden kaynaklanan atıklar', NULL, NULL, 1, '0204', 2, 0, 'Seker üretiminden kaynaklanan atiklar', '02', 'Şeker üretiminden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20401, 'Şeker pancarının temizlenmesinden ve yıkanmasından kaynaklanan toprak', NULL, NULL, 0, '020401', 204, 0, 'Seker pancarinin temizlenmesinden ve yikanmasindan kaynaklanan toprak', '0204', 'Şeker pancarının temizlenmesinden ve yıkanmasından kaynaklanan toprak');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20402, 'Standart dışı kalsiyum karbonat', NULL, NULL, 0, '020402', 204, 0, 'Standart disi kalsiyum karbonat', '0204', 'Standart dışı kalsiyum karbonat');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20403, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '020403', 204, 0, 'Isletme sahasi içerisindeki atik su aritimindan kaynaklanan çamurlar', '0204', 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (205, 'Süt ürünleri endüstrisinden kaynaklanan atıklar', NULL, NULL, 1, '0205', 2, 0, 'Süt ürünleri endüstrisinden kaynaklanan atiklar', '02', 'Süt ürünleri endüstrisinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20502, 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '020502', 205, 0, 'Isletme sahasi içerisindeki atik su aritimindan kaynaklanan çamurlar', '0205', 'İşletme sahası içerisindeki atık su arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20601, 'Tüketime ve işlenmeye uygun olmayan maddeler', NULL, NULL, 0, '020601', 206, 0, 'Tüketime ve islenmeye uygun olmayan maddeler', '0206', 'Tüketime ve işlenmeye uygun olmayan maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20602, 'Koruyucu katkı maddelerinden kaynaklanan atıklar', NULL, NULL, 0, '020602', 206, 0, 'Koruyucu katki maddelerinden kaynaklanan atiklar', '0206', 'Koruyucu katkı maddelerinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20699, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '020699', 206, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0206', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20701, 'Hammaddelerin yıkanmasından, temizlenmesinden ve mekanik olarak sıkılmasından kaynaklanan atıklar', NULL, NULL, 0, '020701', 207, 0, 'Hammaddelerin yikanmasindan, temizlenmesinden ve mekanik olarak sikilmasindan kaynaklanan atiklar', '0207', 'Hammaddelerin yıkanmasından, temizlenmesinden ve mekanik olarak sıkılmasından kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20704, 'Tüketime ya da işlenmeye uygun olmayan maddeler', NULL, NULL, 0, '020704', 207, 0, 'Tüketime ya da islenmeye uygun olmayan maddeler', '0207', 'Tüketime ya da işlenmeye uygun olmayan maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20799, 'Başka bir şekilde tanımlanmayan atıklar', NULL, NULL, 0, '020799', 207, 0, 'Baska bir sekilde tanimlanmayan atiklar', '0207', 'Başka bir şekilde tanımlanmayan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30101, 'Ağaç kabuğu ve mantar atıkları', NULL, NULL, 0, '030101', 301, 0, 'Agaç kabugu ve mantar atiklari', '0301', 'Ağaç kabuğu ve mantar atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30104, 'Tehlikeli maddeler içeren talaş, yonga, kıymık, ahşap, kontraplak ve kaplamalar', NULL, 1, 1, '030104', 301, 1, 'Tehlikeli maddeler içeren talas, yonga, kiymik, ahsap, kontraplak ve kaplamalar', '0301', 'Tehlikeli maddeler içeren talaş, yonga, kıymık, ahşap, kontraplak ve kaplamalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '030199', 301, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0301', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (302, 'Ahşap Koruma Atıkları', NULL, NULL, 1, '0302', 3, 0, 'Ahsap Koruma Atiklari', '03', 'Ahşap Koruma Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30203, 'Organometal içeren ahşap koruyucu maddeler', NULL, 1, 1, '030203', 302, 1, 'Organometal içeren ahsap koruyucu maddeler', '0302', 'Organometal içeren ahşap koruyucu maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30205, 'Tehlikeli maddeler içeren diğer ahşap koruyucuları', NULL, 1, 1, '030205', 302, 1, 'Tehlikeli maddeler içeren diger ahsap koruyuculari', '0302', 'Tehlikeli maddeler içeren diğer ahşap koruyucuları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (303, 'Kağıt hamuru, kağıt ve kağıt karton üretim ve işlenmesinden kaynaklanan atıklar', NULL, NULL, 1, '0303', 3, 0, 'Kagit hamuru, kagit ve kagit karton üretim ve islenmesinden kaynaklanan atiklar', '03', 'Kağıt hamuru, kağıt ve kağıt karton üretim ve işlenmesinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30302, 'Yeşil sıvı çamuru (pişirme sıvısı geri kazanımından)', NULL, NULL, 0, '030302', 303, 0, 'Yesil sivi çamuru (pisirme sivisi geri kazanimindan)', '0303', 'Yeşil sıvı çamuru (pişirme sıvısı geri kazanımından)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30307, 'Atık kağıt ve kartonun hamur haline getirilmesi sırasında mekanik olarak ayrılan ıskartalar', NULL, NULL, 0, '030307', 303, 0, 'Atik kagit ve kartonun hamur haline getirilmesi sirasinda mekanik olarak ayrilan iskartalar', '0303', 'Atık kağıt ve kartonun hamur haline getirilmesi sırasında mekanik olarak ayrılan ıskartalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30311, '03 03 10 dışındaki saha içi atık su arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '030311', 303, 0, '03 03 10 disindaki saha içi atik su aritimindan kaynaklanan çamurlar', '0303', '03 03 10 dışındaki saha içi atık su arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '030399', 303, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0303', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (401, 'Deri ve Kürk Endüstrisinden Kaynaklanan Atıklar', NULL, NULL, 1, '0401', 4, 0, 'Deri ve Kürk Endüstrisinden Kaynaklanan Atiklar', '04', 'Deri ve Kürk Endüstrisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101209, 'Gaz arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar', NULL, 1, 1, '101209', 1012, 1, 'Gaz aritimindan kaynaklanan tehlikeli maddeler içeren kati atiklar', '1012', 'Gaz arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101210, '10 12 09 dışındaki gaz arıtma katı atıkları', NULL, NULL, 0, '101210', 1012, 0, '10 12 09 disindaki gaz aritma kati atiklari', '1012', '10 12 09 dışındaki gaz arıtma katı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101212, '10 12 11 dışındaki sırlama atıkları', NULL, NULL, 0, '101212', 1012, 0, '10 12 11 disindaki sirlama atiklari', '1012', '10 12 11 dışındaki sırlama atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101304, 'Kirecin kalsinasyon ve hidratasyonundan kaynaklanan atıklar', NULL, NULL, 0, '101304', 1013, 0, 'Kirecin kalsinasyon ve hidratasyonundan kaynaklanan atiklar', '1013', 'Kirecin kalsinasyon ve hidratasyonundan kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101306, 'Partiküller ve toz (10 13 12 ve 10 13 13 hariç)', NULL, NULL, 0, '101306', 1013, 0, 'Partiküller ve toz (10 13 12 ve 10 13 13 hariç)', '1013', 'Partiküller ve toz (10 13 12 ve 10 13 13 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101309, 'Asbestli çimento üretiminden kaynaklanan asbest içeren atıklar', NULL, 1, 1, '101309', 1013, 1, 'Asbestli çimento üretiminden kaynaklanan asbest içeren atiklar', '1013', 'Asbestli çimento üretiminden kaynaklanan asbest içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101311, '10 13 09 ve 10 13 10 dışındaki çimento bazlı kompozit malzeme üretim atıkları', NULL, NULL, 0, '101311', 1013, 0, '10 13 09 ve 10 13 10 disindaki çimento bazli kompozit malzeme üretim atiklari', '1013', '10 13 09 ve 10 13 10 dışındaki çimento bazlı kompozit malzeme üretim atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '101399', 1013, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1013', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101401, 'Gaz temizlemeden kaynaklanan cıva içeren atıklar', NULL, 1, 1, '101401', 1014, 1, 'Gaz temizlemeden kaynaklanan civa içeren atiklar', '1014', 'Gaz temizlemeden kaynaklanan cıva içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110106, 'Başka bir şekilde tanımlanmamış asitler', NULL, 1, 1, '110106', 1101, 1, 'Baska bir sekilde tanimlanmamis asitler', '1101', 'Başka bir şekilde tanımlanmamış asitler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110107, 'Sıyırma bazları', NULL, 1, 1, '110107', 1101, 1, 'Siyirma bazlari', '1101', 'Sıyırma bazları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110108, 'Fosfatlama çamurları', NULL, 1, 1, '110108', 1101, 1, 'Fosfatlama çamurlari', '1101', 'Fosfatlama çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110110, '11 01 09 dışındaki çamurlar ve filtre kekleri', NULL, NULL, 0, '110110', 1101, 0, '11 01 09 disindaki çamurlar ve filtre kekleri', '1101', '11 01 09 dışındaki çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110112, '11 01 11 dışındaki sulu durulama sıvıları', NULL, NULL, 0, '110112', 1101, 0, '11 01 11 disindaki sulu durulama sivilari', '1101', '11 01 11 dışındaki sulu durulama sıvıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110114, '11 01 13 dışındaki yağ alma atıkları', NULL, NULL, 0, '110114', 1101, 0, '11 01 13 disindaki yag alma atiklari', '1101', '11 01 13 dışındaki yağ alma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180205, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerden oluşan kimyasallar', NULL, 1, 1, '180205', 1802, 1, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerden olusan kimyasallar', '1802', 'Tehlikeli maddeler içeren ya da tehlikeli maddelerden oluşan kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191212, '19 12 11 dışında atıkların mekanik işlenmesinden kaynaklanan diğer atıklar (karışık malzemeler dahil)', NULL, NULL, 0, '191212', 1912, 0, '19 12 11 disinda atiklarin mekanik islenmesinden kaynaklanan diger atiklar (karisik malzemeler dahil)', '1912', '19 12 11 dışında atıkların mekanik işlenmesinden kaynaklanan diğer atıklar (karışık malzemeler dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30204, 'İnorganik ahşap koruyucu maddeler', NULL, 1, 1, '030204', 302, 1, 'İnorganik ahsap koruyucu maddeler', '0302', 'İnorganik ahşap koruyucu maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130508, 'Kum odacığından ve yağ/su ayırıcılarından çıkan karışık atıklar', NULL, 1, 1, '130508', 1305, 1, 'Kum odacigindan ve yag/su ayiricilarindan çikan karisik atiklar', '1305', 'Kum odacığından ve yağ/su ayırıcılarından çıkan karışık atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191003, 'Tehlikeli maddeler içeren uçucu atık parçacıkları ve tozlar', NULL, 1, 1, '191003', 1910, 1, 'Tehlikeli maddeler içeren uçucu atik parçaciklari ve tozlar', '1910', 'Tehlikeli maddeler içeren uçucu atık parçacıkları ve tozlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (507, 'Doğal Gaz Saflaştırma ve Nakliyesinde Oluşan Atıklar', NULL, NULL, 1, '0507', 5, 0, 'Dogal Gaz Saflastirma ve Nakliyesinde Olusan Atiklar', '05', 'Doğal Gaz Saflaştırma ve Nakliyesinde Oluşan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (60405, 'Başka ağır metaller içeren atıklar', NULL, 1, 1, '060405', 604, 1, 'Baska agir metaller içeren atiklar', '0604', 'Başka ağır metaller içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61304, 'Asbest işlenmesinden kaynaklanan atıklar', NULL, 1, 1, '061304', 613, 1, 'Asbest islenmesinden kaynaklanan atiklar', '0613', 'Asbest işlenmesinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70215, '07 02 14 dışındaki katkı maddelerinin atıkları', NULL, NULL, 0, '070215', 702, 0, '07 02 14 disindaki katki maddelerinin atiklari', '0702', '07 02 14 dışındaki katkı maddelerinin atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70511, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '070511', 705, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0705', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80118, '08 01 17 dışındaki boya ve vernik sökülmesinden kaynaklanan atıklar', NULL, NULL, 0, '080118', 801, 0, '08 01 17 disindaki boya ve vernik sökülmesinden kaynaklanan atiklar', '0801', '08 01 17 dışındaki boya ve vernik sökülmesinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100804, 'Partiküller ve toz', NULL, NULL, 0, '100804', 1008, 0, 'Partiküller ve toz', '1008', 'Partiküller ve toz');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100813, '10 08 12 dışındaki anot üretiminden kaynaklanan karbon içerikli atıklar', NULL, NULL, 0, '100813', 1008, 0, '10 08 12 disindaki anot üretiminden kaynaklanan karbon içerikli atiklar', '1008', '10 08 12 dışındaki anot üretiminden kaynaklanan karbon içerikli atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101119, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar', NULL, 1, 1, '101119', 1011, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren kati atiklar', '1011', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90106, 'Fotoğrafçılık atıklarının saha içi arıtılmasından oluşan gümüş içeren atıklar', NULL, 1, 1, '090106', 901, 1, 'Fotografçilik atiklarinin saha içi aritilmasindan olusan gümüs içeren atiklar', '0901', 'Fotoğrafçılık atıklarının saha içi arıtılmasından oluşan gümüş içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100213, 'Gaz arıtımı sonucu oluşan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', NULL, 1, 1, '100213', 1002, 1, 'Gaz aritimi sonucu olusan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri', '1002', 'Gaz arıtımı sonucu oluşan ve tehlikeli maddeler içeren çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10307, 'Metalik minerallerin fiziki ve kimyasal işlenmesinden kaynaklanan tehlikeli maddeler içeren diğer atıklar', NULL, 1, 1, '010307', 103, 1, 'Metalik minerallerin fiziki ve kimyasal islenmesinden kaynaklanan tehlikeli maddeler içeren diger atiklar', '0103', 'Metalik minerallerin fiziki ve kimyasal işlenmesinden kaynaklanan tehlikeli maddeler içeren diğer atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30201, 'Halojenlenmemiş organik ahşap koruyucu maddeler', NULL, 1, 1, '030201', 302, 1, 'Halojenlenmemis organik ahsap koruyucu maddeler', '0302', 'Halojenlenmemiş organik ahşap koruyucu maddeler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110109, 'Tehlikeli maddeler içeren çamurlar ve filtre kekleri', NULL, 1, 1, '110109', 1101, 1, 'Tehlikeli maddeler içeren çamurlar ve filtre kekleri', '1101', 'Tehlikeli maddeler içeren çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1201, 'Metallerin ve Plastiklerin Fiziki ve Mekanik Yüzey İşlemlerinden ve Biçimlendirilmesinden Kaynaklanan Atıklar', NULL, NULL, 1, '1201', 12, 0, 'Metallerin ve Plastiklerin Fiziki ve Mekanik Yüzey Islemlerinden ve Biçimlendirilmesinden Kaynaklanan Atiklar', '12', 'Metallerin ve Plastiklerin Fiziki ve Mekanik Yüzey İşlemlerinden ve Biçimlendirilmesinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1603, 'Standart Dışı Gruplar ve Kullanılmamış Ürünler', NULL, NULL, 1, '1603', 16, 0, 'Standart Disi Gruplar ve Kullanilmamis Ürünler', '16', 'Standart Dışı Gruplar ve Kullanılmamış Ürünler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1604, 'Patlayıcı Atıklar', NULL, NULL, 1, '1604', 16, 0, 'Patlayici Atiklar', '16', 'Patlayıcı Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160403, 'Diğer patlayıcı atıklar', NULL, 1, 1, '160403', 1604, 1, 'Diger patlayici atiklar', '1604', 'Diğer patlayıcı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160504, 'Basınçlı tanklar içinde tehlikeli maddeler içeren gazlar (halonlar dahil)', NULL, 1, 1, '160504', 1605, 1, 'Basinçli tanklar içinde tehlikeli maddeler içeren gazlar (halonlar dahil)', '1605', 'Basınçlı tanklar içinde tehlikeli maddeler içeren gazlar (halonlar dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160509, '16 05 06, 16 05 07 ya da 16 05 08 dışındaki ıskarta kimyasallar', NULL, NULL, 0, '160509', 1605, 0, '16 05 06, 16 05 07 ya da 16 05 08 disindaki iskarta kimyasallar', '1605', '16 05 06, 16 05 07 ya da 16 05 08 dışındaki ıskarta kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1607, 'Nakliye Tankı, Depolama Tankı ve Varil Temizleme İşlemlerinden Kaynaklanan Atıklar (05 ve 13 hariç)', NULL, NULL, 1, '1607', 16, 0, 'Nakliye Tanki, Depolama Tanki ve Varil Temizleme Islemlerinden Kaynaklanan Atiklar (05 ve 13 hariç)', '16', 'Nakliye Tankı, Depolama Tankı ve Varil Temizleme İşlemlerinden Kaynaklanan Atıklar (05 ve 13 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160801, 'Altın, gümüş, renyum, rodyum, paladyum, iridyum ya da platin içeren bitik katalizörler (16 08 07 hariç)', NULL, NULL, 0, '160801', 1608, 0, 'Altin, gümüs, renyum, rodyum, paladyum, iridyum ya da platin içeren bitik katalizörler (16 08 07 hariç)', '1608', 'Altın, gümüş, renyum, rodyum, paladyum, iridyum ya da platin içeren bitik katalizörler (16 08 07 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160803, 'Başka bir şekilde tanımlanmamış ara metaller ve ara metal bileşenleri içeren bitik katalizörler', NULL, NULL, 0, '160803', 1608, 0, 'Baska bir sekilde tanimlanmamis ara metaller ve ara metal bilesenleri içeren bitik katalizörler', '1608', 'Başka bir şekilde tanımlanmamış ara metaller ve ara metal bileşenleri içeren bitik katalizörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160903, 'Peroksitler(örneğin hidrojen peroksit)', NULL, 1, 1, '160903', 1609, 1, 'Peroksitler(örnegin hidrojen peroksit)', '1609', 'Peroksitler(örneğin hidrojen peroksit)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1610, 'Saha Dışı Arıtmaya Gönderilecek Sulu Sıvı Atıklar', NULL, NULL, 1, '1610', 16, 0, 'Saha Disi Aritmaya Gönderilecek Sulu Sivi Atiklar', '16', 'Saha Dışı Arıtmaya Gönderilecek Sulu Sıvı Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1611, 'Atık Astarlar ve Refraktörler', NULL, NULL, 1, '1611', 16, 0, 'Atik Astarlar ve Refraktörler', '16', 'Atık Astarlar ve Refraktörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161101, 'Metalürjik proseslerden kaynaklanan, tehlikeli maddeler içeren karbon bazlı astarlar ve refraktörler', NULL, 1, 1, '161101', 1611, 1, 'Metalürjik proseslerden kaynaklanan, tehlikeli maddeler içeren karbon bazli astarlar ve refraktörler', '1611', 'Metalürjik proseslerden kaynaklanan, tehlikeli maddeler içeren karbon bazlı astarlar ve refraktörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (2001, 'Ayrı Toplanan Fraksiyonlar (15 01 Hariç)', NULL, NULL, 1, '2001', 20, 0, 'Ayri Toplanan Fraksiyonlar (15 01 Hariç)', '20', 'Ayrı Toplanan Fraksiyonlar (15 01 Hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190811, 'Endüstriyel atık suyun biyolojik arıtılmasından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '190811', 1908, 1, 'Endüstriyel atik suyun biyolojik aritilmasindan kaynaklanan tehlikeli maddeler içeren çamurlar', '1908', 'Endüstriyel atık suyun biyolojik arıtılmasından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190814, '19 08 13 dışındaki endüstriyel atık suyun diğer yöntemlerle arıtılmasından kaynaklanan çamurlar', NULL, NULL, 0, '190814', 1908, 0, '19 08 13 disindaki endüstriyel atik suyun diger yöntemlerle aritilmasindan kaynaklanan çamurlar', '1908', '19 08 13 dışındaki endüstriyel atık suyun diğer yöntemlerle arıtılmasından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190904, 'Kullanılmış aktif karbon', NULL, NULL, 0, '190904', 1909, 0, 'Kullanilmis aktif karbon', '1909', 'Kullanılmış aktif karbon');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190906, 'İyon değiştiricilerinin rejenerasyonundan kaynaklanan solüsyonlar ve çamurlar', NULL, NULL, 0, '190906', 1909, 0, 'Iyon degistiricilerinin rejenerasyonundan kaynaklanan solüsyonlar ve çamurlar', '1909', 'İyon değiştiricilerinin rejenerasyonundan kaynaklanan solüsyonlar ve çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191001, 'Demir ve çelik atıkları', NULL, NULL, 0, '191001', 1910, 0, 'Demir ve çelik atiklari', '1910', 'Demir ve çelik atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191004, '19 10 03 dışındaki uçucu atık parçacıkları ve tozlar', NULL, NULL, 0, '191004', 1910, 0, '19 10 03 disindaki uçucu atik parçaciklari ve tozlar', '1910', '19 10 03 dışındaki uçucu atık parçacıkları ve tozlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191104, 'Yakıtların bazlarla temizlenmesinden kaynaklanan atıklar', NULL, 1, 1, '191104', 1911, 1, 'Yakitlarin bazlarla temizlenmesinden kaynaklanan atiklar', '1911', 'Yakıtların bazlarla temizlenmesinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191106, '19 11 05 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '191106', 1911, 0, '19 11 05 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '1911', '19 11 05 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191206, 'Tehlikeli maddeler içeren ahşap', NULL, 1, 1, '191206', 1912, 1, 'Tehlikeli maddeler içeren ahsap', '1912', 'Tehlikeli maddeler içeren ahşap');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191209, 'Mineraller (örneğin kum, taşlar)', NULL, NULL, 0, '191209', 1912, 0, 'Mineraller (örnegin kum, taslar)', '1912', 'Mineraller (örneğin kum, taşlar)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191211, 'Atıkların mekanik işlenmesinden kaynaklanan tehlikeli maddeler içeren diğer atıklar (karışık malzemeler dahil)', NULL, 1, 1, '191211', 1912, 1, 'Atiklarin mekanik islenmesinden kaynaklanan tehlikeli maddeler içeren diger atiklar (karisik malzemeler dahil)', '1912', 'Atıkların mekanik işlenmesinden kaynaklanan tehlikeli maddeler içeren diğer atıklar (karışık malzemeler dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191303, 'Toprak ıslahından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '191303', 1913, 1, 'Toprak islahindan kaynaklanan tehlikeli maddeler içeren çamurlar', '1913', 'Toprak ıslahından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191306, '19 13 05 dışındaki yeraltı suyunun ıslahından kaynaklanan çamurlar', NULL, NULL, 0, '191306', 1913, 0, '19 13 05 disindaki yeralti suyunun islahindan kaynaklanan çamurlar', '1913', '19 13 05 dışındaki yeraltı suyunun ıslahından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1706, 'Yalıtım Malzemeleri ve Asbest İçeren İnşaat Malzemeleri', NULL, NULL, 1, '1706', 17, 0, 'Yalitim Malzemeleri ve Asbest Içeren Insaat Malzemeleri', '17', 'Yalıtım Malzemeleri ve Asbest İçeren İnşaat Malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1708, 'Alçı Bazlı İnşaat Malzemeleri', NULL, NULL, 1, '1708', 17, 0, 'Alçi Bazli Insaat Malzemeleri', '17', 'Alçı Bazlı İnşaat Malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1709, 'Diğer İnşaat ve Yıkıntı Atıkları', NULL, NULL, 1, '1709', 17, 0, 'Diger Insaat ve Yikinti Atiklari', '17', 'Diğer İnşaat ve Yıkıntı Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170902, 'PCB içeren inşaat ve yıkıntı atıkları (örneğin PCB içeren dolgu macunları, PCB içeren reçine bazlı taban kaplama malzemeleri, PCB içeren kaplanmış sırlama birimleri, PCB içeren kapasitörler)', NULL, 2, 1, '170902', 1709, 1, 'PCB içeren insaat ve yikinti atiklari (örnegin PCB içeren dolgu macunlari, PCB içeren reçine bazli taban kaplama malzemeleri, PCB içeren kaplanmis sirlama birimleri, PCB içeren kapasitörler)', '1709', 'PCB içeren inşaat ve yıkıntı atıkları (örneğin PCB içeren dolgu macunları, PCB içeren reçine bazlı taban kaplama malzemeleri, PCB içeren kaplanmış sırlama birimleri, PCB içeren kapasitörler)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1801, 'İnsanlarda Doğum, Teşhis, Tedavi ya da Hastalık Önleme Çalışmalarından Kaynaklanan Atıklar', NULL, NULL, 1, '1801', 18, 0, 'Insanlarda Dogum, Teshis, Tedavi ya da Hastalik Önleme Çalismalarindan Kaynaklanan Atiklar', '18', 'İnsanlarda Doğum, Teşhis, Tedavi ya da Hastalık Önleme Çalışmalarından Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180103, 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olan atıklar', NULL, 2, 1, '180103', 1801, 1, 'Enfeksiyonu önlemek amaci ile toplanmalari ve bertarafi özel isleme tabi olan atiklar', '1801', 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180104, 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olmayan atıklar (örneğin sargılar, vücut alçıları, tek kullanımlık giysiler, alt bezleri)', NULL, NULL, 0, '180104', 1801, 0, 'Enfeksiyonu önlemek amaci ile toplanmalari ve bertarafi özel isleme tabi olmayan atiklar (örnegin sargilar, vücut alçilari, tek kullanimlik giysiler, alt bezleri)', '1801', 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olmayan atıklar (örneğin sargılar, vücut alçıları, tek kullanımlık giysiler, alt bezleri)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180202, 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olan atıklar', NULL, 2, 1, '180202', 1802, 1, 'Enfeksiyonu önlemek amaci ile toplanmalari ve bertarafi özel isleme tabi olan atiklar', '1802', 'Enfeksiyonu önlemek amacı ile toplanmaları ve bertarafı özel işleme tabi olan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (19, 'ATIK YÖNETİM TESİSLERİNDEN, TESİS DIŞI ATIK SU ARITMA TESİSLERİNDEN VE İNSAN TÜKETİMİ VE ENDÜSTRİYEL KULLANIM İÇİN SU HAZIRLAMA TESİSLERİNDEN KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '19', 0, 0, 'ATIK YÖNETIM TESISLERINDEN, TESIS DISI ATIK SU ARITMA TESISLERINDEN VE INSAN TÜKETIMI VE ENDÜSTRIYEL KULLANIM IÇIN SU HAZIRLAMA TESISLERINDEN KAYNAKLANAN ATIKLAR', NULL, 'ATIK YÖNETİM TESİSLERİNDEN, TESİS DIŞI ATIK SU ARITMA TESİSLERİNDEN VE İNSAN TÜKETİMİ VE ENDÜSTRİYEL KULLANIM İÇİN SU HAZIRLAMA TESİSLERİNDEN KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190107, 'Gaz arıtımından kaynaklanan katı atıklar', NULL, 1, 1, '190107', 1901, 1, 'Gaz aritimindan kaynaklanan kati atiklar', '1901', 'Gaz arıtımından kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190111, 'Tehlikeli maddeler içeren taban külü ve cüruf', NULL, 1, 1, '190111', 1901, 1, 'Tehlikeli maddeler içeren taban külü ve cüruf', '1901', 'Tehlikeli maddeler içeren taban külü ve cüruf');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190117, 'Tehlikeli maddeler içeren piroliz atıkları', NULL, 1, 1, '190117', 1901, 1, 'Tehlikeli maddeler içeren piroliz atiklari', '1901', 'Tehlikeli maddeler içeren piroliz atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (191308, '19 13 07 dışındaki yeraltı suyunun ıslahından kaynaklanan sulu sıvı atıklar ve sulu konsantrasyonlar', NULL, NULL, 0, '191308', 1913, 0, '19 13 07 disindaki yeralti suyunun islahindan kaynaklanan sulu sivi atiklar ve sulu konsantrasyonlar', '1913', '19 13 07 dışındaki yeraltı suyunun ıslahından kaynaklanan sulu sıvı atıklar ve sulu konsantrasyonlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200121, 'Flüoresan lambalar ve diğer cıva içeren atıklar', NULL, 1, 1, '200121', 2001, 1, 'Flüoresan lambalar ve diger civa içeren atiklar', '2001', 'Flüoresan lambalar ve diğer cıva içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200126, '20 01 25 dışındaki sıvı ve katı yağlar', NULL, 1, 1, '200126', 2001, 1, '20 01 25 disindaki sivi ve kati yaglar', '2001', '20 01 25 dışındaki sıvı ve katı yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200132, '20 01 31 dışındaki ilaçlar', NULL, NULL, 0, '200132', 2001, 0, '20 01 31 disindaki ilaçlar', '2001', '20 01 31 dışındaki ilaçlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200133, '16 06 01, 16 06 02 veya 16 06 03?un altında geçen pil ve akümülatörler ve bu pilleri içeren sınıflandırılmamış karışık pil ve akümülatörler', NULL, 2, 1, '200133', 2001, 1, '16 06 01, 16 06 02 veya 16 06 03?un altinda geçen pil ve akümülatörler ve bu pilleri içeren siniflandirilmamis karisik pil ve akümülatörler', '2001', '16 06 01, 16 06 02 veya 16 06 03?un altında geçen pil ve akümülatörler ve bu pilleri içeren sınıflandırılmamış karışık pil ve akümülatörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200137, 'Tehlikeli maddeler içeren ahşap', NULL, 1, 1, '200137', 2001, 1, 'Tehlikeli maddeler içeren ahsap', '2001', 'Tehlikeli maddeler içeren ahşap');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200141, 'Baca temizliğinden kaynaklanan atıklar', NULL, NULL, 0, '200141', 2001, 0, 'Baca temizliginden kaynaklanan atiklar', '2001', 'Baca temizliğinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (2003, 'Diğer Belediye Atıkları', NULL, NULL, 1, '2003', 20, 0, 'Diger Belediye Atiklari', '20', 'Diğer Belediye Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200302, 'Pazarlardan kaynaklanan atıklar', NULL, NULL, 0, '200302', 2003, 0, 'Pazarlardan kaynaklanan atiklar', '2003', 'Pazarlardan kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200399, 'Başka bir şekilde tanımlanmamış belediye atıkları', NULL, NULL, 0, '200399', 2003, 0, 'Baska bir sekilde tanimlanmamis belediye atiklari', '2003', 'Başka bir şekilde tanımlanmamış belediye atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100906, '10 09 05 dışında henüz döküm yapılamamış maça ve kum döküm kalıpları', NULL, NULL, 0, '100906', 1009, 0, '10 09 05 disinda henüz döküm yapilamamis maça ve kum döküm kaliplari', '1009', '10 09 05 dışında henüz döküm yapılamamış maça ve kum döküm kalıpları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101201, 'Isıl işlem öncesi karışım hazırlama atıkları', NULL, NULL, 0, '101201', 1012, 0, 'Isil islem öncesi karisim hazirlama atiklari', '1012', 'Isıl işlem öncesi karışım hazırlama atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100199', 1001, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1001', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100322, '10 03 21 dışındaki partiküller ve tozlar (öğütücü değirmen tozu dahil)', NULL, NULL, 0, '100322', 1003, 0, '10 03 21 disindaki partiküller ve tozlar (ögütücü degirmen tozu dahil)', '1003', '10 03 21 dışındaki partiküller ve tozlar (öğütücü değirmen tozu dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (30105, '03 01 04 dışındaki talaş, yonga, kıymık, ahşap, kontraplak ve kaplamalar', NULL, NULL, 0, '030105', 301, 0, '03 01 04 disindaki talas, yonga, kiymik, ahsap, kontraplak ve kaplamalar', '0301', '03 01 04 dışındaki talaş, yonga, kıymık, ahşap, kontraplak ve kaplamalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101313, '10 13 12 dışındaki gaz arıtma katı atıkları', NULL, NULL, 0, '101313', 1013, 0, '10 13 12 disindaki gaz aritma kati atiklari', '1013', '10 13 12 dışındaki gaz arıtma katı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120101, 'Demir metal çapakları ve talaşları', NULL, NULL, 0, '120101', 1201, 0, 'Demir metal çapaklari ve talaslari', '1201', 'Demir metal çapakları ve talaşları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (130112, 'Kolayca biyolojik olarak bozunabilir hidrolik yağlar', 1, 2, 1, '130112', 1301, 1, 'Kolayca biyolojik olarak bozunabilir hidrolik yaglar', '1301', 'Kolayca biyolojik olarak bozunabilir hidrolik yağlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160112, '16 01 11 dışındaki fren balataları', NULL, NULL, 0, '160112', 1601, 0, '16 01 11 disindaki fren balatalari', '1601', '16 01 11 dışındaki fren balataları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160508, 'Tehlikeli maddeler içeren ya da bunlardan oluşan ıskarta organik kimyasallar', NULL, 1, 1, '160508', 1605, 1, 'Tehlikeli maddeler içeren ya da bunlardan olusan iskarta organik kimyasallar', '1605', 'Tehlikeli maddeler içeren ya da bunlardan oluşan ıskarta organik kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170801, 'Tehlikeli maddeler ile kontamine olmuş alçı bazlı inşaat malzemeleri', NULL, 1, 1, '170801', 1708, 1, 'Tehlikeli maddeler ile kontamine olmus alçi bazli insaat malzemeleri', '1708', 'Tehlikeli maddeler ile kontamine olmuş alçı bazlı inşaat malzemeleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190401, 'Vitrifiye edilmiş atıklar', NULL, NULL, 0, '190401', 1904, 0, 'Vitrifiye edilmis atiklar', '1904', 'Vitrifiye edilmiş atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200117, 'Foto kimyasallar', NULL, 1, 1, '200117', 2001, 1, 'Foto kimyasallar', '2001', 'Foto kimyasallar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200128, '20 01 27 dışındaki boya, mürekkepler, yapıştırıcılar ve reçineler', NULL, NULL, 0, '200128', 2001, 0, '20 01 27 disindaki boya, mürekkepler, yapistiricilar ve reçineler', '2001', '20 01 27 dışındaki boya, mürekkepler, yapıştırıcılar ve reçineler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161104, '16 11 03 dışındaki metalürjik proseslerden kaynaklanan diğer astar ve refraktörler', NULL, NULL, 0, '161104', 1611, 0, '16 11 03 disindaki metalürjik proseslerden kaynaklanan diger astar ve refraktörler', '1611', '16 11 03 dışındaki metalürjik proseslerden kaynaklanan diğer astar ve refraktörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161106, '16 11 05 dışındaki metalürjik olmayan proseslerden kaynaklanan astar ve refraktörler', NULL, NULL, 0, '161106', 1611, 0, '16 11 05 disindaki metalürjik olmayan proseslerden kaynaklanan astar ve refraktörler', '1611', '16 11 05 dışındaki metalürjik olmayan proseslerden kaynaklanan astar ve refraktörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1701, 'Beton, Tuğla, Kiremit ve Seramik', NULL, NULL, 1, '1701', 17, 0, 'Beton, Tugla, Kiremit ve Seramik', '17', 'Beton, Tuğla, Kiremit ve Seramik');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170106, 'Tehlikeli maddeler içeren beton, tuğla, kiremit ve seramik karışımları ya da ayrılmış grupları', NULL, 1, 1, '170106', 1701, 1, 'Tehlikeli maddeler içeren beton, tugla, kiremit ve seramik karisimlari ya da ayrilmis gruplari', '1701', 'Tehlikeli maddeler içeren beton, tuğla, kiremit ve seramik karışımları ya da ayrılmış grupları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170204, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerle kontamine olmuş ahşap, cam ve plastik', NULL, 1, 1, '170204', 1702, 1, 'Tehlikeli maddeler içeren ya da tehlikeli maddelerle kontamine olmus ahsap, cam ve plastik', '1702', 'Tehlikeli maddeler içeren ya da tehlikeli maddelerle kontamine olmuş ahşap, cam ve plastik');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170405, 'Demir ve çelik', NULL, NULL, 0, '170405', 1704, 0, 'Demir ve çelik', '1704', 'Demir ve çelik');
INSERT INTO "e-izin"."atikKodGecici" VALUES (170409, 'Tehlikeli maddelerle kontamine olmuş metal atıkları', NULL, 1, 1, '170409', 1704, 1, 'Tehlikeli maddelerle kontamine olmus metal atiklari', '1704', 'Tehlikeli maddelerle kontamine olmuş metal atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1705, 'Toprak (Kirlenmiş Yerlerde Yapılan Hafriyat Dahil), Kayalar ve Dip Tarama Çamurları', NULL, NULL, 1, '1705', 17, 0, 'Toprak (Kirlenmis Yerlerde Yapilan Hafriyat Dahil), Kayalar ve Dip Tarama Çamurlari', '17', 'Toprak (Kirlenmiş Yerlerde Yapılan Hafriyat Dahil), Kayalar ve Dip Tarama Çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1902, 'Atıkların Fiziki/Kimyasal Arıtımından Kaynaklanan Atıklar (Krom Giderme, Siyanür Giderme, Nötralizasyon Dahil)', NULL, NULL, 1, '1902', 19, 0, 'Atiklarin Fiziki/Kimyasal Aritimindan Kaynaklanan Atiklar (Krom Giderme, Siyanür Giderme, Nötralizasyon Dahil)', '19', 'Atıkların Fiziki/Kimyasal Arıtımından Kaynaklanan Atıklar (Krom Giderme, Siyanür Giderme, Nötralizasyon Dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190205, 'Fiziksel ve kimyasal işlemlerden kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '190205', 1902, 1, 'Fiziksel ve kimyasal islemlerden kaynaklanan tehlikeli maddeler içeren çamurlar', '1902', 'Fiziksel ve kimyasal işlemlerden kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1903, 'Stabilize Edilmiş/Katılaştırılmış Atıklar4', NULL, NULL, 1, '1903', 19, 0, 'Stabilize Edilmis/Katilastirilmis Atiklar4', '19', 'Stabilize Edilmiş/Katılaştırılmış Atıklar4');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190305, '19 03 04 dışındaki stabilize olmuş atıklar', NULL, NULL, 0, '190305', 1903, 0, '19 03 04 disindaki stabilize olmus atiklar', '1903', '19 03 04 dışındaki stabilize olmuş atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190307, '19 03 06 dışındaki katılaştırılmış atıklar', NULL, NULL, 0, '190307', 1903, 0, '19 03 06 disindaki katilastirilmis atiklar', '1903', '19 03 06 dışındaki katılaştırılmış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190402, 'Uçucu kül ve diğer baca gazı arıtma atıkları', NULL, 1, 1, '190402', 1904, 1, 'Uçucu kül ve diger baca gazi aritma atiklari', '1904', 'Uçucu kül ve diğer baca gazı arıtma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1905, 'Katı Atıkların Aerobik Arıtımından Kaynaklanan Atıklar', NULL, NULL, 1, '1905', 19, 0, 'Kati Atiklarin Aerobik Aritimindan Kaynaklanan Atiklar', '19', 'Katı Atıkların Aerobik Arıtımından Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190599, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '190599', 1905, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1905', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190603, 'Belediye atıklarının anaerobik arıtımından kaynaklanan sıvılar', NULL, NULL, 0, '190603', 1906, 0, 'Belediye atiklarinin anaerobik aritimindan kaynaklanan sivilar', '1906', 'Belediye atıklarının anaerobik arıtımından kaynaklanan sıvılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190604, 'Belediye atıklarının anaerobik arıtımından kaynaklanan posalar', NULL, NULL, 0, '190604', 1906, 0, 'Belediye atiklarinin anaerobik aritimindan kaynaklanan posalar', '1906', 'Belediye atıklarının anaerobik arıtımından kaynaklanan posalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190606, 'Hayvansal ve bitkisel atıklarını anaerobik arıtımından kaynaklanan posalar', NULL, NULL, 0, '190606', 1906, 0, 'Hayvansal ve bitkisel atiklarini anaerobik aritimindan kaynaklanan posalar', '1906', 'Hayvansal ve bitkisel atıklarını anaerobik arıtımından kaynaklanan posalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1908, 'Başka Bir Şekilde Tanımlanmamış Atık Su Arıtma Tesisi Atıkları', NULL, NULL, 1, '1908', 19, 0, 'Baska Bir Sekilde Tanimlanmamis Atik Su Aritma Tesisi Atiklari', '19', 'Başka Bir Şekilde Tanımlanmamış Atık Su Arıtma Tesisi Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190806, 'Doymuş ya da kullanılmış iyon değiştirici reçineler', NULL, 1, 1, '190806', 1908, 1, 'Doymus ya da kullanilmis iyon degistirici reçineler', '1908', 'Doymuş ya da kullanılmış iyon değiştirici reçineler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190809, 'Yağ ve su ayrışmasından kaynaklanan sadece yenilebilir yağlar içeren yağ karışımları ve gres', NULL, NULL, 0, '190809', 1908, 0, 'Yag ve su ayrismasindan kaynaklanan sadece yenilebilir yaglar içeren yag karisimlari ve gres', '1908', 'Yağ ve su ayrışmasından kaynaklanan sadece yenilebilir yağlar içeren yağ karışımları ve gres');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70611, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '070611', 706, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0706', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (607, 'Halojenlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Halojenli Kimyasal İşlemlerden Kaynaklanan Atıklar', NULL, NULL, 1, '0607', 6, 0, 'Halojenlerin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) ve Halojenli Kimyasal Islemlerden Kaynaklanan Atiklar', '06', 'Halojenlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Halojenli Kimyasal İşlemlerden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (608, 'Silikon ve Silikon Türevlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0608', 6, 0, 'Silikon ve Silikon Türevlerinin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '06', 'Silikon ve Silikon Türevlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (609, 'Fosforlu Kimyasalların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Fosforlu Kimyasal İşlenmesinden Kaynaklanan Atıklar', NULL, NULL, 1, '0609', 6, 0, 'Fosforlu Kimyasallarin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) ve Fosforlu Kimyasal Islenmesinden Kaynaklanan Atiklar', '06', 'Fosforlu Kimyasalların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) ve Fosforlu Kimyasal İşlenmesinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (610, 'Gübre Üretimi ve Azotlu Kimyasalların İşlenmesi ve Azot Kimyasalları İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0610', 6, 0, 'Gübre Üretimi ve Azotlu Kimyasallarin Islenmesi ve Azot Kimyasallari Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '06', 'Gübre Üretimi ve Azotlu Kimyasalların İşlenmesi ve Azot Kimyasalları İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (61399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '061399', 613, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0613', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (701, 'Temel Organik Kimyasal Maddelerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0701', 7, 0, 'Temel Organik Kimyasal Maddelerin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '07', 'Temel Organik Kimyasal Maddelerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70104, 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070104', 701, 1, 'Diger organik çözücüler, yikama sivilari ve ana çözeltiler', '0701', 'Diğer organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70110, 'Diğer filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070110', 701, 1, 'Diger filtre kekleri ve kullanilmis absorbanlar', '0701', 'Diğer filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (702, 'Plastiklerin, Sentetik Kauçuk ve Yapay Elyafların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0702', 7, 0, 'Plastiklerin, Sentetik Kauçuk ve Yapay Elyaflarin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '07', 'Plastiklerin, Sentetik Kauçuk ve Yapay Elyafların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70207, 'Halojenli dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070207', 702, 1, 'Halojenli dip tortusu ve reaksiyon kalintilari', '0702', 'Halojenli dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70209, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070209', 702, 1, 'Halojenli filtre kekleri ve kullanilmis absorbanlar', '0702', 'Halojenli filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70212, '07 02 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '070212', 702, 0, '07 02 11 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0702', '07 02 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70217, '07 02 16 dışında zararlı silikon içeren atıklar', NULL, NULL, 0, '070217', 702, 0, '07 02 16 disinda silikon içeren atiklar', '0702', '07 02 16 dışında silikon içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70303, 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070303', 703, 1, 'Halojenli organik çözücüler, yikama sivilari ve ana çözeltiler', '0703', 'Halojenli organik çözücüler, yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70307, 'Halojenli dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070307', 703, 1, 'Halojenli dip tortusu ve reaksiyon kalintilari', '0703', 'Halojenli dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70311, 'Saha içi atıksu arıtmından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '070311', 703, 1, 'Saha içi atiksu aritmindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0703', 'Saha içi atıksu arıtmından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (704, 'Organik Bitki Koruma Ürünlerinin (02 01 08 ve 02 01 09 hariç), Ahşap Koruyucu Olarak Kullanılan Maddelerin ( Ajanlarının) (03 02 Hariç) ve Diğer Biositlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0704', 7, 0, 'Organik Bitki Koruma Ürünlerinin (02 01 08 ve 02 01 09 hariç), Ahsap Koruyucu Olarak Kullanilan Maddelerin ( Ajanlarinin) (03 02 Hariç) ve Diger Biositlerin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '07', 'Organik Bitki Koruma Ürünlerinin (02 01 08 ve 02 01 09 hariç), Ahşap Koruyucu Olarak Kullanılan Maddelerin ( Ajanlarının) (03 02 Hariç) ve Diğer Biositlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70410, 'Diğer filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070410', 704, 1, 'Diger filtre kekleri ve kullanilmis absorbanlar', '0704', 'Diğer filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70413, 'Tehlikeli madde içeren katı atıklar', NULL, 1, 1, '070413', 704, 1, 'Tehlikeli madde içeren kati atiklar', '0704', 'Tehlikeli madde içeren katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (705, 'İlaçların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0705', 7, 0, 'Ilaçlarin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '07', 'İlaçların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70509, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070509', 705, 1, 'Halojenli filtre kekleri ve kullanilmis absorbanlar', '0705', 'Halojenli filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70512, '07 05 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '070512', 705, 0, '07 05 11 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0705', '07 05 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (706, 'Yağ, Gres, Sabun, Deterjan, Dezenfektan ve Kozmetiklerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0706', 7, 0, 'Yag, Gres, Sabun, Deterjan, Dezenfektan ve Kozmetiklerin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '07', 'Yağ, Gres, Sabun, Deterjan, Dezenfektan ve Kozmetiklerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70607, 'Halojenli dip tortuları ve reaksiyon kalıntıları', NULL, 1, 1, '070607', 706, 1, 'Halojenli dip tortulari ve reaksiyon kalintilari', '0706', 'Halojenli dip tortuları ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (707, 'Başka Bir Şekilde Tanımlanmamış Kimyasal ve Kimyasal Ürünlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0707', 7, 0, 'Baska Bir Sekilde Tanimlanmamis Kimyasal ve Kimyasal Ürünlerinin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '07', 'Başka Bir Şekilde Tanımlanmamış Kimyasal ve Kimyasal Ürünlerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70709, 'Halojenli filtre kekleri ve kullanılmış absorbanlar', NULL, 1, 1, '070709', 707, 1, 'Halojenli filtre kekleri ve kullanilmis absorbanlar', '0707', 'Halojenli filtre kekleri ve kullanılmış absorbanlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70712, '07 07 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '070712', 707, 0, '07 07 11 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '0707', '07 07 11 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (8, 'ASTARLAR (BOYALAR, VERNİKLER VE VİTRİFİYE EMAYELER), YAPIŞKANLAR, MACUNLAR VE BASKI MÜREKKEPLERİNİN ÜRETİM, FORMÜLASYON, TEDARİK VE KULLANIMINDAN (İFTK) KAYNAKLANAN ATIKLAR', NULL, NULL, 1, '08', 0, 0, 'ASTARLAR (BOYALAR, VERNIKLER VE VITRIFIYE EMAYELER), YAPISKANLAR, MACUNLAR VE BASKI MÜREKKEPLERININ ÜRETIM, FORMÜLASYON, TEDARIK VE KULLANIMINDAN (IFTK) KAYNAKLANAN ATIKLAR', NULL, 'ASTARLAR (BOYALAR, VERNİKLER VE VİTRİFİYE EMAYELER), YAPIŞKANLAR, MACUNLAR VE BASKI MÜREKKEPLERİNİN ÜRETİM, FORMÜLASYON, TEDARİK VE KULLANIMINDAN (İFTK) KAYNAKLANAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80114, '08 01 13 dışındaki boya ve vernik çamurları', NULL, NULL, 0, '080114', 801, 0, '08 01 13 disindaki boya ve vernik çamurlari', '0801', '08 01 13 dışındaki boya ve vernik çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80116, '08 01 15 dışındaki boya ve vernik içeren sulu çamurlar', NULL, NULL, 0, '080116', 801, 0, '08 01 15 disindaki boya ve vernik içeren sulu çamurlar', '0801', '08 01 15 dışındaki boya ve vernik içeren sulu çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80117, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve verniğin sökülmesinden kaynaklanan atıklar', NULL, 1, 1, '080117', 801, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren boya ve vernigin sökülmesinden kaynaklanan atiklar', '0801', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren boya ve verniğin sökülmesinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100329, 'Tuz cürufları ve kara cürufların arıtımından çıkan ve tehlikeli maddeler içeren atıklar', NULL, 1, 1, '100329', 1003, 1, 'Tuz cüruflari ve kara cüruflarin aritimindan çikan ve tehlikeli maddeler içeren atiklar', '1003', 'Tuz cürufları ve kara cürufların arıtımından çıkan ve tehlikeli maddeler içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1004, 'Kurşun Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, NULL, 1, '1004', 10, 0, 'Kursun Isil Metalurjisinden Kaynaklanan Atiklar', '10', 'Kurşun Isıl Metalurjisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100405, 'Diğer partiküller ve toz', NULL, 1, 1, '100405', 1004, 1, 'Diger partiküller ve toz', '1004', 'Diğer partiküller ve toz');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100410, '10 04 09 dışındaki soğutma suyu arıtma atıkları', NULL, NULL, 0, '100410', 1004, 0, '10 04 09 disindaki sogutma suyu aritma atiklari', '1004', '10 04 09 dışındaki soğutma suyu arıtma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100501, 'Birincil ve ikincil üretim cürufları', NULL, NULL, 0, '100501', 1005, 0, 'Birincil ve ikincil üretim cüruflari', '1005', 'Birincil ve ikincil üretim cürufları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100506, 'Gaz arıtım çamurları ve filtre kekleri', NULL, 1, 1, '100506', 1005, 1, 'Gaz aritim çamurlari ve filtre kekleri', '1005', 'Gaz arıtım çamurları ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100509, '10 05 08 dışındaki soğutma suyu arıtma atıkları', NULL, NULL, 0, '100509', 1005, 0, '10 05 08 disindaki sogutma suyu aritma atiklari', '1005', '10 05 08 dışındaki soğutma suyu arıtma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80416, '08 04 15 dışındaki yapışkan veya dolgu macunlarının sulu atıkları', NULL, NULL, 0, '080416', 804, 0, '08 04 15 disindaki yapiskan veya dolgu macunlarinin sulu atiklari', '0804', '08 04 15 dışındaki yapışkan veya dolgu macunlarının sulu atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100510, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir cüruf ve köpükler', NULL, 1, 1, '100510', 1005, 1, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çikaran yanici veya yayilabilir cüruf ve köpükler', '1005', 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir cüruf ve köpükler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100606, 'Gaz arıtımından kaynaklanan katı atıklar', NULL, 1, 1, '100606', 1006, 1, 'Gaz aritimindan kaynaklanan kati atiklar', '1006', 'Gaz arıtımından kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100699, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '100699', 1006, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1006', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100702, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', NULL, NULL, 0, '100702', 1007, 0, 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler', '1007', 'Birincil ve ikincil üretimden kaynaklanan cüruf ve köpükler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100707, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar', NULL, 1, 1, '100707', 1007, 1, 'Sogutma suyunun aritilmasindan kaynaklanan yag içeren atiklar', '1007', 'Soğutma suyunun arıtılmasından kaynaklanan yağ içeren atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100808, 'Birincil ve ikincil üretimden kaynaklanan tuz cürufu', NULL, 1, 1, '100808', 1008, 1, 'Birincil ve ikincil üretimden kaynaklanan tuz cürufu', '1008', 'Birincil ve ikincil üretimden kaynaklanan tuz cürufu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100810, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir cüruf ve köpükler', NULL, 1, 1, '100810', 1008, 1, 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çikaran yanici veya yayilabilir cüruf ve köpükler', '1008', 'Suyla temas halinde tehlikeli miktarlarda alevlenebilir gazlar çıkaran yanıcı veya yayılabilir cüruf ve köpükler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100818, '10 08 17 dışındaki gaz arıtma çamurları ve filtre kekleri', NULL, NULL, 0, '100818', 1008, 0, '10 08 17 disindaki gaz aritma çamurlari ve filtre kekleri', '1008', '10 08 17 dışındaki gaz arıtma çamurları ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100820, '10 08 19 dışındaki soğutma suyu arıtma atıkları', NULL, NULL, 0, '100820', 1008, 0, '10 08 19 disindaki sogutma suyu aritma atiklari', '1008', '10 08 19 dışındaki soğutma suyu arıtma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100905, 'Henüz döküm yapılamamış, tehlikeli madde içeren maça ve kum döküm kalıpları', NULL, 1, 1, '100905', 1009, 1, 'Henüz döküm yapilamamis, tehlikeli madde içeren maça ve kum döküm kaliplari', '1009', 'Henüz döküm yapılamamış, tehlikeli madde içeren maça ve kum döküm kalıpları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100909, 'Tehlikeli maddeler içeren baca gazı tozu', NULL, 1, 1, '100909', 1009, 1, 'Tehlikeli maddeler içeren baca gazi tozu', '1009', 'Tehlikeli maddeler içeren baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100913, 'Tehlikeli maddeler içeren atık bağlayıcılar', NULL, 1, 1, '100913', 1009, 1, 'Tehlikeli maddeler içeren atik baglayicilar', '1009', 'Tehlikeli maddeler içeren atık bağlayıcılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100916, '10 09 15 dışındaki çatlak belirleme kimyasalları atığı', NULL, NULL, 0, '100916', 1009, 0, '10 09 15 disindaki çatlak belirleme kimyasallari atigi', '1009', '10 09 15 dışındaki çatlak belirleme kimyasalları atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101005, 'Henüz döküm yapılamamış, tehlikeli madde içeren maça ve kum döküm kalıpları', NULL, 1, 1, '101005', 1010, 1, 'Henüz döküm yapilamamis, tehlikeli madde içeren maça ve kum döküm kaliplari', '1010', 'Henüz döküm yapılamamış, tehlikeli madde içeren maça ve kum döküm kalıpları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101009, 'Tehlikeli maddeler içeren baca gazı tozu', NULL, 1, 1, '101009', 1010, 1, 'Tehlikeli maddeler içeren baca gazi tozu', '1010', 'Tehlikeli maddeler içeren baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101015, 'Tehlikeli madde içeren çatlak belirleme kimyasalları atığı', NULL, 1, 1, '101015', 1010, 1, 'Tehlikeli madde içeren çatlak belirleme kimyasallari atigi', '1010', 'Tehlikeli madde içeren çatlak belirleme kimyasalları atığı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1011, 'Cam ve Cam Ürünleri Üretim Atıkları', NULL, NULL, 1, '1011', 10, 0, 'Cam ve Cam Ürünleri Üretim Atiklari', '10', 'Cam ve Cam Ürünleri Üretim Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101111, 'Ağır metaller içeren küçük parçacıklar ve cam tozu halinde atık cam(örneğin katot ışın tüplerinden)', NULL, 1, 1, '101111', 1011, 1, 'Agir metaller içeren küçük parçaciklar ve cam tozu halinde atik cam(örnegin katot isin tüplerinden)', '1011', 'Ağır metaller içeren küçük parçacıklar ve cam tozu halinde atık cam(örneğin katot ışın tüplerinden)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101115, 'Baca gazı arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar', NULL, 1, 1, '101115', 1011, 1, 'Baca gazi aritimindan kaynaklanan tehlikeli maddeler içeren kati atiklar', '1011', 'Baca gazı arıtımından kaynaklanan tehlikeli maddeler içeren katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101118, '10 11 17 dışındaki baca gazı arıtımından kaynaklanan çamurlar ve filtre kekleri', NULL, NULL, 0, '101118', 1011, 0, '10 11 17 disindaki baca gazi aritimindan kaynaklanan çamurlar ve filtre kekleri', '1011', '10 11 17 dışındaki baca gazı arıtımından kaynaklanan çamurlar ve filtre kekleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1012, 'Seramik Ürünler, Tuğlalar, Fayanslar ve İnşaat Malzemelerinin Üretiminden Kaynaklanan Atıklar', NULL, NULL, 1, '1012', 10, 0, 'Seramik Ürünler, Tuglalar, Fayanslar ve Insaat Malzemelerinin Üretiminden Kaynaklanan Atiklar', '10', 'Seramik Ürünler, Tuğlalar, Fayanslar ve İnşaat Malzemelerinin Üretiminden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (802, 'Diğer Kaplama Maddelerinin (Seramik Kaplama Dahil) İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0802', 8, 0, 'Diger Kaplama Maddelerinin (Seramik Kaplama Dahil) Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '08', 'Diğer Kaplama Maddelerinin (Seramik Kaplama Dahil) İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (803, 'Baskı Mürekkeplerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0803', 8, 0, 'Baski Mürekkeplerinin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '08', 'Baskı Mürekkeplerinin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80315, '08 05 14 dışındaki mürekkep çamurları', NULL, NULL, 0, '080315', 803, 0, '08 05 14 disindaki mürekkep çamurlari', '0803', '08 05 14 dışındaki mürekkep çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80399, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '080399', 803, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0803', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (804, 'Yapışkanlar ve Yalıtıcıların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar (Su Geçirmeyen Ürünler Dahil)', NULL, NULL, 1, '0804', 8, 0, 'Yapiskanlar ve Yaliticilarin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar (Su Geçirmeyen Ürünler Dahil)', '08', 'Yapışkanlar ve Yalıtıcıların İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar (Su Geçirmeyen Ürünler Dahil)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80411, 'Organik çözücüler ya da diğer tehlikeli maddeler içeren yapışkan ve dolgu macunu çamurları', NULL, 1, 1, '080411', 804, 1, 'Organik çözücüler ya da diger tehlikeli maddeler içeren yapiskan ve dolgu macunu çamurlari', '0804', 'Organik çözücüler ya da diğer tehlikeli maddeler içeren yapışkan ve dolgu macunu çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90107, 'Gümüş veya da gümüş bileşenleri içeren fotoğraf filmi ve kağıdı', NULL, NULL, 0, '090107', 901, 0, 'Gümüs veya da gümüs bilesenleri içeren fotograf filmi ve kagidi', '0901', 'Gümüş veya da gümüş bileşenleri içeren fotoğraf filmi ve kağıdı');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90110, 'Pilsiz çalışan tek kullanımlık fotoğraf makineleri', NULL, NULL, 0, '090110', 901, 0, 'Pilsiz çalisan tek kullanimlik fotograf makineleri', '0901', 'Pilsiz çalışan tek kullanımlık fotoğraf makineleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90112, '09 01 11 dışındaki pille çalışan tek kullanımlık fotoğraf makineleri', NULL, NULL, 0, '090112', 901, 0, '09 01 11 disindaki pille çalisan tek kullanimlik fotograf makineleri', '0901', '09 01 11 dışındaki pille çalışan tek kullanımlık fotoğraf makineleri');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '090199', 901, 0, 'Baska bir sekilde tanimlanmamis atiklar', '0901', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1001, 'Enerji Santrallerinden ve Diğer Yakma Tesislerinden Kaynaklanan Atıklar (19 Hariç)', NULL, NULL, 1, '1001', 10, 0, 'Enerji Santrallerinden ve Diger Yakma Tesislerinden Kaynaklanan Atiklar (19 Hariç)', '10', 'Enerji Santrallerinden ve Diğer Yakma Tesislerinden Kaynaklanan Atıklar (19 Hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100105, 'Baca gazı kükürt giderme işleminden (desülfrizasyon) çıkan kalsiyum bazlı katı atıklar', NULL, NULL, 0, '100105', 1001, 0, 'Baca gazi kükürt giderme isleminden (desülfrizasyon) çikan kalsiyum bazli kati atiklar', '1001', 'Baca gazı kükürt giderme işleminden (desülfrizasyon) çıkan kalsiyum bazlı katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100116, 'Atıkların birlikte yakılmasından (co-incineration) kaynaklanan ve tehlikeli maddeler içeren uçucu kül', NULL, 1, 1, '100116', 1001, 1, 'Atiklarin birlikte yakilmasindan (co-incineration) kaynaklanan ve tehlikeli maddeler içeren uçucu kül', '1001', 'Atıkların birlikte yakılmasından (co-incineration) kaynaklanan ve tehlikeli maddeler içeren uçucu kül');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100119, '10 01 05, 10 01 07 ve 10 01 18 dışındaki gaz temizleme atıkları', NULL, NULL, 0, '100119', 1001, 0, '10 01 05, 10 01 07 ve 10 01 18 disindaki gaz temizleme atiklari', '1001', '10 01 05, 10 01 07 ve 10 01 18 dışındaki gaz temizleme atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100121, '10 01 20 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar', NULL, NULL, 0, '100121', 1001, 0, '10 01 20 disindaki saha içi atiksu aritimindan kaynaklanan çamurlar', '1001', '10 01 20 dışındaki saha içi atıksu arıtımından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100124, 'Akışkan yatak kumları', NULL, NULL, 0, '100124', 1001, 0, 'Akiskan yatak kumlari', '1001', 'Akışkan yatak kumları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1002, 'Demir ve Çelik Endüstrisinden Kaynaklanan Atıklar', NULL, NULL, 1, '1002', 10, 0, 'Demir ve Çelik Endüstrisinden Kaynaklanan Atiklar', '10', 'Demir ve Çelik Endüstrisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100207, 'Tehlikeli maddeler içeren gazların arıtımı sonucu ortaya çıkan katı atıklar', NULL, 1, 1, '100207', 1002, 1, 'Tehlikeli maddeler içeren gazlarin aritimi sonucu ortaya çikan kati atiklar', '1002', 'Tehlikeli maddeler içeren gazların arıtımı sonucu ortaya çıkan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100212, '10 02 11 dışındaki soğutma suyu arıtma atıkları', NULL, NULL, 0, '100212', 1002, 0, '10 02 11 disindaki sogutma suyu aritma atiklari', '1002', '10 02 11 dışındaki soğutma suyu arıtma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1003, 'Alüminyum Isıl Metalurjisinden Kaynaklanan Atıklar', NULL, NULL, 1, '1003', 10, 0, 'Alüminyum Isil Metalurjisinden Kaynaklanan Atiklar', '10', 'Alüminyum Isıl Metalurjisinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100309, 'İkincil üretimden kaynaklanan kara cüruflar', NULL, 1, 1, '100309', 1003, 1, 'Ikincil üretimden kaynaklanan kara cüruflar', '1003', 'İkincil üretimden kaynaklanan kara cüruflar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100316, '10 03 05 dışındaki köpükler', NULL, NULL, 0, '100316', 1003, 0, '10 03 05 disindaki köpükler', '1003', '10 03 05 dışındaki köpükler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100318, '10 03 17 dışındaki anot üretiminden kaynaklanan karbon içerikli atıklar', NULL, NULL, 0, '100318', 1003, 0, '10 03 17 disindaki anot üretiminden kaynaklanan karbon içerikli atiklar', '1003', '10 03 17 dışındaki anot üretiminden kaynaklanan karbon içerikli atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100323, 'Tehlikeli maddeler içeren gaz arıtımı katı atıkları', NULL, 1, 1, '100323', 1003, 1, 'Tehlikeli maddeler içeren gaz aritimi kati atiklari', '1003', 'Tehlikeli maddeler içeren gaz arıtımı katı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100327, 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar', NULL, 1, 1, '100327', 1003, 1, 'Sogutma suyunun aritilmasindan kaynaklanan yag içerikli atiklar', '1003', 'Soğutma suyunun arıtılmasından kaynaklanan yağ içerikli atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1, 'MADENLERİN ARANMASI, ÇIKARILMASI, İŞLETİLMESİ, FİZİKİ VE KİMYASAL İŞLEME TABİ TUTULMASI SIRASINDA ORTAYA ÇIKAN ATIKLAR', NULL, NULL, 1, '01', 0, 0, '(01) MADENLERIN ARANMASI, ÇIKARILMASI, ISLETILMESI, FIZIKI VE KIMYASAL ISLEME TABI TUTULMASI SIRASINDA ORTAYA ÇIKAN ATIKLAR', NULL, 'MADENLERİN ARANMASI, ÇIKARILMASI, İŞLETİLMESİ, FİZİKİ VE KİMYASAL İŞLEME TABİ TUTULMASI SIRASINDA ORTAYA ÇIKAN ATIKLAR');
INSERT INTO "e-izin"."atikKodGecici" VALUES (103, 'Metalik Minerallerin Fiziki ve Kimyasal Olarak İşlenmesinden Kaynaklanan Atıklar', NULL, NULL, 1, '0103', 1, 0, 'Metalik Minerallerin Fiziki ve Kimyasal Olarak Islenmesinden Kaynaklanan Atiklar', '01', 'Metalik Minerallerin Fiziki ve Kimyasal Olarak İşlenmesinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10309, '01 03 10 dışındaki alüminyum oksit üretiminden çıkan kırmızı çamur', NULL, NULL, 0, '010309', 103, 0, '01 03 10 disindaki alüminyum oksit üretiminden çikan kirmizi çamur', '0103', '01 03 10 dışındaki alüminyum oksit üretiminden çıkan kırmızı çamur');
INSERT INTO "e-izin"."atikKodGecici" VALUES (104, 'Metalik Olmayan Minerallerin Fiziki ve Kimyasal İşlemlerinden Kaynaklanan Atıklar', NULL, NULL, 1, '0104', 1, 0, 'Metalik Olmayan Minerallerin Fiziki ve Kimyasal Islemlerinden Kaynaklanan Atiklar', '01', 'Metalik Olmayan Minerallerin Fiziki ve Kimyasal İşlemlerinden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10410, '01 04 07 dışındaki tozumsu ve pudramsı atıklar', NULL, NULL, 0, '010410', 104, 0, '01 04 07 disindaki tozumsu ve pudramsi atiklar', '0104', '01 04 07 dışındaki tozumsu ve pudramsı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10412, '01 04 07 ve 01 04 11 dışındaki minerallerin yıkanması ve temizlenmesinden kaynaklanan ince taneli atıklar ve diğer atıklar', NULL, NULL, 0, '010412', 104, 0, '01 04 07 ve 01 04 11 disindaki minerallerin yikanmasi ve temizlenmesinden kaynaklanan ince taneli atiklar ve diger atiklar', '0104', '01 04 07 ve 01 04 11 dışındaki minerallerin yıkanması ve temizlenmesinden kaynaklanan ince taneli atıklar ve diğer atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10504, 'Temizsu sondaj çamurları ve atıkları', NULL, NULL, 0, '010504', 105, 0, 'Temizsu sondaj çamurlari ve atiklari', '0105', 'Temizsu sondaj çamurları ve atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10506, 'Tehlikeli maddeler içeren sondaj çamurları ve diğer sondaj atıkları', NULL, 1, 1, '010506', 105, 1, 'Tehlikeli maddeler içeren sondaj çamurlari ve diger sondaj atiklari', '0105', 'Tehlikeli maddeler içeren sondaj çamurları ve diğer sondaj atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10508, '01 05 05 ve 01 05 06 dışındaki klorür içeren sondaj çamurları ve atıkları', NULL, NULL, 0, '010508', 105, 0, '01 05 05 ve 01 05 06 disindaki klorür içeren sondaj çamurlari ve atiklari', '0105', '01 05 05 ve 01 05 06 dışındaki klorür içeren sondaj çamurları ve atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (201, 'Tarım, Bahçıvanlık, Su Ürünleri Üretimi, Ormancılık, Avcılık ve Balıkçılıktan Kaynaklanan Atıklar', NULL, NULL, 1, '0201', 2, 0, 'Tarim, Bahçivanlik, Su Ürünleri Üretimi, Ormancilik, Avcilik ve Balikçiliktan Kaynaklanan Atiklar', '02', 'Tarım, Bahçıvanlık, Su Ürünleri Üretimi, Ormancılık, Avcılık ve Balıkçılıktan Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (20106, 'Ayrı toplanmış ve saha dışında işlem görecek hayvan pislikleri, idrar ve tezek (pisletilmiş saman dahil), akan sıvılar', NULL, NULL, 0, '020106', 201, 0, 'Ayri toplanmis ve saha disinda islem görecek hayvan pislikleri, idrar ve tezek (pisletilmis saman dahil), akan sivilar', '0201', 'Ayrı toplanmış ve saha dışında işlem görecek hayvan pislikleri, idrar ve tezek (pisletilmiş saman dahil), akan sıvılar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (40219, 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar', NULL, 1, 1, '040219', 402, 1, 'Saha içi atiksu aritimindan kaynaklanan tehlikeli maddeler içeren çamurlar', '0402', 'Saha içi atıksu arıtımından kaynaklanan tehlikeli maddeler içeren çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70101, 'Su bazlı yıkama sıvıları ve ana çözeltiler', NULL, 1, 1, '070101', 701, 1, 'Su bazli yikama sivilari ve ana çözeltiler', '0701', 'Su bazlı yıkama sıvıları ve ana çözeltiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (70508, 'Diğer dip tortusu ve reaksiyon kalıntıları', NULL, 1, 1, '070508', 705, 1, 'Diger dip tortusu ve reaksiyon kalintilari', '0705', 'Diğer dip tortusu ve reaksiyon kalıntıları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100703, 'Gaz arıtımından kaynaklanan katı atıklar', NULL, NULL, 0, '100703', 1007, 0, 'Gaz aritimindan kaynaklanan kati atiklar', '1007', 'Gaz arıtımından kaynaklanan katı atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101013, 'Tehlikeli maddeler içeren bağlayıcı atıkları', NULL, 1, 1, '101013', 1010, 1, 'Tehlikeli maddeler içeren baglayici atiklari', '1010', 'Tehlikeli maddeler içeren bağlayıcı atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100101, '(10 01 04?ün altındaki kazan tozu hariç) dip külü, cüruf ve kazan tozu', NULL, NULL, 0, '100101', 1001, 0, '(10 01 04?ün altindaki kazan tozu hariç) dip külü, cüruf ve kazan tozu', '1001', '(10 01 04?ün altındaki kazan tozu hariç) dip külü, cüruf ve kazan tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10411, '01 04 07 dışındaki potas ve kaya tuzu işlemesinden kaynaklanan atıklar', NULL, NULL, 0, '010411', 104, 0, '01 04 07 disindaki potas ve kaya tuzu islemesinden kaynaklanan atiklar', '0104', '01 04 07 dışındaki potas ve kaya tuzu işlemesinden kaynaklanan atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (1014, 'Krematoryum Atıkları', NULL, NULL, 1, '1014', 10, 0, 'Krematoryum Atiklari', '10', 'Krematoryum Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80501, 'Atık izosiyanatlar', NULL, 1, 1, '080501', 805, 1, 'Atik izosiyanatlar', '0805', 'Atık izosiyanatlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (901, 'Fotoğraf Endüstrisi Atıkları', NULL, NULL, 1, '0901', 9, 0, 'Fotograf Endüstrisi Atiklari', '09', 'Fotoğraf Endüstrisi Atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (90102, 'Su bazlı ofset plakası banyo solüsyonu', NULL, 1, 1, '090102', 901, 1, 'Su bazli ofset plakasi banyo solüsyonu', '0901', 'Su bazlı ofset plakası banyo solüsyonu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (110302, 'Diğer atıklar', NULL, 1, 1, '110302', 1103, 1, 'Diger atiklar', '1103', 'Diğer atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120116, 'Tehlikeli maddeler içeren kumlama maddeleri atıkları', NULL, 1, 1, '120116', 1201, 1, 'Tehlikeli maddeler içeren kumlama maddeleri atiklari', '1201', 'Tehlikeli maddeler içeren kumlama maddeleri atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (601, 'Asitlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar', NULL, NULL, 1, '0601', 6, 0, 'Asitlerin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar', '06', 'Asitlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (150203, '15 02 02 dışındaki emiciler, filtre malzemeleri, temizleme bezleri, koruyucu giysiler', NULL, NULL, 0, '150203', 1502, 0, '15 02 02 disindaki emiciler, filtre malzemeleri, temizleme bezleri, koruyucu giysiler', '1502', '15 02 02 dışındaki emiciler, filtre malzemeleri, temizleme bezleri, koruyucu giysiler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (161105, 'Metalürjik olmayan proseslerden kaynaklanan, tehlikeli maddeler içeren astarlar ve refraktörler', NULL, 1, 1, '161105', 1611, 1, 'Metalürjik olmayan proseslerden kaynaklanan, tehlikeli maddeler içeren astarlar ve refraktörler', '1611', 'Metalürjik olmayan proseslerden kaynaklanan, tehlikeli maddeler içeren astarlar ve refraktörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190304, '19 03 08 dışındaki tehlikeli olarak işaretlenmiş kısmen (6) stabilize olmuş atıklar', NULL, 1, 1, '190304', 1903, 1, '19 03 08 dişindaki tehlikeli olarak isaretlenmis kismen (6) stabilize olmus atiklar', '1903', 'Tehlikeli olarak işaretlenmiş kısmen (6) stabilize olmuş atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190810, '19 08 09 dışındaki yağ ve su ayrışmasından çıkan yağ karışımları ve gres', NULL, 1, 1, '190810', 1908, 1, '19 08 09 disindaki yag ve su ayrismasindan çikan yag karisimlari ve gres', '1908', '19 08 09 dışındaki yağ ve su ayrışmasından çıkan yağ karışımları ve gres');
INSERT INTO "e-izin"."atikKodGecici" VALUES (200131, 'Sitotoksik ve sitostatik ilaçlar', NULL, 1, 1, '200131', 2001, 1, 'Sitotoksik ve sitostatik ilaçlar', '2001', 'Sitotoksik ve sitostatik ilaçlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100102, 'Uçucu kömür külü', NULL, NULL, 0, '100102', 1001, 0, 'Uçucu kömür külü', '1001', 'Uçucu kömür külü');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160304, '16 03 03 dışındaki inorganik atıklar', NULL, NULL, 0, '160304', 1603, 0, '16 03 03 disindaki inorganik atiklar', '1603', '16 03 03 dışındaki inorganik atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120199, 'Başka bir şekilde tanımlanmamış atıklar', NULL, NULL, 0, '120199', 1201, 0, 'Baska bir sekilde tanimlanmamis atiklar', '1201', 'Başka bir şekilde tanımlanmamış atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100328, '10 03 27 dışındaki soğutma suyu arıtma atıkları', NULL, NULL, 0, '100328', 1003, 0, '10 03 27 disindaki sogutma suyu aritma atiklari', '1003', '10 03 27 dışındaki soğutma suyu arıtma atıkları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190902, 'Su berraklaştırılmasından kaynaklanan çamurlar', NULL, NULL, 0, '190902', 1909, 0, 'Su berraklastirilmasindan kaynaklanan çamurlar', '1909', 'Su berraklaştırılmasından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190812, '19 08 11 dışındaki endüstriyel atık suyun biyolojik arıtılmasından kaynaklanan çamurlar', NULL, NULL, 0, '190812', 1908, 0, '19 08 11 disindaki endüstriyel atik suyun biyolojik aritilmasindan kaynaklanan çamurlar', '1908', '19 08 11 dışındaki endüstriyel atık suyun biyolojik arıtılmasından kaynaklanan çamurlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (703, 'Organik Boyaların ve Pigmentlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar(06 11 dışındaki)', NULL, NULL, 1, '0703', 7, 0, 'Organik Boyalarin ve Pigmentlerin Imalat, Formülasyon, Tedarik ve Kullanimindan (IFTK) Kaynaklanan Atiklar(06 11 disindaki)', '07', 'Organik Boyaların ve Pigmentlerin İmalat, Formülasyon, Tedarik ve Kullanımından (İFTK) Kaynaklanan Atıklar(06 11 dışındaki)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (101010, '10 10 09 dışındaki baca gazı tozu', NULL, NULL, 0, '101010', 1010, 0, '10 10 09 disindaki baca gazi tozu', '1010', '10 10 09 dışındaki baca gazı tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (80314, 'Tehlikeli maddeler içeren mürekkep çamurları', NULL, 1, 1, '080314', 803, 1, 'Tehlikeli maddeler içeren mürekkep çamurlari', '0803', 'Tehlikeli maddeler içeren mürekkep çamurları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (100115, '10 01 14 dışındaki birlikte yakılmadan (co-incineration) kaynaklanan dip külü, cüruf ve kazan tozu', NULL, NULL, 0, '100115', 1001, 0, '10 01 14 disindaki birlikte yakilmadan (co-incineration) kaynaklanan dip külü, cüruf ve kazan tozu', '1001', '10 01 14 dışındaki birlikte yakılmadan (co-incineration) kaynaklanan dip külü, cüruf ve kazan tozu');
INSERT INTO "e-izin"."atikKodGecici" VALUES (301, 'Ağaç İşlemeden ve Sunta ve Mobilya Üretiminden Kaynaklanan Atıklar', NULL, NULL, 1, '0301', 3, 0, 'Agaç Islemeden ve Sunta ve Mobilya Üretiminden Kaynaklanan Atiklar', '03', 'Ağaç İşlemeden ve Sunta ve Mobilya Üretiminden Kaynaklanan Atıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (120104, 'Demir dışı metal toz ve parçacıklar', NULL, NULL, 0, '120104', 1201, 0, 'Demir disi metal toz ve parçaciklar', '1201', 'Demir dışı metal toz ve parçacıklar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160108, 'Cıva içeren parçalar', NULL, 1, 1, '160108', 1601, 1, 'Civa içeren parçalar', '1601', 'Cıva içeren parçalar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160807, 'Tehlikeli maddelerle kontamine olmuş bitik katalizörler', NULL, 1, 1, '160807', 1608, 1, 'Tehlikeli maddelerle kontamine olmus bitik katalizörler', '1608', 'Tehlikeli maddelerle kontamine olmuş bitik katalizörler');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180207, 'Sitotoksik ve sitostatik ilaçlar', NULL, 1, 1, '180207', 1802, 1, 'Sitotoksik ve sitostatik ilaçlar', '1802', 'Sitotoksik ve sitostatik ilaçlar');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190703, '19 07 02 dışındaki düzenli depolama sahası sızıntı suları', NULL, NULL, 0, '190703', 1907, 0, '19 07 02 disindaki düzenli depolama sahasi sizinti sulari', '1907', '19 07 02 dışındaki düzenli depolama sahası sızıntı suları');
INSERT INTO "e-izin"."atikKodGecici" VALUES (180201, 'Kesiciler (18 02 02 hariç)', NULL, 2, 0, '180201', 1802, 0, 'Kesiciler (18 02 02 hariç)', '1802', 'Kesiciler (18 02 02 hariç)');
INSERT INTO "e-izin"."atikKodGecici" VALUES (10310, '01 03 07 dışındaki alüminyum oksit üretiminden çıkan tehlikeli maddeler içeren kırmızı çamur', NULL, NULL, 1, '010310', 103, 1, '01 03 07 dışındaki alüminyum oksit üretiminden çıkan tehlikeli maddeler içeren kırmızı çamur', NULL, '01 03 07 dışındaki alüminyum oksit üretiminden çıkan tehlikeli maddeler içeren kırmızı çamur');
INSERT INTO "e-izin"."atikKodGecici" VALUES (160307, 'Metalik cıva', NULL, NULL, 1, '160307', 1603, 1, 'Metalik cıva', NULL, 'Metalik cıva');
INSERT INTO "e-izin"."atikKodGecici" VALUES (190308, 'Kısmen stabilize olmuş cıva', NULL, NULL, 1, '190308', 1903, 1, 'Kismen stabilize olmuş civa', NULL, 'Kısmen stabilize olmuş cıva');


--
-- Data for Name: AltBasvuruAtikKodu; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruAtikKoduAsama; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruLisansIptal; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruLisansIptalAsama; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruLisansVize; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruLisansVizeAsama; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruSurucu; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruSurucuAsama; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruTasimaArac; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruTasimaAracAsama; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AltBasvuruTasimaAracOdeme; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: AtikTehlikelilikOzellik; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."AtikTehlikelilikOzellik" VALUES ('02dd98ec-1bbb-4afa-aa15-f46388e66c84', '2023-06-22 11:51:01.224759', '82d6cbf7-c4da-40ce-93d2-da92257afde8', NULL, NULL, 0, 4, NULL, NULL, '4585a073-9bd2-430b-9990-d22422fb1d00');
INSERT INTO public."AtikTehlikelilikOzellik" VALUES ('3bd590dd-06ad-467c-bbf4-655ec25fda1e', '2023-06-22 14:09:51.131748', 'b7fa947b-038b-49e5-b734-4d89df76393f', NULL, NULL, 0, 13, NULL, NULL, '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8');
INSERT INTO public."AtikTehlikelilikOzellik" VALUES ('8617b19b-3fff-4c6d-9121-700b50ab2ec7', '2023-06-22 14:09:51.131552', 'edd7635f-6dee-44aa-a45c-75d9b409ac2c', NULL, NULL, 0, 5, NULL, NULL, '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8');
INSERT INTO public."AtikTehlikelilikOzellik" VALUES ('9f30b138-ae0d-496f-bc19-f3022d6edc46', '2023-06-22 14:09:51.130905', '5cef9af3-6038-4757-a175-294cc49b5e97', NULL, NULL, 0, 1, NULL, NULL, '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8');
INSERT INTO public."AtikTehlikelilikOzellik" VALUES ('ca7d15c1-96a2-460a-9901-ee57bdc68aed', '2023-06-22 14:09:51.131338', '0af1b6a4-caca-4136-b518-9d4c69263249', NULL, NULL, 0, 4, NULL, NULL, '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8');


--
-- Data for Name: AtyonAtikKod; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."AtyonAtikKod" VALUES ('a45b9f86-371f-442e-954b-2a4633331485', '2023-06-22 11:51:01.311818', 'dfdeaee1-869d-42e2-8341-957431bad0e7', NULL, NULL, 0, '4585a073-9bd2-430b-9990-d22422fb1d00', 2);


--
-- Data for Name: AtyonBasvuru; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."AtyonBasvuru" VALUES ('48519c61-9f8d-4379-8ae8-28a781561f7d', '2023-06-22 11:36:54.597564', '100b8aad-d349-478a-90f4-4048b9490935', NULL, NULL, 10, 'd957f7d7-c18d-4d90-b887-433b28a4911d', 'd957f7d7-c18d-4d90-b887-433b28a4911d', 5, NULL, NULL, 'e6921d00-ce37-4791-93ac-5eb67d99f737', 'e73363f8-0f91-443c-809d-694e2b06e2c3', NULL);
INSERT INTO public."AtyonBasvuru" VALUES ('f23d6df0-09e5-4085-8120-85df8c349d3d', '2023-06-21 21:35:34.147467', '6d5a4e54-a4fb-4bb3-8714-107e3864366e', NULL, NULL, 5, '252f3ac6-5063-48f9-986e-fb62217afd61', '252f3ac6-5063-48f9-986e-fb62217afd61', NULL, NULL, NULL, '040824bf-dade-4667-bcc3-dc7fc943ceb8', 'e73363f8-0f91-443c-809d-694e2b06e2c3', NULL);


--
-- Data for Name: AtyonBasvuruBelge; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."AtyonBasvuruBelge" VALUES ('a2895676-f0df-4951-92d9-4428e9e11e80', '2023-06-22 11:48:09.138213', 'eb33d35f-329b-4590-ba31-e005c5755da9', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '2023-08-07 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('91a67186-0273-41a7-84a1-6d2a9cb2259e', '2023-06-22 11:48:25.592273', '709bb303-f466-46a2-8889-5f16dc73bdd5', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 2, '2023-07-09 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('98221093-7295-477f-a4a5-c2af0ab2ae1d', '2023-06-22 11:37:03.012654', '7b0fe2c0-b4be-49f5-ba75-a9a8078f59ec', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '2023-08-07 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('9688b047-4783-48ee-9ccb-885845496073', '2023-06-22 11:39:01.260347', '22272382-abfb-4018-9fa6-098dae920134', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 3, '2023-06-30 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('cfc64910-cd23-479a-a0bb-4640c4be292c', '2023-06-22 11:42:00.917541', '067103f6-1683-49a6-b447-aaeaf3c032c7', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 4, '2023-06-30 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('1a5829db-79c5-411d-b2d5-13a61a483e81', '2023-06-22 11:42:19.684888', '639612c0-0897-4719-a618-96b8af96445c', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 2, '2023-06-30 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('9c2f51b2-50cb-42dd-a68b-9dfaac4aad1a', '2023-06-22 11:42:32.55313', 'c3b64138-7c2c-4705-a244-77e168dbec65', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 5, '2023-08-07 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('7bb02ed7-4349-4ed5-9571-d0d5bc57c21d', '2023-06-22 14:11:30.618028', '907baf01-0601-43ea-9dd8-ccbc148ace2d', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 3, '2023-06-29 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('6ca85cc5-8f83-4358-b0cd-c15cce25eb97', '2023-06-22 14:11:45.131604', '2d182c62-ae20-4264-9739-d7b10c0d9b88', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 4, '2023-06-29 00:00:00');
INSERT INTO public."AtyonBasvuruBelge" VALUES ('3dc7d8ca-2de7-479a-8c48-af4a7db64b08', '2023-06-22 14:11:54.634418', '83b2f88e-14bc-45b5-a5b2-5b802879a640', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', '00000000-0000-0000-0000-000000000000', NULL, NULL, 5, '2023-08-07 00:00:00');


--
-- Data for Name: AtyonBasvuruCevreMuhendisi; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."AtyonBasvuruCevreMuhendisi" VALUES ('46508e9b-24b8-493e-9137-74cb4b2a7b27', '2023-06-21 21:35:38.153215', 'e1f9fe4a-2a61-48bf-9199-94d6274f7d4f', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', '51322476134');
INSERT INTO public."AtyonBasvuruCevreMuhendisi" VALUES ('e65752db-0e00-478d-a4bc-755620b1ba58', '2023-06-22 11:36:55.860124', '63fe680e-a1cc-4e13-a38b-e8d7e2b1185e', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', '51322476134');


--
-- Data for Name: BasvuruAsama; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."BasvuruAsama" VALUES ('7f95a5d0-98d8-496d-ba12-18817d359079', '2023-06-22 11:56:06.132828', 'd20a7bdb-ecb7-46bc-8992-06c144754580', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', 'Şube Müdürü bu başvuruyu değerlendirsin.', 2, 15, 3, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('86f45b10-b9b4-4274-955b-3285aa7a355b', '2023-06-22 12:00:01.271371', 'ba6a3a51-5b28-4e4a-beb5-84ba3c7006af', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', 'Uzman, bu başvuruyu değerlendirsin.', 2, 3, 4, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('8d6d7494-086a-429a-83e4-0ec4d0829b16', '2023-06-22 12:04:34.640009', '8c434524-18a8-4e5e-9515-5e2836a481b8', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', 'rett', 2, 4, 6, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('eada9488-20fe-4744-90d0-2309381bafd8', '2023-06-22 11:54:10.888269', '3b2463fb-cdfb-4f94-a966-efe170587e02', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', 'başvuruyu onaya göndermek istiyorum.', 2, 1, 15, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('f500a5d2-48ae-4cb2-b5dc-079f080f057f', '2023-06-22 11:36:54.627798', '07d51f78-6f84-4023-9766-7bf1b0f7b250', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', '', 2, NULL, 1, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('dfd70a7c-b4c6-4cbf-8dce-0c8acc7a332c', '2023-06-22 12:11:29.114402', '5ce4e07b-7c17-485e-aba6-f1834168f9e1', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', NULL, 1, 6, 10, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('33c8d56c-4264-465c-9971-410510d42414', '2023-06-22 14:12:07.695612', '4d93c79e-f3a7-48d8-ac81-066c778b83d8', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', 'testtest', 2, 1, 15, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('89f2def7-4ae3-4bf9-a7c1-d243df0b59ce', '2023-06-23 06:53:03.886928', '8311e3ab-2653-4055-a77e-223c09d24d09', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', 'uzman ataması yapıldı..', 2, 3, 4, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('8b776662-6a5e-45cb-8355-2a9f37441140', '2023-06-21 21:35:34.267186', '77f1c147-2dfa-40b7-9229-f3c5a83bd9a2', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', '', 2, NULL, 1, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('a387cced-0557-49c6-93d8-c9d24f53f921', '2023-06-23 06:51:38.6819', 'dcb2a4fb-5c46-45b6-9efd-f78bc8cd71b1', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', 'şube md ataması yapıldı..', 2, 15, 3, NULL);
INSERT INTO public."BasvuruAsama" VALUES ('66c08445-5ba1-4774-b94d-38087817ad88', '2023-06-23 06:55:40.424777', '5c73e335-1df6-4769-b4c3-bd8c25c977b1', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', 'imza sirküsü okunmadığından güncellenmesi gerekmektedir.', 1, 4, 5, NULL);


--
-- Data for Name: BasvuruCevreMuhendisiEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: BasvuruGecmis; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."BasvuruGecmis" VALUES ('3721f42c-ddce-4ea6-b606-7a6b641d8d99', '2023-06-21 21:35:38.186795', 'c21fb95f-cec0-404f-a868-0c5ea8bc3fdb', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', '{"KurulusKullaniciKimlikRef":"252f3ac6-5063-48f9-986e-fb62217afd61","FirmaKimlikRef":"252f3ac6-5063-48f9-986e-fb62217afd61","LisansDurum":null,"LisansTarihi":null,"VizeDurum":null,"GorevliUzmanKimlikRef":null,"GorevliSubeMuduruKimlikRef":null,"GorevliIlMudurYardimcisiKimlikRef":null,"AltBasvuruAtikKodu":[],"AltBasvuruLisansIptal":[],"AltBasvuruLisansVize":[],"AltBasvuruSurucu":[],"AltBasvuruTasimaArac":[],"AtyonBasvuruBelge":[],"AtyonBasvuruCevreMuhendisi":[],"BasvuruAsama":[],"BasvuruGecmis":[],"BasvuruOdeme":[],"BasvuruSurucu":[],"BasvuruTasimaArac":[],"IlDegisikligiBasvuru":[],"Kimlik":"f23d6df0-09e5-4085-8120-85df8c349d3d","Olusturulma":"2023-06-21T21:35:34.147467","Olusturan":"6d5a4e54-a4fb-4bb3-8714-107e3864366e","Guncelleme":null,"Guncelleyen":null,"Durum":1}', '{"KurulusKullaniciKimlikRef":"252f3ac6-5063-48f9-986e-fb62217afd61","FirmaKimlikRef":"252f3ac6-5063-48f9-986e-fb62217afd61","LisansDurum":null,"LisansTarihi":null,"VizeDurum":null,"GorevliUzmanKimlikRef":null,"GorevliSubeMuduruKimlikRef":null,"GorevliIlMudurYardimcisiKimlikRef":null,"AltBasvuruAtikKodu":[],"AltBasvuruLisansIptal":[],"AltBasvuruLisansVize":[],"AltBasvuruSurucu":[],"AltBasvuruTasimaArac":[],"AtyonBasvuruBelge":[],"AtyonBasvuruCevreMuhendisi":[{"AtyonBasvuruKimlikRef":"f23d6df0-09e5-4085-8120-85df8c349d3d","PersonelTCKimlik":"51322476134","BasvuruCevreMuhendisiEksiklik":[],"Kimlik":"46508e9b-24b8-493e-9137-74cb4b2a7b27","Olusturulma":"2023-06-21T21:35:38.1532153+03:00","Olusturan":"e1f9fe4a-2a61-48bf-9199-94d6274f7d4f","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"BasvuruAsama":[],"BasvuruGecmis":[],"BasvuruOdeme":[],"BasvuruSurucu":[],"BasvuruTasimaArac":[],"IlDegisikligiBasvuru":[],"Kimlik":"f23d6df0-09e5-4085-8120-85df8c349d3d","Olusturulma":"2023-06-21T21:35:34.147467","Olusturan":"6d5a4e54-a4fb-4bb3-8714-107e3864366e","Guncelleme":null,"Guncelleyen":null,"Durum":1}');
INSERT INTO public."BasvuruGecmis" VALUES ('c71bc169-ffea-41a8-8dcf-6600309d095d', '2023-06-22 11:36:55.872481', '920519ed-5b89-4ee7-857e-c9f258f7bd29', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', '{"KurulusKullaniciKimlikRef":"d957f7d7-c18d-4d90-b887-433b28a4911d","FirmaKimlikRef":"d957f7d7-c18d-4d90-b887-433b28a4911d","LisansDurum":null,"LisansTarihi":null,"VizeDurum":null,"GorevliUzmanKimlikRef":null,"GorevliSubeMuduruKimlikRef":null,"GorevliIlMudurYardimcisiKimlikRef":null,"AltBasvuruAtikKodu":[],"AltBasvuruLisansIptal":[],"AltBasvuruLisansVize":[],"AltBasvuruSurucu":[],"AltBasvuruTasimaArac":[],"AtyonBasvuruBelge":[],"AtyonBasvuruCevreMuhendisi":[],"BasvuruAsama":[],"BasvuruGecmis":[],"BasvuruOdeme":[],"BasvuruSurucu":[],"BasvuruTasimaArac":[],"IlDegisikligiBasvuru":[],"Kimlik":"48519c61-9f8d-4379-8ae8-28a781561f7d","Olusturulma":"2023-06-22T11:36:54.597564","Olusturan":"100b8aad-d349-478a-90f4-4048b9490935","Guncelleme":null,"Guncelleyen":null,"Durum":1}', '{"KurulusKullaniciKimlikRef":"d957f7d7-c18d-4d90-b887-433b28a4911d","FirmaKimlikRef":"d957f7d7-c18d-4d90-b887-433b28a4911d","LisansDurum":null,"LisansTarihi":null,"VizeDurum":null,"GorevliUzmanKimlikRef":null,"GorevliSubeMuduruKimlikRef":null,"GorevliIlMudurYardimcisiKimlikRef":null,"AltBasvuruAtikKodu":[],"AltBasvuruLisansIptal":[],"AltBasvuruLisansVize":[],"AltBasvuruSurucu":[],"AltBasvuruTasimaArac":[],"AtyonBasvuruBelge":[],"AtyonBasvuruCevreMuhendisi":[{"AtyonBasvuruKimlikRef":"48519c61-9f8d-4379-8ae8-28a781561f7d","PersonelTCKimlik":"51322476134","BasvuruCevreMuhendisiEksiklik":[],"Kimlik":"e65752db-0e00-478d-a4bc-755620b1ba58","Olusturulma":"2023-06-22T11:36:55.8601243+00:00","Olusturan":"63fe680e-a1cc-4e13-a38b-e8d7e2b1185e","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"BasvuruAsama":[],"BasvuruGecmis":[],"BasvuruOdeme":[],"BasvuruSurucu":[],"BasvuruTasimaArac":[],"IlDegisikligiBasvuru":[],"Kimlik":"48519c61-9f8d-4379-8ae8-28a781561f7d","Olusturulma":"2023-06-22T11:36:54.597564","Olusturan":"100b8aad-d349-478a-90f4-4048b9490935","Guncelleme":null,"Guncelleyen":null,"Durum":1}');


--
-- Data for Name: BasvuruOdeme; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: BasvuruOdemeEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: BasvuruSurucu; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."BasvuruSurucu" VALUES ('301cc608-e9bc-45cd-a12b-43e7cada5cd0', '2023-06-22 11:53:05.897039', 'f93e0511-ad3e-4e0a-8d5c-a58cfe21d357', NULL, NULL, 1, '48519c61-9f8d-4379-8ae8-28a781561f7d', 'aeb9a120-0eca-4aa2-a7bf-0c8a900ea394', NULL, NULL);
INSERT INTO public."BasvuruSurucu" VALUES ('2eaaedaf-de5a-4199-b833-35dd34c3d55f', '2023-06-22 14:10:52.134847', 'a38767cc-bd58-4a3b-ac1d-55d804af84a6', NULL, NULL, 1, 'f23d6df0-09e5-4085-8120-85df8c349d3d', 'c09573ee-6aea-4e50-adc8-4444efaf3951', NULL, NULL);


--
-- Data for Name: BasvuruSurucuEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."BasvuruSurucuEksiklik" VALUES ('e77d8b6c-9d0f-43d5-be7d-4ce117dfa45d', '2023-06-22 12:04:22.95229', 'b0f8438a-ab32-41bc-9c9a-5d369b965c2c', NULL, NULL, 1, '301cc608-e9bc-45cd-a12b-43e7cada5cd0', 1, NULL, NULL, NULL, 2);


--
-- Data for Name: BasvuruTasimaArac; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."BasvuruTasimaArac" VALUES ('ef714752-5b8a-4a9f-b2af-00c8f79e6f2e', '2023-06-22 11:51:00.879997', '9872c60e-ecd6-4e75-bfe3-8f2d897a00a8', NULL, NULL, 1, '4585a073-9bd2-430b-9990-d22422fb1d00', '48519c61-9f8d-4379-8ae8-28a781561f7d', NULL, NULL);
INSERT INTO public."BasvuruTasimaArac" VALUES ('65fca7cf-9c53-4640-b9fa-7ef01903fe25', '2023-06-22 14:09:51.126388', '1859ce2c-e43d-4ae4-95b7-1bc52acfd1b8', NULL, NULL, 1, '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8', 'f23d6df0-09e5-4085-8120-85df8c349d3d', NULL, NULL);


--
-- Data for Name: BasvuruTasimaAracEksiklik; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."BasvuruTasimaAracEksiklik" VALUES ('97bd4e95-a0bf-4233-9fc6-15f7128aa94f', '2023-06-22 12:04:15.421194', '20dfe8c8-29eb-422c-a9d3-d31d2039ea4a', NULL, NULL, 1, 'ef714752-5b8a-4a9f-b2af-00c8f79e6f2e', 1, NULL, NULL, NULL, 2);


--
-- Data for Name: EK1EK2; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."EK1EK2" VALUES ('b0b2851b-46e7-4981-886e-62ed653cdf7b', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1000, '1. Enerji Endüstrisi', 0, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('25ea958c-caa1-4d8b-b528-589580a7d24f', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1339, '5.5 Motorlu hava tasitlarinin üretimi.', 1048, 1, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('f52cc12d-aeb2-43cb-a5ee-1e80c99081dd', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1019, '2.Madencilik ve Yapi Malzemeleri Endüstrisi', 0, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('219b23dd-fab4-4201-a5c4-aa321cf6fa41', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1025, '3. Metal Endüstrisi', 0, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('b933aade-d63e-4851-ad7d-5aa0e798c17a', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1035, '4. Kimya ve Petrokimya Endüstrisi', 0, 0, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('b1322948-22df-4170-a40e-537c05d2e4a9', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1048, '5. Yüzey Kaplama Endüstrisi', 0, 0, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('98b6b772-61cc-4915-9624-52139588c202', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1057, '6. Orman Ürünleri ve Selüloz Tesisleri', 0, 0, 6, 1);
INSERT INTO public."EK1EK2" VALUES ('bf7f367a-dbd0-4e0a-902a-9cfcd040153c', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1060, '7. Gida Endüstrisi, Tarim ve Hayvancilik', 0, 0, 7, 1);
INSERT INTO public."EK1EK2" VALUES ('cef26651-ba2b-4bcd-9d73-b12c60d5cc3d', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1063, '8. Atik Yönetimi', 0, 0, 8, 1);
INSERT INTO public."EK1EK2" VALUES ('8a077736-5441-41f5-8637-3e87c495fc97', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1066, '9. Maddelerin Depolanmasi, Doldurma ve Bosaltilmasi      ', 0, 0, 9, 1);
INSERT INTO public."EK1EK2" VALUES ('a6b71ded-01ed-40cc-aff1-68f2f9ed7acd', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1078, '10. Diger Tesisler', 0, 0, 10, 1);
INSERT INTO public."EK1EK2" VALUES ('6175c725-0b5e-47e9-b698-2ce6f4040d66', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 308, '8.7.1 Mekanik Ayırma ', 306, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('6c037d9a-ddc8-4fe6-8777-9edf060b1be7', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 311, '8.7.2 Biyokurutma', 306, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('4bbdf0ce-fac3-42d4-9134-2aeeedcb70ae', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 312, '8.7.3 Biyometanizasyon', 306, 1, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('5de1987f-aaaf-4bda-90d4-184034cf55d2', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 313, '8.7.4 Kompost ', 306, 1, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('04d6a560-9ab7-4441-9977-a3205d1c94b9', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 315, '8.8.1 Depolama', 314, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('d5d929b8-2b97-43ca-9236-3ea7ffe3a169', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 316, '8.8.2 Derine Enjeksiyon', 314, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('ec68c447-ae7a-47d2-9bb2-7d40f5aa56eb', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 318, '8.8.3 Alıcı Ortamda Bertaraf', 314, 1, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('0eac7c8b-5111-4654-9f5c-8d56f41db92b', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1001, '1.1 Termik ve Isi Santralleri ', 1000, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('cb8e41f5-0e6c-4f43-b7cf-46f822d200fd', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1004, '1.2  Asagidaki yakitlari yakan tesisler ', 1000, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('a5ca667e-0aa3-4a75-a2e1-a3a9a797bb96', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1010, '1.3  Yakma isil gücü 100 MW veya üzeri kombine çevrim, birlesik isi güç santralleri, içten yanmali motorlar ve gaz türbinleri. (Mobil santrallerde kullanilan içten yanmali motorlar ve gaz türbinleri dahil).', 1000, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('a8c2a7e9-8ebd-4f54-8ab7-8c7c3c2ab75e', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1011, '1.4 Yakma isil gücü 100 MW veya üzerinde olan jeneratör ve is makinalari tahrikinde kullanilan gaz türbinleri. (Kapali çevrim gaz türbinleri, sondaj tesisleri ve acil durumlarda kullanilan jeneratörler hariç).', 1000, 0, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('98fd1fc9-dd3b-47fb-80ca-a60e8eee7f5f', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1012, '1.6 Katran, katran ürünleri, katran suyu veya gazi damitma ve islenmesiyle ilgili tesisler.', 1000, 1, 6, 1);
INSERT INTO public."EK1EK2" VALUES ('d57d2466-b22f-45e4-986e-acba08ce2d89', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1013, '1.7 Parçalama yoluyla hidrokarbonlardan gaz yakit elde edilen tesisler.', 1000, 1, 7, 1);
INSERT INTO public."EK1EK2" VALUES ('e2c1960b-7b73-4c5d-9ad8-5d41db44b29d', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1014, '1.5 Nükleer güç santralleri', 1000, 1, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('da5c42f2-c00c-4676-98df-f787f3a32050', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1015, '1.8 Rafineriler:', 1000, 0, 8, 1);
INSERT INTO public."EK1EK2" VALUES ('2801a7bf-fcbe-4749-b707-4f81954cec62', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1016, '1.9 Kok firinlari', 1000, 0, 9, 1);
INSERT INTO public."EK1EK2" VALUES ('a127c170-25fa-4a20-a167-b1e5b2068b88', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1018, '1.10 500.000 ton/gün ve üzeri ham petrol veya 500.000m3/gün ve üzeri dogalgazin çikarilmasi.', 1000, 0, 10, 1);
INSERT INTO public."EK1EK2" VALUES ('0ae271a6-f495-4a1c-9fcd-f1a843521a3b', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1002, '1.1.1 Kati  ve  sivi yakitli tesislerden toplam yakma sistemi isil gücü 100 MW veya daha fazla olan tesisler', 1001, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('21c34f27-dd2d-40b7-b80e-b2485c018f02', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1003, '1.1.2 Gaz yakitli tesislerden toplam yakma sistemi isil gücü 100 MW veya daha fazla olan tesisler', 1001, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('c713c318-2ad4-47db-bfde-b964ea842cf5', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1005, '1.2.1 Kati (Kömür, kok, kömür briketi, turba, odun, plastik veya kimyasal maddelerle kaplanmamis ve muameleye tabi tutulmamis odun artiklari, petrol koku) ve sivi (fuel-oil, nafta, motorin, biyodizel vb.) yakitli tesislerden toplam yakma sistemi isil gücü 100 MW veya daha fazla olan tesisler', 1004, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('11276a29-f331-4fab-bd5c-7548e3b485ed', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1006, '1.2.2  Gaz yakit (dogalgaz, sivilastirilmis petrol gazi, kokgazi, yüksek firin gazi, fuel gaz) yakan ve toplam yakma sistemi isil gücü 100 MW veya daha fazla olan tesisler.', 1004, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('965149ae-f5be-40a0-8371-61594416eb0a', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1008, '1.2.3  Biyokütlenin (Pirina, ayçiçegi, pamuk çigiti vb) yakit olarak kullanildigi toplam yakma isil gücü 100 MW veya daha fazla olan tesisler.', 1004, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('f9a02fc8-a2f0-4d78-b968-5e604a3e12e1', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1009, '1.2.4  Yukarida belirtilen yakitlar disindaki, yakit tanimina girmeyen kati ve sivi yanici maddelerle çalisan, toplam yakma isil gücü 50 MW veya üzerinde olan yakma tesisleri.', 1004, 0, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('5bede6e0-000f-47e4-844e-0d7b0c180993', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1020, '2.1 Çimento klinkeri ve entegre çimento üretim tesisleri', 1019, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('2c1488d1-5df8-4c24-9972-69e19908c014', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1021, '2.2 Yakit olarak petrol koku kullanan ve  günlük sonmemis kirec üretim kapasitesi 250 ton ve üzeri olan dolomit,  kireçtasi veya magnezit  pisirme tesisleri', 1019, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('909d7158-12d6-4998-8630-473cde2d3121', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1022, '2.3 Asbest ve asbest içeren ürünleri çikarma, üretme, isleme, dönüsüm tesisleri.', 1019, 1, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('c4cb6e60-21d8-4435-ad0e-3b0a63a82676', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1023, '2.4 300 ton/gün ve üzerinde eritme kapasitesine sahip, cam elyaf dahil cam üretim tesisleri.(Haberlesme ve medikal alanda kullanilan ürünleri hazir cam çubuk, bilye ve kütükten üreten tesisler, hazir cam çubuk, bilye ve kütükten elyaf çekme yoluyla cam elyaf üreten tesisler hariçtir)', 1019, 0, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('0371dbd5-4369-4e1b-a4e0-b5e4dca781d2', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1024, '2.5 300 ton/gün ve üzeri seramik veya porselen üretiminin yapildigi tesisler.', 1019, 0, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('8dc15343-71dd-4907-b029-442a91e5fed3', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1026, '3.1 Sülfür cevheri dahil metal cevherleri kavuran (oksit haline getirmek için hava altinda isitilmasi), ergiten ve sinterleyen  (ince taneli maddelerin isitma yoluyla bir araya baglanmasi) tesisler.', 1025, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('a26b8ff5-924c-46fe-811e-d14f3b131cd9', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1028, '3.2 Cevherden demir ve çelik üreten tesisler', 1025, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('2ac6fc81-6c31-4e1b-abec-7cc29c1a516d', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1029, '3.3 Kapasitesi 100 ton/ gün ve üzerindeki, cevherden, konsantreden ya da ikincil hammaddelerden metalürjik, kimyasal veya elektrolitik prosesler ile demir içermeyen ham metal üretim tesisleri,', 1025, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('a842e0e3-2432-45a8-85ff-efa3c3d0861f', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1031, '3.4 Kapasitesi 500 ton/ gün ve üzerindeki ham demir üretim tesisi (Kupol Ocaklari dahil)', 1025, 0, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('903c0e7d-8714-4975-baa6-296c9419bc9b', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1032, '3.5 Kapasitesi 2000 ton/ gün ve üzerindeki hurda demir çelikten çelik üreten tesisler', 1025, 0, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('de8c41a6-9fbb-412a-8e98-a4c342a77d29', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1033, '3.6 Kapasitesi 50 ton/gün ve üzerindeki demir disi metal ergitme tesisleri  (Vakumlu ergitme tesisleri ve Basinçli döküm veya kokilli döküm makinalarinin bir parçasi olan ergitme tesisleri haric)', 1025, 0, 6, 1);
INSERT INTO public."EK1EK2" VALUES ('1e08233b-1a50-4f0c-8c43-4010a583f701', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1322, '3.7 Sicak Haddeleme Tesisleri ', 1025, 0, 7, 1);
INSERT INTO public."EK1EK2" VALUES ('4a131178-338a-4e4b-9816-65432bb768c5', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1325, '3.8  Üretim kapasitesi 700 ton/gün ve daha büyük olan demir, temper veya çelik dökümhaneleri', 1025, 0, 8, 1);
INSERT INTO public."EK1EK2" VALUES ('1c5ae517-9fbb-42a9-9f7c-05c0b2dfadfc', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1327, '3.9 5.000 adet/gün ve üzerindeki kursunlu akümülatör ile endüstriyel akümülatör hücreleri üreten tesisler  (1)', 1025, 1, 9, 1);
INSERT INTO public."EK1EK2" VALUES ('0bfdc8e6-7f6c-4574-9bcf-e8e6d0a0d144', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1036, '4.1 Entegre kimya tesisleri.', 1035, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('537aea98-c4d5-432d-bb29-d2a9dc87c400', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1046, '4.2  Toplam 100 ton/gün veya daha fazla organik kimyasal çözücü maddelerin (alkoller, aldehitler, aromatikler, ketonlar, asitler, esterler, asetatlar eterler vb.) hammadde olarak kullanildigi tesisler', 1035, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('e6a89927-735a-4924-9067-6c76117bb7ae', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1047, '4.3  Petrol ve petrol ürünlerinin destilasyon ve rafinasyon islemlerinin gerçeklestirildigi tesisler', 1035, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('18ed2f1b-0b3f-4366-91dc-e425833cd7ec', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1337, '4.4 Terbiye islemlerinden kasar(hasil,sökme,agartma,merserizasyon,kostikleme ve benzeri) ve boyama birimlerini birlikte içeren,üretim kapasitesi 3.000 ton/yil ve üzeri olan iplik,kumas veya hali fabrikalari.(1)', 1035, 1, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('32529440-9bac-4380-ab42-6a94d01fb1c4', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1038, '4.1.1 Üretim kapasitesi toplam 200 ton/gün ve daha fazla olan asitler, bazlar veya tuzlar gibi inorganik kimyasal maddelerin üretildigi tesisler.', 1036, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('907953fa-380f-48ef-90bc-022e08358c1c', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1039, '4.1.2 Amonyak, klor ya da hidrojen klorür, flor ya da hidrojen florür, karbon oksitler, kükürt ve bilesikleri, azot oksitler, hidrojen, kükürt di oksit, karbonil klorür gibi inorganik gazlarin üretildigi tesisler.', 1036, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('3bf1320a-c518-4a5d-8a0d-979ebc3a594f', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1040, '4.1.3 Hammadde asamasindan baslamak suretiyle 50 ton/gün ve daha fazla fosfor, azot ya da potasyum bazli gübre üretimi (basit bilesik gübreler)', 1036, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('33c8d607-32a5-41f8-82bb-c5037f5e5444', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1043, '4.1.4 Kapasitesi 100 ton/gün  ve daha büyük olan basit hidrokarbon (lineer veya döngüsel, doymus veya doymamis, alifatik veya aromatik) üreten tesisler', 1036, 0, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('78f29851-ae83-4fa8-8330-9efbb5bf8f70', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1045, '4.1.5 Üretim kapasitesi 100 ton/gün ve daha fazla olan organik kimyasal çözücü maddelerin (alkoller, aldehitler, aromatikler, ketonlar, asitler, esterler, asetatlar eterler vb.) üretildigi tesisler', 1036, 1, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('1ad82602-5e6f-41a0-aa16-2cbf6339f012', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1049, '5.1 Maddelerin, profil ve tabaka biçimindeki malzemelerin cilalandigi, kurutuldugu tesisler(cilalarin organik çözücü madde ihtiva ettigi ve cila kullanim kapasitesinin 250 kg/saat ve üzerinde oldugu tesisler)(1)', 1048, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('c5dcbf4a-e83d-46c5-a0ee-b18b60d12919', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1050, '5.2 Profil ve tabaka biçimindeki malzemelerin döner baski makinalari ile basildigi ve kurutuldugu tesisler.', 1048, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('8996ea61-4cf5-40d1-8500-466398be3db1', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1053, '5.3  10.000 adet/yil ve üzeri motorlu tasitlarin üretimi,kara tasitlari (otomobil,kamyon vb.),tarim makinalari (traktör,biçerdöver vb.),is makinalari (dozer,ekskavatör vb.),savunma sanayi tasitlari(tank,zirhli araç vb.) boyandigi ve verniklendigi tesisler.(1)', 1048, 1, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('7a0d79fe-686f-434f-ad85-64e9e5d34f0f', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1350, '7.7.2 25000 bas ve üzeri küçükbas yetistirme tesisleri*', 1348, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('4da11b5c-3712-4152-bd28-2d8eecef58b1', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1054, '5.4  Demiryolu tasitlarinin üretiminin yapildigi tesisler (Tüm parçalarin sadece montajinin yapildigi tesisler hariç)(1.000 adet/yil ve üzeri).', 1048, 1, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('78659791-b0eb-4406-80b7-dc27820bc451', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1056, '5.6 Ahsap veya metal yüzeylerin 250 kg/saat ve  üzerinde organik çözücü kullanilarak boyandigi tesisler*', 1048, 1, 6, 1);
INSERT INTO public."EK1EK2" VALUES ('223337fb-5739-42c4-a8bd-d899ba739cfa', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1051, '5.2.1 Boya ve Cila maddeleri: Organik çözücü olarak yalniz etanol ihtiva eden ve bundan 500 kg/saat ve üzerinde kullanan tesisler', 1050, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('131d6e87-f9d4-488b-a025-aa49fdea63a8', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1052, '5.2.2 Boya ve Cila maddeleri: Diger organik çözücüleri 250 kg/saat ve üzerinde kullanan tesisler', 1050, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('b9dd7488-5a3e-42bc-9a71-b61a05c7ec82', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1058, '6.1 Selülöz üretimi tesisleri', 1057, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('6b86d204-5864-41fc-a634-892384ed3ae6', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1059, '6.2 Kereste veya benzeri lifli maddelerden kagit hamuru üretim tesisleri', 1057, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('a5d4293b-d320-433c-ad50-f6e3bbcc8ed9', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1340, '6.3 Hazir selülozdan ve / veya atik kagittan her çesit karton,kagit veya mukavva üretimi yapan tesisler (300 ton/gün ve üzeri kapasiteli)', 1057, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('25adcacd-ef06-48df-b31e-beb0f911f4f6', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1061, '7.1 Seker Fabrikalari*', 1060, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('4e845b16-72e6-4d67-b4ec-b9e4b2d006b9', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1062, '7.2 Üretim kapasitesi 30 ton / gün ve üzeri olan zeytin isleme tesisleri.', 1060, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('343b928b-f79b-4a9b-8166-02db1b22818a', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1341, '7.3 Bitkisel ürünlerden ham yag üretimi veya rafinasyon isleminin yapildigi tesisler. (200 ton /gün yag ve üzeri (kekik,papatya vb. Esansiyel yaglar hariç))', 1060, 1, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('756b65fa-9712-4ac5-b6fc-b7b469cc61af', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1342, '7.4 Kapasitesi 25.000 ton/yil ve üzeri olan maya üretim tesisleri.', 1060, 1, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('ffb20b53-fd2e-425c-8ed2-2d6b4da7f688', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1344, '7.5 Suma ve malttan 50.000 m3/yil ve daha fazla alkollü içeçek üreten yerler.', 1060, 1, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('4f1a1f8c-1ae6-4c7a-97fc-aaefb51b25c7', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1346, '7.6 Kapasitesi 2.000 ton/yil ve üzeri olan ham deri isleme tesisleri(konfeksiyon ürünleri hariç)', 1060, 1, 6, 1);
INSERT INTO public."EK1EK2" VALUES ('4e0c1eed-cb0b-4324-933f-08587a16cd07', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1348, '7.7 Hayvan Yetistirme Tesisleri*', 1060, 1, 7, 1);
INSERT INTO public."EK1EK2" VALUES ('f804b947-4061-4318-b09a-92a11e0908cb', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1355, '7.8 Hayvan Kesim Tesisleri*', 1060, 1, 8, 1);
INSERT INTO public."EK1EK2" VALUES ('4e8c5522-4867-4f24-84c1-63bb42df6dd9', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1364, '7.9 Süt isletme tesisleri.(çig süt isetme kapasitesi 100.000litre/gün ve üzeri)*', 1060, 1, 9, 1);
INSERT INTO public."EK1EK2" VALUES ('29563ea1-546c-47c7-8cb0-f2181fbd3e59', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 306, '8.7 Biyobozunur Atık İşleme Tesisleri*', 1063, 1, 7, 1);
INSERT INTO public."EK1EK2" VALUES ('4ed28c09-8c27-409c-821e-7b47c4907991', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 314, '8.8 Maden Atığı Bertaraf Tesisleri*', 1063, 1, 8, 1);
INSERT INTO public."EK1EK2" VALUES ('43fda8e8-8a5e-4d69-a2a6-eb1cff433b9f', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1064, '8.1 Atik ara depolama, geri kazanim ve bertaraf tesisleri*(Bu maddeye Çevre izninde gürültü konusunda getirilen muafiyet Atik Pil ve Akümülatör ve Ömrünü Tamamlamis Lastik Geri Kazanim tesisleri için geçerli degildir.)', 1063, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('d5852c35-17e0-43c5-8abe-004e95c9359f', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1065, '8.3 Gemi geri dönüsüm tesisleri*', 1063, 1, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('34dc0ad7-2bcc-4696-8967-af9916803634', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1329, '8.2 Hurda parçalama tesisleri dahil hurdalarin veya ömrünü tamamlamis araçlarin depolama alanlari ve/veya isleme tesisleri,atik elektrikli ve elektronik esya isleme tesisleri,tanker temizleme tesisleri ile PCB arındırma tesisleri .*', 1063, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('ae89c10f-1b59-4eee-b245-8a7aa94fb54e', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1365, '8.4 Ileri Termal Islem Tesisleri(Piroliz,Gazlastirma)', 1063, 1, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('98ce88a6-2105-4e25-93c4-7d47c08fb2df', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1366, '8.5 Atiktan Türetilmis Yakit(ATY) Hazirlama Tesisleri', 1063, 1, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('e5db0c59-45e3-4988-861b-0cf458ef25d8', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1367, '8.6 Tibbi atik strelizasyon tesisleri', 1063, 1, 6, 1);
INSERT INTO public."EK1EK2" VALUES ('da97e199-24ae-4471-b9b5-aba265dd31be', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1068, '9.1 Yanici, parlayici veya patlayici gazlar için depolama ve dolum tesisleri*', 1066, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('981876ce-0912-4593-b5b2-ac31805e2f25', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1072, '9.2 Ham petrol, petrol ürünleri ve petrokimyasal ve kimyasal ürünler için depolama tesisleri  *', 1066, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('a9a8a0cd-dbbf-45a2-9f0e-9b01b045eefd', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1076, '9.3 Metanol için toplam depolama tank kapasitesi 30.000 ton ve daha fazla olan tesisler*', 1066, 1, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('8074022a-01b4-4753-9cc2-1997ef843c96', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1077, '9.4 Akrilonitril için toplam depolama tank kapasitesi 2000 ton ve daha fazla olan tesisler*', 1066, 1, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('946ff01e-22f8-4180-9cae-3292b48074ff', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1069, '9.1.1 Sivilastirilmis petrol gazlari için toplam depolama tank kapasitesi 10.000 m3 veya daha fazla olan tesisler( Isinma amaçli kullanilan depolama tanklari hariçtir)', 1068, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('0ffb88fd-25f1-4291-b83c-b81c4aaf13c4', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1070, '9.1.2 Dogal gaz/LNG (sivilastirilmis dogalgaz) vb. gazlar  için toplam depolama tank kapasitesi 20.000 m3 ve daha fazla olan tesisler, ( Isinma amaçli kullanilan depolama tanklari hariçtir)', 1068, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('18ea27f9-2f86-4411-b307-63b06e9d54f4', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1071, '9.1.3 Dolum kapasitesi 200 ton/gün ve daha büyük olan Sivilastirilmis petrol gazlarindan tüp dolum islemlerinin gerceklestirildigi tesisler', 1068, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('b8abbed7-a570-441b-b127-795889664fcb', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1073, '9.2.1 Ham petrol için toplam depolama tank kapasitesi 100.000 ton ve daha fazla olan tesisler', 1072, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('dd2887b5-125e-4b13-a141-6e3e7f2c73d4', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1074, '9.2.2 Benzin, nafta, motorin, fuel-oil vb. akaryakitlar,  için toplam depolama tank kapasitesi 50.000 ton ve daha fazla olan tesisleri( Isinma amaçli kullanilan depolama tanklari hariçtir)', 1072, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('00df172a-62f2-4c43-a6e9-dd07327ebcf9', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1075, '9.2.3 Organik kimyasal çözücü maddeler için (alkoller, aldehitler, aromatikler, aminler, ketonlar, asitler, esterler, asetatlar, eterler vb.) toplam depolama tank kapasitesi 50.000 ton ve daha fazla olan tesisler', 1072, 0, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('3ee33724-a985-47d2-b936-7c6eb7159776', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1079, '10.1 Sanayilerin toplu olarak yer aldigi bölgelere ait atik su aritma tesisleri.', 1078, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('8626617f-9fb0-4bb4-a563-444429ee9dda', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1330, '10.2 Nüfusu 100.000 kisi ve üzeri olan kentsel ve/veya evsel nitelikli atik su aritma tesisleri.*', 1078, 1, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('f756d21c-dc3a-48cf-8107-d5206d00f729', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1323, '3.7.1 Kapasitesi 5.000 ton/gün ve üzerindeki demir veya çeligin haddelendigi tesisler', 1322, 0, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('370fff9b-4774-4ec1-8d89-3aceaa107249', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1324, '3.7.2 Kapasitesi 250 ton/gün ve üzerindeki demir disi metallerin haddelendigi tesisler', 1322, 0, 2, 1);
INSERT INTO public."EK1EK2" VALUES ('5fb006b9-0f77-4e00-9a7f-0dec140b5b24', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1349, '7.7.1 5000 bas ve üzeri büyükbas yetistirme tesisleri*', 1348, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('c6770491-9cf3-4644-9b58-5f9371baffb7', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1351, '7.7.3 Büyükbas ve küçükbas hayvanlarin birlikte yetistirilmesi.(5.000 büyükbas ve üzeri ,1 büyükbas = 5 küçükbas esdegeri esas alinmalidir.)', 1348, 1, 3, 1);
INSERT INTO public."EK1EK2" VALUES ('9e00c55c-0e42-4b9e-86db-030453dcb1bc', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1352, '7.7.4 1000 bas ve üzeri domuz besi tesisleri.*', 1348, 1, 4, 1);
INSERT INTO public."EK1EK2" VALUES ('d8ec560a-7f27-4a40-8f09-2823c4452ca2', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1354, '7.7.5 Kanatli yetistirme tesisleri.[bir üretim periyodunda 60.000 adet ve üzeri tavuk(civciv,damizlik,piliç vb.)veya esdeger diger kanatlilar])(1 adet hindi=7 adet tavuk esdegeri esas alinmalidir.)*', 1348, 1, 5, 1);
INSERT INTO public."EK1EK2" VALUES ('98784e3b-d108-48e8-8cb0-492e730c7c1e', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1362, '7.8.1 Büyükbas ve/ veya küçükbas hayvan kesiminin yapildigi tesisler.(100 kesim ünitesi/gün ve üzeri),(her bir kesim ünitesi esdegerleri;1 bas sigir,2bas devekusu,4 bas domuz,8 bas koyun,10 bas keçi,130 bas tavsan)*', 1355, 1, 1, 1);
INSERT INTO public."EK1EK2" VALUES ('8f2897f2-d176-41b0-ac98-41057cab9d85', '2023-05-30 13:19:11.956484', 'c8cf106d-36a8-45a0-9089-c063b804c257', NULL, NULL, 1, 1363, '7.8.2 Kanatli hayvanlarin kesiminin yapildigi tesisler.(50.000 adet/gün ve üzeri tavuk ve esdegeri diger kanatlilar.)(1 adet hindi=7 adet tavuk esdegeri esas alinmalidir.)*', 1355, 1, 2, 1);


--
-- Data for Name: IlDegisikligiBasvuru; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: IlDegisikligiBasvuruAsama; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: NaceKodu; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: OdemeReferansNumarasi; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Personel; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."Personel" VALUES ('56ef81de-1211-4d44-81d4-267d1263113e', '2023-03-01 13:39:47', '54720a70-38a6-4dd0-848b-bc4e1be1f9c7', NULL, NULL, 0, 'Test Ad', 'Test Soyad', NULL, NULL, NULL, NULL, '54784GTH', '87784GTJ', '2023-04-02 13:39:47', '2024-03-01 13:39:47', '2023-07-01 13:39:47', '2023-07-01 13:39:47');
INSERT INTO public."Personel" VALUES ('75037928-43f6-461e-8794-f03523875634', '2023-03-01 13:39:47', '54720a70-38a6-4dd0-848b-bc4e1be1f9c7', NULL, NULL, 0, 'Test Ad 2', 'Test Soyad 2', NULL, NULL, NULL, NULL, '748THD6', '8745HWDa', '2023-07-08 13:39:47', '2025-03-01 13:39:47', '2023-03-07 13:39:47', '2023-03-15 13:39:47');


--
-- Data for Name: Surucu; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."Surucu" VALUES ('aeb9a120-0eca-4aa2-a7bf-0c8a900ea394', '2023-06-22 11:53:05.896757', '79b6fae4-87c1-4dbe-bc44-1da76a73e0bc', NULL, NULL, 1, 'Yasin', 'Ersever', '51322476134', '(333) 333 - 3333', 'testsurucu@test.com');
INSERT INTO public."Surucu" VALUES ('c09573ee-6aea-4e50-adc8-4444efaf3951', '2023-06-22 14:10:52.134843', '2df620e3-7c52-4d9b-a257-48e83891f85f', NULL, NULL, 1, 'Yasin', 'Ersever', '51322476134', '(333) 333 - 3333', 'testtest@testtest.com');


--
-- Data for Name: SurucuBelge; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."SurucuBelge" VALUES ('80c0b48b-41a3-4c91-ae92-31db62da3171', '2023-06-22 11:53:05.897185', '4804a414-1eb5-464e-b399-304fdac1c9ad', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', 'aeb9a120-0eca-4aa2-a7bf-0c8a900ea394', 1, '-infinity');
INSERT INTO public."SurucuBelge" VALUES ('94f5ad0f-1743-4880-98d9-2461ec6cb6fc', '2023-06-22 11:53:05.937903', 'be37ed3b-4f82-4c3f-a6ec-5cb1924bc55d', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', 'aeb9a120-0eca-4aa2-a7bf-0c8a900ea394', 3, '-infinity');
INSERT INTO public."SurucuBelge" VALUES ('70d78109-82e9-4ff1-bbf4-84c6461fe908', '2023-06-22 14:10:52.13485', 'ae7e6ebb-d650-492f-b2c7-55b948d0ac63', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', 'c09573ee-6aea-4e50-adc8-4444efaf3951', 1, '-infinity');
INSERT INTO public."SurucuBelge" VALUES ('97bf17ed-431f-48de-9a04-64f8496e9b8f', '2023-06-22 14:10:52.135323', 'c17de9a5-07d7-4a64-8a31-04b2fa13fc4f', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', 'c09573ee-6aea-4e50-adc8-4444efaf3951', 3, '-infinity');


--
-- Data for Name: SurucuGecmis; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."SurucuGecmis" VALUES ('af7bd431-420a-4bcd-8ac4-eb78e7774770', '2023-06-22 11:53:06.041405', '2e52f4a1-02a0-4065-a22b-411af0b9ef44', NULL, NULL, 1, 'aeb9a120-0eca-4aa2-a7bf-0c8a900ea394', '', '{"Ad":"Yasin","Soyad":"Ersever","TCKimlik":"51322476134","Telefon":"(333) 333 - 3333","Eposta":"testsurucu@test.com","BasvuruSurucu":[{"AtyonBasvuruKimlikRef":"48519c61-9f8d-4379-8ae8-28a781561f7d","SurucuKimlikRef":"aeb9a120-0eca-4aa2-a7bf-0c8a900ea394","SurucuUygunlukNot":null,"SurucuUygunluk":null,"AtyonBasvuruKimlikRefNavigation":null,"BasvuruSurucuEksiklik":[],"Kimlik":"301cc608-e9bc-45cd-a12b-43e7cada5cd0","Olusturulma":"2023-06-22T11:53:05.8970399+00:00","Olusturan":"f93e0511-ad3e-4e0a-8d5c-a58cfe21d357","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"SurucuBelge":[{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","SurucuKimlikRef":"aeb9a120-0eca-4aa2-a7bf-0c8a900ea394","BelgeTuru":1,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"80c0b48b-41a3-4c91-ae92-31db62da3171","Olusturulma":"2023-06-22T11:53:05.8971852+00:00","Olusturan":"4804a414-1eb5-464e-b399-304fdac1c9ad","Guncelleme":null,"Guncelleyen":null,"Durum":1},{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","SurucuKimlikRef":"aeb9a120-0eca-4aa2-a7bf-0c8a900ea394","BelgeTuru":3,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"94f5ad0f-1743-4880-98d9-2461ec6cb6fc","Olusturulma":"2023-06-22T11:53:05.9379038+00:00","Olusturan":"be37ed3b-4f82-4c3f-a6ec-5cb1924bc55d","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"SurucuGecmis":[],"Kimlik":"aeb9a120-0eca-4aa2-a7bf-0c8a900ea394","Olusturulma":"2023-06-22T11:53:05.8967572+00:00","Olusturan":"79b6fae4-87c1-4dbe-bc44-1da76a73e0bc","Guncelleme":null,"Guncelleyen":null,"Durum":1}');
INSERT INTO public."SurucuGecmis" VALUES ('6fc625b5-fd7d-4f49-a9ed-4d020da88116', '2023-06-22 14:10:52.135997', 'b10ff859-d316-4e39-893d-8cda0c03da92', NULL, NULL, 1, 'c09573ee-6aea-4e50-adc8-4444efaf3951', '', '{"Ad":"Yasin","Soyad":"Ersever","TCKimlik":"51322476134","Telefon":"(333) 333 - 3333","Eposta":"testtest@testtest.com","BasvuruSurucu":[{"AtyonBasvuruKimlikRef":"f23d6df0-09e5-4085-8120-85df8c349d3d","SurucuKimlikRef":"c09573ee-6aea-4e50-adc8-4444efaf3951","SurucuUygunlukNot":null,"SurucuUygunluk":null,"AtyonBasvuruKimlikRefNavigation":null,"BasvuruSurucuEksiklik":[],"Kimlik":"2eaaedaf-de5a-4199-b833-35dd34c3d55f","Olusturulma":"2023-06-22T14:10:52.1348473+00:00","Olusturan":"a38767cc-bd58-4a3b-ac1d-55d804af84a6","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"SurucuBelge":[{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","SurucuKimlikRef":"c09573ee-6aea-4e50-adc8-4444efaf3951","BelgeTuru":1,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"70d78109-82e9-4ff1-bbf4-84c6461fe908","Olusturulma":"2023-06-22T14:10:52.1348509+00:00","Olusturan":"ae7e6ebb-d650-492f-b2c7-55b948d0ac63","Guncelleme":null,"Guncelleyen":null,"Durum":1},{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","SurucuKimlikRef":"c09573ee-6aea-4e50-adc8-4444efaf3951","BelgeTuru":3,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"97bf17ed-431f-48de-9a04-64f8496e9b8f","Olusturulma":"2023-06-22T14:10:52.1353236+00:00","Olusturan":"c17de9a5-07d7-4a64-8a31-04b2fa13fc4f","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"SurucuGecmis":[],"Kimlik":"c09573ee-6aea-4e50-adc8-4444efaf3951","Olusturulma":"2023-06-22T14:10:52.1348438+00:00","Olusturan":"2df620e3-7c52-4d9b-a257-48e83891f85f","Guncelleme":null,"Guncelleyen":null,"Durum":1}');


--
-- Data for Name: SurucuTasimaArac; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: TasimaArac; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."TasimaArac" VALUES ('4585a073-9bd2-430b-9990-d22422fb1d00', '2023-06-22 11:51:00.879445', 'd3cd9b0e-a0db-4367-b8ad-11452c93daec', NULL, NULL, 1, 1, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, '350', NULL, NULL, 1, NULL, NULL, '35 LA 353', NULL, NULL, '12', NULL, NULL, 4, NULL, NULL, '2023-04-13 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '35353535', '353535', '34', 'test araç adı', 'test araç soyadı', '0555 555 55 55', 'testarac@test.com', 'Test Adres');
INSERT INTO public."TasimaArac" VALUES ('723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8', '2023-06-22 14:09:51.126361', 'fd7e28f2-37f9-445e-a1c8-d11ca16ba486', NULL, NULL, 1, 2, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, '333', NULL, NULL, 1, NULL, NULL, '33OT33', NULL, NULL, '333', NULL, NULL, 24, NULL, NULL, '2023-06-15 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '333', '333', '34', 'testtest', 'testtest', '3333333333', 'testtest@test.com', 'testtestadres');


--
-- Data for Name: TasimaAracBelge; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."TasimaAracBelge" VALUES ('0a397ccf-4921-4bfa-872f-ec83082eb5af', '2023-06-22 11:51:00.880141', '61e3c8c6-3699-4b6f-a7f5-1eea8a68f358', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', '4585a073-9bd2-430b-9990-d22422fb1d00', 2, '-infinity');
INSERT INTO public."TasimaAracBelge" VALUES ('4d87ad61-9584-4b19-abce-ab1999757724', '2023-06-22 11:51:00.925791', '1959cccc-5214-42b8-970e-f93adee6328e', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', '4585a073-9bd2-430b-9990-d22422fb1d00', 4, '-infinity');
INSERT INTO public."TasimaAracBelge" VALUES ('a56bdcca-6877-4055-ac95-ec350af75357', '2023-06-22 11:51:00.925644', '201d5be8-77d2-4921-a6d6-e7be738dd92e', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', '4585a073-9bd2-430b-9990-d22422fb1d00', 3, '-infinity');
INSERT INTO public."TasimaAracBelge" VALUES ('6248ec4f-71d5-4dba-af69-af887ede5918', '2023-06-22 14:09:51.126696', 'abc24d88-af9a-455d-801e-13d3554b2a5e', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8', 4, '-infinity');
INSERT INTO public."TasimaAracBelge" VALUES ('88c51d0f-8702-47e4-9a75-c38e780c4a71', '2023-06-22 14:09:51.126396', '978cff9e-6ce9-4199-9add-600eb5ab0faf', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8', 2, '-infinity');
INSERT INTO public."TasimaAracBelge" VALUES ('ea9a09b5-4298-41c2-9e0c-a58d5dd05f63', '2023-06-22 14:09:51.126564', '76c2d4e8-38a1-4103-9925-1d4919ac28b4', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8', 3, '-infinity');


--
-- Data for Name: TasimaAracGecmis; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."TasimaAracGecmis" VALUES ('8406b632-2f3f-42c6-85be-560d5239ad35', '2023-06-22 11:51:01.389933', '199ebde3-9fdf-4b59-a265-7719f0a8fbb0', NULL, NULL, 1, '4585a073-9bd2-430b-9990-d22422fb1d00', '', '{"AracTuru":1,"AracTuruUygunluk":null,"AracTuruUygunlukNot":null,"TeminTuru":1,"TeminTuruUygunluk":null,"TeminTuruUygunlukNot":null,"TasinacakAtikTuru":1,"TasinacakAtikTuruUygunluk":null,"TasinacakAtikTuruUygunlukNot":null,"TehlikeliAtikGrubu":1,"TehlikeliAtikGrubuUygunluk":null,"TehlikeliAtikGrubuUygunlukNot":null,"AracTasimaKapasitesi":"350","AracTasimaKapasitesiUygunluk":null,"AracTasimaKapasitesiUygunlukNot":null,"AmbalajTuru":1,"AmbalajTuruUygunluk":null,"AmbalajTuruUygunlukNot":null,"Plaka":"35 LA 353","PlakaUygunluk":null,"PlakaUygunlukNot":null,"SaseNumarasi":"12","SaseNumarasiUygunluk":null,"SaseNumarasiUygunlukNot":null,"AracSinifi":4,"AracSinifiUygunluk":null,"AracSinifiUygunlukNot":null,"İlkTescilTarihi":"2023-04-13T00:00:00","TescilTarihiUygunluk":null,"TescilTarihiUygunlukNot":null,"MobilCihazId":null,"CihazIdUygunluk":null,"CihazIdUygunlukNot":null,"YetkiBelge":null,"YetkiBelgeUygunluk":null,"YetkiBelgeUygunlukNot":null,"AtikKod":null,"AtikKodUygunluk":null,"AtikKodUygunlukNot":null,"MaliSorumlulukSigortasiPoliceNo":"35353535","TasitADRUygunlukBelgeNo":"353535","IlKodu":"34","AracSahibiAd":"test araç adı","AracSahibiSoyad":"test araç soyadı","AracSahibiTelefon":"0555 555 55 55","AracSahibiEposta":"testarac@test.com","AracSahibiAdres":"Test Adres","AltBasvuruAtikKodu":[],"AtikTehlikelilikOzellik":[{"TehlikelilikOzellik":4,"TehlikelilikOzellikUygunluk":null,"TehlikelilikOzellikUygunlukNot":null,"TasimaAracKimlikRef":"4585a073-9bd2-430b-9990-d22422fb1d00","Kimlik":"02dd98ec-1bbb-4afa-aa15-f46388e66c84","Olusturulma":"2023-06-22T11:51:01.2247593+00:00","Olusturan":"82d6cbf7-c4da-40ce-93d2-da92257afde8","Guncelleme":null,"Guncelleyen":null,"Durum":0}],"AtyonAtikKod":[{"TasimaAracKimlikRef":"4585a073-9bd2-430b-9990-d22422fb1d00","AtikKodu":2,"Kimlik":"a45b9f86-371f-442e-954b-2a4633331485","Olusturulma":"2023-06-22T11:51:01.3118185+00:00","Olusturan":"dfdeaee1-869d-42e2-8341-957431bad0e7","Guncelleme":null,"Guncelleyen":null,"Durum":0}],"BasvuruTasimaArac":[{"TasimaAracKimlikRef":"4585a073-9bd2-430b-9990-d22422fb1d00","AtyonBasvuruKimlikRef":"48519c61-9f8d-4379-8ae8-28a781561f7d","TasimaAracUygunlukNot":null,"TasimaAracUygunluk":null,"AtyonBasvuruKimlikRefNavigation":{"KurulusKullaniciKimlikRef":"d957f7d7-c18d-4d90-b887-433b28a4911d","FirmaKimlikRef":"d957f7d7-c18d-4d90-b887-433b28a4911d","LisansDurum":null,"LisansTarihi":null,"VizeDurum":null,"GorevliUzmanKimlikRef":null,"GorevliSubeMuduruKimlikRef":null,"GorevliIlMudurYardimcisiKimlikRef":null,"AltBasvuruAtikKodu":[],"AltBasvuruLisansIptal":[],"AltBasvuruLisansVize":[],"AltBasvuruSurucu":[],"AltBasvuruTasimaArac":[],"AtyonBasvuruBelge":[],"AtyonBasvuruCevreMuhendisi":[],"BasvuruAsama":[],"BasvuruGecmis":[],"BasvuruOdeme":[],"BasvuruSurucu":[],"BasvuruTasimaArac":[],"IlDegisikligiBasvuru":[],"Kimlik":"48519c61-9f8d-4379-8ae8-28a781561f7d","Olusturulma":"2023-06-22T11:36:54.597564","Olusturan":"100b8aad-d349-478a-90f4-4048b9490935","Guncelleme":null,"Guncelleyen":null,"Durum":1},"BasvuruTasimaAracEksiklik":[],"Kimlik":"ef714752-5b8a-4a9f-b2af-00c8f79e6f2e","Olusturulma":"2023-06-22T11:51:00.8799974+00:00","Olusturan":"9872c60e-ecd6-4e75-bfe3-8f2d897a00a8","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"IlDegisikligiBasvuru":[],"TasimaAracBelge":[{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","TasimaAracKimlikRef":"4585a073-9bd2-430b-9990-d22422fb1d00","BelgeTuru":2,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"0a397ccf-4921-4bfa-872f-ec83082eb5af","Olusturulma":"2023-06-22T11:51:00.8801416+00:00","Olusturan":"61e3c8c6-3699-4b6f-a7f5-1eea8a68f358","Guncelleme":null,"Guncelleyen":null,"Durum":1},{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","TasimaAracKimlikRef":"4585a073-9bd2-430b-9990-d22422fb1d00","BelgeTuru":3,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"a56bdcca-6877-4055-ac95-ec350af75357","Olusturulma":"2023-06-22T11:51:00.9256446+00:00","Olusturan":"201d5be8-77d2-4921-a6d6-e7be738dd92e","Guncelleme":null,"Guncelleyen":null,"Durum":1},{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","TasimaAracKimlikRef":"4585a073-9bd2-430b-9990-d22422fb1d00","BelgeTuru":4,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"4d87ad61-9584-4b19-abce-ab1999757724","Olusturulma":"2023-06-22T11:51:00.9257918+00:00","Olusturan":"1959cccc-5214-42b8-970e-f93adee6328e","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"TasimaAracGecmis":[],"Kimlik":"4585a073-9bd2-430b-9990-d22422fb1d00","Olusturulma":"2023-06-22T11:51:00.8794454+00:00","Olusturan":"d3cd9b0e-a0db-4367-b8ad-11452c93daec","Guncelleme":null,"Guncelleyen":null,"Durum":1}');
INSERT INTO public."TasimaAracGecmis" VALUES ('8d4cd298-f3d3-436c-b6cd-838651bd0d71', '2023-06-22 14:09:51.135308', '93faa99f-4032-4de9-983f-7a4c298ede02', NULL, NULL, 1, '723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8', '', '{"AracTuru":2,"AracTuruUygunluk":null,"AracTuruUygunlukNot":null,"TeminTuru":1,"TeminTuruUygunluk":null,"TeminTuruUygunlukNot":null,"TasinacakAtikTuru":1,"TasinacakAtikTuruUygunluk":null,"TasinacakAtikTuruUygunlukNot":null,"TehlikeliAtikGrubu":1,"TehlikeliAtikGrubuUygunluk":null,"TehlikeliAtikGrubuUygunlukNot":null,"AracTasimaKapasitesi":"333","AracTasimaKapasitesiUygunluk":null,"AracTasimaKapasitesiUygunlukNot":null,"AmbalajTuru":1,"AmbalajTuruUygunluk":null,"AmbalajTuruUygunlukNot":null,"Plaka":"33OT33","PlakaUygunluk":null,"PlakaUygunlukNot":null,"SaseNumarasi":"333","SaseNumarasiUygunluk":null,"SaseNumarasiUygunlukNot":null,"AracSinifi":24,"AracSinifiUygunluk":null,"AracSinifiUygunlukNot":null,"İlkTescilTarihi":"2023-06-15T00:00:00","TescilTarihiUygunluk":null,"TescilTarihiUygunlukNot":null,"MobilCihazId":null,"CihazIdUygunluk":null,"CihazIdUygunlukNot":null,"YetkiBelge":null,"YetkiBelgeUygunluk":null,"YetkiBelgeUygunlukNot":null,"AtikKod":null,"AtikKodUygunluk":null,"AtikKodUygunlukNot":null,"MaliSorumlulukSigortasiPoliceNo":"333","TasitADRUygunlukBelgeNo":"333","IlKodu":"34","AracSahibiAd":"testtest","AracSahibiSoyad":"testtest","AracSahibiTelefon":"3333333333","AracSahibiEposta":"testtest@test.com","AracSahibiAdres":"testtestadres","AltBasvuruAtikKodu":[],"AtikTehlikelilikOzellik":[{"TehlikelilikOzellik":1,"TehlikelilikOzellikUygunluk":null,"TehlikelilikOzellikUygunlukNot":null,"TasimaAracKimlikRef":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","Kimlik":"9f30b138-ae0d-496f-bc19-f3022d6edc46","Olusturulma":"2023-06-22T14:09:51.1309057+00:00","Olusturan":"5cef9af3-6038-4757-a175-294cc49b5e97","Guncelleme":null,"Guncelleyen":null,"Durum":0},{"TehlikelilikOzellik":4,"TehlikelilikOzellikUygunluk":null,"TehlikelilikOzellikUygunlukNot":null,"TasimaAracKimlikRef":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","Kimlik":"ca7d15c1-96a2-460a-9901-ee57bdc68aed","Olusturulma":"2023-06-22T14:09:51.1313385+00:00","Olusturan":"0af1b6a4-caca-4136-b518-9d4c69263249","Guncelleme":null,"Guncelleyen":null,"Durum":0},{"TehlikelilikOzellik":5,"TehlikelilikOzellikUygunluk":null,"TehlikelilikOzellikUygunlukNot":null,"TasimaAracKimlikRef":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","Kimlik":"8617b19b-3fff-4c6d-9121-700b50ab2ec7","Olusturulma":"2023-06-22T14:09:51.131552+00:00","Olusturan":"edd7635f-6dee-44aa-a45c-75d9b409ac2c","Guncelleme":null,"Guncelleyen":null,"Durum":0},{"TehlikelilikOzellik":13,"TehlikelilikOzellikUygunluk":null,"TehlikelilikOzellikUygunlukNot":null,"TasimaAracKimlikRef":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","Kimlik":"3bd590dd-06ad-467c-bbf4-655ec25fda1e","Olusturulma":"2023-06-22T14:09:51.1317487+00:00","Olusturan":"b7fa947b-038b-49e5-b734-4d89df76393f","Guncelleme":null,"Guncelleyen":null,"Durum":0}],"AtyonAtikKod":[],"BasvuruTasimaArac":[{"TasimaAracKimlikRef":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","AtyonBasvuruKimlikRef":"f23d6df0-09e5-4085-8120-85df8c349d3d","TasimaAracUygunlukNot":null,"TasimaAracUygunluk":null,"AtyonBasvuruKimlikRefNavigation":{"KurulusKullaniciKimlikRef":"252f3ac6-5063-48f9-986e-fb62217afd61","FirmaKimlikRef":"252f3ac6-5063-48f9-986e-fb62217afd61","LisansDurum":null,"LisansTarihi":null,"VizeDurum":null,"GorevliUzmanKimlikRef":null,"GorevliSubeMuduruKimlikRef":null,"GorevliIlMudurYardimcisiKimlikRef":null,"AltBasvuruAtikKodu":[],"AltBasvuruLisansIptal":[],"AltBasvuruLisansVize":[],"AltBasvuruSurucu":[],"AltBasvuruTasimaArac":[],"AtyonBasvuruBelge":[],"AtyonBasvuruCevreMuhendisi":[],"BasvuruAsama":[],"BasvuruGecmis":[],"BasvuruOdeme":[],"BasvuruSurucu":[],"BasvuruTasimaArac":[],"IlDegisikligiBasvuru":[],"Kimlik":"f23d6df0-09e5-4085-8120-85df8c349d3d","Olusturulma":"2023-06-21T21:35:34.147467","Olusturan":"6d5a4e54-a4fb-4bb3-8714-107e3864366e","Guncelleme":null,"Guncelleyen":null,"Durum":1},"BasvuruTasimaAracEksiklik":[],"Kimlik":"65fca7cf-9c53-4640-b9fa-7ef01903fe25","Olusturulma":"2023-06-22T14:09:51.1263889+00:00","Olusturan":"1859ce2c-e43d-4ae4-95b7-1bc52acfd1b8","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"IlDegisikligiBasvuru":[],"TasimaAracBelge":[{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","TasimaAracKimlikRef":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","BelgeTuru":2,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"88c51d0f-8702-47e4-9a75-c38e780c4a71","Olusturulma":"2023-06-22T14:09:51.1263968+00:00","Olusturan":"978cff9e-6ce9-4199-9add-600eb5ab0faf","Guncelleme":null,"Guncelleyen":null,"Durum":1},{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","TasimaAracKimlikRef":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","BelgeTuru":3,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"ea9a09b5-4298-41c2-9e0c-a58d5dd05f63","Olusturulma":"2023-06-22T14:09:51.126564+00:00","Olusturan":"76c2d4e8-38a1-4103-9925-1d4919ac28b4","Guncelleme":null,"Guncelleyen":null,"Durum":1},{"BelgeKimlikRef":"00000000-0000-0000-0000-000000000000","TasimaAracKimlikRef":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","BelgeTuru":4,"SonGecerlilikTarihi":"0001-01-01T00:00:00","Kimlik":"6248ec4f-71d5-4dba-af69-af887ede5918","Olusturulma":"2023-06-22T14:09:51.1266962+00:00","Olusturan":"abc24d88-af9a-455d-801e-13d3554b2a5e","Guncelleme":null,"Guncelleyen":null,"Durum":1}],"TasimaAracGecmis":[],"Kimlik":"723fd9d4-e1e0-4106-b8e2-da0b1e20c5a8","Olusturulma":"2023-06-22T14:09:51.1263615+00:00","Olusturan":"fd7e28f2-37f9-445e-a1c8-d11ca16ba486","Guncelleme":null,"Guncelleyen":null,"Durum":1}');


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."__EFMigrationsHistory" VALUES ('20230131191453_ek3aform', '7.0.1');
INSERT INTO public."__EFMigrationsHistory" VALUES ('20230201071206_duzenlemeler yapildi', '7.0.1');


--
-- Name: AltBasvuruAtikKoduAsama AltBasvuruAtikKoduAsama_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruAtikKoduAsama"
    ADD CONSTRAINT "AltBasvuruAtikKoduAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruAtikKodu AltBasvuruAtikKodu_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruAtikKodu"
    ADD CONSTRAINT "AltBasvuruAtikKodu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruLisansIptalAsama AltBasvuruLisansIptalAsama_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruLisansIptalAsama"
    ADD CONSTRAINT "AltBasvuruLisansIptalAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruLisansIptal AltBasvuruLisansIptal_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruLisansIptal"
    ADD CONSTRAINT "AltBasvuruLisansIptal_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruLisansVizeAsama AltBasvuruLisansVizeAsama_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruLisansVizeAsama"
    ADD CONSTRAINT "AltBasvuruLisansVizeAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruLisansVize AltBasvuruLisansVize_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruLisansVize"
    ADD CONSTRAINT "AltBasvuruLisansVize_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruSurucuAsama AltBasvuruSurucuAsama_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruSurucuAsama"
    ADD CONSTRAINT "AltBasvuruSurucuAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruSurucu AltBasvuruSurucu_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruSurucu"
    ADD CONSTRAINT "AltBasvuruSurucu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruTasimaAracAsama AltBasvuruTasimaAracAsama_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruTasimaAracAsama"
    ADD CONSTRAINT "AltBasvuruTasimaAracAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruTasimaAracOdeme AltBasvuruTasimaAracOdeme_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruTasimaAracOdeme"
    ADD CONSTRAINT "AltBasvuruTasimaAracOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruTasimaArac AltBasvuruTasimaArac_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruTasimaArac"
    ADD CONSTRAINT "AltBasvuruTasimaArac_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtikTehlikelilikOzellik AtikTehlikelilikOzellik_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtikTehlikelilikOzellik"
    ADD CONSTRAINT "AtikTehlikelilikOzellik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtyonAtikKod AtyonAtikKod_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtyonAtikKod"
    ADD CONSTRAINT "AtyonAtikKod_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtyonBasvuruBelge AtyonBasvuruBelge_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtyonBasvuruBelge"
    ADD CONSTRAINT "AtyonBasvuruBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtyonBasvuru AtyonBasvuru_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtyonBasvuru"
    ADD CONSTRAINT "AtyonBasvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtyonBasvuruCevreMuhendisi AtyonCevreMuhendisi_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtyonBasvuruCevreMuhendisi"
    ADD CONSTRAINT "AtyonCevreMuhendisi_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruAsama BasvuruAsama_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruAsama"
    ADD CONSTRAINT "BasvuruAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruCevreMuhendisiEksiklik BasvuruCevreMuhendisiEksiklik_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruCevreMuhendisiEksiklik"
    ADD CONSTRAINT "BasvuruCevreMuhendisiEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruGecmis BasvuruGecmis_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruGecmis"
    ADD CONSTRAINT "BasvuruGecmis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruOdemeEksiklik BasvuruOdemeEksiklik_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruOdemeEksiklik"
    ADD CONSTRAINT "BasvuruOdemeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruOdeme BasvuruOdeme_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruOdeme"
    ADD CONSTRAINT "BasvuruOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruSurucuEksiklik BasvuruSurucuEksiklik_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruSurucuEksiklik"
    ADD CONSTRAINT "BasvuruSurucuEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruSurucu BasvuruSurucu_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruSurucu"
    ADD CONSTRAINT "BasvuruSurucu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruTasimaAracEksiklik BasvuruTasimaAracEksiklik_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruTasimaAracEksiklik"
    ADD CONSTRAINT "BasvuruTasimaAracEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruTasimaArac BasvuruTasimaArac_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruTasimaArac"
    ADD CONSTRAINT "BasvuruTasimaArac_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: IlDegisikligiBasvuruAsama IlDegisikligiBasvuruAsama_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."IlDegisikligiBasvuruAsama"
    ADD CONSTRAINT "IlDegisikligiBasvuruAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: IlDegisikligiBasvuru IlDegisikligiBasvuru_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."IlDegisikligiBasvuru"
    ADD CONSTRAINT "IlDegisikligiBasvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: OdemeReferansNumarasi OdemeReferansNumarasi_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."OdemeReferansNumarasi"
    ADD CONSTRAINT "OdemeReferansNumarasi_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: SurucuBelge SurucuBelge_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."SurucuBelge"
    ADD CONSTRAINT "SurucuBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: SurucuGecmis SurucuGecmis_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."SurucuGecmis"
    ADD CONSTRAINT "SurucuGecmis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: SurucuTasimaArac SurucuTasimaArac_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."SurucuTasimaArac"
    ADD CONSTRAINT "SurucuTasimaArac_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Surucu Surucu_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."Surucu"
    ADD CONSTRAINT "Surucu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TasimaAracBelge TasimaAracBelge_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."TasimaAracBelge"
    ADD CONSTRAINT "TasimaAracBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TasimaAracGecmis TasimaAracGecmis_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."TasimaAracGecmis"
    ADD CONSTRAINT "TasimaAracGecmis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TasimaArac TasimaArac_pkey; Type: CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."TasimaArac"
    ADD CONSTRAINT "TasimaArac_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtikKod AtikKod_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."AtikKod"
    ADD CONSTRAINT "AtikKod_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruAtikKod BasvuruAtikKod_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruAtikKod"
    ADD CONSTRAINT "BasvuruAtikKod_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruDRKod BasvuruDRKod_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruDRKod"
    ADD CONSTRAINT "BasvuruDRKod_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruIzinKonu BasvuruIzinKonu_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruIzinKonu"
    ADD CONSTRAINT "BasvuruIzinKonu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruKapsam BasvuruKapsam_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruKapsam"
    ADD CONSTRAINT "BasvuruKapsam_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruLisansKonu BasvuruKonu_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruLisansKonu"
    ADD CONSTRAINT "BasvuruKonu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruNot BasvuruNotlar_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruNot"
    ADD CONSTRAINT "BasvuruNotlar_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruOzet BasvuruOzet_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruOzet"
    ADD CONSTRAINT "BasvuruOzet_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Basvuru Basvuru_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."Basvuru"
    ADD CONSTRAINT "Basvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: DRKod DRKod_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."DRKod"
    ADD CONSTRAINT "DRKod_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: EK3ANaceBilgi EK3ANaceBilgi_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3ANaceBilgi"
    ADD CONSTRAINT "EK3ANaceBilgi_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: EK3ATesisFaaliyetBolge EK3ATesisFaaliyetBölge_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3ATesisFaaliyetBolge"
    ADD CONSTRAINT "EK3ATesisFaaliyetBölge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: EK3AYillikTuketimKapasite EK3AYillikTuketimKapasite_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3AYillikTuketimKapasite"
    ADD CONSTRAINT "EK3AYillikTuketimKapasite_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: EK3AYillikUretimKapasite EK3AYillikUretimKapasite_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3AYillikUretimKapasite"
    ADD CONSTRAINT "EK3AYillikUretimKapasite_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: EK3A EK3A_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3A"
    ADD CONSTRAINT "EK3A_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ILMudurluguUygunlukUzmanKonu ILMudurluguUygunlukUzmanKonu_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."ILMudurluguUygunlukUzmanKonu"
    ADD CONSTRAINT "ILMudurluguUygunlukUzmanKonu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: IlMudurluguUygunluk IlMudurluguUygunluk_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."IlMudurluguUygunluk"
    ADD CONSTRAINT "IlMudurluguUygunluk_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: EkTuru Kapsam_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EkTuru"
    ADD CONSTRAINT "Kapsam_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Kapsam Kapsam_pkey1; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."Kapsam"
    ADD CONSTRAINT "Kapsam_pkey1" PRIMARY KEY ("Kimlik");


--
-- Name: LisansKonu LisansKonu_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."LisansKonu"
    ADD CONSTRAINT "LisansKonu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: atikKodGecici atikKodGecici_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."atikKodGecici"
    ADD CONSTRAINT "atikKodGecici_pkey" PRIMARY KEY (atikkodid);


--
-- Name: IsAkisi İsAkisi_pkey; Type: CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."IsAkisi"
    ADD CONSTRAINT "İsAkisi_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruAtikKoduAsama AltBasvuruAtikKoduAsama_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruAtikKoduAsama"
    ADD CONSTRAINT "AltBasvuruAtikKoduAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruAtikKodu AltBasvuruAtikKodu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruAtikKodu"
    ADD CONSTRAINT "AltBasvuruAtikKodu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruLisansIptalAsama AltBasvuruLisansIptalAsama_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruLisansIptalAsama"
    ADD CONSTRAINT "AltBasvuruLisansIptalAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruLisansIptal AltBasvuruLisansIptal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruLisansIptal"
    ADD CONSTRAINT "AltBasvuruLisansIptal_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruLisansVizeAsama AltBasvuruLisansVizeAsama_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruLisansVizeAsama"
    ADD CONSTRAINT "AltBasvuruLisansVizeAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruLisansVize AltBasvuruLisansVize_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruLisansVize"
    ADD CONSTRAINT "AltBasvuruLisansVize_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruSurucuAsama AltBasvuruSurucuAsama_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruSurucuAsama"
    ADD CONSTRAINT "AltBasvuruSurucuAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruSurucu AltBasvuruSurucu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruSurucu"
    ADD CONSTRAINT "AltBasvuruSurucu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruTasimaAracAsama AltBasvuruTasimaAracAsama_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruTasimaAracAsama"
    ADD CONSTRAINT "AltBasvuruTasimaAracAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruTasimaAracOdeme AltBasvuruTasimaAracOdeme_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruTasimaAracOdeme"
    ADD CONSTRAINT "AltBasvuruTasimaAracOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruTasimaArac AltBasvuruTasimaArac_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruTasimaArac"
    ADD CONSTRAINT "AltBasvuruTasimaArac_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtikTehlikelilikOzellik AtikTehlikelilikOzellik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtikTehlikelilikOzellik"
    ADD CONSTRAINT "AtikTehlikelilikOzellik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtyonAtikKod AtyonAtikKod_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtyonAtikKod"
    ADD CONSTRAINT "AtyonAtikKod_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtyonBasvuruBelge AtyonBasvuruBelge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtyonBasvuruBelge"
    ADD CONSTRAINT "AtyonBasvuruBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtyonBasvuru AtyonBasvuru_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtyonBasvuru"
    ADD CONSTRAINT "AtyonBasvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AtyonBasvuruCevreMuhendisi AtyonCevreMuhendisi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtyonBasvuruCevreMuhendisi"
    ADD CONSTRAINT "AtyonCevreMuhendisi_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruAsama BasvuruAsama_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruAsama"
    ADD CONSTRAINT "BasvuruAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruCevreMuhendisiEksiklik BasvuruCevreMuhendisiEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruCevreMuhendisiEksiklik"
    ADD CONSTRAINT "BasvuruCevreMuhendisiEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruGecmis BasvuruGecmis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruGecmis"
    ADD CONSTRAINT "BasvuruGecmis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruOdemeEksiklik BasvuruOdemeEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruOdemeEksiklik"
    ADD CONSTRAINT "BasvuruOdemeEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruOdeme BasvuruOdeme_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruOdeme"
    ADD CONSTRAINT "BasvuruOdeme_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruSurucuEksiklik BasvuruSurucuEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruSurucuEksiklik"
    ADD CONSTRAINT "BasvuruSurucuEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruSurucu BasvuruSurucu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruSurucu"
    ADD CONSTRAINT "BasvuruSurucu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruTasimaAracEksiklik BasvuruTasimaAracEksiklik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruTasimaAracEksiklik"
    ADD CONSTRAINT "BasvuruTasimaAracEksiklik_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BasvuruTasimaArac BasvuruTasimaArac_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruTasimaArac"
    ADD CONSTRAINT "BasvuruTasimaArac_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: EK1EK2 EK1Ek2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EK1EK2"
    ADD CONSTRAINT "EK1Ek2_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: IlDegisikligiBasvuruAsama IlDegisikligiBasvuruAsama_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."IlDegisikligiBasvuruAsama"
    ADD CONSTRAINT "IlDegisikligiBasvuruAsama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: IlDegisikligiBasvuru IlDegisikligiBasvuru_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."IlDegisikligiBasvuru"
    ADD CONSTRAINT "IlDegisikligiBasvuru_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: OdemeReferansNumarasi OdemeReferansNumarasi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OdemeReferansNumarasi"
    ADD CONSTRAINT "OdemeReferansNumarasi_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: Personel Personel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Personel"
    ADD CONSTRAINT "Personel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: SurucuBelge SurucuBelge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurucuBelge"
    ADD CONSTRAINT "SurucuBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: SurucuGecmis SurucuGecmis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurucuGecmis"
    ADD CONSTRAINT "SurucuGecmis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: SurucuTasimaArac SurucuTasimaArac_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurucuTasimaArac"
    ADD CONSTRAINT "SurucuTasimaArac_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Surucu Surucu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Surucu"
    ADD CONSTRAINT "Surucu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TasimaAracBelge TasimaAracBelge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TasimaAracBelge"
    ADD CONSTRAINT "TasimaAracBelge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TasimaAracGecmis TasimaAracGecmis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TasimaAracGecmis"
    ADD CONSTRAINT "TasimaAracGecmis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: TasimaArac TasimaArac_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TasimaArac"
    ADD CONSTRAINT "TasimaArac_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltBasvuruAtikKoduAsama AltBasvuruAtikKoduAsama_AltBasvuruAtikKoduKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruAtikKoduAsama"
    ADD CONSTRAINT "AltBasvuruAtikKoduAsama_AltBasvuruAtikKoduKimlikRef_fkey" FOREIGN KEY ("AltBasvuruAtikKoduKimlikRef") REFERENCES atyon."AltBasvuruAtikKodu"("Kimlik");


--
-- Name: AltBasvuruAtikKodu AltBasvuruAtikKodu_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruAtikKodu"
    ADD CONSTRAINT "AltBasvuruAtikKodu_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: AltBasvuruAtikKodu AltBasvuruAtikKodu_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruAtikKodu"
    ADD CONSTRAINT "AltBasvuruAtikKodu_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES atyon."TasimaArac"("Kimlik");


--
-- Name: AltBasvuruLisansIptalAsama AltBasvuruLisansIptalAsama_AltBasvuruLisansIptalKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruLisansIptalAsama"
    ADD CONSTRAINT "AltBasvuruLisansIptalAsama_AltBasvuruLisansIptalKimlikRef_fkey" FOREIGN KEY ("AltBasvuruLisansIptalKimlikRef") REFERENCES atyon."AltBasvuruLisansIptal"("Kimlik");


--
-- Name: AltBasvuruLisansIptal AltBasvuruLisansIptal_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruLisansIptal"
    ADD CONSTRAINT "AltBasvuruLisansIptal_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: AltBasvuruLisansVizeAsama AltBasvuruLisansVizeAsama_AltBasvuruLisansVizeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruLisansVizeAsama"
    ADD CONSTRAINT "AltBasvuruLisansVizeAsama_AltBasvuruLisansVizeKimlikRef_fkey" FOREIGN KEY ("AltBasvuruLisansVizeKimlikRef") REFERENCES atyon."AltBasvuruLisansVize"("Kimlik");


--
-- Name: AltBasvuruLisansVize AltBasvuruLisansVize_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruLisansVize"
    ADD CONSTRAINT "AltBasvuruLisansVize_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: AltBasvuruSurucuAsama AltBasvuruSurucuAsama_AltBasvuruSurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruSurucuAsama"
    ADD CONSTRAINT "AltBasvuruSurucuAsama_AltBasvuruSurucuKimlikRef_fkey" FOREIGN KEY ("AltBasvuruSurucuKimlikRef") REFERENCES atyon."AltBasvuruSurucu"("Kimlik");


--
-- Name: AltBasvuruSurucu AltBasvuruSurucu_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruSurucu"
    ADD CONSTRAINT "AltBasvuruSurucu_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: AltBasvuruTasimaAracAsama AltBasvuruTasimaAracAsama_AltBasvuruTasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruTasimaAracAsama"
    ADD CONSTRAINT "AltBasvuruTasimaAracAsama_AltBasvuruTasimaAracKimlikRef_fkey" FOREIGN KEY ("AltBasvuruTasimaAracKimlikRef") REFERENCES atyon."AltBasvuruTasimaArac"("Kimlik");


--
-- Name: AltBasvuruTasimaAracOdeme AltBasvuruTasimaAracOdeme_AltBasvuruTasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruTasimaAracOdeme"
    ADD CONSTRAINT "AltBasvuruTasimaAracOdeme_AltBasvuruTasimaAracKimlikRef_fkey" FOREIGN KEY ("AltBasvuruTasimaAracKimlikRef") REFERENCES atyon."AltBasvuruTasimaArac"("Kimlik");


--
-- Name: AltBasvuruTasimaAracOdeme AltBasvuruTasimaAracOdeme_OdemeReferansNumarasiKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruTasimaAracOdeme"
    ADD CONSTRAINT "AltBasvuruTasimaAracOdeme_OdemeReferansNumarasiKimlikRef_fkey" FOREIGN KEY ("OdemeReferansNumarasiKimlikRef") REFERENCES atyon."OdemeReferansNumarasi"("Kimlik");


--
-- Name: AltBasvuruTasimaArac AltBasvuruTasimaArac_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AltBasvuruTasimaArac"
    ADD CONSTRAINT "AltBasvuruTasimaArac_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: AtikTehlikelilikOzellik AtikTehlikelilikOzellik_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtikTehlikelilikOzellik"
    ADD CONSTRAINT "AtikTehlikelilikOzellik_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES atyon."TasimaArac"("Kimlik");


--
-- Name: AtyonAtikKod AtyonAtikKod_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtyonAtikKod"
    ADD CONSTRAINT "AtyonAtikKod_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES atyon."TasimaArac"("Kimlik");


--
-- Name: AtyonBasvuruBelge AtyonBasvuruBelge_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtyonBasvuruBelge"
    ADD CONSTRAINT "AtyonBasvuruBelge_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: AtyonBasvuruCevreMuhendisi AtyonBasvuruCevreMuhendisi_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."AtyonBasvuruCevreMuhendisi"
    ADD CONSTRAINT "AtyonBasvuruCevreMuhendisi_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: BasvuruAsama BasvuruAsama_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruAsama"
    ADD CONSTRAINT "BasvuruAsama_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: BasvuruCevreMuhendisiEksiklik BasvuruCevreMuhendisiEksiklik_BasvuruCevreMuhendisiKimlikR_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruCevreMuhendisiEksiklik"
    ADD CONSTRAINT "BasvuruCevreMuhendisiEksiklik_BasvuruCevreMuhendisiKimlikR_fkey" FOREIGN KEY ("BasvuruCevreMuhendisiKimlikRef") REFERENCES atyon."AtyonBasvuruCevreMuhendisi"("Kimlik");


--
-- Name: BasvuruGecmis BasvuruGecmis_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruGecmis"
    ADD CONSTRAINT "BasvuruGecmis_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: BasvuruOdemeEksiklik BasvuruOdemeEksiklik_BasvuruOdemeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruOdemeEksiklik"
    ADD CONSTRAINT "BasvuruOdemeEksiklik_BasvuruOdemeKimlikRef_fkey" FOREIGN KEY ("BasvuruOdemeKimlikRef") REFERENCES atyon."BasvuruOdeme"("Kimlik");


--
-- Name: BasvuruOdeme BasvuruOdeme_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruOdeme"
    ADD CONSTRAINT "BasvuruOdeme_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: BasvuruOdeme BasvuruOdeme_OdemeReferansNumarasiKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruOdeme"
    ADD CONSTRAINT "BasvuruOdeme_OdemeReferansNumarasiKimlikRef_fkey" FOREIGN KEY ("OdemeReferansNumarasiKimlikRef") REFERENCES atyon."OdemeReferansNumarasi"("Kimlik");


--
-- Name: BasvuruSurucuEksiklik BasvuruSurucuEksiklik_BasvuruSurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruSurucuEksiklik"
    ADD CONSTRAINT "BasvuruSurucuEksiklik_BasvuruSurucuKimlikRef_fkey" FOREIGN KEY ("BasvuruSurucuKimlikRef") REFERENCES atyon."BasvuruSurucu"("Kimlik");


--
-- Name: BasvuruSurucu BasvuruSurucu_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruSurucu"
    ADD CONSTRAINT "BasvuruSurucu_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: BasvuruSurucu BasvuruSurucu_SurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruSurucu"
    ADD CONSTRAINT "BasvuruSurucu_SurucuKimlikRef_fkey" FOREIGN KEY ("SurucuKimlikRef") REFERENCES atyon."Surucu"("Kimlik");


--
-- Name: BasvuruTasimaAracEksiklik BasvuruTasimaAracEksiklik_BasvuruTasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruTasimaAracEksiklik"
    ADD CONSTRAINT "BasvuruTasimaAracEksiklik_BasvuruTasimaAracKimlikRef_fkey" FOREIGN KEY ("BasvuruTasimaAracKimlikRef") REFERENCES atyon."BasvuruTasimaArac"("Kimlik");


--
-- Name: BasvuruTasimaArac BasvuruTasimaArac_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruTasimaArac"
    ADD CONSTRAINT "BasvuruTasimaArac_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: BasvuruTasimaArac BasvuruTasimaArac_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."BasvuruTasimaArac"
    ADD CONSTRAINT "BasvuruTasimaArac_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES atyon."TasimaArac"("Kimlik");


--
-- Name: IlDegisikligiBasvuruAsama IlDegisikligiBasvuruAsama_IlDegisikligiBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."IlDegisikligiBasvuruAsama"
    ADD CONSTRAINT "IlDegisikligiBasvuruAsama_IlDegisikligiBasvuruKimlikRef_fkey" FOREIGN KEY ("IlDegisikligiBasvuruKimlikRef") REFERENCES atyon."IlDegisikligiBasvuru"("Kimlik");


--
-- Name: IlDegisikligiBasvuru IlDegisikligiBasvuru_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."IlDegisikligiBasvuru"
    ADD CONSTRAINT "IlDegisikligiBasvuru_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES atyon."AtyonBasvuru"("Kimlik");


--
-- Name: IlDegisikligiBasvuru IlDegisikligiBasvuru_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."IlDegisikligiBasvuru"
    ADD CONSTRAINT "IlDegisikligiBasvuru_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES atyon."TasimaArac"("Kimlik");


--
-- Name: SurucuBelge SurucuBelge_SurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."SurucuBelge"
    ADD CONSTRAINT "SurucuBelge_SurucuKimlikRef_fkey" FOREIGN KEY ("SurucuKimlikRef") REFERENCES atyon."Surucu"("Kimlik");


--
-- Name: SurucuGecmis SurucuGecmis_SurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."SurucuGecmis"
    ADD CONSTRAINT "SurucuGecmis_SurucuKimlikRef_fkey" FOREIGN KEY ("SurucuKimlikRef") REFERENCES atyon."Surucu"("Kimlik");


--
-- Name: TasimaAracBelge TasimaAracBelge_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."TasimaAracBelge"
    ADD CONSTRAINT "TasimaAracBelge_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES atyon."TasimaArac"("Kimlik");


--
-- Name: TasimaAracGecmis TasimaAracGecmis_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: atyon; Owner: -
--

ALTER TABLE ONLY atyon."TasimaAracGecmis"
    ADD CONSTRAINT "TasimaAracGecmis_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES atyon."TasimaArac"("Kimlik");


--
-- Name: BasvuruKapsam  Basvuru_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruKapsam"
    ADD CONSTRAINT " Basvuru_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik");


--
-- Name: BasvuruKapsam  Kapsam_KapsamKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruKapsam"
    ADD CONSTRAINT " Kapsam_KapsamKimlikRef_fkey" FOREIGN KEY ("KapsamKimlikRef") REFERENCES "e-izin"."Kapsam"("Kimlik");


--
-- Name: AtikKod AtikKod_UstKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."AtikKod"
    ADD CONSTRAINT "AtikKod_UstKimlikRef_fkey" FOREIGN KEY ("UstKimlikRef") REFERENCES "e-izin"."AtikKod"("Kimlik") NOT VALID;


--
-- Name: BasvuruOzet BasvuruOzet_UstKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruOzet"
    ADD CONSTRAINT "BasvuruOzet_UstKimlikRef_fkey" FOREIGN KEY ("UstKimlikRef") REFERENCES "e-izin"."BasvuruOzet"("Kimlik");


--
-- Name: EK3A Basvuru_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3A"
    ADD CONSTRAINT "Basvuru_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik") NOT VALID;


--
-- Name: BasvuruLisansKonu Basvuru_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruLisansKonu"
    ADD CONSTRAINT "Basvuru_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik");


--
-- Name: BasvuruAtikKod Basvuru_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruAtikKod"
    ADD CONSTRAINT "Basvuru_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik");


--
-- Name: BasvuruDRKod Basvuru_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruDRKod"
    ADD CONSTRAINT "Basvuru_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik");


--
-- Name: IlMudurluguUygunluk Basvuru_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."IlMudurluguUygunluk"
    ADD CONSTRAINT "Basvuru_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik");


--
-- Name: BasvuruOzet Basvuru_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruOzet"
    ADD CONSTRAINT "Basvuru_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik");


--
-- Name: BasvuruNot Basvuru_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruNot"
    ADD CONSTRAINT "Basvuru_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik");


--
-- Name: BasvuruIzinKonu Basvuru_KimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruIzinKonu"
    ADD CONSTRAINT "Basvuru_KimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik");


--
-- Name: Basvuru Basvuru_UstKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."Basvuru"
    ADD CONSTRAINT "Basvuru_UstKimlikRef_fkey" FOREIGN KEY ("UstKimlikRef") REFERENCES "e-izin"."Basvuru"("Kimlik") NOT VALID;


--
-- Name: BasvuruDRKod DRKod_DRKodKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruDRKod"
    ADD CONSTRAINT "DRKod_DRKodKimlikRef_fkey" FOREIGN KEY ("DRKodKimlikRef") REFERENCES "e-izin"."DRKod"("Kimlik");


--
-- Name: EK3ATesisFaaliyetBolge EK3A_EK3AKimlikRef; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3ATesisFaaliyetBolge"
    ADD CONSTRAINT "EK3A_EK3AKimlikRef" FOREIGN KEY ("EK3AKimlikRef") REFERENCES "e-izin"."EK3A"("Kimlik");


--
-- Name: EK3ANaceBilgi EK3A_EK3AKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3ANaceBilgi"
    ADD CONSTRAINT "EK3A_EK3AKimlikRef_fkey" FOREIGN KEY ("EK3AKimlikRef") REFERENCES "e-izin"."EK3A"("Kimlik");


--
-- Name: EK3AYillikUretimKapasite EK3A_EK3AKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3AYillikUretimKapasite"
    ADD CONSTRAINT "EK3A_EK3AKimlikRef_fkey" FOREIGN KEY ("EK3AKimlikRef") REFERENCES "e-izin"."EK3A"("Kimlik");


--
-- Name: EK3AYillikTuketimKapasite EK3A_EK3AKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."EK3AYillikTuketimKapasite"
    ADD CONSTRAINT "EK3A_EK3AKimlikRef_fkey" FOREIGN KEY ("EK3AKimlikRef") REFERENCES "e-izin"."EK3A"("Kimlik");


--
-- Name: Kapsam EkTur_EkTurKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."Kapsam"
    ADD CONSTRAINT "EkTur_EkTurKimlikRef_fkey" FOREIGN KEY ("EkTuruKimlikRef") REFERENCES "e-izin"."EkTuru"("Kimlik") NOT VALID;


--
-- Name: ILMudurluguUygunlukUzmanKonu IlMudurluguUygunluk_IlMudurluguUygunlukKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."ILMudurluguUygunlukUzmanKonu"
    ADD CONSTRAINT "IlMudurluguUygunluk_IlMudurluguUygunlukKimlikRef_fkey" FOREIGN KEY ("IlMudurluguUygunlukKimlikRef") REFERENCES "e-izin"."IlMudurluguUygunluk"("Kimlik");


--
-- Name: IlMudurluguUygunluk IlMudurluguUygunluk_UstKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."IlMudurluguUygunluk"
    ADD CONSTRAINT "IlMudurluguUygunluk_UstKimlikRef_fkey" FOREIGN KEY ("UstKimlikRef") REFERENCES "e-izin"."IlMudurluguUygunluk"("Kimlik") NOT VALID;


--
-- Name: IsAkisi IsAkisi_KapsamKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."IsAkisi"
    ADD CONSTRAINT "IsAkisi_KapsamKimlikRef_fkey" FOREIGN KEY ("KapsamKimlikRef") REFERENCES "e-izin"."EkTuru"("Kimlik") NOT VALID;


--
-- Name: IsAkisi IsAkisi_UstKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."IsAkisi"
    ADD CONSTRAINT "IsAkisi_UstKimlikRef_fkey" FOREIGN KEY ("UstKimlikRef") REFERENCES "e-izin"."IsAkisi"("Kimlik") NOT VALID;


--
-- Name: Kapsam Kapsam_UstKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."Kapsam"
    ADD CONSTRAINT "Kapsam_UstKimlikRef_fkey" FOREIGN KEY ("UstKimlikRef") REFERENCES "e-izin"."Kapsam"("Kimlik") NOT VALID;


--
-- Name: BasvuruLisansKonu LisansKonu_LisansKonuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."BasvuruLisansKonu"
    ADD CONSTRAINT "LisansKonu_LisansKonuKimlikRef_fkey" FOREIGN KEY ("LisansKonuKimlikRef") REFERENCES "e-izin"."LisansKonu"("Kimlik");


--
-- Name: LisansKonu LisansKonu_UstKimlikRef_fkey; Type: FK CONSTRAINT; Schema: e-izin; Owner: -
--

ALTER TABLE ONLY "e-izin"."LisansKonu"
    ADD CONSTRAINT "LisansKonu_UstKimlikRef_fkey" FOREIGN KEY ("UstKimlikRef") REFERENCES "e-izin"."LisansKonu"("Kimlik") NOT VALID;


--
-- Name: AltBasvuruAtikKoduAsama AltBasvuruAtikKoduAsama_AltBasvuruAtikKoduKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruAtikKoduAsama"
    ADD CONSTRAINT "AltBasvuruAtikKoduAsama_AltBasvuruAtikKoduKimlikRef_fkey" FOREIGN KEY ("AltBasvuruAtikKoduKimlikRef") REFERENCES public."AltBasvuruAtikKodu"("Kimlik");


--
-- Name: AltBasvuruAtikKodu AltBasvuruAtikKodu_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruAtikKodu"
    ADD CONSTRAINT "AltBasvuruAtikKodu_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik");


--
-- Name: AltBasvuruAtikKodu AltBasvuruAtikKodu_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruAtikKodu"
    ADD CONSTRAINT "AltBasvuruAtikKodu_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES public."TasimaArac"("Kimlik") NOT VALID;


--
-- Name: AltBasvuruLisansIptalAsama AltBasvuruLisansIptalAsama_AltBasvuruLisansIptalKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruLisansIptalAsama"
    ADD CONSTRAINT "AltBasvuruLisansIptalAsama_AltBasvuruLisansIptalKimlikRef_fkey" FOREIGN KEY ("AltBasvuruLisansIptalKimlikRef") REFERENCES public."AltBasvuruLisansIptal"("Kimlik");


--
-- Name: AltBasvuruLisansIptal AltBasvuruLisansIptal_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruLisansIptal"
    ADD CONSTRAINT "AltBasvuruLisansIptal_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik");


--
-- Name: AltBasvuruLisansVizeAsama AltBasvuruLisansVizeAsama_AltBasvuruLisansVizeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruLisansVizeAsama"
    ADD CONSTRAINT "AltBasvuruLisansVizeAsama_AltBasvuruLisansVizeKimlikRef_fkey" FOREIGN KEY ("AltBasvuruLisansVizeKimlikRef") REFERENCES public."AltBasvuruLisansVize"("Kimlik");


--
-- Name: AltBasvuruLisansVize AltBasvuruLisansVize_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruLisansVize"
    ADD CONSTRAINT "AltBasvuruLisansVize_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik");


--
-- Name: AltBasvuruSurucuAsama AltBasvuruSurucuAsama_AltBasvuruSurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruSurucuAsama"
    ADD CONSTRAINT "AltBasvuruSurucuAsama_AltBasvuruSurucuKimlikRef_fkey" FOREIGN KEY ("AltBasvuruSurucuKimlikRef") REFERENCES public."AltBasvuruSurucu"("Kimlik") NOT VALID;


--
-- Name: AltBasvuruSurucu AltBasvuruSurucu_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruSurucu"
    ADD CONSTRAINT "AltBasvuruSurucu_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik") NOT VALID;


--
-- Name: AltBasvuruTasimaAracAsama AltBasvuruTasimaAracAsama_AltBasvuruTasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruTasimaAracAsama"
    ADD CONSTRAINT "AltBasvuruTasimaAracAsama_AltBasvuruTasimaAracKimlikRef_fkey" FOREIGN KEY ("AltBasvuruTasimaAracKimlikRef") REFERENCES public."AltBasvuruTasimaArac"("Kimlik") NOT VALID;


--
-- Name: AltBasvuruTasimaAracOdeme AltBasvuruTasimaAracOdeme_AltBasvuruTasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruTasimaAracOdeme"
    ADD CONSTRAINT "AltBasvuruTasimaAracOdeme_AltBasvuruTasimaAracKimlikRef_fkey" FOREIGN KEY ("AltBasvuruTasimaAracKimlikRef") REFERENCES public."AltBasvuruTasimaArac"("Kimlik");


--
-- Name: AltBasvuruTasimaAracOdeme AltBasvuruTasimaAracOdeme_OdemeReferansNumarasiKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruTasimaAracOdeme"
    ADD CONSTRAINT "AltBasvuruTasimaAracOdeme_OdemeReferansNumarasiKimlikRef_fkey" FOREIGN KEY ("OdemeReferansNumarasiKimlikRef") REFERENCES public."OdemeReferansNumarasi"("Kimlik") NOT VALID;


--
-- Name: AltBasvuruTasimaArac AltBasvuruTasimaArac_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltBasvuruTasimaArac"
    ADD CONSTRAINT "AltBasvuruTasimaArac_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik") NOT VALID;


--
-- Name: AtikTehlikelilikOzellik AtikTehlikelilikOzellik_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtikTehlikelilikOzellik"
    ADD CONSTRAINT "AtikTehlikelilikOzellik_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES public."TasimaArac"("Kimlik") NOT VALID;


--
-- Name: AtyonAtikKod AtyonAtikKod_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtyonAtikKod"
    ADD CONSTRAINT "AtyonAtikKod_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES public."TasimaArac"("Kimlik");


--
-- Name: AtyonBasvuruBelge AtyonBasvuruBelge_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtyonBasvuruBelge"
    ADD CONSTRAINT "AtyonBasvuruBelge_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik") NOT VALID;


--
-- Name: AtyonBasvuruCevreMuhendisi AtyonBasvuruCevreMuhendisi_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AtyonBasvuruCevreMuhendisi"
    ADD CONSTRAINT "AtyonBasvuruCevreMuhendisi_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik") NOT VALID;


--
-- Name: BasvuruAsama BasvuruAsama_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruAsama"
    ADD CONSTRAINT "BasvuruAsama_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik");


--
-- Name: BasvuruCevreMuhendisiEksiklik BasvuruCevreMuhendisiEksiklik_BasvuruCevreMuhendisiKimlikR_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruCevreMuhendisiEksiklik"
    ADD CONSTRAINT "BasvuruCevreMuhendisiEksiklik_BasvuruCevreMuhendisiKimlikR_fkey" FOREIGN KEY ("BasvuruCevreMuhendisiKimlikRef") REFERENCES public."AtyonBasvuruCevreMuhendisi"("Kimlik") NOT VALID;


--
-- Name: BasvuruGecmis BasvuruGecmis_BasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruGecmis"
    ADD CONSTRAINT "BasvuruGecmis_BasvuruKimlikRef_fkey" FOREIGN KEY ("BasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik");


--
-- Name: BasvuruOdemeEksiklik BasvuruOdemeEksiklik_BasvuruOdemeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruOdemeEksiklik"
    ADD CONSTRAINT "BasvuruOdemeEksiklik_BasvuruOdemeKimlikRef_fkey" FOREIGN KEY ("BasvuruOdemeKimlikRef") REFERENCES public."BasvuruOdeme"("Kimlik") NOT VALID;


--
-- Name: BasvuruOdeme BasvuruOdeme_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruOdeme"
    ADD CONSTRAINT "BasvuruOdeme_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik") NOT VALID;


--
-- Name: BasvuruOdeme BasvuruOdeme_OdemeReferansNumarasiKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruOdeme"
    ADD CONSTRAINT "BasvuruOdeme_OdemeReferansNumarasiKimlikRef_fkey" FOREIGN KEY ("OdemeReferansNumarasiKimlikRef") REFERENCES public."OdemeReferansNumarasi"("Kimlik") NOT VALID;


--
-- Name: BasvuruSurucuEksiklik BasvuruSurucuEksiklik_BasvuruSurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruSurucuEksiklik"
    ADD CONSTRAINT "BasvuruSurucuEksiklik_BasvuruSurucuKimlikRef_fkey" FOREIGN KEY ("BasvuruSurucuKimlikRef") REFERENCES public."BasvuruSurucu"("Kimlik") NOT VALID;


--
-- Name: BasvuruSurucu BasvuruSurucu_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruSurucu"
    ADD CONSTRAINT "BasvuruSurucu_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik") NOT VALID;


--
-- Name: BasvuruSurucu BasvuruSurucu_SurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruSurucu"
    ADD CONSTRAINT "BasvuruSurucu_SurucuKimlikRef_fkey" FOREIGN KEY ("SurucuKimlikRef") REFERENCES public."Surucu"("Kimlik") NOT VALID;


--
-- Name: BasvuruTasimaAracEksiklik BasvuruTasimaAracEksiklik_BasvuruTasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruTasimaAracEksiklik"
    ADD CONSTRAINT "BasvuruTasimaAracEksiklik_BasvuruTasimaAracKimlikRef_fkey" FOREIGN KEY ("BasvuruTasimaAracKimlikRef") REFERENCES public."BasvuruTasimaArac"("Kimlik") NOT VALID;


--
-- Name: BasvuruTasimaArac BasvuruTasimaArac_AtyonBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruTasimaArac"
    ADD CONSTRAINT "BasvuruTasimaArac_AtyonBasvuruKimlikRef_fkey" FOREIGN KEY ("AtyonBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik") NOT VALID;


--
-- Name: BasvuruTasimaArac BasvuruTasimaArac_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BasvuruTasimaArac"
    ADD CONSTRAINT "BasvuruTasimaArac_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES public."TasimaArac"("Kimlik") NOT VALID;


--
-- Name: IlDegisikligiBasvuruAsama IlDegisikligiBasvuruAsama_IlDegisikligiBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."IlDegisikligiBasvuruAsama"
    ADD CONSTRAINT "IlDegisikligiBasvuruAsama_IlDegisikligiBasvuruKimlikRef_fkey" FOREIGN KEY ("IlDegisikligiBasvuruKimlikRef") REFERENCES public."IlDegisikligiBasvuru"("Kimlik") NOT VALID;


--
-- Name: IlDegisikligiBasvuru IlDegisikligiBasvuru_AnaBasvuruKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."IlDegisikligiBasvuru"
    ADD CONSTRAINT "IlDegisikligiBasvuru_AnaBasvuruKimlikRef_fkey" FOREIGN KEY ("AnaBasvuruKimlikRef") REFERENCES public."AtyonBasvuru"("Kimlik") NOT VALID;


--
-- Name: IlDegisikligiBasvuru IlDegisikligiBasvuru_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."IlDegisikligiBasvuru"
    ADD CONSTRAINT "IlDegisikligiBasvuru_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES public."TasimaArac"("Kimlik") NOT VALID;


--
-- Name: SurucuBelge SurucuBelge_SurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurucuBelge"
    ADD CONSTRAINT "SurucuBelge_SurucuKimlikRef_fkey" FOREIGN KEY ("SurucuKimlikRef") REFERENCES public."Surucu"("Kimlik") NOT VALID;


--
-- Name: SurucuGecmis SurucuGecmis_SurucuKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurucuGecmis"
    ADD CONSTRAINT "SurucuGecmis_SurucuKimlikRef_fkey" FOREIGN KEY ("SurucuKimlikRef") REFERENCES public."Surucu"("Kimlik");


--
-- Name: TasimaAracBelge TasimaAracBelge_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TasimaAracBelge"
    ADD CONSTRAINT "TasimaAracBelge_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES public."TasimaArac"("Kimlik") NOT VALID;


--
-- Name: TasimaAracGecmis TasimaAracGecmis_TasimaAracKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TasimaAracGecmis"
    ADD CONSTRAINT "TasimaAracGecmis_TasimaAracKimlikRef_fkey" FOREIGN KEY ("TasimaAracKimlikRef") REFERENCES public."TasimaArac"("Kimlik");


--
-- PostgreSQL database dump complete
--

