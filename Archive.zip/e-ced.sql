--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."UzmanUygunluk" DROP CONSTRAINT IF EXISTS "UzmanUygunluk_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."UzmanAtama" DROP CONSTRAINT IF EXISTS "UzmanAtama_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeTutar" DROP CONSTRAINT IF EXISTS "ProjeTutar_ProjeTutarKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeTutar" DROP CONSTRAINT IF EXISTS "ProjeTutar_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeSektor" DROP CONSTRAINT IF EXISTS "ProjeSektor_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjePersonel" DROP CONSTRAINT IF EXISTS "ProjePersonel_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeMuafiyetBasvurusuTip" DROP CONSTRAINT IF EXISTS "ProjeMuafiyetBasvurusuTip_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeMuafiyetBasvuruSonucu" DROP CONSTRAINT IF EXISTS "ProjeMuafiyetBasvuruSonucu_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeAkis" DROP CONSTRAINT IF EXISTS "ProjeMuafityetAkis_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeKonumIl" DROP CONSTRAINT IF EXISTS "ProjeKonum_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeKonumMevki" DROP CONSTRAINT IF EXISTS "ProjeKonumMevki_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeKonumIlce" DROP CONSTRAINT IF EXISTS "ProjeKonumIlce_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeFaaliyetNace" DROP CONSTRAINT IF EXISTS "ProjeFaaliyetNace_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeEksiklikBildirimi" DROP CONSTRAINT IF EXISTS "ProjeEksiklikBildirimi_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeAltSektor" DROP CONSTRAINT IF EXISTS "ProjeAltSektor_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."ProjeAkisAtananlar" DROP CONSTRAINT IF EXISTS "ProjeAkısAtananlar_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."Geometri" DROP CONSTRAINT IF EXISTS "Geometri_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."Gecmis" DROP CONSTRAINT IF EXISTS "Gecmis_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."CevreselVeriFormu" DROP CONSTRAINT IF EXISTS "CevreselVeriFormu_ProjeKimlik_fkey";
ALTER TABLE IF EXISTS ONLY public."Belge" DROP CONSTRAINT IF EXISTS "Belge_ProjeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."BelgeUygunluk" DROP CONSTRAINT IF EXISTS "BelgeUygunluk_BelgeKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."AltKurum" DROP CONSTRAINT IF EXISTS "AltKurum_AltKurumKimlikRef_fkey";
ALTER TABLE IF EXISTS ONLY public."YerGormeDilekce" DROP CONSTRAINT IF EXISTS "YerGormeDilekce_pkey";
ALTER TABLE IF EXISTS ONLY public."UzmanUygunluk" DROP CONSTRAINT IF EXISTS "UzmanUygunluk_pkey";
ALTER TABLE IF EXISTS ONLY public."UzmanAtama" DROP CONSTRAINT IF EXISTS "UzmanAtama_pkey";
ALTER TABLE IF EXISTS ONLY public."Tutar" DROP CONSTRAINT IF EXISTS "Tutar_pkey";
ALTER TABLE IF EXISTS ONLY public."Proje" DROP CONSTRAINT IF EXISTS "Proje_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeTutar" DROP CONSTRAINT IF EXISTS "ProjeTutar_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeSektor" DROP CONSTRAINT IF EXISTS "ProjeSektor_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjePersonel" DROP CONSTRAINT IF EXISTS "ProjePersonel_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeMuafiyetBasvurusuTip" DROP CONSTRAINT IF EXISTS "ProjeMuafiyetBasvurusuTip_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeMuafiyetBasvuruSonucu" DROP CONSTRAINT IF EXISTS "ProjeMuafiyetBasvuruSonucu_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeAkis" DROP CONSTRAINT IF EXISTS "ProjeMuafityetAkis_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeKonumIl" DROP CONSTRAINT IF EXISTS "ProjeKonum_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeKonumMevki" DROP CONSTRAINT IF EXISTS "ProjeKonumMevki_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeKonumIlce" DROP CONSTRAINT IF EXISTS "ProjeKonumIlce_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeFaaliyetNace" DROP CONSTRAINT IF EXISTS "ProjeFaaliyetNace_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeEksiklikBildirimi" DROP CONSTRAINT IF EXISTS "ProjeEksiklikBildirimi_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeAltSektor" DROP CONSTRAINT IF EXISTS "ProjeAltSektor_pkey";
ALTER TABLE IF EXISTS ONLY public."ProjeAkisAtananlar" DROP CONSTRAINT IF EXISTS "ProjeAkısAtananlar_pkey";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY public."Geometri" DROP CONSTRAINT IF EXISTS "Geometri_pkey";
ALTER TABLE IF EXISTS ONLY public."CevreselVeriFormu" DROP CONSTRAINT IF EXISTS "CevreselVeriFormu_pkey";
ALTER TABLE IF EXISTS ONLY public."Belge" DROP CONSTRAINT IF EXISTS "Belge_pkey";
ALTER TABLE IF EXISTS ONLY public."BelgeUygunluk" DROP CONSTRAINT IF EXISTS "BelgeUygunluk_pkey";
ALTER TABLE IF EXISTS ONLY public."AltKurum" DROP CONSTRAINT IF EXISTS "AltKurum_pkey";
ALTER TABLE IF EXISTS ONLY base."DBAnaModel2" DROP CONSTRAINT IF EXISTS "DBAnaModel_pkey";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS public."YerGormeDilekce";
DROP VIEW IF EXISTS public."View_ProjeHangiAsamada";
DROP TABLE IF EXISTS public."UzmanUygunluk";
DROP VIEW IF EXISTS public."UzmanIncelemeBekleyenlerListesi";
DROP TABLE IF EXISTS public."Tutar";
DROP TABLE IF EXISTS public."ProjeTutar";
DROP TABLE IF EXISTS public."ProjeSektor";
DROP TABLE IF EXISTS public."ProjePersonel";
DROP TABLE IF EXISTS public."ProjeMuafiyetBasvurusuTip";
DROP TABLE IF EXISTS public."ProjeMuafiyetBasvuruSonucu";
DROP TABLE IF EXISTS public."ProjeKonumMevki";
DROP TABLE IF EXISTS public."ProjeKonumIlce";
DROP TABLE IF EXISTS public."ProjeKonumIl";
DROP TABLE IF EXISTS public."ProjeFaaliyetNace";
DROP TABLE IF EXISTS public."ProjeEksiklikBildirimi";
DROP TABLE IF EXISTS public."ProjeAltSektor";
DROP TABLE IF EXISTS public."ProjeAkisAtananlar";
DROP TABLE IF EXISTS public."ProjeAkis";
DROP TABLE IF EXISTS public."Geometri";
DROP TABLE IF EXISTS public."Gecmis";
DROP TABLE IF EXISTS public."CevreselVeriFormu";
DROP TABLE IF EXISTS public."BelgeUygunluk";
DROP TABLE IF EXISTS public."Belge";
DROP VIEW IF EXISTS public."AtanmisUzmanlar";
DROP TABLE IF EXISTS public."UzmanAtama";
DROP TABLE IF EXISTS public."Proje";
DROP TABLE IF EXISTS public."AltKurum";
DROP TABLE IF EXISTS base."DBAnaModel2";
DROP SCHEMA IF EXISTS ced;
DROP SCHEMA IF EXISTS base;
--
-- Name: base; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA base;


--
-- Name: ced; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA ced;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: DBAnaModel2; Type: TABLE; Schema: base; Owner: -
--

CREATE TABLE base."DBAnaModel2" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL
);


--
-- Name: AltKurum; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AltKurum" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "AltKurumKimlikRef" uuid NOT NULL
);


--
-- Name: Proje; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Proje" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeUstKimlikRef" uuid,
    "ProjeTip" integer NOT NULL,
    "HesapKimlikRef" uuid NOT NULL,
    "HazirlayanHesapKimlikRef" uuid NOT NULL,
    "Kapasite" character varying,
    "Tutar" numeric,
    "Ozet" character varying,
    "Adres" character varying,
    "Adi" character varying,
    "HesapAdi" character varying,
    "HazirlayanHesapAdi" character varying,
    "HesaplanmisProjeBedeli" numeric
);


--
-- Name: UzmanAtama; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UzmanAtama" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "Tip" integer NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL,
    "Koordinator" boolean
);


--
-- Name: AtanmisUzmanlar; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public."AtanmisUzmanlar" AS
 SELECT p."Kimlik",
    p."ProjeTip",
    u."KullaniciKimlikRef",
    p."Durum",
    u."Tip",
    u."Koordinator"
   FROM (public."Proje" p
     JOIN public."UzmanAtama" u ON ((p."Kimlik" = u."ProjeKimlikRef")));


--
-- Name: Belge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Belge" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer,
    "ProjeKimlikRef" uuid,
    "BelgeAdi" character varying,
    "DosyaTipi" integer
);


--
-- Name: BelgeUygunluk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BelgeUygunluk" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "BelgeKimlikRef" uuid,
    "Onay" integer,
    "Aciklama" character varying,
    "BildirenKimlikRef" uuid
);


--
-- Name: CevreselVeriFormu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CevreselVeriFormu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "Miktar" character varying,
    "Aciklama" character varying,
    "ProjeKimlik" uuid NOT NULL,
    "AtikAsama" integer,
    "Atik" integer,
    "AtikBirim" integer
);


--
-- Name: Gecmis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Gecmis" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "EskiDurum" integer,
    "YeniDurum" integer,
    "GecmisKayit" character varying,
    "MevcutKayit" character varying
);


--
-- Name: Geometri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Geometri" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL
);


--
-- Name: ProjeAkis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeAkis" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "Akis" integer,
    "AtananKimlikRef" uuid NOT NULL
);


--
-- Name: ProjeAkisAtananlar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeAkisAtananlar" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "AtananKimlikRef" uuid,
    "AtananTip" integer
);


--
-- Name: ProjeAltSektor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeAltSektor" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "AltSektorTanimRef" uuid NOT NULL
);


--
-- Name: ProjeEksiklikBildirimi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeEksiklikBildirimi" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "EksiklikYapanKimlikRef" uuid,
    "EksiklikAciklama" character varying,
    "FirmaGorsunMu" boolean,
    "ProjeKimlikRef" uuid
);


--
-- Name: ProjeFaaliyetNace; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeFaaliyetNace" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "NACETanimKimlikRef" uuid NOT NULL
);


--
-- Name: ProjeKonumIl; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeKonumIl" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid,
    "Il" uuid
);


--
-- Name: ProjeKonumIlce; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeKonumIlce" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid,
    "Ilce" uuid
);


--
-- Name: ProjeKonumMevki; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeKonumMevki" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid,
    "Mevki" character varying
);


--
-- Name: ProjeMuafiyetBasvuruSonucu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeMuafiyetBasvuruSonucu" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "ProjeSonucu" integer NOT NULL
);


--
-- Name: ProjeMuafiyetBasvurusuTip; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeMuafiyetBasvurusuTip" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "Tip" integer NOT NULL
);


--
-- Name: ProjePersonel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjePersonel" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "KullaniciKimlikRef" uuid NOT NULL
);


--
-- Name: ProjeSektor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeSektor" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "SektorTanimRef" uuid NOT NULL
);


--
-- Name: ProjeTutar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjeTutar" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid NOT NULL,
    "ProjeTutarKimlikRef" uuid NOT NULL
);


--
-- Name: Tutar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Tutar" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "Ad" character varying,
    "Tutar" numeric,
    "AltLimit" numeric,
    "UstLimit" numeric,
    "Yil" integer
);


--
-- Name: UzmanIncelemeBekleyenlerListesi; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public."UzmanIncelemeBekleyenlerListesi" AS
 SELECT p."Kimlik",
    p."Adi",
    p."Durum",
    p."HazirlayanHesapAdi",
    p."HesapAdi",
    p."Olusturulma",
    p."ProjeTip",
    pm."Akis",
    pm."AtananKimlikRef"
   FROM ((public."Proje" p
     JOIN public."UzmanAtama" u ON ((p."Kimlik" = u."ProjeKimlikRef")))
     JOIN public."ProjeAkis" pm ON ((pm."ProjeKimlikRef" = p."Kimlik")));


--
-- Name: UzmanUygunluk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UzmanUygunluk" (
    "Kimlik" uuid NOT NULL,
    "Olusturulma" timestamp without time zone NOT NULL,
    "Olusturan" uuid NOT NULL,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "Durum" integer NOT NULL,
    "ProjeKimlikRef" uuid,
    "Aciklama" character varying,
    "KullaniciKimlikRef" uuid,
    "MusaitlikDurumu" integer
);


--
-- Name: View_ProjeHangiAsamada; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public."View_ProjeHangiAsamada" AS
 SELECT p."Kimlik",
    p."ProjeTip",
    pr."Olusturulma",
    pr."Akis",
    pr."AtananKimlikRef"
   FROM (public."Proje" p
     JOIN public."ProjeAkis" pr ON ((pr."ProjeKimlikRef" = p."Kimlik")))
  ORDER BY pr."Olusturulma" DESC;


--
-- Name: YerGormeDilekce; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."YerGormeDilekce" (
    "Kimlik" uuid NOT NULL,
    "Durum" integer,
    "Olusturulma" timestamp without time zone,
    "Olusturan" uuid,
    "Guncelleme" timestamp without time zone,
    "Guncelleyen" uuid,
    "ProjeKimlikRef" uuid,
    "Dilekce" character varying
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Data for Name: DBAnaModel2; Type: TABLE DATA; Schema: base; Owner: -
--



--
-- Data for Name: AltKurum; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Belge; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."Belge" VALUES ('73458ebe-77f9-479e-bdb8-6871300efc0e', '2023-08-18 16:53:58.735148', 'd61cfe3a-76eb-4569-8751-65620bd260ce', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 'Yeni Metin Belgesi (3).txt', 1);
INSERT INTO public."Belge" VALUES ('386062fd-10e0-4f6f-894b-716d4e7066d8', '2023-08-18 16:54:18.210812', 'c31e5d9d-119f-4b4c-98f8-24813b8e3514', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 'Yeni Metin Belgesi (3).txt', 5);
INSERT INTO public."Belge" VALUES ('4315baa6-5821-4a38-989c-3d86a7fe2765', '2023-08-18 16:54:24.60711', '52cafa3a-50ae-4856-90ad-47a659cec4a2', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 'Yeni Metin Belgesi (3).txt', 6);
INSERT INTO public."Belge" VALUES ('5ecde46a-1e35-4ec6-8f21-b90a4ca6c5d4', '2023-08-18 17:09:55.820905', '6bbba074-4903-492a-9109-8d9fc31ba5ee', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 'Yeni Metin Belgesi (3).txt', 1);
INSERT INTO public."Belge" VALUES ('afaf172a-2b51-4723-8edd-3f995441eca6', '2023-08-18 17:10:02.070406', '08c94cfc-4daa-4790-b3bb-a27df9a941de', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 'Yeni Metin Belgesi (3).txt', 5);
INSERT INTO public."Belge" VALUES ('703bb085-a76e-45af-8eee-5cd04649c6f3', '2023-08-18 17:10:16.372421', 'd912aaf0-3974-4e0f-ad7d-626b7f22ce57', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 'Yeni Metin Belgesi (3).txt', 6);


--
-- Data for Name: BelgeUygunluk; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."BelgeUygunluk" VALUES ('abceafde-54ad-4a61-a52f-59934f35a1a3', '2023-08-18 16:59:34.234691', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '73458ebe-77f9-479e-bdb8-6871300efc0e', 1, 'dfdfdfdf', '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."BelgeUygunluk" VALUES ('350e73a7-517c-4876-9891-0f74333e423a', '2023-08-18 16:59:56.867185', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '386062fd-10e0-4f6f-894b-716d4e7066d8', 1, 'dffddf', '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."BelgeUygunluk" VALUES ('e2e61328-3abe-468c-afa9-ece4367ddee4', '2023-08-18 17:00:06.630033', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '4315baa6-5821-4a38-989c-3d86a7fe2765', 1, 'ddd', '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."BelgeUygunluk" VALUES ('a76d4c94-0898-48b3-b279-def4135e11e4', '2023-08-18 17:02:05.938945', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '73458ebe-77f9-479e-bdb8-6871300efc0e', 1, 'ssdsdds', 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."BelgeUygunluk" VALUES ('35b500ff-7ac9-45f7-8072-a7c8f3434f9b', '2023-08-18 17:02:23.653488', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '386062fd-10e0-4f6f-894b-716d4e7066d8', 1, 'ddfdfd', 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."BelgeUygunluk" VALUES ('3fe0558c-574e-4564-b9b6-8cdec45faede', '2023-08-18 17:02:31.051045', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '4315baa6-5821-4a38-989c-3d86a7fe2765', 1, 'dfdfdfd', 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."BelgeUygunluk" VALUES ('b91713a3-a933-496a-9208-e9500d24724a', '2023-08-18 17:13:23.061411', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '5ecde46a-1e35-4ec6-8f21-b90a4ca6c5d4', 1, 'dssdsd', '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."BelgeUygunluk" VALUES ('5da7a5a9-ff83-42eb-8bac-dfb53f505d70', '2023-08-18 17:13:34.695608', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, 'afaf172a-2b51-4723-8edd-3f995441eca6', 0, 'değillll', '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."BelgeUygunluk" VALUES ('c0175f55-440f-493f-9082-ebdb5fbb7180', '2023-08-18 17:13:49.885074', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '703bb085-a76e-45af-8eee-5cd04649c6f3', 1, 'sdsdsd', '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."BelgeUygunluk" VALUES ('447a66b8-3648-4872-9e8a-6600580b8ee5', '2023-08-18 17:24:44.999626', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '5ecde46a-1e35-4ec6-8f21-b90a4ca6c5d4', 1, 'aaaa', 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."BelgeUygunluk" VALUES ('eec0a9e2-3bc3-4e4f-9505-72895b3b3819', '2023-08-18 17:24:51.592557', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, 'afaf172a-2b51-4723-8edd-3f995441eca6', 1, 'aaaa', 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."BelgeUygunluk" VALUES ('fa367616-81bb-4816-86a1-9cc95097b00a', '2023-08-18 17:25:08.246169', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '703bb085-a76e-45af-8eee-5cd04649c6f3', 1, 'ddd', 'e6921d00-ce37-4791-93ac-5eb67d99f737');


--
-- Data for Name: CevreselVeriFormu; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Gecmis; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Geometri; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Proje; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."Proje" VALUES ('90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', '2023-08-18 16:53:15.492514', '3fbbe160-6d02-408a-83f5-a556efe95841', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', 1, '3fbbe160-6d02-408a-83f5-a556efe95841', '25afde51-1b93-4f80-b9a0-53ea30d43072', 'KapasiteKapasite', 3432432432, 'Proje ÖzetiProje ÖzetiProje ÖzetiProje ÖzetiProje Özeti', 'Proje Adresi', 'Test Yasemin Proje Adı', 'Fatih Şahin', 'İNFOLİNE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', NULL);
INSERT INTO public."Proje" VALUES ('41be752a-90b5-4992-abe4-a61618bc121d', '2023-08-18 17:09:38.691954', '3fbbe160-6d02-408a-83f5-a556efe95841', NULL, NULL, 1, '00000000-0000-0000-0000-000000000000', 1, '3fbbe160-6d02-408a-83f5-a556efe95841', '25afde51-1b93-4f80-b9a0-53ea30d43072', 'Proje Özeti', 433434343, 'Proje ÖzetiProje ÖzetiProje ÖzetiProje ÖzetiProje Özeti', 'MevkiMevkiMevkiMevki', 'ret proje testia', 'Fatih Şahin', 'İNFOLİNE BİLGİ TEKNOLOJİLERİ TİCARET ANONİM ŞİRKETİ', NULL);


--
-- Data for Name: ProjeAkis; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeAkis" VALUES ('1087eefd-a9cc-4e86-86e6-d04476b4d4da', '2023-08-18 16:52:31.454955', '2402051c-d2b7-45ce-9df2-c81fa64fcc68', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 1000, '00000000-0000-0000-0000-000000000000');
INSERT INTO public."ProjeAkis" VALUES ('c8f69e9f-441d-4ea6-a13c-7e94167f5595', '2023-08-18 16:54:39.848003', 'cd31a826-8c9d-4350-855b-020d35285503', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 1100, 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."ProjeAkis" VALUES ('46b84249-9d17-4ec6-b6ce-eafe0a1b6395', '2023-08-18 16:57:47.747724', '15a43ab2-6ca9-4f62-806f-2235178e643a', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 1200, '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."ProjeAkis" VALUES ('bfa3a31a-f1d8-4e46-8162-8bbf2971e679', '2023-08-18 17:00:39.142882', '443025ed-7671-47e7-b61c-5c969026b510', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 1300, '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."ProjeAkis" VALUES ('7e5b1913-6d43-44a4-baef-18a2e471bce9', '2023-08-18 17:02:48.311103', '563bdb01-47a1-44d5-ba15-1c333911919f', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 1400, 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."ProjeAkis" VALUES ('7dd09781-88db-404a-a4a2-d82d5c2289d0', '2023-08-18 17:04:17.249259', '6047c00b-3f10-40fb-b4e6-75f998ee5d22', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 1800, '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."ProjeAkis" VALUES ('acb4e44d-258a-4a83-9f22-edc04a43022f', '2023-08-18 17:08:59.478349', '35f70c5c-031c-437d-ab69-3e18564305d4', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 1000, '00000000-0000-0000-0000-000000000000');
INSERT INTO public."ProjeAkis" VALUES ('69cac290-77fc-4275-bea4-41c023278d6f', '2023-08-18 17:10:31.028729', '173af225-5d91-4fae-8c67-8f52c8ec256c', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 1100, 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."ProjeAkis" VALUES ('b1fd6a3e-8b50-4b9a-b5b3-dee6579c77c7', '2023-08-18 17:11:55.695568', 'b568fe5d-e88d-4e6d-b817-cbd6023e0b48', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 1200, '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."ProjeAkis" VALUES ('d2124459-c5ed-4b0d-8b1b-ae7ad760c68e', '2023-08-18 17:14:45.367289', '5a2b3d75-1d80-4104-9c14-d04c483b71eb', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 1600, '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."ProjeAkis" VALUES ('62769f37-7e31-40d9-af3c-5fba5c1c2977', '2023-08-18 17:18:27.197044', '0cbf4ab2-0fc4-4602-a172-919c08a6f47f', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 1900, '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."ProjeAkis" VALUES ('bbb55e73-e21e-4532-be9b-8b8e36c441ea', '2023-08-18 17:22:29.518017', '03554894-20f3-4622-a585-fbc8c211d601', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 2300, '040824bf-dade-4667-bcc3-dc7fc943ceb8');
INSERT INTO public."ProjeAkis" VALUES ('0b657105-4d06-49c8-b20f-da0b67546095', '2023-08-18 17:25:19.774762', '8a3e96b2-2f7e-40af-ab43-b66eb64ede79', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 2500, 'e6921d00-ce37-4791-93ac-5eb67d99f737');
INSERT INTO public."ProjeAkis" VALUES ('c167e63d-07b4-4cf5-8dc9-04dd8f1b6b9e', '2023-08-18 17:29:11.876138', '61a6ae06-7b9c-410a-bc96-8cecdd836cbb', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 1800, '040824bf-dade-4667-bcc3-dc7fc943ceb8');


--
-- Data for Name: ProjeAkisAtananlar; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeAkisAtananlar" VALUES ('1a5cba38-6cc3-4d58-89e6-aeef21973ab6', '2023-08-18 16:54:36.418869', '0a318f8b-4a3e-4fb9-aa14-92fcdecf4273', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 'e6921d00-ce37-4791-93ac-5eb67d99f737', 8);
INSERT INTO public."ProjeAkisAtananlar" VALUES ('19c8dde5-a49a-4020-9f6e-eb31023f1a0d', '2023-08-18 16:57:50.653509', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', '040824bf-dade-4667-bcc3-dc7fc943ceb8', 9);
INSERT INTO public."ProjeAkisAtananlar" VALUES ('28afd2ca-8ef6-4be8-8ee6-aca6c8ec3fbe', '2023-08-18 17:10:28.824512', 'bedba22c-78bf-4185-b3e2-9a4bd675b331', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 'e6921d00-ce37-4791-93ac-5eb67d99f737', 8);
INSERT INTO public."ProjeAkisAtananlar" VALUES ('972cc729-d50e-45f3-8d77-81fa8eca7721', '2023-08-18 17:11:56.793598', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', '040824bf-dade-4667-bcc3-dc7fc943ceb8', 9);


--
-- Data for Name: ProjeAltSektor; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeAltSektor" VALUES ('77686e20-7879-463f-99f4-c71651b36696', '2023-08-18 16:53:23.235542', '9fcf4ac9-b24f-461a-b68c-607cd523c86c', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', '0aa28167-4a05-4b6b-8a5a-160dc670a236');


--
-- Data for Name: ProjeEksiklikBildirimi; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeEksiklikBildirimi" VALUES ('6e9aeda6-8881-48b6-812c-dde01387e841', '2023-08-18 17:14:43.389468', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '040824bf-dade-4667-bcc3-dc7fc943ceb8', 'eksiklik bildiriyorum', true, '41be752a-90b5-4992-abe4-a61618bc121d');


--
-- Data for Name: ProjeFaaliyetNace; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ProjeKonumIl; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeKonumIl" VALUES ('838ed8c1-4955-4ced-a062-57d5f12fa299', '2023-08-18 16:53:20.055766', 'f6c114dc-d912-4eec-820f-1f5c614e0bc9', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', '201019cd-5f79-49db-9415-ce47e48ffb55');
INSERT INTO public."ProjeKonumIl" VALUES ('c1aa6b03-8758-4db9-a498-d0b7d9d097d8', '2023-08-18 17:09:41.172062', '672c3ba3-0d6b-4695-b5b1-cbf40e1baa66', '2023-08-18 17:17:36.658868', 'ce626f40-5191-4d42-9f17-408c0220cc43', -1, '41be752a-90b5-4992-abe4-a61618bc121d', '201019cd-5f79-49db-9415-ce47e48ffb55');
INSERT INTO public."ProjeKonumIl" VALUES ('76052a32-3d5f-4712-90c7-ba287d637a35', '2023-08-18 17:17:36.659222', 'b06428c9-2fc6-4b80-a027-0410bc1db3bd', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', '201019cd-5f79-49db-9415-ce47e48ffb55');


--
-- Data for Name: ProjeKonumIlce; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeKonumIlce" VALUES ('e858c052-139e-4b5b-91ce-39311b72cbc0', '2023-08-18 16:53:20.055015', 'ac96804f-be81-4573-a975-1800332f7202', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 'bbd7af55-dcd4-4741-b4af-a054f28b870e');
INSERT INTO public."ProjeKonumIlce" VALUES ('89a441e3-c969-4c40-befe-9bf30a2b8261', '2023-08-18 17:09:41.171421', '79a72ba0-5083-4f3c-828a-1c5baa190655', '2023-08-18 17:17:36.656475', 'd6c0108d-d12d-4bd9-a6bb-b949000a174c', -1, '41be752a-90b5-4992-abe4-a61618bc121d', 'd6248b4b-d9a1-4268-a612-fbeac378f55e');
INSERT INTO public."ProjeKonumIlce" VALUES ('47e02144-07ef-4f62-9f8d-833af8b16250', '2023-08-18 17:17:36.65753', 'e5349e9f-6c3c-4943-bdea-ac96dae72d0b', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 'bbd7af55-dcd4-4741-b4af-a054f28b870e');
INSERT INTO public."ProjeKonumIlce" VALUES ('d26c1f15-ec65-4f2e-819a-1a2195285f00', '2023-08-18 17:17:36.658217', '52359535-c4cb-43f7-9ce5-84dd071a9b84', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 'd6248b4b-d9a1-4268-a612-fbeac378f55e');


--
-- Data for Name: ProjeKonumMevki; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeKonumMevki" VALUES ('ba8fb026-54eb-4374-a8f2-3b036a3b197f', '2023-08-18 16:53:20.056361', '7f4af528-d352-4c40-8489-c141cb9eb00c', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 'Mevki');
INSERT INTO public."ProjeKonumMevki" VALUES ('2e05a5ef-088f-49eb-9ef7-fe39bf10809a', '2023-08-18 17:09:41.17259', 'af3587f4-9f47-4bdc-b0e4-a3119a50d02c', '2023-08-18 17:17:36.659857', '59ec7ebe-0e31-4123-b608-386dc1864616', -1, '41be752a-90b5-4992-abe4-a61618bc121d', 'MevkiMevki');
INSERT INTO public."ProjeKonumMevki" VALUES ('583f83bf-89d7-4579-be8e-65163b04418e', '2023-08-18 17:17:36.66134', 'e740add4-c66a-403a-8c84-c49d52d9b2eb', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 'MevkiMevki');


--
-- Data for Name: ProjeMuafiyetBasvuruSonucu; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeMuafiyetBasvuruSonucu" VALUES ('a1472dc1-9674-46e4-9e03-5dde7a21b92a', '2023-08-18 17:04:18.166561', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 1);
INSERT INTO public."ProjeMuafiyetBasvuruSonucu" VALUES ('97700229-802e-49d9-af73-c766cb7b3d67', '2023-08-18 17:29:13.896971', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 0);


--
-- Data for Name: ProjeMuafiyetBasvurusuTip; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeMuafiyetBasvurusuTip" VALUES ('1e5cfbca-cdf8-4e78-90b6-ab2ca75f2d40', '2023-08-18 16:53:16.798679', '3fbbe160-6d02-408a-83f5-a556efe95841', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 1);
INSERT INTO public."ProjeMuafiyetBasvurusuTip" VALUES ('b175dd15-8837-40e1-a776-f260d01f55a1', '2023-08-18 17:09:39.431916', '3fbbe160-6d02-408a-83f5-a556efe95841', NULL, NULL, -1, '41be752a-90b5-4992-abe4-a61618bc121d', 2);
INSERT INTO public."ProjeMuafiyetBasvurusuTip" VALUES ('a767c3a2-d5c9-422f-89da-c1f4c12e7ca0', '2023-08-18 17:17:34.824778', '3fbbe160-6d02-408a-83f5-a556efe95841', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 2);


--
-- Data for Name: ProjePersonel; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ProjeSektor; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."ProjeSektor" VALUES ('5a609913-85dc-4138-a5ed-be0ccf1e2e55', '2023-08-18 16:53:21.761115', '6258c93a-7138-434e-af51-e63478e12723', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', '238688f8-6ed4-4626-aa4c-80efb37dd78e');
INSERT INTO public."ProjeSektor" VALUES ('d39ba13a-3303-4d89-b6bc-3f208a689dc9', '2023-08-18 17:09:42.942644', '16fd6f99-2677-4a3b-8c1e-d561eafc90f6', '2023-08-18 17:17:38.30747', '84711469-9934-439a-99d0-ad05ae24893b', -1, '41be752a-90b5-4992-abe4-a61618bc121d', '238688f8-6ed4-4626-aa4c-80efb37dd78e');
INSERT INTO public."ProjeSektor" VALUES ('dccc27b7-068e-47ad-8b5e-a8192c709b50', '2023-08-18 17:17:39.922358', '98f59c94-c6b1-4881-86a2-bfcbcf0add3f', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', '238688f8-6ed4-4626-aa4c-80efb37dd78e');
INSERT INTO public."ProjeSektor" VALUES ('306bbd26-0da2-4f36-9b73-4c14aca18049', '2023-08-18 17:17:41.819255', 'a2bb2c4d-632e-4b7f-9bef-5b9ee5a7c897', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 'ef5587d2-19e3-453a-8230-fd39af93b5da');


--
-- Data for Name: ProjeTutar; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: Tutar; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: UzmanAtama; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."UzmanAtama" VALUES ('3f3ac4d6-1da5-4dd3-b26d-39bd47310a6c', '2023-08-18 16:57:46.066322', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '90727ece-c0f6-4a8c-8ad0-5f3f74f9807c', 9, '040824bf-dade-4667-bcc3-dc7fc943ceb8', NULL);
INSERT INTO public."UzmanAtama" VALUES ('74e14ec9-7c65-4a1b-995b-bd9f818e6d8e', '2023-08-18 17:11:53.761077', '00000000-0000-0000-0000-000000000000', NULL, NULL, 1, '41be752a-90b5-4992-abe4-a61618bc121d', 9, '040824bf-dade-4667-bcc3-dc7fc943ceb8', NULL);


--
-- Data for Name: UzmanUygunluk; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: YerGormeDilekce; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public."YerGormeDilekce" VALUES ('2c049bb9-5375-4518-8b7f-66bf38410089', 1, '2023-07-25 14:12:49.898634', '80c7159b-9821-4868-8657-19c250bffb71', NULL, NULL, '4236987c-afd5-47bd-ad6c-8c24665559c7', 'dfdfdfdfff');


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: DBAnaModel2 DBAnaModel_pkey; Type: CONSTRAINT; Schema: base; Owner: -
--

ALTER TABLE ONLY base."DBAnaModel2"
    ADD CONSTRAINT "DBAnaModel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltKurum AltKurum_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltKurum"
    ADD CONSTRAINT "AltKurum_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: BelgeUygunluk BelgeUygunluk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BelgeUygunluk"
    ADD CONSTRAINT "BelgeUygunluk_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Belge Belge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Belge"
    ADD CONSTRAINT "Belge_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: CevreselVeriFormu CevreselVeriFormu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreselVeriFormu"
    ADD CONSTRAINT "CevreselVeriFormu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Geometri Geometri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Geometri"
    ADD CONSTRAINT "Geometri_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: ProjeAkisAtananlar ProjeAkısAtananlar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeAkisAtananlar"
    ADD CONSTRAINT "ProjeAkısAtananlar_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeAltSektor ProjeAltSektor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeAltSektor"
    ADD CONSTRAINT "ProjeAltSektor_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeEksiklikBildirimi ProjeEksiklikBildirimi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeEksiklikBildirimi"
    ADD CONSTRAINT "ProjeEksiklikBildirimi_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeFaaliyetNace ProjeFaaliyetNace_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeFaaliyetNace"
    ADD CONSTRAINT "ProjeFaaliyetNace_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeKonumIlce ProjeKonumIlce_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeKonumIlce"
    ADD CONSTRAINT "ProjeKonumIlce_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeKonumMevki ProjeKonumMevki_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeKonumMevki"
    ADD CONSTRAINT "ProjeKonumMevki_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeKonumIl ProjeKonum_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeKonumIl"
    ADD CONSTRAINT "ProjeKonum_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeAkis ProjeMuafityetAkis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeAkis"
    ADD CONSTRAINT "ProjeMuafityetAkis_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeMuafiyetBasvuruSonucu ProjeMuafiyetBasvuruSonucu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeMuafiyetBasvuruSonucu"
    ADD CONSTRAINT "ProjeMuafiyetBasvuruSonucu_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeMuafiyetBasvurusuTip ProjeMuafiyetBasvurusuTip_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeMuafiyetBasvurusuTip"
    ADD CONSTRAINT "ProjeMuafiyetBasvurusuTip_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjePersonel ProjePersonel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjePersonel"
    ADD CONSTRAINT "ProjePersonel_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeSektor ProjeSektor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeSektor"
    ADD CONSTRAINT "ProjeSektor_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: ProjeTutar ProjeTutar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeTutar"
    ADD CONSTRAINT "ProjeTutar_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Proje Proje_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Proje"
    ADD CONSTRAINT "Proje_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: Tutar Tutar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Tutar"
    ADD CONSTRAINT "Tutar_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: UzmanAtama UzmanAtama_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UzmanAtama"
    ADD CONSTRAINT "UzmanAtama_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: UzmanUygunluk UzmanUygunluk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UzmanUygunluk"
    ADD CONSTRAINT "UzmanUygunluk_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: YerGormeDilekce YerGormeDilekce_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."YerGormeDilekce"
    ADD CONSTRAINT "YerGormeDilekce_pkey" PRIMARY KEY ("Kimlik");


--
-- Name: AltKurum AltKurum_AltKurumKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AltKurum"
    ADD CONSTRAINT "AltKurum_AltKurumKimlikRef_fkey" FOREIGN KEY ("AltKurumKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: BelgeUygunluk BelgeUygunluk_BelgeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BelgeUygunluk"
    ADD CONSTRAINT "BelgeUygunluk_BelgeKimlikRef_fkey" FOREIGN KEY ("BelgeKimlikRef") REFERENCES public."Belge"("Kimlik");


--
-- Name: Belge Belge_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Belge"
    ADD CONSTRAINT "Belge_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: CevreselVeriFormu CevreselVeriFormu_ProjeKimlik_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CevreselVeriFormu"
    ADD CONSTRAINT "CevreselVeriFormu_ProjeKimlik_fkey" FOREIGN KEY ("ProjeKimlik") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: Gecmis Gecmis_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Gecmis"
    ADD CONSTRAINT "Gecmis_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik");


--
-- Name: Geometri Geometri_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Geometri"
    ADD CONSTRAINT "Geometri_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik");


--
-- Name: ProjeAkisAtananlar ProjeAkısAtananlar_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeAkisAtananlar"
    ADD CONSTRAINT "ProjeAkısAtananlar_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: ProjeAltSektor ProjeAltSektor_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeAltSektor"
    ADD CONSTRAINT "ProjeAltSektor_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: ProjeEksiklikBildirimi ProjeEksiklikBildirimi_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeEksiklikBildirimi"
    ADD CONSTRAINT "ProjeEksiklikBildirimi_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: ProjeFaaliyetNace ProjeFaaliyetNace_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeFaaliyetNace"
    ADD CONSTRAINT "ProjeFaaliyetNace_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik");


--
-- Name: ProjeKonumIlce ProjeKonumIlce_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeKonumIlce"
    ADD CONSTRAINT "ProjeKonumIlce_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: ProjeKonumMevki ProjeKonumMevki_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeKonumMevki"
    ADD CONSTRAINT "ProjeKonumMevki_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: ProjeKonumIl ProjeKonum_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeKonumIl"
    ADD CONSTRAINT "ProjeKonum_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik");


--
-- Name: ProjeAkis ProjeMuafityetAkis_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeAkis"
    ADD CONSTRAINT "ProjeMuafityetAkis_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: ProjeMuafiyetBasvuruSonucu ProjeMuafiyetBasvuruSonucu_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeMuafiyetBasvuruSonucu"
    ADD CONSTRAINT "ProjeMuafiyetBasvuruSonucu_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: ProjeMuafiyetBasvurusuTip ProjeMuafiyetBasvurusuTip_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeMuafiyetBasvurusuTip"
    ADD CONSTRAINT "ProjeMuafiyetBasvurusuTip_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- Name: ProjePersonel ProjePersonel_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjePersonel"
    ADD CONSTRAINT "ProjePersonel_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik");


--
-- Name: ProjeSektor ProjeSektor_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeSektor"
    ADD CONSTRAINT "ProjeSektor_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik");


--
-- Name: ProjeTutar ProjeTutar_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeTutar"
    ADD CONSTRAINT "ProjeTutar_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik");


--
-- Name: ProjeTutar ProjeTutar_ProjeTutarKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjeTutar"
    ADD CONSTRAINT "ProjeTutar_ProjeTutarKimlikRef_fkey" FOREIGN KEY ("ProjeTutarKimlikRef") REFERENCES public."Tutar"("Kimlik");


--
-- Name: UzmanAtama UzmanAtama_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UzmanAtama"
    ADD CONSTRAINT "UzmanAtama_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik");


--
-- Name: UzmanUygunluk UzmanUygunluk_ProjeKimlikRef_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UzmanUygunluk"
    ADD CONSTRAINT "UzmanUygunluk_ProjeKimlikRef_fkey" FOREIGN KEY ("ProjeKimlikRef") REFERENCES public."Proje"("Kimlik") NOT VALID;


--
-- PostgreSQL database dump complete
--

